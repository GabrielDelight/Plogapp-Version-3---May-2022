-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2022 at 07:22 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `plogapp_new_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `_id` varchar(255) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `firstname` longtext DEFAULT NULL,
  `lastname` longtext DEFAULT NULL,
  `password` longtext DEFAULT NULL,
  `adminAccess` longtext DEFAULT NULL,
  `gender` longtext DEFAULT NULL,
  `email` longtext DEFAULT NULL,
  `secretKey` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `blocked_accouts`
--

CREATE TABLE `blocked_accouts` (
  `id` int(225) NOT NULL,
  `owner_id` mediumtext DEFAULT NULL,
  `blocked_ids` mediumtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `chatnotification`
--

CREATE TABLE `chatnotification` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `ownerName` varchar(255) DEFAULT NULL,
  `receiverName` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `lastChat` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `receiverId` varchar(255) DEFAULT NULL,
  `chatReadColor` varchar(255) DEFAULT 'gray',
  `read` varchar(225) NOT NULL DEFAULT 'none',
  `message_icon` varchar(255) NOT NULL,
  `showCheckIcon` longtext DEFAULT 'none',
  `displayMessageCounter` longtext NOT NULL DEFAULT 'none',
  `unreadLength` longtext NOT NULL,
  `readType` longtext NOT NULL DEFAULT 'unread'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chatnotification`
--

INSERT INTO `chatnotification` (`id`, `_id`, `owner`, `avatar`, `ownerName`, `receiverName`, `message`, `lastChat`, `date`, `receiverId`, `chatReadColor`, `read`, `message_icon`, `showCheckIcon`, `displayMessageCounter`, `unreadLength`, `readType`) VALUES
(535, 'f57c3306f5dfd8e477ed825f', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Plog app', 'Gabriel Delight', 'sds', 'sds', '2022-04-01 13:13:49.949', '3ec1e3144312a90089fb42f2', 'gray', 'none', '', 'none', 'block', '1', 'unread'),
(536, 'b85c56e9357ec7874cdbb23f', '3ec1e3144312a90089fb42f2', 'plogapp-1646904681763.jpeg', 'Gabriel Delight', 'User1 User1', 'sds', 'sds', '2022-04-01 13:13:49.950', 'c2585b15e1bbc09bb86000e8', 'gray', 'none', '', 'block', 'none', '', 'unread'),
(763, 'cd379589a13a5e9aab2bb9d8', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Gabriel Delight', 'terry Leo', 'dfdfdhey', 'dfdfdhey', '2022-04-09 14:39:43.543', 'c2263ca46dce14a49f03674f', 'cornflowerblue', 'none', '', 'none', 'block', '4', 'unread'),
(764, 'eb6c3fb71cc34e6941c9f7a6', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'terry Leo', 'terry Leo', 'dfdfdhey', 'dfdfdhey', '2022-04-09 14:39:43.544', '9627470f246cdb74266641dd', 'gray', 'none', '', 'block', 'none', '', 'read'),
(803, '37d90aa2369e64aa5ce5f97f', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Gabriel Delight', 'User1 User1', '0:6', '0:6', '2022-04-11 18:42:58.127', '3ec1e3144312a90089fb42f2', 'cornflowerblue', 'none', 'fa fa-microphone', 'none', 'block', '6', 'unread'),
(804, '84b4f71291a37fd431628d32', '3ec1e3144312a90089fb42f2', 'plogapp-1646904681763.jpeg', 'User1 User1', 'Gabriel Delight', '0:6', '0:6', '2022-04-11 18:42:58.128', '9627470f246cdb74266641dd', 'gray', 'none', 'fa fa-microphone', 'block', 'none', '', 'read'),
(807, 'bc78ea12d47cefe742909f2e', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Plog app', 'Gabriel Delight', '0:1', '0:1', '2022-04-11 18:51:04.542', '9627470f246cdb74266641dd', 'cornflowerblue', 'none', 'fa fa-microphone', 'none', 'none', '', 'read'),
(808, 'a8b049c8ea7c8dd52e7c8a4c', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Gabriel Delight', 'Plog app', '0:1', '0:1', '2022-04-11 18:51:04.543', 'c2585b15e1bbc09bb86000e8', 'cornflowerblue', 'none', 'fa fa-microphone', 'block', 'none', '', 'read');

-- --------------------------------------------------------

--
-- Table structure for table `chatreceiver`
--

CREATE TABLE `chatreceiver` (
  `_id` varchar(255) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `randomId` longtext NOT NULL,
  `message` longtext DEFAULT NULL,
  `replyOldMessage` longtext DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `buffer` varchar(255) DEFAULT NULL,
  `ref` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `receiverId` varchar(255) DEFAULT NULL,
  `receiverName` varchar(255) DEFAULT NULL,
  `ownerName` varchar(255) DEFAULT NULL,
  `sortChat` varchar(255) DEFAULT NULL,
  `pushChat` varchar(255) DEFAULT NULL,
  `count` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `hide` varchar(255) DEFAULT NULL,
  `hideChatText` varchar(255) DEFAULT NULL,
  `hideOldReply` varchar(255) DEFAULT NULL,
  `hideStory` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `hideVideo` varchar(255) DEFAULT NULL,
  `chatType` varchar(255) DEFAULT NULL,
  `audio` varchar(255) DEFAULT NULL,
  `storyImageUrl` varchar(255) DEFAULT NULL,
  `hideAudio` varchar(255) DEFAULT NULL,
  `hideVoiceNote` longtext NOT NULL,
  `voiceNote` varchar(225) NOT NULL,
  `voiceNoteTime` varchar(225) NOT NULL,
  `chatSenderImage` longtext NOT NULL,
  `chatReceiverImage` longtext NOT NULL,
  `readChatColor` longtext NOT NULL DEFAULT 'gray',
  `showCheckIcon` longtext NOT NULL DEFAULT 'none'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chatreceiver`
--

INSERT INTO `chatreceiver` (`_id`, `id`, `randomId`, `message`, `replyOldMessage`, `date`, `buffer`, `ref`, `owner`, `receiverId`, `receiverName`, `ownerName`, `sortChat`, `pushChat`, `count`, `image`, `hide`, `hideChatText`, `hideOldReply`, `hideStory`, `video`, `hideVideo`, `chatType`, `audio`, `storyImageUrl`, `hideAudio`, `hideVoiceNote`, `voiceNote`, `voiceNoteTime`, `chatSenderImage`, `chatReceiverImage`, `readChatColor`, `showCheckIcon`) VALUES
('2022-04-02 14:36:19.257', 251, '493f7a162a473b2b97896ff9', NULL, NULL, NULL, NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushVideoLeft', NULL, 'plogapp1648906579783.png', 'none', NULL, NULL, 'none', 'plogapp-1648906563086.mp4', 'block', 'video', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-02 14:40:04.401', 252, '42f7b152dc07eeeb565ce1e3', NULL, NULL, NULL, NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushVideoLeft', NULL, 'plogapp1648906805088.png', 'none', NULL, NULL, 'none', 'plogapp-1648906790850.webm', 'block', 'video', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-02 14:47:18.686', 253, '90a174f9580fe1937d8608d7', NULL, NULL, NULL, NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushVideoLeft', NULL, 'plogapp1648907239231.png', 'none', NULL, NULL, 'none', 'plogapp-1648907233120.mp4', 'block', 'video', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-02 14:48:32.542', 254, 'c8b4256d1105fb47139547e1', NULL, NULL, NULL, NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushVideoLeft', NULL, 'plogapp1648907312922.png', 'none', NULL, NULL, 'none', 'plogapp-1648907299550.mp4', 'block', 'video', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-02 14:52:38.781', 255, 'c89bde95be2741144a42e2a9', NULL, NULL, NULL, NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushVideoLeft', NULL, 'plogapp1648907559311.png', 'none', NULL, NULL, 'none', 'plogapp-1648907554706.mp4', 'block', 'video', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-02 15:16:35.029', 256, '053fd981b4100c7cf26fa71f', NULL, NULL, NULL, NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushVideoLeft', NULL, 'plogapp1648908995438.png', 'none', NULL, NULL, 'none', 'plogapp-1648908989994.mp4', 'block', 'video', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-02 15:18:37.625', 257, 'bb4de9935fa7100155596d22', NULL, NULL, NULL, NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushVideoLeft', NULL, 'plogapp1648909118589.png', 'none', NULL, NULL, 'none', 'plogapp-1648909111101.mp4', 'block', 'video', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-02 15:18:57.949', 258, 'cabb82d0647e3ea846fb8265', NULL, NULL, NULL, NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushVideoLeft', NULL, 'plogapp1648909138332.png', 'none', NULL, NULL, 'none', 'plogapp-1648909134645.mp4', 'block', 'video', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-02 19:57:21.742', 259, '4bc765ad8ec1ca3cf1856efa', '', NULL, NULL, NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushImgLeft', NULL, 'plogapp1648925839754.jpeg', 'block', 'none', NULL, 'none', NULL, 'none', 'image', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-04 17:43:40.222', 260, '5d161d944b83efd6d3d65ff6', 'Hello ', '', '4/4/22', NULL, NULL, '9627470f246cdb74266641dd', '3ec1e3144312a90089fb42f2', 'User1 User1', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-04 17:43:58.917', 261, 'b8758fac4a511f5815f82bc9', NULL, NULL, '2022-04-04 17:43:58.916', NULL, NULL, '9627470f246cdb74266641dd', '3ec1e3144312a90089fb42f2', 'User1 User1', 'Gabriel Delight', NULL, 'pushAudioLeft', NULL, NULL, 'none', NULL, NULL, 'none', NULL, 'none', 'voiceNote', NULL, NULL, 'none', 'block', 'plogapp-1649090635767', '0:2', 'plogapp-1646131942816.jpeg', 'plogapp-1646904681763.jpeg', 'gray', 'none'),
('2022-04-04 17:47:42.158', 262, '4d50f3cea64b0042158ee699', 'Hii', '', '4/4/22', NULL, NULL, '9627470f246cdb74266641dd', '3ec1e3144312a90089fb42f2', 'User1 User1', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-04 17:47:51.449', 263, '9175a8640d36b5504ecfa8a1', 'Hoo', '', '4/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2263ca46dce14a49f03674f', 'User1 User1', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-04 17:47:57.637', 264, '4212ce2d78812a2df0b74008', 'Yey', '', '4/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'User1 User1', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-04 17:48:04.780', 265, 'f841579ba2af8fadb32cd85b', 'hello ', '', '4/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-04 17:48:11.845', 266, '2758dfd51cd0ea071e7eaea1', 'Welcome to plogapp ', '', '4/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-04 17:48:41.609', 267, '17e3cc239319139d0ba9786c', '', NULL, NULL, NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushImgLeft', NULL, 'plogapp1649090916520.jpeg', 'block', 'none', NULL, 'none', NULL, 'none', 'image', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-05 14:18:20.802', 268, 'fac29908684b7cd238e7063f', 'sds', '', '5/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-05 14:18:23.600', 269, 'bf4d0f9f112a66c05c62bc14', 'sdd', '', '5/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-05 14:20:13.214', 270, '58dc6ad1373d840bc0e4fa69', 'Hello \nworld how are you\n\ndoing&gt;', '', '5/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-05 14:20:22.890', 271, 'c953e707d83be5438f3b9f49', 'sdsdsds\n\n\nsd\nsd\ns\nds\nds\nds\nds\nds\nds\nds\nds\n', '', '5/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-05 14:22:44.030', 272, '773e39f10bc4623826e6a991', 'hey what are yyou talking about hub??\nDO you know mw #vex', '', '5/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 06:57:05.159', 273, 'efa8d4857fd29718ef246a6d', 'yo', '', '9/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 08:41:36.420', 274, '7e6423d57370862a311ddf59', 'hello', '', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2263ca46dce14a49f03674f', 'terry Leo', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 10:18:47.881', 275, 'b8667c13e4f394e0197515a3', 'dfdf', '', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2263ca46dce14a49f03674f', 'terry Leo', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 14:31:35.302', 276, '63bbe7b552765f4b7cdd1c58', 'Don\'t tell people your failure they will always see you as a failure and never give your opportunity  \n\nDon\'t tell people you next big move, move in silence, take action and shock them with your results', 'hey what are yyou talking about hub??DO you know mw #vex', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'User1 User1', 'Gabriel Delight', NULL, 'replyPushLeft', '1', NULL, 'none', NULL, 'block', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 14:32:13.526', 277, 'f786d97b9c6406e7f0554ce5', 'Don\'t tell people your failure they will always see you as a failure and never give your opportunity  \n\nDon\'t tell people you next big move, move in silence, take action and shock them with your results', 'hey what are yyou talking about hub??DO you know mw #vex', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'User1 User1', 'Gabriel Delight', NULL, 'replyPushLeft', '1', NULL, 'none', NULL, 'block', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 14:39:43.262', 278, '8fef64a8767f16758816095a', 'dfdfdhey', '', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2263ca46dce14a49f03674f', 'terry Leo', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 14:40:33.739', 279, 'ef0c426452c0c4d5b68067a2', 'Hope you love the app', '', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'terry Leo', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 16:28:16.931', 280, '22c9eef2ef464b5b41064a76', 'xcxcxcx\n', '', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 19:33:20.644', 281, '6085009c119ebc7e0ba8208c', 'Afar', '', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 19:45:11.714', 282, '3732c2d12c8fe0c8dc659c68', 'boy', '', '9/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 19:45:52.432', 283, '7c46524b72702b8fa889ae23', 'Check if the chat smooth ', '', '9/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 19:47:23.645', 284, '23ee1dc8298b6f16b09ca3be', 'How is Ur day going bro ????⚰️ ', '', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 19:47:36.655', 285, 'e59fa1fe5d4bfc6bbe70e46c', 'Lol fine', '', '9/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 19:47:46.005', 286, '52fc9a8130830474c3274324', 'But check wether e smooth', '', '9/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 19:48:15.657', 287, '4d2fb3a85576c1ffb87df1a5', 'Lucky u bro ', '', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 19:48:27.597', 288, '7123e39270404b370b9485ff', 'Thanks man', '', '9/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 19:48:47.618', 289, 'be6ee2289aaf92eea4df9fe8', 'With Ur eye glass when make u look like Mike Zuckerberg', '', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 19:49:06.412', 290, 'd353a6a46aef4091fde4b8e3', 'Lol me nah mark', '', '9/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 19:49:30.820', 291, '511a0ff56e8e87a494be12b8', 'Yea bro ', 'Lol me nah mark', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'replyPushLeft', '1', NULL, 'none', NULL, 'block', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-09 19:49:43.215', 292, 'cfe244952ce7280ec5d80a9c', 'Hehe', 'How is Ur day going bro ????⚰️ ', '9/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'replyPushLeft', '1', NULL, 'none', NULL, 'block', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-11 13:46:36.194', 293, 'd2f405f65454feb62031eefb', 'Hello world how are you doing today', '', '11/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushLeft', '1', NULL, 'none', NULL, 'none', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-11 18:01:13.369', 294, '477d9ca69db36567aa0a29d1', 'hey', 'Hello world how are youdoing>', '11/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'replyPushLeft', '1', NULL, 'none', NULL, 'block', 'none', NULL, 'none', 'text', NULL, NULL, 'none', 'none', '', '', '', '', 'gray', 'none'),
('2022-04-11 18:30:51.864', 295, '70917bde10380cb8f708027d', NULL, NULL, '2022-04-11 18:30:51.860', NULL, NULL, '9627470f246cdb74266641dd', '3ec1e3144312a90089fb42f2', 'User1 User1', 'Gabriel Delight', NULL, 'pushAudioLeft', NULL, NULL, 'none', NULL, NULL, 'none', NULL, 'none', 'voiceNote', NULL, NULL, 'none', 'block', 'plogapp-1649698249174', '0:2', 'plogapp-1646131942816.jpeg', 'plogapp-1646904681763.jpeg', 'gray', 'none'),
('2022-04-11 18:32:45.482', 296, '09a4914d8182e4f96316ac86', NULL, NULL, '2022-04-11 18:32:45.478', NULL, NULL, '9627470f246cdb74266641dd', '3ec1e3144312a90089fb42f2', 'User1 User1', 'Gabriel Delight', NULL, 'pushAudioLeft', NULL, NULL, 'none', NULL, NULL, 'none', NULL, 'none', 'voiceNote', NULL, NULL, 'none', 'block', 'plogapp-1649698363369', '0:1', 'plogapp-1646131942816.jpeg', 'plogapp-1646904681763.jpeg', 'gray', 'none'),
('2022-04-11 18:32:51.597', 297, 'b737f33afce5b9f8aedb435c', NULL, NULL, '2022-04-11 18:32:51.596', NULL, NULL, '9627470f246cdb74266641dd', '3ec1e3144312a90089fb42f2', 'User1 User1', 'Gabriel Delight', NULL, 'pushAudioLeft', NULL, NULL, 'none', NULL, NULL, 'none', NULL, 'none', 'voiceNote', NULL, NULL, 'none', 'block', 'plogapp-1649698370427', '0:1', 'plogapp-1646131942816.jpeg', 'plogapp-1646904681763.jpeg', 'gray', 'none'),
('2022-04-11 18:42:57.618', 298, 'd4ecc3c7b6322f88fc846416', NULL, NULL, '2022-04-11 18:42:57.614', NULL, NULL, '9627470f246cdb74266641dd', '3ec1e3144312a90089fb42f2', 'User1 User1', 'Gabriel Delight', NULL, 'pushAudioLeft', NULL, NULL, 'none', NULL, NULL, 'none', NULL, 'none', 'voiceNote', NULL, NULL, 'none', 'block', 'plogapp-1649698976039', '0:6', 'plogapp-1646131942816.jpeg', 'plogapp-1646904681763.jpeg', 'gray', 'none'),
('2022-04-11 18:47:54.852', 299, '6611f4ddadf10fc50423b200', NULL, NULL, '2022-04-11 18:47:54.847', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushAudioLeft', NULL, NULL, 'none', NULL, NULL, 'none', NULL, 'none', 'voiceNote', NULL, NULL, 'none', 'block', 'plogapp-1649699273024', '0:3', 'plogapp-1646131942816.jpeg', 'plogapp-1646132550991.jpeg', 'gray', 'none');

-- --------------------------------------------------------

--
-- Table structure for table `chatsender`
--

CREATE TABLE `chatsender` (
  `_id` varchar(255) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `randomId` longtext NOT NULL,
  `message` longtext DEFAULT NULL,
  `replyOldMessage` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `buffer` varchar(255) DEFAULT NULL,
  `ref` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `receiverId` varchar(255) DEFAULT NULL,
  `receiverName` varchar(255) DEFAULT NULL,
  `ownerName` varchar(255) DEFAULT NULL,
  `sortChat` varchar(255) DEFAULT NULL,
  `pushChat` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `hide` varchar(255) DEFAULT NULL,
  `hideChatText` varchar(255) DEFAULT NULL,
  `hideOldReply` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `hideVideo` varchar(255) DEFAULT NULL,
  `hideStory` varchar(255) DEFAULT NULL,
  `chatType` varchar(255) DEFAULT NULL,
  `audio` varchar(255) DEFAULT NULL,
  `storyImageUrl` varchar(255) DEFAULT NULL,
  `hideAudio` varchar(255) DEFAULT NULL,
  `hideVoiceNote` longtext NOT NULL,
  `storyImage` varchar(255) DEFAULT NULL,
  `voiceNote` varchar(225) NOT NULL,
  `voiceNoteTime` varchar(225) NOT NULL,
  `chatSenderImage` longtext NOT NULL,
  `chatReceiverImage` longtext NOT NULL,
  `readChatColor` longtext NOT NULL DEFAULT 'gray',
  `showCheckIcon` longtext DEFAULT 'none'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chatsender`
--

INSERT INTO `chatsender` (`_id`, `id`, `randomId`, `message`, `replyOldMessage`, `date`, `buffer`, `ref`, `owner`, `receiverId`, `receiverName`, `ownerName`, `sortChat`, `pushChat`, `image`, `hide`, `hideChatText`, `hideOldReply`, `video`, `hideVideo`, `hideStory`, `chatType`, `audio`, `storyImageUrl`, `hideAudio`, `hideVoiceNote`, `storyImage`, `voiceNote`, `voiceNoteTime`, `chatSenderImage`, `chatReceiverImage`, `readChatColor`, `showCheckIcon`) VALUES
('2022-04-02 19:57:21.667', 260, '25189273b5941395d74fd5ed', '', NULL, NULL, NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushImgRight', 'plogapp1648925839754.jpeg', 'block', 'none', NULL, NULL, 'none', 'none', 'image', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-04 17:43:40.341', 261, 'dc5be9d74d3f338050370d7f', 'Hello ', '', '4/4/22', NULL, NULL, '9627470f246cdb74266641dd', '3ec1e3144312a90089fb42f2', 'User1 User1', 'Gabriel Delight', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'gray', 'none'),
('2022-04-04 17:47:42.331', 263, '16c583577871d5048f7da0bb', 'Hii', '', '4/4/22', NULL, NULL, '9627470f246cdb74266641dd', '3ec1e3144312a90089fb42f2', 'User1 User1', 'Gabriel Delight', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'gray', 'none'),
('2022-04-04 17:47:51.540', 264, '5b358690b1d23b2082e2711e', 'Hoo', '', '4/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2263ca46dce14a49f03674f', 'User1 User1', 'Gabriel Delight', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'gray', 'none'),
('2022-04-04 17:47:57.803', 265, 'a988db3b4a12db9bee5fc0de', 'Yey', '', '4/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'User1 User1', 'Gabriel Delight', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-04 17:48:04.959', 266, '923719771eab980bbb7e44ed', 'hello ', '', '4/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-04 17:48:11.940', 267, 'c9bd25a1c43a54d398954d23', 'Welcome to plogapp ', '', '4/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-04 17:48:41.608', 268, 'b7fe3bf774701c9e5e655b8a', '', NULL, NULL, NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushImgRight', 'plogapp1649090916520.jpeg', 'block', 'none', NULL, NULL, 'none', 'none', 'image', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-05 14:18:20.875', 269, '4efd83273530794cdb84670c', 'sds', '', '5/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-05 14:18:23.642', 270, '6deed0baef0ede210f0b924d', 'sdd', '', '5/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-05 14:20:13.450', 271, 'eebb5253b5fedd0c4b100086', 'Hello \nworld how are you\n\ndoing&gt;', '', '5/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-05 14:22:44.390', 273, 'd0fd86cb1fd868af1dc51acb', 'hey what are yyou talking about hub??\nDO you know mw #vex', '', '5/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-09 06:57:05.342', 274, '3ef598d4f032bc8273d7b737', 'yo', '', '9/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-09 08:41:36.573', 275, '7ba9498f18d32cdd8f88c363', 'hello', '', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2263ca46dce14a49f03674f', 'terry Leo', 'Gabriel Delight', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'gray', 'none'),
('2022-04-09 10:18:48.132', 276, 'ad512bc3829d92480099fafc', 'dfdf', '', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2263ca46dce14a49f03674f', 'terry Leo', 'Gabriel Delight', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'gray', 'none'),
('2022-04-09 14:32:13.649', 278, 'bd1d8f26194aa0aaac10299c', 'Don\'t tell people your failure they will always see you as a failure and never give your opportunity  \n\nDon\'t tell people you next big move, move in silence, take action and shock them with your results', 'hey what are yyou talking about hub??DO you know mw #vex', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'User1 User1', 'Gabriel Delight', NULL, 'replyPushRight', NULL, 'none', NULL, 'block', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-09 14:39:43.323', 279, '6ce185cd0522c9e5865c4133', 'dfdfdhey', '', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2263ca46dce14a49f03674f', 'terry Leo', 'Gabriel Delight', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'gray', 'none'),
('2022-04-09 14:40:33.775', 280, 'dd6c343a8a8e1eda3dd0012b', 'Hope you love the app', '', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'terry Leo', 'Gabriel Delight', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-09 16:28:17.701', 281, '78c04f9ba97946410ade0a4a', 'xcxcxcx\n', '', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-09 19:45:11.847', 283, '3c7ef2c0e898d1d551d7b892', 'boy', '', '9/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-09 19:45:52.536', 284, 'deb45d9f9054ba155e38b297', 'Check if the chat smooth ', '', '9/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-09 19:47:24.119', 285, 'de5d29044d9935c0e72abff8', 'How is Ur day going bro ????⚰️ ', '', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-09 19:47:36.775', 286, 'e04fb017956407e5adfce26c', 'Lol fine', '', '9/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-09 19:47:46.157', 287, '3c0dd1ad12687737dff10985', 'But check wether e smooth', '', '9/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-09 19:48:27.720', 289, 'dc857ebbe8d54791f6cdc0b2', 'Thanks man', '', '9/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-09 19:48:47.738', 290, 'acc0e4beb8a26247c8d56245', 'With Ur eye glass when make u look like Mike Zuckerberg', '', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-09 19:49:06.536', 291, '63a1dff5015bd63ec8619578', 'Lol me nah mark', '', '9/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushRight', NULL, 'none', NULL, 'none', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-09 19:49:31.018', 292, '4db02f45b6e78308c4d3f4f4', 'Yea bro ', 'Lol me nah mark', '9/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'replyPushRight', NULL, 'none', NULL, 'block', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-09 19:49:43.415', 293, 'b93f24c350597504461444ed', 'Hehe', 'How is Ur day going bro ????⚰️ ', '9/4/22', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'replyPushRight', NULL, 'none', NULL, 'block', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-11 18:01:13.469', 295, 'f6ad4445f96ebae7f413a699', 'hey', 'Hello world how are youdoing>', '11/4/22', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'replyPushRight', NULL, 'none', NULL, 'block', NULL, 'none', 'none', 'text', NULL, NULL, 'none', 'none', NULL, '', '', '', '', 'cornflowerblue', 'none'),
('2022-04-11 18:30:51.860', 296, '3c74c16dce62af015babe8d9', NULL, NULL, '2022-04-11 18:30:51.860', NULL, NULL, '9627470f246cdb74266641dd', '3ec1e3144312a90089fb42f2', 'User1 User1', 'Gabriel Delight', NULL, 'pushAudioRight', NULL, 'none', NULL, NULL, NULL, 'none', 'none', 'voiceNote', NULL, NULL, 'none', 'block', NULL, 'plogapp-1649698249174', '0:2', 'plogapp-1646131942816.jpeg', 'plogapp-1646904681763.jpeg', 'gray', 'none'),
('2022-04-11 18:32:45.479', 297, 'f4c9d7ee34e780c928d6d8ef', NULL, NULL, '2022-04-11 18:32:45.478', NULL, NULL, '9627470f246cdb74266641dd', '3ec1e3144312a90089fb42f2', 'User1 User1', 'Gabriel Delight', NULL, 'pushAudioRight', NULL, 'none', NULL, NULL, NULL, 'none', 'none', 'voiceNote', NULL, NULL, 'none', 'block', NULL, 'plogapp-1649698363369', '0:1', 'plogapp-1646131942816.jpeg', 'plogapp-1646904681763.jpeg', 'gray', 'none'),
('2022-04-11 18:32:51.596', 298, 'a33c55115feed87a49ad3dfc', NULL, NULL, '2022-04-11 18:32:51.596', NULL, NULL, '9627470f246cdb74266641dd', '3ec1e3144312a90089fb42f2', 'User1 User1', 'Gabriel Delight', NULL, 'pushAudioRight', NULL, 'none', NULL, NULL, NULL, 'none', 'none', 'voiceNote', NULL, NULL, 'none', 'block', NULL, 'plogapp-1649698370427', '0:1', 'plogapp-1646131942816.jpeg', 'plogapp-1646904681763.jpeg', 'gray', 'none'),
('2022-04-11 18:42:57.615', 299, 'ba3b165d24b16307c8b9bd1b', NULL, NULL, '2022-04-11 18:42:57.614', NULL, NULL, '9627470f246cdb74266641dd', '3ec1e3144312a90089fb42f2', 'User1 User1', 'Gabriel Delight', NULL, 'pushAudioRight', NULL, 'none', NULL, NULL, NULL, 'none', 'none', 'voiceNote', NULL, NULL, 'none', 'block', NULL, 'plogapp-1649698976039', '0:6', 'plogapp-1646131942816.jpeg', 'plogapp-1646904681763.jpeg', 'gray', 'none'),
('2022-04-11 18:47:54.848', 300, 'cb98896587b1c395437e53ce', NULL, NULL, '2022-04-11 18:47:54.847', NULL, NULL, '9627470f246cdb74266641dd', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'Gabriel Delight', NULL, 'pushAudioRight', NULL, 'none', NULL, NULL, NULL, 'none', 'none', 'voiceNote', NULL, NULL, 'none', 'block', NULL, 'plogapp-1649699273024', '0:3', 'plogapp-1646131942816.jpeg', 'plogapp-1646132550991.jpeg', 'cornflowerblue', 'none'),
('2022-04-11 18:51:04.245', 301, '16a38c89d8587dc250f24351', NULL, NULL, '2022-04-11 18:51:04.245', NULL, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', 'Gabriel Delight', 'Plog app', NULL, 'pushAudioRight', NULL, 'none', NULL, NULL, NULL, 'none', 'none', 'voiceNote', NULL, NULL, 'none', 'block', NULL, 'plogapp-1649699462865', '0:1', 'plogapp-1646132550991.jpeg', 'plogapp-1646131942816.jpeg', 'cornflowerblue', 'none');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) DEFAULT NULL,
  `comment` longtext DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `commentorNickName` varchar(255) DEFAULT NULL,
  `postId` varchar(255) DEFAULT NULL,
  `hideImage` varchar(255) DEFAULT NULL,
  `replylength` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `reaction` varchar(255) NOT NULL,
  `verified` varchar(255) DEFAULT NULL,
  `lastPostOwnerId` varchar(255) DEFAULT NULL,
  `lastReplyName` varchar(255) DEFAULT NULL,
  `lastReplyText` varchar(255) DEFAULT NULL,
  `lastReplyAvatar` varchar(255) DEFAULT NULL,
  `lastReplyVerified` longtext NOT NULL,
  `hideReply` varchar(255) DEFAULT NULL,
  `isDisabled` varchar(255) DEFAULT NULL,
  `reactionLength` int(11) NOT NULL,
  `post_url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `_id`, `comment`, `avatar`, `date`, `owner`, `fullName`, `commentorNickName`, `postId`, `hideImage`, `replylength`, `image`, `reaction`, `verified`, `lastPostOwnerId`, `lastReplyName`, `lastReplyText`, `lastReplyAvatar`, `lastReplyVerified`, `hideReply`, `isDisabled`, `reactionLength`, `post_url`) VALUES
(1, '7a97a8dac719e370e8334687', 'Hahahahaha', 'plogapp-1646131942816.jpeg', ' 1 MAR,  2022 at 1:01:23 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', '748e7b816d660b6c2ac69802', 'none', '1', NULL, '', NULL, '3ec1e3144312a90089fb42f2', 'User1 User1', 'Awesome nrother', 'plogapp-1646499448053.jpg', 'null', 'block', NULL, 0, ''),
(2, '51452a295e1828ad90ddc141', 'I love this aoo brahhh', 'plogapp-1646131942816.jpeg', ' 2 MAR,  2022 at 10:18:27 AM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', 'c23bcab0c4ac46ce29b84149', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, ''),
(3, '5c727d7168e51c49d6262f4c', 'One of the best ', 'plogapp-1646131942816.jpeg', ' 2 MAR,  2022 at 10:18:38 AM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', '194b31fbbb17f3d51884027f', 'none', '6', NULL, '', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', 'hello', 'plogapp-1646131942816.jpeg', 'null', 'block', NULL, 0, ''),
(4, '5abaa4b0dd1439af3d3cbec9', 'Hello ', 'plogapp-1646131942816.jpeg', ' 2 MAR,  2022 at 10:28:12 AM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', 'c23bcab0c4ac46ce29b84149', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(5, 'e517deceadc45f82996eff13', 'Cool vide I love it', 'plogapp-1646131942816.jpeg', ' 2 MAR,  2022 at 12:29:15 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', '748e7b816d660b6c2ac69802', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewVideoPostDetails/'),
(6, '9f64583b07669d4f050af99c', 'Cool video', 'plogapp-1646131942816.jpeg', ' 3 MAR,  2022', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', 'eb841e24f21b557bec628a23', 'none', '', NULL, '1', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, ''),
(7, 'ebf62bc1fe427ba540f223d9', 'Col', 'plogapp-1646131942816.jpeg', ' 3 MAR,  2022', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', 'eb841e24f21b557bec628a23', 'none', '', NULL, '1', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, 'sharedLinkVideo/'),
(8, 'da6760794fdf4cadeafd9d9c', 'I love the movie', 'plogapp-1646131942816.jpeg', ' 2 MAR,  2022 at 3:59:02 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', '92f0b824570cf1caf78c0d0a', 'none', '', NULL, '1', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, 'viewVideoPostDetails/'),
(9, '3ac30a1dc5b91c1977800f16', 'dfdf', 'plogapp-1646904681763.jpeg', ' 6 MAR,  2022 at 3:10:42 PM', '3ec1e3144312a90089fb42f2', 'User1 User1', 'user_test', '573d2e4679e86dd347ff3c95', 'none', '3', NULL, '3', NULL, '3ec1e3144312a90089fb42f2', 'User1 User1', 'Cool', 'plogapp-1646499448053.jpg', 'null', 'block', NULL, 1, 'viewImagePostDetails/'),
(10, '3f77a27888c38578dd8b9042', 'tree', 'plogapp-1646904681763.jpeg', ' 6 MAR,  2022 at 3:11:25 PM', '3ec1e3144312a90089fb42f2', 'User1 User1', 'user_test', '573d2e4679e86dd347ff3c95', 'none', '10', NULL, '3', NULL, '3ec1e3144312a90089fb42f2', 'User1 User1', '10', 'plogapp-1646499448053.jpg', 'null', 'block', NULL, 1, 'viewImagePostDetails/'),
(11, '27a2eb5a5b957cc76c51556c', 'hellp', 'plogapp-1646904681763.jpeg', ' 6 MAR,  2022 at 3:17:23 PM', '3ec1e3144312a90089fb42f2', 'User1 User1', 'user_test', '573d2e4679e86dd347ff3c95', 'none', '', NULL, '3', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, 'viewImagePostDetails/'),
(12, 'b0d03f34f42616f34fc2d3b5', 'I love the app', 'plogapp-1646904681763.jpeg', ' 6 MAR,  2022 at 4:41:38 PM', '3ec1e3144312a90089fb42f2', 'User1 User1', 'user_test', '92f0b824570cf1caf78c0d0a', 'none', '9', NULL, '', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', 'Good God', 'plogapp-1646131942816.jpeg', 'null', 'block', NULL, 0, 'viewVideoPostDetails/'),
(13, '19c0258fcce1a927f10dab23', 'I love this app', 'plogapp-1646131942816.jpeg', ' 8 MAR,  2022 at 9:02:47 AM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '194b31fbbb17f3d51884027f', 'none', '', NULL, '1', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, 'viewImagePostDetails/'),
(14, '8c352dedabeb3a76dc94f746', '✌️✌️', 'plogapp-1646904681763.jpeg', ' 8 MAR,  2022 at 9:06:21 AM', '3ec1e3144312a90089fb42f2', 'User1 User1', 'user_test', 'cfc10cde03c60596d53f0b84', 'none', '', NULL, '1', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, 'viewImagePostDetails/'),
(15, '171d972376de476ed224ccf5', '✌️✌️✌️tree', 'plogapp-1646904681763.jpeg', ' 8 MAR,  2022 at 9:06:40 AM', '3ec1e3144312a90089fb42f2', 'User1 User1', 'user_test', 'cfc10cde03c60596d53f0b84', 'none', '', NULL, '1', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, 'viewImagePostDetails/'),
(16, 'ca0a481fe7fe0ce2b143e622', 'We all love the app', 'plogapp-1646904681763.jpeg', ' 10 MAR,  2022 at 2:09:13 PM', '3ec1e3144312a90089fb42f2', 'User1 User1', 'user_test', '82d68e5192831276429f42f4', 'none', '2', NULL, '3', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', 'tree', 'plogapp-1646131942816.jpeg', 'null', 'block', NULL, 1, 'viewImagePostDetails/'),
(17, '75440a2da362f3826578c34a', 'nice app', 'plogapp-1646904681763.jpeg', ' 10 MAR,  2022 at 2:09:27 PM', '3ec1e3144312a90089fb42f2', 'User1 User1', 'user_test', '82d68e5192831276429f42f4', 'none', '', NULL, '3', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, 'viewImagePostDetails/'),
(18, 'cc3224776093427dc20a2e3a', 'Awesome ', 'plogapp-1646131942816.jpeg', ' 5 MAR,  2022', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '0696354db7e2c6be85bbedd3', 'none', '3', NULL, '1', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', 'hello', 'plogapp-1646131942816.jpeg', 'null', 'block', NULL, 1, 'shareLink/'),
(19, '2a8822aae2b1226791c94ff9', 'Lovely', 'plogapp-1646131942816.jpeg', ' 5 MAR,  2022', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '0696354db7e2c6be85bbedd3', 'none', '1', NULL, '1', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', 'hope you love it ', 'plogapp-1646131942816.jpeg', 'null', 'block', NULL, 1, 'shareLink/'),
(20, '73552aea9e17827c6318c972', 'hello', 'plogapp-1646131942816.jpeg', ' 12 MAR,  2022 at 10:13:00 AM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '8a07c8e04267d22e5ea7626c', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(21, '11018db623346155398cf13d', '', 'plogapp-1646131942816.jpeg', ' 12 MAR,  2022 at 10:13:27 AM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '8a07c8e04267d22e5ea7626c', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(22, '3badae8a07817892296c6940', 'g', 'plogapp-1646131942816.jpeg', ' 12 MAR,  2022 at 10:16:15 AM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '8a07c8e04267d22e5ea7626c', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(23, '25a43b76134202aba482da16', '', 'plogapp-1646131942816.jpeg', ' 12 MAR,  2022 at 10:16:37 AM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '8a07c8e04267d22e5ea7626c', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(24, '1324bac45fb70ce12817f0d5', 'tree', 'plogapp-1646131942816.jpeg', ' 12 MAR,  2022 at 10:23:13 AM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '8a07c8e04267d22e5ea7626c', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(25, '4178683e9d838b53dd141af4', 'Hello wolrd', 'plogapp-1646131942816.jpeg', ' 12 MAR,  2022 at 10:28:46 AM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '8a07c8e04267d22e5ea7626c', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(26, '74b38d3ab553bd56d589ad66', 'I love t video', 'plogapp-1646131942816.jpeg', ' 12 MAR,  2022 at 10:29:36 AM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '748e7b816d660b6c2ac69802', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewVideoPostDetails/'),
(27, 'b441961eda9fa737b636a66c', 'I love t ????????????????????????', 'plogapp-1646131942816.jpeg', ' 12 MAR,  2022 at 10:30:28 AM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '748e7b816d660b6c2ac69802', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewVideoPostDetails/'),
(28, 'e0ce136872842e455034e390', '<script>alert(\'hello\')</script>', 'plogapp-1646131942816.jpeg', ' 6 MAR,  2022', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'c3e590c6cb9df8b339fbbad4', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'shareLink/'),
(29, '1346bf24b3e20c07657ca2b1', 'tree', 'plogapp-1646131942816.jpeg', ' 6 MAR,  2022', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'c3e590c6cb9df8b339fbbad4', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'shareLink/'),
(30, '43df43f828c197281632148c', '                   ', 'plogapp-1646131942816.jpeg', ' 6 MAR,  2022', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'c3e590c6cb9df8b339fbbad4', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'shareLink/'),
(31, '7cafc84ddd57a53e6164e024', '                         ', 'plogapp-1646131942816.jpeg', ' 6 MAR,  2022', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'c3e590c6cb9df8b339fbbad4', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'shareLink/'),
(32, '10982b19fb52a359c24c64da', 'I love this okay ', 'plogapp-1647097667791.jpg', ' 14 MAR,  2022 at 1:03:04 PM', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', '3fc4c1f246251b6fa64a0bb5', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(33, '7bf9633b77cf0e9d422ce936', 'COol', 'plogapp-1647097667791.jpg', '2022-3-14T1:05:16 ', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', '3fc4c1f246251b6fa64a0bb5', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(34, '341ca111f888e63b83939847', 'Aha awesome', 'plogapp-1647097667791.jpg', '2022-3-14T17:31:30:39', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '4', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, 'viewImagePostDetails/'),
(35, 'a190010fece3a937269fb0f8', 'tree', 'plogapp-1647097667791.jpg', 'a few seconds ago', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(36, '3d6a32345d77cccba61212d1', 'hello', 'plogapp-1647097667791.jpg', '2022-3-14T17:36:27:279', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(37, 'f953509efbf60ea258a71901', 'jee', 'plogapp-1647097667791.jpg', '2022-3-14T17:36:27:279', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(38, '5e15764989f3c86ea27cd130', 'hafa', 'plogapp-1647097667791.jpg', '2022-3-14T17:37:12:152', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(39, 'e0d11acb9d64f4e624876103', 'tree', 'plogapp-1647097667791.jpg', '2022-3-14T17:37:12:152', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(40, '473a1f3e68f8e0b31d8efbca', 'hafa', 'plogapp-1647097667791.jpg', '2022-3-14T17:38:55:720', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(41, 'dee77c3dee68d843172b2ba8', 'see', 'plogapp-1647097667791.jpg', '2022-3-14T17:39:22:997', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(42, 'c30876b081ebf1b3599e5111', 'tree', 'plogapp-1647097667791.jpg', '2022-3-14T17:40:13:527', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(43, 'abfa677736ddd2a5ebc62f70', 'xr', 'plogapp-1647097667791.jpg', '2022-3-14T17:40:13:527', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(44, '1e035e652bf51be465cd33cc', 'hod', 'plogapp-1647097667791.jpg', '2022-3-14T17:40:13:527', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(45, '391a3b94dc86d1d913f04847', 'helo', 'plogapp-1647097667791.jpg', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(46, 'ebc600dd63279ad1bea104f6', 'sample', 'plogapp-1647097667791.jpg', '2022-3-14T17:42:16:861', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(47, 'c859cb65d660e5b573754bac', 'treeboy', 'plogapp-1647097667791.jpg', '2022-3-14T17:42:16:861', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(48, '2861c3607262691a59b0951d', 'sasa', 'plogapp-1647097667791.jpg', '2022-3-14T17:42:16:861', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(49, 'e8d93c0f9d6e02b5e90daff1', 'hello', 'plogapp-1647097667791.jpg', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '2', NULL, '', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'see', 'plogapp-1647097667791.jpg', 'null', 'block', NULL, 0, 'viewImagePostDetails/'),
(50, '859e35ec9e6d175a7d1d1297', 'sdsds', 'plogapp-1647097667791.jpg', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(51, '308d1081fdc534812dc97fea', 'tree', 'plogapp-1647097667791.jpg', 'undefined-undefined-undefinedTundefined:undefined:undefined:undefined', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(52, '91294631733472ec42020d80', 'dsds', 'plogapp-1647097667791.jpg', 'undefined-undefined-undefinedTundefined:undefined:undefined:undefined', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(53, '660c4f4b63918f9fc5f696a2', 'sdds', 'plogapp-1647097667791.jpg', '5:51:23 PM', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(54, '23827083ea9c70b4bd1edb4c', 'sds', 'plogapp-1647097667791.jpg', '5:51:23 PM', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(55, '8c6808be3e07015b877fb091', 'sd', 'plogapp-1647097667791.jpg', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(56, '78c3a87957efe34a3d834de3', 'see', 'plogapp-1647097667791.jpg', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(57, 'f0e72a3ec7a8e797160eddce', 'sds', 'plogapp-1647097667791.jpg', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(58, '95fb51cac22db48a3adcdb56', 'sdsd', 'plogapp-1647097667791.jpg', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(59, '122b7557dce743de7e8a428a', 'sds', 'plogapp-1647097667791.jpg', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(60, '6b0c125f28c33289e103ca73', 'dsd', 'plogapp-1647097667791.jpg', '2022-3-14T17:59:25:295', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(61, 'd1040bbb9d978c55c320a1ca', '1222', 'plogapp-1647097667791.jpg', '2022-3-14T17:59:25:295', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(62, '7600f6ee2f7ce9fe44fca930', 'help', 'plogapp-1647097667791.jpg', '2022-3-14T17:59:25:295', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(63, '5fa757b65c54aa69ffba47da', 'dsd', 'plogapp-1647097667791.jpg', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(64, '6bee016d9065176340ddd137', 'sds', 'plogapp-1647097667791.jpg', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(65, 'ede0c6d2c29a449571c9d430', 'sdd', 'plogapp-1647097667791.jpg', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(66, 'f6548a2a6fc93d62d1d213dd', 'sds', 'plogapp-1647097667791.jpg', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(67, '1d88b40fd60e6d24639f66c4', 'ssssssssssssss', 'plogapp-1647097667791.jpg', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(68, 'b722f29c1170eb39344adf7d', 'jelo', 'plogapp-1647097667791.jpg', '2022-3-14T18:4:50:444', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '1', NULL, '', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'Tree', 'plogapp-1647097667791.jpg', 'null', 'block', NULL, 0, 'viewImagePostDetails/'),
(69, 'ca5225e16aebdf9d56f1b5c7', 'Badest', 'plogapp-1647097667791.jpg', '2022-3-14T18:19:1:298', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', '49345c95f5eb0208392595df', 'none', '', NULL, '4', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, 'viewVideoPostDetails/'),
(70, '3505bd9e3b6e8a274e63ae07', 'This is the smoothest thing', 'plogapp-1647097667791.jpg', ' 1 MAR,  2022', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', '565d7acd54d605165b271839', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'sharedLinkVideo/'),
(71, 'a88ef4d0114cb15ab9c08650', 'heh', 'plogapp-1647097667791.jpg', '2022-3-14T18:35:39:760', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', '565d7acd54d605165b271839', 'none', '2', NULL, '', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', 'Wee\r\nlive ettt', 'plogapp-1646131942816.jpeg', 'null', 'block', NULL, 0, 'sharedLinkVideo/'),
(72, 'd8d3182137ce99f237a40c7c', 'Good', 'plogapp-1647097667791.jpg', '2022-3-15T10:6:51:731', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'd48b180d4f02ed24da8f89dc', 'none', '2', NULL, '', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'We love the app b rother', 'plogapp-1647097667791.jpg', 'null', 'block', NULL, 0, 'viewImagePostDetails/'),
(73, 'a46639973fc74335a508a883', 'Tree', 'plogapp-1647097667791.jpg', '2022-3-15T13:12:2:672', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', '139daa1c6aa9365430dbb3e2', 'none', '1', NULL, '', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'Awesome', 'plogapp-1647097667791.jpg', 'null', 'block', NULL, 0, 'viewImagePostDetails/'),
(74, '70c45429026607c55a8752aa', 'treee', 'plogapp-1647097667791.jpg', '2022-3-17T17:42:57:773', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', '61f9e02839f1ee4b01d3f4b1', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(75, '1d9dc52b17ba05a535a5749a', 'het', 'plogapp-1647097667791.jpg', '2022-3-18T17:20:27:985', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', '401baddfcca4b3d417beaa2e', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(76, '29edac9d9c5fd151590a655d', 'dop son', 'plogapp-1647097667791.jpg', '2022-3-18T17:26:20:562', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'cfc10cde03c60596d53f0b84', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(77, 'ae2871a6669b97b9692c378a', 'hellodsdsdsdsdsdsd', 'plogapp-1647097667791.jpg', '2022-3-20T7:7:49:521', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'aa33914cccce78a9c092054c', 'none', '1', NULL, '1,2', NULL, 'c2263ca46dce14a49f03674f', 'terry Leo', 'I loe the app', 'plogapp-1647097667791.jpg', 'null', 'block', NULL, 2, 'viewImagePostDetails/'),
(78, 'e6cf744eb0bc0e118ce7ed3b', 'fddfd', 'plogapp-1647097667791.jpg', '2022-3-20T7:50:34:958', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', '2e9d075c688957d58de7e468', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(79, '9777c95f7e6384186d72ddd8', 'sweet', 'plogapp-1646131942816.jpeg', '2022-3-21T15:44:22:859', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '92f0b824570cf1caf78c0d0a', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewVideoPostDetails/'),
(81, '7f9f90812868408d5060519d', 'This is the Best', 'plogapp-1646131942816.jpeg', '2022-03-25 18:42:34.668', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'f40c513ad6557065baf1d328', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(82, '22a5c71b058c26a659cdbfbf', 'Hello', 'plogapp-1646131942816.jpeg', '2022-03-25 19:55:49.936', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'cd3133f41536796f82aa7d38', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(98, '02316963a7cacefb67b5b131', 'tree', 'plogapp-1646131942816.jpeg', '2022-04-02 23:04:04.504', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(99, 'e70438092c514a045565a327', 'sds', 'plogapp-1646131942816.jpeg', '2022-04-02 23:04:25.404', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(100, '74cd6b5483aa5ce21b533cb6', 'xxxddd', 'plogapp-1646131942816.jpeg', '2022-04-02 23:04:32.122', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(101, '79172b87a103b3fee2a864a0', 'Hey', 'plogapp-1646131942816.jpeg', '2022-04-02 23:06:59.350', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(102, 'e2be3466710290208eecc8ac', 'Cool', 'plogapp-1646131942816.jpeg', '2022-04-02 23:07:10.123', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(103, '2568f613650e46f043141393', 'sa,', 'plogapp-1646131942816.jpeg', '2022-04-02 23:07:15.820', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(104, 'ce82d5d3293f68eaf20f23d2', 'tree', 'plogapp-1646131942816.jpeg', '2022-04-02 23:08:24.555', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(105, 'cde2c093c442bf8af99136f6', 'hey', 'plogapp-1646131942816.jpeg', '2022-04-02 23:21:29.625', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(106, '02aeaddfd2e4153ed5495682', 'hello', 'plogapp-1646131942816.jpeg', '2022-04-03 06:39:12.278', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(107, '9508a00a882c8ee773fa0cf4', 'hello', 'plogapp-1646131942816.jpeg', '2022-04-03 07:04:24.628', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(108, 'd143e914ebae32aff3fe8d6b', 'Hey', 'plogapp-1646131942816.jpeg', '2022-04-03 07:06:53.129', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(109, '6ca3530996712dcc082d0dd5', 'Nahh', 'plogapp-1646131942816.jpeg', '2022-04-03 07:07:37.590', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(110, '55ee2fd1bac866be88447132', 'Sample', 'plogapp-1646131942816.jpeg', '2022-04-03 07:07:46.006', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '', NULL, '1', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, 'viewImagePostDetails/'),
(113, '1010fa64c822f15ff7faaf79', 'Lol new', 'plogapp-1646131942816.jpeg', '2022-04-03 20:16:46.003', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(114, 'b6acc25c46e1c5a58130fdfd', 'boom', 'plogapp-1646131942816.jpeg', '2022-04-03 20:18:57.010', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(115, 'b69ddadbf5f4139b551d95c3', 'Cut llop', 'plogapp-1646131942816.jpeg', '2022-04-03 20:19:03.926', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '1', NULL, '1', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', 'hello wolrd', 'plogapp-1646131942816.jpeg', 'null', 'block', NULL, 1, 'viewImagePostDetails/'),
(116, 'c4cc56f49892559be435e88f', 'hey', 'plogapp-1646131942816.jpeg', '2022-04-04 11:50:28.916', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '', NULL, '1', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, 'viewImagePostDetails/'),
(117, 'd7d91bf30c8b46a4d1f4d244', 'tree', 'plogapp-1646131942816.jpeg', '2022-04-04 11:50:55.886', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '86cacabe51034f853d0e3691', 'none', '', NULL, '1', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, 'viewImagePostDetails/'),
(140, '6fc0f4fb35049323acb7e632', 'Hello', 'plogapp-1646132550991.jpeg', '2022-04-04 14:07:06.962', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'plog', '21d01217495d43f93946fe49', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'sharedLinkVideo/'),
(144, '20e241de3858df2a74f0c6ea', 'ool', 'plogapp-1646132550991.jpeg', '2022-04-04 14:26:26.957', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'plog', 'fb3da22e2d916cc05f9b074a', 'none', '', NULL, '2,1', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 2, 'shareLink/'),
(146, '960833079adf26b83172543d', 'hello', 'plogapp-1646132550991.jpeg', '2022-04-04 16:05:30.872', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'plog', 'fb3da22e2d916cc05f9b074a', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'shareLink/'),
(147, 'c4688c0038806d6acbcb3fef', 'Hello', 'plogapp-1646132550991.jpeg', '2022-04-04 17:16:05.104', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'plog', '21d01217495d43f93946fe49', 'none', '', NULL, '2', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, 'sharedLinkVideo/'),
(148, 'b6e58379e08bea56f053c6da', 'This is  cool ', 'plogapp-1646131942816.jpeg', '2022-04-04 17:52:24.304', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '401baddfcca4b3d417beaa2e', 'none', '2', NULL, '1', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', 'Call u tomorrow ', 'plogapp-1646131942816.jpeg', 'null', 'block', NULL, 1, 'viewImagePostDetails/'),
(149, 'ed58d6ced4c32b2fc84d65f6', 'Greetings ', 'plogapp-1646131942816.jpeg', '2022-04-04 18:10:43.577', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'de56906e8e4a1c098a98aed3', 'none', '', NULL, '1', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, 'shareLink/'),
(150, '8708beab0d675513bb6c5bf3', 'This is awesome btother \r\nI so much love the app to the fullest ', 'plogapp-1646131942816.jpeg', '2022-04-05 14:36:55.862', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'ccd035372ae42c83b1123f08', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(151, 'dbdd7185f326330b8d43eca2', 'This is cool brother', 'plogapp-1646131942816.jpeg', '2022-04-05 14:38:06.620', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'ccd035372ae42c83b1123f08', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(152, 'c1f16a5b13adf4fd4e7520c5', 'Okay let me say!!!\r\nThe app is really cool at first \r\n\r\nI so much love it', 'plogapp-1646131942816.jpeg', '2022-04-05 14:38:37.120', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'ccd035372ae42c83b1123f08', 'none', '', NULL, '1', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, 'viewImagePostDetails/'),
(153, 'b285b1e37264b725f29e18ae', 'This is amazing boss', 'plogapp-1646131942816.jpeg', '2022-04-05 14:51:14.776', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'c3e590c6cb9df8b339fbbad4', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'shareLink/'),
(154, '600f238a63199a8b6bf714d3', 'Hehe \r\nwe love you', 'plogapp-1646131942816.jpeg', '2022-04-05 14:53:11.320', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'c3e590c6cb9df8b339fbbad4', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'shareLink/'),
(155, '73430d24be3025e89399da47', 'dsdsdsdsd', 'plogapp-1646131942816.jpeg', '2022-04-05 14:56:40.553', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'c3e590c6cb9df8b339fbbad4', 'none', '3', NULL, '', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', 'Okay whats happen\r\nTOday\r\n', 'plogapp-1646131942816.jpeg', 'null', 'block', NULL, 0, 'shareLink/'),
(156, '9e27290fc89d4e64b43b4f1e', 'See', 'plogapp-1646131942816.jpeg', '2022-04-05 15:12:04.404', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'eb841e24f21b557bec628a23', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'sharedLinkVideo/'),
(157, '2649a605c9d6188bb813b347', 'This is dope', 'plogapp-1646131942816.jpeg', '2022-04-05 18:07:39.945', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'aa33914cccce78a9c092054c', 'none', '', NULL, '1,2', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 2, 'viewImagePostDetails/'),
(158, '66bf1ae3b8879b6f5b8b5f13', 'hmm', 'plogapp-1646131942816.jpeg', '2022-04-05 19:01:06.121', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '573d2e4679e86dd347ff3c95', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(159, 'ac08b0e765c8cd3264e437bf', 'hello world ????????', 'plogapp-1646131942816.jpeg', '2022-04-06 13:24:51.292', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'cfc10cde03c60596d53f0b84', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(160, 'e62efa2a00b9c8663df5d33e', 'heyy', 'plogapp-1646131942816.jpeg', '2022-04-06 14:06:00.398', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '5137a9062b6822d8458398bb', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(161, '83d3398cff44eea3d9e20f1d', 'tree', 'plogapp-1646131942816.jpeg', '2022-04-06 14:06:09.324', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '5137a9062b6822d8458398bb', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(162, '3b817d56772e2bbfe208a581', 'Hello', 'plogapp-1646131942816.jpeg', '2022-04-09 05:56:24.505', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '7d4d6c4c94922b46e9a083a9', 'none', '6', NULL, '1', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', 'So much brother', 'plogapp-1646131942816.jpeg', 'null', 'block', NULL, 1, 'viewImagePostDetails/'),
(163, 'c42a032abae2a26ca29187c7', 'hello ', 'plogapp-1646131942816.jpeg', '2022-04-09 17:48:36.867', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'c15e34ef07523d7e3f0ae1d9', 'none', '1', NULL, '1', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', 'Cool bro', 'plogapp-1646131942816.jpeg', 'null', 'block', NULL, 1, 'viewImagePostDetails/'),
(164, '39f5265d263865cd40b68327', 'Awesome ro', 'plogapp-1646131942816.jpeg', '2022-04-09 18:21:33.142', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '559946f3e20fed74b80f7e1a', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewVideoPostDetails/'),
(165, '6d68bd6aa74e61a782cdfc06', 'Hell', 'plogapp-1646131942816.jpeg', '2022-04-09 18:28:43.463', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'fb3da22e2d916cc05f9b074a', 'none', '', NULL, '1', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, 'shareLink/'),
(166, 'bf3b384f6cf804a968376db8', 'Good ine', 'plogapp-1646131942816.jpeg', '2022-04-09 18:30:40.712', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'eb841e24f21b557bec628a23', 'none', '', NULL, '1', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 1, 'sharedLinkVideo/'),
(167, '38f24d9985b44e77840aff75', '#dope man', 'plogapp-1646131942816.jpeg', '2022-04-12 19:32:59.566', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', '3afe6e81275852a5f67638cc', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewVideoPostDetails/'),
(168, '588dc8de707a626047e8397f', 'hey', 'plogapp-1646131942816.jpeg', '2022-04-17 09:59:03.326', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'aaf6c64bce315fcfd7743d25', 'none', '', NULL, '', NULL, NULL, NULL, NULL, NULL, '', 'none', NULL, 0, 'viewImagePostDetails/'),
(169, '8f53655d5f0cff999bb2b4dd', 'Cool', 'plogapp-1646131942816.jpeg', '2022-04-17 10:21:05.425', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'aaf6c64bce315fcfd7743d25', 'none', '1', NULL, '', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', 'Cool', 'plogapp-1646131942816.jpeg', 'null', 'block', NULL, 0, 'viewImagePostDetails/'),
(170, 'a894e00a215fd316da097ed5', 'Hafa', 'plogapp-1646131942816.jpeg', '2022-04-17 18:50:21.387', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'd8d475c6547f93c8c08e5e6e', 'none', '1', NULL, '1', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', 'Hello', 'plogapp-1646131942816.jpeg', 'null', 'block', NULL, 1, 'viewImagePostDetails/');

-- --------------------------------------------------------

--
-- Table structure for table `follower`
--

CREATE TABLE `follower` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `follower_id` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `cartQuantity` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `follower`
--

INSERT INTO `follower` (`id`, `_id`, `owner`, `follower_id`, `date`, `status`, `cartQuantity`) VALUES
(38, NULL, 'c2263ca46dce14a49f03674f', '9627470f246cdb74266641dd', '3/21/2022', NULL, NULL),
(39, NULL, 'c2263ca46dce14a49f03674f', '3ec1e3144312a90089fb42f2', '3/21/2022', NULL, NULL),
(40, NULL, 'c2263ca46dce14a49f03674f', 'c2585b15e1bbc09bb86000e8', '3/21/2022', NULL, NULL),
(64, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', '3/31/2022', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `following`
--

CREATE TABLE `following` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `following_id` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `following`
--

INSERT INTO `following` (`id`, `_id`, `owner`, `following_id`, `date`, `status`) VALUES
(38, NULL, 'c2263ca46dce14a49f03674f', '9627470f246cdb74266641dd', '3/21/2022', NULL),
(39, NULL, 'c2263ca46dce14a49f03674f', '3ec1e3144312a90089fb42f2', '3/21/2022', NULL),
(40, NULL, 'c2263ca46dce14a49f03674f', 'c2585b15e1bbc09bb86000e8', '3/21/2022', NULL),
(64, NULL, 'c2585b15e1bbc09bb86000e8', '9627470f246cdb74266641dd', '3/31/2022', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `eventId` varchar(255) DEFAULT NULL,
  `eventOwner` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `ownerName` varchar(255) DEFAULT NULL,
  `urlLink` varchar(255) DEFAULT NULL,
  `count` varchar(255) DEFAULT NULL,
  `readStatus` varchar(255) DEFAULT NULL,
  `readStatusColor` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`id`, `_id`, `owner`, `avatar`, `text`, `date`, `eventId`, `eventOwner`, `comment`, `ownerName`, `urlLink`, `count`, `readStatus`, `readStatusColor`) VALUES
(1, 'ade382211561211b772bba38', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', ' 1 MAR,  2022', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(2, '86161c2642943483abd99303', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Started following you', ' 1 MAR,  2022', NULL, '9627470f246cdb74266641dd', '', 'Plog app', 'profile/c2585b15e1bbc09bb86000e8', NULL, 'fa fa-question', NULL),
(3, 'df9d10b42ca71a48ebbf23ac', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your post', ' 3 MAR,  2022 at 9:03:21 AM', '139daa1c6aa9365430dbb3e2', 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'viewImagePostDetails/139daa1c6aa9365430dbb3e2', NULL, 'fa fa-question', NULL),
(4, 'b8046550b5652e68cba5ec5d', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your post', ' 4 MAR,  2022 at 4:17:13 PM', 'b1b104968cefd3644a3d0589', 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'viewImagePostDetails/b1b104968cefd3644a3d0589', NULL, 'fa fa-question', NULL),
(5, 'b00b6c7e02645ae59893c9bf', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', ' 4 MAR,  2022', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(6, 'd102b3528e40c83180c44afd', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', ' 4 MAR,  2022', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(7, '3cf1f17237a09d77e0e445db', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', ' 4 MAR,  2022', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(8, 'c84671e3712eab0ef43bd38c', '3ec1e3144312a90089fb42f2', 'plogapp-1646499448053.jpg', 'Commented on your post', ' 6 MAR,  2022 at 3:10:42 PM', '573d2e4679e86dd347ff3c95', '9627470f246cdb74266641dd', 'dfdf', 'User1 User1', 'viewImagePostDetails/573d2e4679e86dd347ff3c95', NULL, NULL, NULL),
(9, 'bd33ad0788741fa856ce1ba8', '3ec1e3144312a90089fb42f2', 'plogapp-1646499448053.jpg', 'Commented on your post', ' 6 MAR,  2022 at 3:11:25 PM', '573d2e4679e86dd347ff3c95', '9627470f246cdb74266641dd', 'tree', 'User1 User1', 'viewImagePostDetails/573d2e4679e86dd347ff3c95', NULL, NULL, NULL),
(10, 'f353a5d616b8e37ba86690d2', '3ec1e3144312a90089fb42f2', 'plogapp-1646499448053.jpg', 'Commented on your post', ' 6 MAR,  2022 at 3:17:23 PM', '573d2e4679e86dd347ff3c95', '9627470f246cdb74266641dd', 'hellp', 'User1 User1', 'viewImagePostDetails/573d2e4679e86dd347ff3c95', NULL, NULL, NULL),
(11, '2e56e10e897cae5add20ecd4', '3ec1e3144312a90089fb42f2', 'plogapp-1646499448053.jpg', 'Reacted to your post', ' 6 MAR,  2022 at 3:44:25 PM', '573d2e4679e86dd347ff3c95', '9627470f246cdb74266641dd', 'Ukrainian President Volodymyr Zelensky reiterated his call for direct talks with Russian President Vladimir Putin to end the invasion of his country, the U.S. Embassy in Kyiv said Russia’s overnight attack on a nuclear power plant amounted to “a war crime', 'User1 User1', 'viewImagePostDetails/573d2e4679e86dd347ff3c95', NULL, 'fa fa-question', NULL),
(12, '4b3f61c2b68313928b200e2c', '3ec1e3144312a90089fb42f2', 'plogapp-1646499448053.jpg', 'Commented on your post', ' 6 MAR,  2022 at 4:41:38 PM', '92f0b824570cf1caf78c0d0a', '9627470f246cdb74266641dd', 'I love the app', 'User1 User1', 'viewVideoPostDetails/92f0b824570cf1caf78c0d0a', NULL, NULL, NULL),
(13, 'de28c25ae118aa1dd4ec49c5', '3ec1e3144312a90089fb42f2', 'plogapp-1646499448053.jpg', 'Reacted to your post', ' 6 MAR,  2022 at 4:44:54 PM', 'cfc10cde03c60596d53f0b84', '9627470f246cdb74266641dd', '????????????????????????Ukrainian President Volodymyr Zelensky reiterated his call for direct talks with Russian President Vladimir Putin to end the invasion of his country, the U.S. Embassy in Kyiv said Russia’s overnight attack on a nuclear power plant ', 'User1 User1', 'viewImagePostDetails/cfc10cde03c60596d53f0b84', NULL, 'fa fa-question', NULL),
(14, '38a572399abea8933a3aff90', '3ec1e3144312a90089fb42f2', 'plogapp-1646499448053.jpg', 'Replied to your comment', '2022 MAR 0', '7a97a8dac719e370e8334687', '9627470f246cdb74266641dd', 'Awesome nrother', 'User1 User1', 'replyComment/7a97a8dac719e370e8334687', NULL, NULL, NULL),
(15, '7674ad3ba7da8e9f1b262b57', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your comment', '2022 MAR 0', '8ee1996e42edd67b4818621e', '3ec1e3144312a90089fb42f2', 'Cool', 'Gabriel Delight', 'replyComment/3ac30a1dc5b91c1977800f16', NULL, NULL, NULL),
(16, 'e89fcddefa1ad58697272f16', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your comment', '2022 MAR 0', 'f5548aea3722be8ded8f13ba', '3ec1e3144312a90089fb42f2', 'This is awesome', 'Gabriel Delight', 'replyComment/3ac30a1dc5b91c1977800f16', NULL, NULL, NULL),
(17, '9e5854e1434fbb77cc167bb9', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your comment', '2022 MAR 0', 'c3c1e4d0257624cfa161bd06', '3ec1e3144312a90089fb42f2', 'Cool', 'Gabriel Delight', 'replyComment/3ac30a1dc5b91c1977800f16', NULL, NULL, NULL),
(18, '58e39f8f850a5e272e5034e0', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your post', ' 6 MAR,  2022 at 5:35:54 PM', '1bda0157c8ad26f9abcebf6a', 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'viewImagePostDetails/1bda0157c8ad26f9abcebf6a', NULL, 'fa fa-question', NULL),
(19, 'd6c401aae86a732817f31001', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your post', ' 6 MAR,  2022 at 5:36:14 PM', '10a2323b8354be56bcd238fb', 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'viewImagePostDetails/10a2323b8354be56bcd238fb', NULL, 'fa fa-question', NULL),
(20, '35f108389df546587810456b', '3ec1e3144312a90089fb42f2', 'plogapp-1646499448053.jpg', 'Commented on your post', ' 8 MAR,  2022 at 9:06:21 AM', 'cfc10cde03c60596d53f0b84', '9627470f246cdb74266641dd', '✌️✌️', 'User1 User1', 'viewImagePostDetails/cfc10cde03c60596d53f0b84', NULL, NULL, NULL),
(21, '816aad295c1c407a6551379a', '3ec1e3144312a90089fb42f2', 'plogapp-1646499448053.jpg', 'Commented on your post', ' 8 MAR,  2022 at 9:06:40 AM', 'cfc10cde03c60596d53f0b84', '9627470f246cdb74266641dd', '✌️✌️✌️tree', 'User1 User1', 'viewImagePostDetails/cfc10cde03c60596d53f0b84', NULL, NULL, NULL),
(22, 'fb0f232ff726c0cfa6d4aa66', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your comment', ' 8 MAR,  2022 at 9:23:43 AM', '8c352dedabeb3a76dc94f746', '3ec1e3144312a90089fb42f2', '✌️✌️', 'Gabriel Delight', 'viewImagePostDetails/cfc10cde03c60596d53f0b84', NULL, 'fa fa-question', NULL),
(23, '4066572bb2fcc137bf5b1abe', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your comment', ' 8 MAR,  2022 at 9:23:43 AM', '171d972376de476ed224ccf5', '3ec1e3144312a90089fb42f2', '✌️✌️✌️tree', 'Gabriel Delight', 'viewImagePostDetails/cfc10cde03c60596d53f0b84', NULL, 'fa fa-question', NULL),
(24, '42d999dc2677d355f163d8f2', '3ec1e3144312a90089fb42f2', 'plogapp-1646499448053.jpg', 'Started following you', ' 8 MAR,  2022', NULL, '9627470f246cdb74266641dd', '', 'User1 User1', 'profile/3ec1e3144312a90089fb42f2', NULL, 'fa fa-question', NULL),
(25, '9f14b174982130fa24d1acc6', '3ec1e3144312a90089fb42f2', 'plogapp-1646499448053.jpg', 'Started following you', ' 8 MAR,  2022', NULL, 'c2585b15e1bbc09bb86000e8', '', 'User1 User1', 'profile/3ec1e3144312a90089fb42f2', NULL, 'fa fa-question', NULL),
(26, '6c38fa91d122bd0ee62d3f73', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', ' 8 MAR,  2022', NULL, '3ec1e3144312a90089fb42f2', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(27, 'c554f5b4ecc8bf57e3e42497', '3ec1e3144312a90089fb42f2', 'plogapp-1646499448053.jpg', 'Reacted to your post', ' 10 MAR,  2022 at 10:13:15 AM', 'baca76f4d50d7da4db472c3e', '9627470f246cdb74266641dd', '', 'User1 User1', 'viewImagePostDetails/baca76f4d50d7da4db472c3e', NULL, 'fa fa-question', NULL),
(28, '2f1ad99994a4228e8b3e4b22', '3ec1e3144312a90089fb42f2', 'plogapp-1646499448053.jpg', 'Reacted to your post', ' 10 MAR,  2022 at 10:13:17 AM', '24585135f38985f9d3d325d3', '9627470f246cdb74266641dd', '??????', 'User1 User1', 'viewImagePostDetails/24585135f38985f9d3d325d3', NULL, 'fa fa-question', NULL),
(29, '0959d56850ccdd8ca18c9e94', '3ec1e3144312a90089fb42f2', 'plogapp-1646904681763.jpeg', 'Commented on your post', ' 10 MAR,  2022 at 2:09:13 PM', '82d68e5192831276429f42f4', '9627470f246cdb74266641dd', 'We all love the app', 'User1 User1', 'viewImagePostDetails/82d68e5192831276429f42f4', NULL, NULL, NULL),
(30, '9e54ded15e57c63730e0d5ea', '3ec1e3144312a90089fb42f2', 'plogapp-1646904681763.jpeg', 'Commented on your post', ' 10 MAR,  2022 at 2:09:27 PM', '82d68e5192831276429f42f4', '9627470f246cdb74266641dd', 'nice app', 'User1 User1', 'viewImagePostDetails/82d68e5192831276429f42f4', NULL, NULL, NULL),
(31, 'cc0aff4e07d3be57374cc2a9', '3ec1e3144312a90089fb42f2', 'plogapp-1646904681763.jpeg', 'Reacted to your post', ' 10 MAR,  2022 at 2:12:57 PM', 'a88fe5113a138e1709095a40', '9627470f246cdb74266641dd', '', 'User1 User1', 'viewImagePostDetails/a88fe5113a138e1709095a40', NULL, 'fa fa-question', NULL),
(32, '3afa8aa753a7fa3026d34cc8', '3ec1e3144312a90089fb42f2', 'plogapp-1646904681763.jpeg', 'Started following you', ' 10 MAR,  2022', NULL, 'c2585b15e1bbc09bb86000e8', '', 'User1 User1', 'profile/3ec1e3144312a90089fb42f2', NULL, 'fa fa-question', NULL),
(33, '3de8f41558e99cd6cdfd2808', '3ec1e3144312a90089fb42f2', 'plogapp-1646904681763.jpeg', 'Reacted to your post', ' 10 MAR,  2022 at 8:04:02 PM', '194b31fbbb17f3d51884027f', '9627470f246cdb74266641dd', '', 'User1 User1', 'viewImagePostDetails/194b31fbbb17f3d51884027f', NULL, 'fa fa-question', NULL),
(34, 'd2dfdc01e248161f61567124', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your post', ' 11 MAR,  2022 at 12:07:43 PM', '5ad964576eae43a711c3ebaf', '3ec1e3144312a90089fb42f2', '', 'Gabriel Delight', 'viewImagePostDetails/5ad964576eae43a711c3ebaf', NULL, 'fa fa-question', NULL),
(35, '52a6cde6a4ca880243d89cc5', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your post', ' 11 MAR,  2022 at 6:41:01 PM', '665390293c777a49701d065f', '3ec1e3144312a90089fb42f2', 'Setting up Font #Awesome can be as simple as adding two lines of code to your website, or you can be a pro and customize the LESS yourself! Font Awesome even plays nicely with Bootstrap!', 'Gabriel Delight', 'viewImagePostDetails/665390293c777a49701d065f', NULL, 'fa fa-question', NULL),
(36, '70028d601045164d8db3639b', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Commented on your post', ' 12 MAR,  2022 at 10:13:00 AM', '8a07c8e04267d22e5ea7626c', '3ec1e3144312a90089fb42f2', 'hello', 'Gabriel Delight', 'viewImagePostDetails/8a07c8e04267d22e5ea7626c', NULL, NULL, NULL),
(37, '90131b213e7716abcfccd49f', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Commented on your post', ' 12 MAR,  2022 at 10:13:27 AM', '8a07c8e04267d22e5ea7626c', '3ec1e3144312a90089fb42f2', '', 'Gabriel Delight', 'viewImagePostDetails/8a07c8e04267d22e5ea7626c', NULL, NULL, NULL),
(38, 'd8ab0a9f1676aa125940fa8a', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Commented on your post', ' 12 MAR,  2022 at 10:16:15 AM', '8a07c8e04267d22e5ea7626c', '3ec1e3144312a90089fb42f2', 'g', 'Gabriel Delight', 'viewImagePostDetails/8a07c8e04267d22e5ea7626c', NULL, NULL, NULL),
(39, '92cd8048c133d3d9582d207e', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Commented on your post', ' 12 MAR,  2022 at 10:16:37 AM', '8a07c8e04267d22e5ea7626c', '3ec1e3144312a90089fb42f2', '', 'Gabriel Delight', 'viewImagePostDetails/8a07c8e04267d22e5ea7626c', NULL, NULL, NULL),
(40, 'd51b63c8a76884ee3a3e3efb', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Commented on your post', ' 12 MAR,  2022 at 10:23:13 AM', '8a07c8e04267d22e5ea7626c', '3ec1e3144312a90089fb42f2', 'tree', 'Gabriel Delight', 'viewImagePostDetails/8a07c8e04267d22e5ea7626c', NULL, NULL, NULL),
(41, '7e6504ca1b36bc1d322e3fcb', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Commented on your post', ' 12 MAR,  2022 at 10:28:46 AM', '8a07c8e04267d22e5ea7626c', '3ec1e3144312a90089fb42f2', 'Hello wolrd', 'Gabriel Delight', 'viewImagePostDetails/8a07c8e04267d22e5ea7626c', NULL, NULL, NULL),
(42, 'c98518f4798fb04c22e458e8', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Replied to your comment', '2022 MAR 6', 'ca0a481fe7fe0ce2b143e622', '3ec1e3144312a90089fb42f2', 'tree', 'Gabriel Delight', 'replyComment/ca0a481fe7fe0ce2b143e622', NULL, NULL, NULL),
(43, 'cf5f08b9c82bf9918c0522ee', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your post', '2022-3-14T19:50:5:126', 'de56906e8e4a1c098a98aed3', 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'shareLink/de56906e8e4a1c098a98aed3', NULL, 'fa fa-question', NULL),
(44, 'eadd3fad5c8c79370a669061', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your post', '2022-3-14T19:50:7:451', '565d7acd54d605165b271839', 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'shareLink/565d7acd54d605165b271839', NULL, 'fa fa-question', NULL),
(45, '50880f13277f867cf633fce6', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Commented on your post', '2022-3-15T13:12:2:672', '139daa1c6aa9365430dbb3e2', 'c2585b15e1bbc09bb86000e8', 'Tree', 'terry Leo', 'viewImagePostDetails/139daa1c6aa9365430dbb3e2', NULL, NULL, NULL),
(46, '5e3279601debcc4143db2a18', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', ' 15 MAR,  2022', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(47, '0f0b3b8207752f9a0e0b5292', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-3-15T14:6:29:653', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(48, 'a968cd1d1417706c40f4fc19', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-15T18:58:59:235', NULL, '3ec1e3144312a90089fb42f2', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(49, '992f8547befe2be400008881', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-15T19:4:47:101', NULL, '3ec1e3144312a90089fb42f2', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(50, 'caa1f83e8b6658491b67893a', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-15T19:4:47:836', NULL, 'c2585b15e1bbc09bb86000e8', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(51, '58ef76b3bf63d6310d6e0c88', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-15T19:4:48:509', NULL, '9627470f246cdb74266641dd', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(52, 'fa4b7fe883ee371766f3d6ee', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-17T12:25:23:519', NULL, '9627470f246cdb74266641dd', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(53, '4f18645dd94ec2faabb51b74', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-17T12:31:34:52', NULL, '9627470f246cdb74266641dd', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(54, '02dc9950bb6331affea31e59', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-17T13:1:12:151', NULL, '9627470f246cdb74266641dd', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(55, '4b8bafc81e5e13ab40aee421', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-17T13:1:53:620', NULL, '9627470f246cdb74266641dd', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(56, '9b587f96689e01af17dc6ba9', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-17T13:3:41:648', NULL, '9627470f246cdb74266641dd', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(57, 'a865804352f2c114e352101c', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-17T13:4:57:193', NULL, '9627470f246cdb74266641dd', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(58, 'bdf773c68fbbf7280e340805', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-17T13:6:12:342', NULL, '9627470f246cdb74266641dd', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(59, 'e92f97ed5d3cedd4ce16745d', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-17T13:11:21:707', NULL, '9627470f246cdb74266641dd', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(60, 'b843e85c298efd75ff9a38ae', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-17T13:13:56:62', NULL, '9627470f246cdb74266641dd', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(61, 'd3ea769b92d982e3d2e4ce20', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-17T13:17:5:88', NULL, 'c2585b15e1bbc09bb86000e8', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(62, 'ac9426e63672790feb26e843', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-3-17T13:23:46:329', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(63, '4c2c324525d78679378d4653', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-3-17T13:36:51:263', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(64, '564568f1d9d3c973f58465f8', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-17T13:37:33:890', NULL, '9627470f246cdb74266641dd', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(65, '29e9aae659cbd424a20e952f', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-3-17T13:37:46:600', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(66, '464d5f4da61be455063d2ca1', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-18T13:34:15:273', NULL, '3ec1e3144312a90089fb42f2', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(67, 'f0d30d90ca5a08cf9fab9f2a', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-18T13:34:19:853', NULL, 'c2585b15e1bbc09bb86000e8', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(68, '706e6435b710f0210548a0a6', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-3-18T14:0:59:944', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(69, '97af4e221bf675c923b8678a', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-3-18T14:1:13:509', NULL, '3ec1e3144312a90089fb42f2', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(70, 'd2d6de88b8f1dec681fe3cd7', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-3-18T14:1:25:672', NULL, '3ec1e3144312a90089fb42f2', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(71, 'af06443c9602caf26a87c469', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-3-18T14:27:4:806', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(72, 'd108bff51e2c27aab39b09b4', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-3-18T14:27:5:225', NULL, '3ec1e3144312a90089fb42f2', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(73, '39b7b9d2dfe8c07c86997d41', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-3-18T14:27:5:728', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(74, 'c69591e20749a2acb904535e', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Commented on your post', '2022-3-18T17:26:20:562', 'cfc10cde03c60596d53f0b84', '9627470f246cdb74266641dd', 'dop son', 'terry Leo', 'viewImagePostDetails/cfc10cde03c60596d53f0b84', NULL, NULL, NULL),
(75, '19e053977cff3ced706ebe1e', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Commented on your post', '2022-3-20T7:7:49:521', 'aa33914cccce78a9c092054c', 'c2585b15e1bbc09bb86000e8', 'hellodsdsdsdsdsdsd', 'terry Leo', 'viewImagePostDetails/aa33914cccce78a9c092054c', NULL, NULL, NULL),
(76, 'aaa44eb3d934651bbc82a5f2', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Reacted to your post', '2022-3-20T7:44:17:528', '7e321f8fd96adb575ad502c3', 'c2585b15e1bbc09bb86000e8', '', 'terry Leo', 'viewImagePostDetails/7e321f8fd96adb575ad502c3', NULL, 'fa fa-question', NULL),
(77, 'ae04a2f8bf9aedc9fd6e1c2d', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Commented on your post', '2022-3-20T7:50:34:958', '2e9d075c688957d58de7e468', 'c2585b15e1bbc09bb86000e8', 'fddfd', 'terry Leo', 'viewImagePostDetails/2e9d075c688957d58de7e468', NULL, NULL, NULL),
(78, '6b29b2c7432be49c17981b16', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Replied to your comment', '2022-3-21T15:51:58:516', 'b0d03f34f42616f34fc2d3b5', '3ec1e3144312a90089fb42f2', 'Good God', 'Gabriel Delight', 'replyComment/b0d03f34f42616f34fc2d3b5', NULL, NULL, NULL),
(79, 'b9d4da9796b14c11ec974ef7', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-21T16:11:57:609', NULL, '9627470f246cdb74266641dd', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(80, 'e29b3921da33df85c179fe4f', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-21T16:11:58:381', NULL, '3ec1e3144312a90089fb42f2', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(81, '07176f62d5d30ffea0c12fee', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Reacted to your post', '2022-3-21T16:12:3:951', '92f0b824570cf1caf78c0d0a', '9627470f246cdb74266641dd', '', 'terry Leo', 'viewVideoPostDetails/92f0b824570cf1caf78c0d0a', NULL, 'fa fa-check', '#bdbdbd'),
(82, 'a18532ab72865d6503b9ab35', 'c2263ca46dce14a49f03674f', 'plogapp-1647097667791.jpg', 'Started following you', '2022-3-21T16:14:35:63', NULL, 'c2585b15e1bbc09bb86000e8', '', 'terry Leo', 'profile/c2263ca46dce14a49f03674f', NULL, 'fa fa-question', NULL),
(83, '83953908dde83897b3a15bce', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-22 22:45:13.445', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(84, 'a9b380160f4f8322fc27a862', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-22 22:46:48.895', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(85, '3e6ed41427c8b023fdc71b01', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-22 22:48:02.205', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(86, '9739978f27b1e212d336ba2e', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-22 22:49:55.890', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(87, '491eafd361cb8ac91a4ed939', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-22 22:49:57.049', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(88, '00b7869dadee392708496ee6', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-22 22:49:58.717', NULL, '3ec1e3144312a90089fb42f2', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(89, 'fabe5d238b44a3ff4c2bca04', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-22 22:50:22.002', NULL, '3ec1e3144312a90089fb42f2', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(90, 'c1959b43656943f54a37501d', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-22 22:50:22.665', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(91, '17da51ea63a7296acad21d5b', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-22 22:50:23.677', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(92, '86467760769873edf2b4ac46', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-22 22:54:19.139', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(93, 'de9e8347f48bf7dd29bb3ac4', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-22 22:54:42.859', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(94, '2d7d578060a23964b44b794e', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-22 22:56:37.218', NULL, '3ec1e3144312a90089fb42f2', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(95, '9a781391da3d25cc95feda68', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-22 22:56:46.596', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(96, 'fb2f7b957163caa80a7346bb', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-22 22:58:19.250', NULL, '3ec1e3144312a90089fb42f2', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(97, 'cb2aff37a76e902dd9394c43', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-22 22:58:25.889', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(98, '889b15c1efa180808ecb34b6', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-23 16:53:58.292', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(99, 'e67de6dc43e514f8b4235a0f', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-26 11:29:19.084', NULL, '3ec1e3144312a90089fb42f2', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(100, '51dd287bcb9eaccbe338bdbc', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-26 11:29:19.857', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(101, '7fc7fee0d858238ff46f58fa', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-27 10:02:13.719', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(102, '7cd6aec865493ce445090c23', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-27 10:04:05.561', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(103, '4ea6375ea1d797419550e1f4', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-27 10:15:16.160', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(104, 'a4ebccc5ddb83762931e351d', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-27 10:26:10.327', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(105, '223459f191a9ad1235d280db', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-27 10:31:23.973', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(106, '8cc15762da5686f316193721', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Started following you', '2022-03-31 17:00:54.183', NULL, '9627470f246cdb74266641dd', '', 'Plog app', 'profile/c2585b15e1bbc09bb86000e8', NULL, 'fa fa-question', NULL),
(107, '46ed1312a6359bc5467d5e89', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-03-31 18:13:12.709', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(108, '37fac53b1aea383240abf34c', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Reacted to your comment', '2022-04-03 08:14:05.994', '90c5a502dc73e3313aa1e24e', '9627470f246cdb74266641dd', 'Awesome', 'Plog app', 'replyComment/da0b3920064442e415e6c8ea', NULL, NULL, NULL),
(109, '060d350c863999dd372091a6', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Reacted to your comment', '2022-04-03 08:14:09.182', 'bdfe34b227b13efcfeee44d9', '9627470f246cdb74266641dd', 'cool', 'Plog app', 'replyComment/da0b3920064442e415e6c8ea', NULL, NULL, NULL),
(110, 'f73c9f431a4403705eaffd94', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Reacted to your comment', '2022-04-03 08:17:09.892', 'bdfe34b227b13efcfeee44d9', '9627470f246cdb74266641dd', 'cool', 'Plog app', 'replyComment/da0b3920064442e415e6c8ea', NULL, NULL, NULL),
(111, '9f0e11f1ecfa4be58f9e91bf', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Commented on your post', '2022-04-03 09:20:05.813', '86cacabe51034f853d0e3691', '9627470f246cdb74266641dd', 'hekllo', 'Plog app', 'viewImagePostDetails/86cacabe51034f853d0e3691', NULL, NULL, NULL),
(112, '86db2f6cd2f2ce39105f6aad', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your comment', '2022-04-03 09:26:19.330', '6b658c5ed72e9da04567852b', 'c2585b15e1bbc09bb86000e8', 'hekllo', 'Gabriel Delight', 'viewImagePostDetails/86cacabe51034f853d0e3691', NULL, 'fa fa-question', NULL),
(113, 'd71fe911aacba53de8ea58f3', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Commented on your post', '2022-04-04 13:51:00.324', '3fab7977670f6b803f70fb4a', '9627470f246cdb74266641dd', 'Cpp', 'Plog app', 'viewImagePostDetails/3fab7977670f6b803f70fb4a', NULL, NULL, NULL),
(114, '6111559db22bdd1c736f0815', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Commented on your post', '2022-04-04 13:59:50.440', '3fab7977670f6b803f70fb4a', '9627470f246cdb74266641dd', 'sddsds', 'Plog app', 'viewImagePostDetails/3fab7977670f6b803f70fb4a', NULL, NULL, NULL),
(115, '080da4c3f8b5fbe938947cb1', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Commented on your post', '2022-04-04 14:03:34.892', 'f40c513ad6557065baf1d328', '9627470f246cdb74266641dd', 'custome brahh', 'Plog app', 'viewImagePostDetails/f40c513ad6557065baf1d328', NULL, NULL, NULL),
(116, '25e30fa72863acf175006253', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Commented on your post', '2022-04-04 14:06:08.049', 'f40c513ad6557065baf1d328', '9627470f246cdb74266641dd', 'cool', 'Plog app', 'viewImagePostDetails/f40c513ad6557065baf1d328', NULL, NULL, NULL),
(117, '08f99403d88166bca7fa8d02', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Commented on your post', '2022-04-04 14:16:36.046', 'f40c513ad6557065baf1d328', '9627470f246cdb74266641dd', 'Testing ', 'Plog app', 'viewImagePostDetails/f40c513ad6557065baf1d328', NULL, NULL, NULL),
(118, 'f9c7e686be301a9e272a4393', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Reacted to your post', '2022-04-04 14:26:05.242', 'f40c513ad6557065baf1d328', '9627470f246cdb74266641dd', '', 'Plog app', 'viewImagePostDetails/f40c513ad6557065baf1d328', NULL, 'fa fa-question', NULL),
(119, 'f04cb493945181457fdd2cda', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Commented on your post', '2022-04-04 17:52:24.382', '401baddfcca4b3d417beaa2e', 'c2263ca46dce14a49f03674f', 'This is  cool ', 'Gabriel Delight', 'viewImagePostDetails/401baddfcca4b3d417beaa2e', NULL, NULL, NULL),
(120, '99c4f29f55f9601ab27326c3', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Commented on your post', '2022-04-04 18:10:43.578', 'de56906e8e4a1c098a98aed3', 'c2263ca46dce14a49f03674f', 'Greetings ', 'Gabriel Delight', 'shareLink/de56906e8e4a1c098a98aed3', NULL, NULL, NULL),
(121, '098445d55eafcde68e699a00', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your post', '2022-04-05 15:07:06.901', '559946f3e20fed74b80f7e1a', 'c2585b15e1bbc09bb86000e8', 'Awesome creed  video', 'Gabriel Delight', 'viewVideoPostDetails/559946f3e20fed74b80f7e1a', NULL, 'fa fa-question', NULL),
(122, 'be3b4c13038ffebfaee271ff', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Replied to your comment', '2022-04-05 15:16:26.442', 'a88ef4d0114cb15ab9c08650', 'c2263ca46dce14a49f03674f', 'Hehe his app is cool brah', 'Gabriel Delight', 'replyComment/a88ef4d0114cb15ab9c08650', NULL, NULL, NULL),
(123, 'b127e97a3eceb40e41596e3f', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Replied to your comment', '2022-04-05 15:16:39.055', 'a88ef4d0114cb15ab9c08650', 'c2263ca46dce14a49f03674f', 'Wee\r\nlive ettt', 'Gabriel Delight', 'replyComment/a88ef4d0114cb15ab9c08650', NULL, NULL, NULL),
(124, '8600d8a24174204e8720f2e7', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-04-05 17:00:52.970', NULL, '3ec1e3144312a90089fb42f2', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(125, 'c7233e4cd76b03e7b3c72424', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Tagged you on a post', '2022-04-05 17:53:06.463', '0fbcca21e4002f2320047499', 'c2263ca46dce14a49f03674f', 'This is awesome brother', 'Gabriel Delight', 'viewImagePostDetails/0fbcca21e4002f2320047499', NULL, 'fa fa-tags', NULL),
(126, '7b218c48bf10dea10a16ddc5', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Tagged you on a post', '2022-04-05 17:53:06.466', '0fbcca21e4002f2320047499', 'c2585b15e1bbc09bb86000e8', 'This is awesome brother', 'Gabriel Delight', 'viewImagePostDetails/0fbcca21e4002f2320047499', NULL, 'fa fa-check', '#bdbdbd'),
(127, '3ecd37cd560c7c2f346f8057', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Tagged you on a post', '2022-04-05 17:53:06.468', '0fbcca21e4002f2320047499', '3ec1e3144312a90089fb42f2', 'This is awesome brother', 'Gabriel Delight', 'viewImagePostDetails/0fbcca21e4002f2320047499', NULL, 'fa fa-tags', NULL),
(128, '20a7fda357919ccafd126d5d', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Reacted to your comment', '2022-04-05 18:03:50.364', 'ae2871a6669b97b9692c378a', 'c2263ca46dce14a49f03674f', 'hellodsdsdsdsdsdsd', 'Plog app', 'viewImagePostDetails/aa33914cccce78a9c092054c', NULL, 'fa fa-question', NULL),
(129, '05bed64998c598cb6486345c', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your post', '2022-04-05 18:04:17.952', 'aa33914cccce78a9c092054c', 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'viewImagePostDetails/aa33914cccce78a9c092054c', NULL, 'fa fa-question', NULL),
(130, '8a1a7c8ab68a96b100249fb9', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your comment', '2022-04-05 18:07:20.091', 'ae2871a6669b97b9692c378a', 'c2263ca46dce14a49f03674f', 'hellodsdsdsdsdsdsd', 'Gabriel Delight', 'viewImagePostDetails/aa33914cccce78a9c092054c', NULL, 'fa fa-question', NULL),
(131, '00a443da1bd062f0dbdfb955', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Commented on your post', '2022-04-05 18:07:40.042', 'aa33914cccce78a9c092054c', 'c2585b15e1bbc09bb86000e8', 'This is dope', 'Gabriel Delight', 'viewImagePostDetails/aa33914cccce78a9c092054c', NULL, NULL, NULL),
(132, '8c35f2777aa9e4acd184f789', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Reacted to your comment', '2022-04-05 18:10:07.390', 'ae2871a6669b97b9692c378a', 'c2263ca46dce14a49f03674f', 'hellodsdsdsdsdsdsd', 'Plog app', 'viewImagePostDetails/aa33914cccce78a9c092054c', NULL, 'fa fa-question', NULL),
(133, '4326e505395e5e3f6b1467cb', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Reacted to your comment', '2022-04-05 18:10:12.891', '2649a605c9d6188bb813b347', '9627470f246cdb74266641dd', 'This is dope', 'Plog app', 'viewImagePostDetails/aa33914cccce78a9c092054c', NULL, 'fa fa-question', NULL),
(134, '06840522042b87599eb8ba0a', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Reacted to your comment', '2022-04-05 18:14:46.405', '2649a605c9d6188bb813b347', '9627470f246cdb74266641dd', 'This is dope', 'Plog app', 'viewImagePostDetails/aa33914cccce78a9c092054c', NULL, 'fa fa-question', NULL),
(135, 'b31153a6aa2d34d2f6862e63', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your post', '2022-04-05 18:55:15.931', 'fb3da22e2d916cc05f9b074a', 'c2585b15e1bbc09bb86000e8', 'Awesome', 'Gabriel Delight', 'shareLink/fb3da22e2d916cc05f9b074a', NULL, 'fa fa-question', NULL),
(136, 'ec7d60204af238fe991f2dd0', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-04-05 22:36:47.203', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(137, 'fcb7509564a4bd3ba37780d1', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-04-05 22:36:48.073', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(138, 'a0551f4632cd5ff1e1431899', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-04-05 23:22:31.028', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(139, 'b3442c9b4cb59d6897821c41', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-04-05 23:22:31.665', NULL, '3ec1e3144312a90089fb42f2', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(140, 'd9017b3c387a59714d3fe459', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-04-05 23:22:32.910', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(141, 'fc734d8cb45b4955fe48164f', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Commented on your post', '2022-04-06 14:06:00.507', '5137a9062b6822d8458398bb', 'c2585b15e1bbc09bb86000e8', 'heyy', 'Gabriel Delight', 'viewImagePostDetails/5137a9062b6822d8458398bb', NULL, NULL, NULL),
(142, '79f20c25244cb5e96f4c9a01', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Commented on your post', '2022-04-06 14:06:09.604', '5137a9062b6822d8458398bb', 'c2585b15e1bbc09bb86000e8', 'tree', 'Gabriel Delight', 'viewImagePostDetails/5137a9062b6822d8458398bb', NULL, NULL, NULL),
(143, '169012fd21c0952cb9822b8f', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-04-06 14:07:39.692', NULL, '3ec1e3144312a90089fb42f2', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(144, '89b9c7c5171f812aafd2a1e1', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-04-09 07:57:56.760', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(145, '4935d4499979f7e8991bce0b', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-04-09 07:57:57.398', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(146, 'c1aac4071a4fff8f8c75ae98', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Reacted to your post', '2022-04-09 08:22:26.260', 'aaf6c64bce315fcfd7743d25', '9627470f246cdb74266641dd', 'Hello', 'Plog app', 'viewImagePostDetails/aaf6c64bce315fcfd7743d25', NULL, 'fa fa-question', NULL),
(147, 'e5f00d2a77b15d57ece3df45', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Reacted to your post', '2022-04-09 08:23:02.609', '0fbcca21e4002f2320047499', '9627470f246cdb74266641dd', 'This is awesome brother', 'Plog app', 'viewImagePostDetails/0fbcca21e4002f2320047499', NULL, 'fa fa-question', NULL),
(148, '168c547d22682af9031e64f9', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Reacted to your post', '2022-04-09 08:24:33.334', 'aaf6c64bce315fcfd7743d25', '9627470f246cdb74266641dd', 'Hello', 'Plog app', 'viewImagePostDetails/aaf6c64bce315fcfd7743d25', NULL, 'fa fa-question', NULL),
(149, '812023d72f292b14d89d2e0d', 'c2585b15e1bbc09bb86000e8', 'plogapp-1646132550991.jpeg', 'Reacted to your post', '2022-04-09 08:27:18.740', 'ccd035372ae42c83b1123f08', '9627470f246cdb74266641dd', 'he  llo wolrd how \n\nare you doing \n\nhuh&gt; we miss', 'Plog app', 'viewImagePostDetails/ccd035372ae42c83b1123f08', NULL, 'fa fa-check', '#bdbdbd'),
(150, 'fdb663949ccb006b404f384a', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your post', '2022-04-09 15:47:10.447', '559946f3e20fed74b80f7e1a', 'c2585b15e1bbc09bb86000e8', 'Awesome creed  video', 'Gabriel Delight', 'viewVideoPostDetails/559946f3e20fed74b80f7e1a', NULL, 'fa fa-question', NULL),
(151, '8002e33282162234226d39e6', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-04-09 16:14:07.905', NULL, 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(152, 'c441db06fa90d82e5c0d935d', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-04-09 16:18:35.714', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(153, '92eb3f99f6a3ef7eabb1cbbc', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-04-09 16:19:06.223', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(154, '3eec8d9258311ac52ff967fd', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-04-09 17:38:47.411', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(155, '99a2b82e3f23d841044770a2', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Commented on your post', '2022-04-09 17:48:37.142', 'c15e34ef07523d7e3f0ae1d9', 'c2263ca46dce14a49f03674f', 'hello ', 'Gabriel Delight', 'viewImagePostDetails/c15e34ef07523d7e3f0ae1d9', NULL, NULL, NULL),
(156, '22e0e4266267f809a398596d', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your post', '2022-04-09 18:21:26.635', '559946f3e20fed74b80f7e1a', 'c2585b15e1bbc09bb86000e8', 'Awesome creed  video', 'Gabriel Delight', 'viewVideoPostDetails/559946f3e20fed74b80f7e1a', NULL, 'fa fa-question', NULL),
(157, '11615cbed51f40ca6611a2ac', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Commented on your post', '2022-04-09 18:21:33.660', '559946f3e20fed74b80f7e1a', 'c2585b15e1bbc09bb86000e8', 'Awesome ro', 'Gabriel Delight', 'viewVideoPostDetails/559946f3e20fed74b80f7e1a', NULL, NULL, NULL),
(158, '9d7380e947c32f8491ed2be0', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your comment', '2022-04-09 18:28:36.800', '20e241de3858df2a74f0c6ea', 'c2585b15e1bbc09bb86000e8', 'ool', 'Gabriel Delight', '', NULL, 'fa fa-question', NULL),
(159, '4ec80a2a203aa763484a96ad', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Commented on your post', '2022-04-09 18:28:43.464', 'fb3da22e2d916cc05f9b074a', 'c2585b15e1bbc09bb86000e8', 'Hell', 'Gabriel Delight', 'shareLink/fb3da22e2d916cc05f9b074a', NULL, NULL, NULL),
(160, '2c35f5c2af9258cf9b1234ff', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your post', '2022-04-09 18:41:20.771', '2e9d075c688957d58de7e468', 'c2585b15e1bbc09bb86000e8', '', 'Gabriel Delight', 'viewImagePostDetails/2e9d075c688957d58de7e468', NULL, 'fa fa-question', NULL),
(161, '80e97adc6f3798658265d04e', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Started following you', '2022-04-09 19:43:10.615', NULL, 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'profile/9627470f246cdb74266641dd', NULL, 'fa fa-question', NULL),
(162, 'c458dc8d5056a0881e46f8a0', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your post', '2022-04-11 13:56:17.001', '6ac6cc7f5138b99072bd2704', 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'viewImagePostDetails/6ac6cc7f5138b99072bd2704', NULL, 'fa fa-question', NULL),
(163, '9997f2abcf982460035a0d32', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your post', '2022-04-11 14:00:42.210', '401baddfcca4b3d417beaa2e', 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'viewImagePostDetails/401baddfcca4b3d417beaa2e', NULL, 'fa fa-question', NULL),
(164, 'abc426255604c9081614b898', '9627470f246cdb74266641dd', 'plogapp-1646131942816.jpeg', 'Reacted to your post', '2022-04-12 15:45:16.251', '49345c95f5eb0208392595df', 'c2263ca46dce14a49f03674f', '', 'Gabriel Delight', 'viewVideoPostDetails/49345c95f5eb0208392595df', NULL, 'fa fa-question', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sortDate` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image1` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image2` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imageLength` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postType` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postImageId` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `possterName` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `posterNickName` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `posterGenderType` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `posertFollowing` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `posterPostLikes` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verified` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hideSLides` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reaction` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isLike` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commentlength` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Initcomment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastCommentAvatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hideLastComment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commentImage` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commentName` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verifiedComment` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commentWidth` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commentHeight` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shareLength` int(11) DEFAULT 0,
  `posterFollower` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `posterFollowing` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `posterBio` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isDisabled` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `checkPost` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reactionLength` int(11) DEFAULT NULL,
  `ownerPrimaryid` int(11) DEFAULT NULL,
  `tag_list` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `views` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `_id`, `sortDate`, `avatar`, `description`, `image`, `image1`, `image2`, `imageLength`, `video`, `postType`, `date`, `postImageId`, `possterName`, `posterNickName`, `posterGenderType`, `posertFollowing`, `posterPostLikes`, `verified`, `hideSLides`, `reaction`, `isLike`, `owner`, `commentlength`, `Initcomment`, `lastCommentAvatar`, `hideLastComment`, `commentImage`, `commentName`, `verifiedComment`, `commentWidth`, `commentHeight`, `shareLength`, `posterFollower`, `posterFollowing`, `posterBio`, `isDisabled`, `Email`, `checkPost`, `reactionLength`, `ownerPrimaryid`, `tag_list`, `views`) VALUES
(1, '7a6afa2b868847d0e5fe582a', '2022-03-01 11:47:01.984', 'plogapp-1646131942816.jpeg', '', 'plogapp-1646131621765.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 11:47:01 AM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', NULL, NULL, NULL, NULL, 'none', '', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, NULL, 1, '', ''),
(2, '51347efdaf64ad606b5c4cd7', '2022-03-01 12:05:10.691', 'plogapp-1646132550991.jpeg', '', 'plogapp-1646132710681.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 12:05:10 PM', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'plog', NULL, NULL, NULL, NULL, 'none', '', NULL, 'c2585b15e1bbc09bb86000e8', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'I am 0plog', NULL, NULL, NULL, NULL, 2, '', ''),
(3, '748e7b816d660b6c2ac69802', '2022-03-01 12:14:19.952', 'plogapp-1646131942816.jpeg', 'video', NULL, NULL, NULL, NULL, 'plogapp-1646133259251.mp4', 'video', ' 1 MAR,  2022 at 12:14:19 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', NULL, NULL, NULL, NULL, NULL, '1', NULL, '9627470f246cdb74266641dd', '4', 'I love t ????????????????????????', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 1, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', '1'),
(4, '261e68a0ac16f480ef24de45', '2022-03-01 12:23:10.947', 'plogapp-1646131942816.jpeg', 'Robot', 'plogapp-1646133790862.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 12:23:10 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', NULL, NULL, NULL, NULL, 'none', '', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, NULL, 1, '', ''),
(5, '1231321f284700b8170b8004', '2022-03-01 12:23:48.031', 'plogapp-1646131942816.jpeg', 'Nature', 'plogapp-1646133828013.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 12:23:48 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', NULL, NULL, NULL, NULL, 'none', '', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 0, 1, '', ''),
(6, 'baca76f4d50d7da4db472c3e', '2022-03-01 12:24:32.834', 'plogapp-1646131942816.jpeg', '', 'plogapp-1646133872799.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 12:24:32 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', NULL, NULL, NULL, NULL, 'none', '3,1', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 2, 1, '', ''),
(7, 'a88fe5113a138e1709095a40', '2022-03-01 12:27:57.599', 'plogapp-1646131942816.jpeg', '', 'plogapp-1646134077387.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 12:27:57 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', NULL, NULL, NULL, NULL, 'none', '3,1', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 2, 1, '', ''),
(8, '82d68e5192831276429f42f4', '2022-03-01 12:30:12.743', 'plogapp-1646131942816.jpeg', '', 'plogapp-1646134212713.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 12:30:12 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', NULL, NULL, NULL, NULL, 'none', '1', NULL, '9627470f246cdb74266641dd', '2', 'nice app', 'plogapp-1646904681763.jpeg', 'block', '3ec1e3144312a90089fb42f2', 'User1 User1', 'null', '20', '20', 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', ''),
(9, 'd1021315dd511e732b0e6fe1', '2022-03-01 12:33:51.334', 'plogapp-1646131942816.jpeg', '', 'plogapp-1646134431305.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 12:33:51 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', NULL, NULL, NULL, NULL, 'none', '1', NULL, '9627470f246cdb74266641dd', '1', NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', ''),
(10, '194b31fbbb17f3d51884027f', '2022-03-01 12:38:32.179', 'plogapp-1646131942816.jpeg', '', 'plogapp-1646134712124.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 12:38:32 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', NULL, NULL, NULL, NULL, 'none', '1,3', NULL, '9627470f246cdb74266641dd', '1', 'I love this app', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 2, 1, '', ''),
(11, 'c23bcab0c4ac46ce29b84149', '2022-03-01 12:39:07.850', 'plogapp-1646131942816.jpeg', '', 'plogapp-1646134747831.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 12:39:07 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', NULL, NULL, NULL, NULL, 'none', '', NULL, '9627470f246cdb74266641dd', '2', 'Hello ', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 0, 1, '', ''),
(12, '2e9d075c688957d58de7e468', '2022-03-01 12:51:12.529', 'plogapp-1646132550991.jpeg', '', 'plogapp-1646135472371.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 12:51:12 PM', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'plog', NULL, NULL, NULL, NULL, 'none', '1', NULL, 'c2585b15e1bbc09bb86000e8', '1', 'fddfd', 'plogapp-1647097667791.jpg', 'block', 'c2263ca46dce14a49f03674f', 'terry Leo', 'null', '20', '20', 0, NULL, NULL, 'I am 0plog', NULL, NULL, NULL, 1, 2, '', ''),
(13, '5137a9062b6822d8458398bb', '2022-03-01 12:51:36.905', 'plogapp-1646132550991.jpeg', '', 'plogapp-1646135496847.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 12:51:36 PM', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'plog', NULL, NULL, NULL, NULL, 'none', '', NULL, 'c2585b15e1bbc09bb86000e8', '1', 'tree', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 0, NULL, NULL, 'I am 0plog', NULL, NULL, NULL, NULL, 2, '', ''),
(14, '139daa1c6aa9365430dbb3e2', '2022-03-01 12:52:15.520', 'plogapp-1646132550991.jpeg', '', 'plogapp-1646135535500.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 12:52:15 PM', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'plog', NULL, NULL, NULL, NULL, 'none', '1', NULL, 'c2585b15e1bbc09bb86000e8', '1', 'Tree', 'plogapp-1647097667791.jpg', 'block', 'c2263ca46dce14a49f03674f', 'terry Leo', 'null', '20', '20', 0, NULL, NULL, 'I am 0plog', NULL, NULL, NULL, 1, 2, '', ''),
(15, '1bda0157c8ad26f9abcebf6a', '2022-03-01 12:52:49.382', 'plogapp-1646132550991.jpeg', '', 'plogapp-1646135569354.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 12:52:49 PM', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'plog', NULL, NULL, NULL, NULL, 'none', '1', NULL, 'c2585b15e1bbc09bb86000e8', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'I am 0plog', NULL, NULL, NULL, 1, 2, '', ''),
(16, '7e321f8fd96adb575ad502c3', '2022-03-01 12:53:53.895', 'plogapp-1646132550991.jpeg', '', 'plogapp-1646135633879.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 12:53:53 PM', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'plog', NULL, NULL, NULL, NULL, 'none', '4', NULL, 'c2585b15e1bbc09bb86000e8', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 'I am 0plog', NULL, NULL, NULL, 1, 2, '', ''),
(17, 'b1b104968cefd3644a3d0589', '2022-03-01 12:54:22.790', 'plogapp-1646132550991.jpeg', '', 'plogapp-1646135662774.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 12:54:22 PM', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'plog', NULL, NULL, NULL, NULL, 'none', '1', NULL, 'c2585b15e1bbc09bb86000e8', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'I am 0plog', NULL, NULL, NULL, 1, 2, '', ''),
(18, '10a2323b8354be56bcd238fb', '2022-03-01 12:54:58.163', 'plogapp-1646132550991.jpeg', '', 'plogapp-1646135698155.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 12:54:58 PM', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'plog', NULL, NULL, NULL, NULL, 'none', '1', NULL, 'c2585b15e1bbc09bb86000e8', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 'I am 0plog', NULL, NULL, NULL, 1, 2, '', ''),
(19, 'aa33914cccce78a9c092054c', '2022-03-01 12:56:07.319', 'plogapp-1646132550991.jpeg', '', 'plogapp-1646135767304.jpeg', '', '', '1', NULL, 'image', ' 1 MAR,  2022 at 12:56:07 PM', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'plog', NULL, NULL, NULL, NULL, 'none', '1', NULL, 'c2585b15e1bbc09bb86000e8', '1', 'This is dope', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 0, NULL, NULL, 'I am 0plog', NULL, NULL, NULL, 1, 2, '', ''),
(33, '8b1af196177a182283e9800a', '2022-03-01 17:02:17.537', 'plogapp-1646131942816.jpeg', '????????????????????????????????????????????????????', NULL, NULL, NULL, NULL, NULL, 'text', ' 1 MAR,  2022 at 5:02:17 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', NULL, NULL, NULL, NULL, NULL, '1', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', ''),
(34, '24585135f38985f9d3d325d3', '2022-03-01 17:16:19.167', 'plogapp-1646131942816.jpeg', '🙂😊😁🙂🙃🤪', NULL, NULL, NULL, NULL, NULL, 'text', ' 1 MAR,  2022 at 5:16:19 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', NULL, NULL, NULL, NULL, NULL, '3', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', ''),
(35, '0e0bf5c3abfe407cdb846613', '2022-03-01 17:41:32.339', 'plogapp-1646131942816.jpeg', '????????????????????????????', NULL, NULL, NULL, NULL, NULL, 'text', ' 1 MAR,  2022 at 5:41:32 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', NULL, NULL, NULL, NULL, NULL, '', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 0, 1, '', ''),
(36, '92f0b824570cf1caf78c0d0a', '2022-03-02 15:57:39.933', 'plogapp-1646131942816.jpeg', '#vibes', NULL, NULL, NULL, NULL, 'plogapp-1646233059194.mp4', 'video', ' 2 MAR,  2022 at 3:57:39 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', NULL, NULL, NULL, NULL, NULL, '4', NULL, '9627470f246cdb74266641dd', '3', 'sweet', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', '1'),
(37, 'd8d475c6547f93c8c08e5e6e', '2022-03-04 12:25:29.968', 'plogapp-1646131942816.jpeg', 'Technology affects the way individuals communicate, learn, and think. It helps society and determines how people interact with each other on a daily basis. Technology plays an important role in society today. It has positive and negative effects on the world and it impacts daily lives.7 Nov 2019\n', NULL, NULL, NULL, NULL, NULL, 'text', ' 4 MAR,  2022 at 12:25:28 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'sds sds', NULL, NULL, NULL, NULL, NULL, '1', NULL, '9627470f246cdb74266641dd', '1', 'Hafa', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', ''),
(38, '573d2e4679e86dd347ff3c95', '2022-03-04 16:56:32.997', 'plogapp-1646131942816.jpeg', 'Ukrainian President Volodymyr Zelensky reiterated his call for direct talks with Russian President Vladimir Putin to end the invasion of his country, the U.S. Embassy in Kyiv said Russia’s overnight attack on a nuclear power plant amounted to “a war crime.”\n\nIn his first news conference since the start of Russia’s invasion of Ukraine, Zelensky on Thursday repeated his desire to have direct talks with Putin, who has rebuffed the Ukrainian president’s request before and during the invasion.\n\nZelensky made his appeal despite saying he is living through “a nightmare” and “cannot even imagine the type of man who would plan such acts.”\n\n“It’s not that I want to talk to Putin. I need to talk to Putin. The world', NULL, NULL, NULL, NULL, NULL, 'text', ' 4 MAR,  2022 at 4:56:32 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'sds sds', NULL, NULL, NULL, NULL, NULL, '3,1', NULL, '9627470f246cdb74266641dd', '1', 'hmm', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 2, 1, '', ''),
(39, 'cfc10cde03c60596d53f0b84', '2022-03-04 17:04:03.902', 'plogapp-1646131942816.jpeg', '✌️????????????????Ukrainian President Volodymyr Zelensky reiterated his call for direct talks with Russian President Vladimir Putin to end the invasion of his country, the U.S. Embassy in Kyiv said Russia’s overnight attack on a nuclear power plant amounted to “a war crime.”\r\n\r\nIn his ????????????????????????first news conference since the start of Russia’s invasion of Ukraine, Zelen', NULL, NULL, NULL, NULL, NULL, 'text', ' 4 MAR,  2022 at 5:04:03 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'sds sds', NULL, NULL, NULL, NULL, NULL, '3,1', NULL, '9627470f246cdb74266641dd', '1', 'hello world ????????', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 2, 1, '', ''),
(40, 'cd3133f41536796f82aa7d38', '2022-03-06 18:50:06.573', 'plogapp-1646131942816.jpeg', '', 'plogapp-1646589006310.jpeg', '', '', '1', NULL, 'image', ' 6 MAR,  2022 at 6:50:06 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, 'none', '1', NULL, '9627470f246cdb74266641dd', '1', 'Hello', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', ''),
(41, '4585f618d3b4ab4aaeee7b74', '2022-03-08 10:06:16.682', 'plogapp-1646131942816.jpeg', '???????????????????? hello', NULL, NULL, NULL, NULL, NULL, 'text', ' 8 MAR,  2022 at 10:06:16 AM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, NULL, 1, '', ''),
(42, '8a07c8e04267d22e5ea7626c', '2022-03-08 11:09:46.596', 'plogapp-1646904681763.jpeg', '', 'plogapp-1646734186289.jpeg', '', '', '1', NULL, 'image', ' 8 MAR,  2022 at 11:09:46 AM', '3ec1e3144312a90089fb42f2', 'User1 User1', 'user_test', NULL, NULL, NULL, NULL, 'none', '', NULL, '3ec1e3144312a90089fb42f2', '6', 'Hello wolrd', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 0, NULL, NULL, 'I love plogapp', NULL, NULL, NULL, NULL, 3, '', ''),
(43, '5ad964576eae43a711c3ebaf', '2022-03-08 11:12:22.324', 'plogapp-1646904681763.jpeg', '', 'plogapp-1646734342262.jpeg', '', '', '1', NULL, 'image', ' 8 MAR,  2022 at 11:12:22 AM', '3ec1e3144312a90089fb42f2', 'User1 User1', 'user_test', NULL, NULL, NULL, NULL, 'none', '1', NULL, '3ec1e3144312a90089fb42f2', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'I love plogapp', NULL, NULL, NULL, 1, 3, '', ''),
(44, '925cfc734d17d20c3866aff2', '2022-03-08 12:35:52.732', 'plogapp-1646131942816.jpeg', '????????????????????????????☹☹????????????????????????????????????????????????????????????????????????', NULL, NULL, NULL, NULL, NULL, 'text', ' 8 MAR,  2022 at 12:35:52 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, NULL, 1, '', ''),
(46, '665390293c777a49701d065f', '2022-03-10 15:20:21.206', 'plogapp-1646904681763.jpeg', 'Setting up Font #Awesome can be as simple as adding two lines of code to your website, or you can be a pro and customize the LESS yourself! Font Awesome even plays nicely with Bootstrap!', NULL, NULL, NULL, NULL, NULL, 'text', ' 10 MAR,  2022 at 3:20:21 PM', '3ec1e3144312a90089fb42f2', 'User1 User1', 'user_test', NULL, NULL, NULL, NULL, NULL, '1', NULL, '3ec1e3144312a90089fb42f2', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'I love plogapp', NULL, NULL, NULL, 1, 3, '', ''),
(47, '428c86fd8b252fdd63633013', '2022-03-11 11:52:36.515', 'plogapp-1646904681763.jpeg', '#', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 11:52:36 AM', '3ec1e3144312a90089fb42f2', 'User1 User1', 'user_test', NULL, NULL, NULL, NULL, NULL, '', NULL, '3ec1e3144312a90089fb42f2', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'I love plogapp', NULL, NULL, NULL, NULL, 3, '', ''),
(48, 'cb0d4f902918186e2d058574', '2022-03-11 11:52:40.395', 'plogapp-1646904681763.jpeg', '#', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 11:52:40 AM', '3ec1e3144312a90089fb42f2', 'User1 User1', 'user_test', NULL, NULL, NULL, NULL, NULL, '', NULL, '3ec1e3144312a90089fb42f2', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'I love plogapp', NULL, NULL, NULL, NULL, 3, '', ''),
(49, '2572359acd81c3eb0fbe08ba', '2022-03-11 17:14:06.040', 'plogapp-1646131942816.jpeg', 'welcome to my page www.facebook.com', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 5:14:05 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, NULL, 1, '', ''),
(50, 'd4ae3b13eff0b009fc7c1520', '2022-03-11 17:17:14.929', 'plogapp-1646131942816.jpeg', 'like www.tre.com', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 5:17:14 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '1', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', ''),
(51, '25d8e820d59f1d965450f819', '2022-03-11 17:31:23.596', 'plogapp-1646131942816.jpeg', 'Hello', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 5:31:23 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, NULL, 1, '', ''),
(52, '1bcd3715fe4b6d60b1fa16b7', '2022-03-11 17:31:44.391', 'plogapp-1646131942816.jpeg', 'reeeeeeeeeee', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 5:31:44 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, NULL, 1, '', ''),
(53, '820d3a02a770096f88454249', '2022-03-11 17:32:45.638', 'plogapp-1646131942816.jpeg', 'tree', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 5:32:45 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '1', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', ''),
(54, 'ec073f8ee8aaa3972d6befbf', '2022-03-11 17:33:51.161', 'plogapp-1646131942816.jpeg', 'tree', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 5:33:51 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, NULL, 1, '', ''),
(55, '7d4d6c4c94922b46e9a083a9', '2022-03-11 17:34:10.128', 'plogapp-1646131942816.jpeg', 'treedd', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 5:34:10 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '', NULL, '9627470f246cdb74266641dd', '1', 'Hello', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, NULL, 1, '', ''),
(56, '4ead2f416f7138fcc7741911', '2022-03-11 17:35:17.536', 'plogapp-1646131942816.jpeg', 'treeeeeeeeeeeeeee', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 5:35:17 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '1', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', ''),
(57, '1e421fe30d12c7bf749e0028', '2022-03-11 17:36:47.359', 'plogapp-1646131942816.jpeg', 'tree', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 5:36:47 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, NULL, 1, '', ''),
(58, '57b9a387b2ea7f8a195c3fd3', '2022-03-11 17:37:55.056', 'plogapp-1646131942816.jpeg', 'tree', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 5:37:55 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, NULL, 1, '', ''),
(59, '3f6ce0d93cfe0eeabc3622a2', '2022-03-11 18:46:19.219', 'plogapp-1646131942816.jpeg', '#helllo this is my like www.plogapp.com', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 6:46:19 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '1', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', ''),
(60, 'abb0f341e47915b319a43e70', '2022-03-11 18:52:56.824', 'plogapp-1646131942816.jpeg', 'hello dfdf', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 6:52:56 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '1', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', ''),
(61, '07ec9f52037f1bab04996950', '2022-03-11 19:45:16.003', 'plogapp-1646131942816.jpeg', 'clean', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 7:45:15 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, NULL, 1, '', ''),
(63, 'abd6164023bc8bc2bb5b3a54', '2022-03-11 19:48:23.093', 'plogapp-1646131942816.jpeg', 'hey', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 7:48:23 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, NULL, 1, '', ''),
(64, 'caed445f1dd2d841dbf7ea23', '2022-03-11 19:50:39.964', 'plogapp-1646131942816.jpeg', 'hello #test www.plogapp.com', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 7:50:39 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '1', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', ''),
(66, '6c1b96535715ef5810b7dae5', '2022-03-11 19:53:09.163', 'plogapp-1646131942816.jpeg', '', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 7:53:09 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '1', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', ''),
(67, '1819dc3e7167c4f79a911da7', '2022-03-11 19:57:28.067', 'plogapp-1646131942816.jpeg', '', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 7:57:28 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '1', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', ''),
(68, 'c4ff67895ce4bdf487458c02', '2022-03-11 20:01:20.003', 'plogapp-1646131942816.jpeg', '<script>alert(\'hello world\')</script>', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 8:01:19 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '1', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', ''),
(69, '3fab7977670f6b803f70fb4a', '2022-03-11 20:13:39.965', 'plogapp-1646131942816.jpeg', 'hello wolrd  how are you href=\'hello\' ', NULL, NULL, NULL, NULL, NULL, 'text', ' 11 MAR,  2022 at 8:13:39 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '', NULL, '9627470f246cdb74266641dd', '1', 'sddsds', 'plogapp-1646132550991.jpeg', 'block', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'null', '20', '20', 1, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, NULL, 1, '', ''),
(70, '3fc4c1f246251b6fa64a0bb5', '2022-03-14 12:54:19.998', 'plogapp-1647097667791.jpg', 'Awesome', NULL, NULL, NULL, NULL, NULL, 'text', '2022-3-14T12:54:19', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', NULL, NULL, NULL, NULL, NULL, '4', NULL, 'c2263ca46dce14a49f03674f', '2', 'COol', 'plogapp-1647097667791.jpg', 'block', 'c2263ca46dce14a49f03674f', 'terry Leo', 'null', '20', '20', 0, NULL, NULL, '', NULL, NULL, NULL, 1, 4, '', ''),
(71, 'd48b180d4f02ed24da8f89dc', '2022-03-14 17:32:19.800', 'plogapp-1647097667791.jpg', '', 'plogapp-1647275539664.jpeg', '', '', '1', NULL, 'image', '2022-3-14T17:31:30:39', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', NULL, NULL, NULL, NULL, 'none', '4', NULL, 'c2263ca46dce14a49f03674f', '36', 'Good', 'plogapp-1647097667791.jpg', 'block', 'c2263ca46dce14a49f03674f', 'terry Leo', 'null', '20', '20', 0, NULL, NULL, '', NULL, NULL, NULL, 1, 4, '', ''),
(72, 'a3c2659d263a736b5fc59f01', '2022-03-14 18:12:38.446', 'plogapp-1647097667791.jpg', 'How fr universe', NULL, NULL, NULL, NULL, NULL, 'text', '2022-3-14T18:12:38:446', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', NULL, NULL, NULL, NULL, NULL, '4', NULL, 'c2263ca46dce14a49f03674f', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '', NULL, NULL, NULL, 1, 4, '', ''),
(73, '49345c95f5eb0208392595df', '2022-03-14 18:18:26.785', 'plogapp-1647097667791.jpg', '', NULL, NULL, NULL, NULL, 'plogapp-1647278306269.mp4', 'video', '2022-3-14T18:18:26:784', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', NULL, NULL, NULL, NULL, NULL, '4,1', NULL, 'c2263ca46dce14a49f03674f', '1', 'Badest', 'plogapp-1647097667791.jpg', 'block', 'c2263ca46dce14a49f03674f', 'terry Leo', 'null', '20', '20', 2, NULL, NULL, '', NULL, NULL, NULL, 2, 4, '', '1'),
(74, '61f9e02839f1ee4b01d3f4b1', '2022-03-16 09:30:05.202', 'plogapp-1647097667791.jpg', '#welcome to www.plogapp.com  welcome to the plc dom tre tree', NULL, NULL, NULL, NULL, NULL, 'text', '2022-3-16T9:30:5:201', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', NULL, NULL, NULL, NULL, NULL, '4', NULL, 'c2263ca46dce14a49f03674f', '1', 'treee', 'plogapp-1647097667791.jpg', 'block', 'c2263ca46dce14a49f03674f', 'terry Leo', 'null', '20', '20', 0, NULL, NULL, 'This is very cool', NULL, NULL, NULL, 1, 4, '', ''),
(75, '5a565c55b88ee4aab7cb4f79', '2022-03-17 19:54:53.237', 'plogapp-1647097667791.jpg', '', 'plogapp-1647543292551.jpeg', 'plogapp-1647543350384.jpeg', 'plogapp-1647543358335.jpeg', '3', NULL, 'image', '2022-3-17T19:54:53:235', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', NULL, NULL, NULL, NULL, 'block', '', NULL, 'c2263ca46dce14a49f03674f', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'This is very cool', NULL, NULL, NULL, NULL, 4, '', ''),
(76, '45cabcf985ea3c95ddff0821', '2022-03-18 09:18:03.776', 'plogapp-1647097667791.jpg', '', 'plogapp-1647591483739.jpeg', 'plogapp-1647591519284.jpeg', '', '2', NULL, 'image', '2022-3-18T9:18:3:774', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', NULL, NULL, NULL, NULL, 'block', '4', NULL, 'c2263ca46dce14a49f03674f', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'This is very cool', NULL, NULL, NULL, 1, 4, '', ''),
(77, '6ac6cc7f5138b99072bd2704', '2022-03-18 10:15:11.574', 'plogapp-1647097667791.jpg', '', 'plogapp-1647594911453.jpeg', 'plogapp-1647594988366.jpeg', '', '2', NULL, 'image', '2022-3-18T10:15:11:571', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', NULL, NULL, NULL, NULL, 'block', '4,1', NULL, 'c2263ca46dce14a49f03674f', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'This is very cool', NULL, NULL, NULL, 2, 4, '', ''),
(78, '7af2711d087c930ad4911dd6', '2022-03-18 10:22:10.858', 'plogapp-1647097667791.jpg', '', 'plogapp-1647595330764.jpeg', 'plogapp-1647595344122.jpeg', 'plogapp-1647595371926.jpeg', '3', NULL, 'image', '2022-3-18T10:22:10:855', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', NULL, NULL, NULL, NULL, 'block', '', NULL, 'c2263ca46dce14a49f03674f', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'This is very cool', NULL, NULL, NULL, NULL, 4, '', ''),
(79, 'b59c3d51bf75a59360cd9fee', '2022-03-18 11:38:17.503', 'plogapp-1647097667791.jpg', '', 'plogapp-1647599897101.jpeg', '', '', '1', NULL, 'image', '2022-3-18T11:38:17:498', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', NULL, NULL, NULL, NULL, 'none', '4', NULL, 'c2263ca46dce14a49f03674f', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'This is very cool', NULL, NULL, NULL, 1, 4, '', ''),
(80, '8b586497fca427cc8416a6ff', '2022-03-18 12:08:23.489', 'plogapp-1647097667791.jpg', '', 'plogapp-1647601703430.jpeg', '', '', '1', NULL, 'image', '2022-3-18T12:8:23:441', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', NULL, NULL, NULL, NULL, 'none', '', NULL, 'c2263ca46dce14a49f03674f', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'This is very cool', NULL, NULL, NULL, NULL, 4, '', ''),
(81, 'c15e34ef07523d7e3f0ae1d9', '2022-03-18 12:27:41.360', 'plogapp-1647097667791.jpg', '', 'plogapp-1647602861346.jpeg', '', '', '1', NULL, 'image', '2022-3-18T12:27:41:355', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', NULL, NULL, NULL, NULL, 'none', '4', NULL, 'c2263ca46dce14a49f03674f', '1', 'hello ', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 0, NULL, NULL, 'This is very cool', NULL, NULL, NULL, 1, 4, '', ''),
(82, '401baddfcca4b3d417beaa2e', '2022-03-18 12:29:26.555', 'plogapp-1647097667791.jpg', '', 'plogapp-1647602966447.jpeg', '', '', '1', NULL, 'image', '2022-3-18T12:29:26:555', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', NULL, NULL, NULL, NULL, 'none', '1', NULL, 'c2263ca46dce14a49f03674f', '1', 'This is  cool ', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 1, NULL, NULL, 'This is very cool', NULL, NULL, NULL, 1, 4, '', ''),
(83, 'f40c513ad6557065baf1d328', '2022-03-22 18:26:37.114', 'plogapp-1646131942816.jpeg', 'This is really cool\r\nI so much love \r\n\r\nthe app to be frank', 'plogapp-1647969996802.jpeg', '', '', '1', NULL, 'image', '2022-3-22T18:26:37:108', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, 'none', '2,1', NULL, '9627470f246cdb74266641dd', '1', 'Testing ', 'plogapp-1646132550991.jpeg', 'block', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'null', '20', '20', 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 2, 1, '', ''),
(84, '86cacabe51034f853d0e3691', '2022-03-22 21:39:46.840', 'plogapp-1646131942816.jpeg', 'Hello #vibes is cool samuel', NULL, NULL, NULL, NULL, NULL, 'text', '2022-03-22 21:39:46.845', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '1', NULL, '9627470f246cdb74266641dd', '19', 'sample', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', ''),
(88, '559946f3e20fed74b80f7e1a', '2022-04-01 20:40:27.637', 'plogapp-1646132550991.jpeg', 'Awesome creed  video', 'plogapp1648842032969.png', NULL, NULL, NULL, 'plogapp-1648842027417.mp4', 'video', '2022-04-01 20:40:27.637', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'plog', NULL, NULL, NULL, NULL, NULL, '2,1', NULL, 'c2585b15e1bbc09bb86000e8', '1', 'Awesome ro', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 1, NULL, NULL, 'I am 0plog', NULL, NULL, NULL, 2, 2, '', '1'),
(89, 'ccd035372ae42c83b1123f08', '2022-04-05 14:14:27.519', 'plogapp-1646131942816.jpeg', 'he  llo wolrd how \n\nare you doing \n\nhuh&gt; we miss', NULL, NULL, NULL, NULL, NULL, 'text', '2022-04-05 14:14:27.525', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '2', NULL, '9627470f246cdb74266641dd', '1', 'Okay let me say!!!\r\nThe app is really cool at first \r\n\r\nI so much love it', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '', ''),
(90, '0fbcca21e4002f2320047499', '2022-04-05 17:53:06.083', 'plogapp-1646131942816.jpeg', 'This is awesome brother', NULL, NULL, NULL, NULL, NULL, 'text', '2022-04-05 17:53:06.088', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '2', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 1, 1, '4,2,3', ''),
(91, 'aaf6c64bce315fcfd7743d25', '2022-04-05 17:54:23.412', 'plogapp-1646131942816.jpeg', 'Hello', NULL, NULL, NULL, NULL, NULL, 'text', '2022-04-05 17:54:23.418', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '2,1', NULL, '9627470f246cdb74266641dd', '1', 'Cool', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 2, 1, '', ''),
(92, '8f603bc9a5f58e94b32c60ca', '2022-04-09 19:43:27.813', 'plogapp-1646131942816.jpeg', '@treeaaaaaa\n hello how are you', NULL, NULL, NULL, NULL, NULL, 'text', '2022-04-09 19:43:27.817', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '', NULL, '9627470f246cdb74266641dd', NULL, NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 0, 1, '', ''),
(93, '3afe6e81275852a5f67638cc', '2022-04-12 12:35:52.480', 'plogapp-1646131942816.jpeg', '#video', 'plogapp1649763369386.png', NULL, NULL, NULL, 'plogapp-1649763351331.mp4', 'video', '2022-04-12 12:35:52.480', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', NULL, NULL, NULL, NULL, NULL, '', NULL, '9627470f246cdb74266641dd', '1', '#dope man', 'plogapp-1646131942816.jpeg', 'block', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 0, NULL, NULL, 'Hello I love Plogapp', NULL, NULL, NULL, 0, 1, '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `replies`
--

CREATE TABLE `replies` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `lastReplyVerified` longtext NOT NULL,
  `commentorNickName` varchar(255) DEFAULT NULL,
  `mainCommentId` varchar(255) DEFAULT NULL,
  `replylength` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `reaction` varchar(255) NOT NULL,
  `verified` varchar(255) DEFAULT NULL,
  `hidePhoto` varchar(255) DEFAULT NULL,
  `isDisabled` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `reactionLength` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `replies`
--

INSERT INTO `replies` (`id`, `_id`, `comment`, `date`, `owner`, `fullName`, `lastReplyVerified`, `commentorNickName`, `mainCommentId`, `replylength`, `image`, `reaction`, `verified`, `hidePhoto`, `isDisabled`, `avatar`, `reactionLength`) VALUES
(8, '8ee1996e42edd67b4818621e', 'Cool', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', '3ac30a1dc5b91c1977800f16', NULL, NULL, '3,1', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 2),
(9, 'f5548aea3722be8ded8f13ba', 'This is awesome', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', '3ac30a1dc5b91c1977800f16', NULL, NULL, '3,1', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 2),
(10, 'c3c1e4d0257624cfa161bd06', 'Cool', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', '3ac30a1dc5b91c1977800f16', NULL, NULL, '3,1', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 2),
(11, '846f9b3ee11ddacc48192e0c', '1', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', '3f77a27888c38578dd8b9042', NULL, NULL, '3', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 1),
(12, '35770a945001b0d0ae6cefa9', '2', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', '3f77a27888c38578dd8b9042', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(13, '34bca09af1d6c42ac26c3491', '3', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', '3f77a27888c38578dd8b9042', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(14, '731277f181e625b3f48961fa', '4', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', '3f77a27888c38578dd8b9042', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(15, 'c62132b4e039f23ba903b9f8', '5', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', '3f77a27888c38578dd8b9042', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(16, 'a38e6b3eae6439ecc48335ac', '6', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', '3f77a27888c38578dd8b9042', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(17, '1d5f3191360e63f75d41d49f', '7', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', '3f77a27888c38578dd8b9042', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(18, '07075188bb39c2c47b9811de', '8', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', '3f77a27888c38578dd8b9042', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(19, 'b4dcf9932f07251805ae721d', '9', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', '3f77a27888c38578dd8b9042', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(20, '904807b0a7ada62b675b8876', '10', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', '3f77a27888c38578dd8b9042', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(21, '369d6296ec488b4d63519a14', '1', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', 'b0d03f34f42616f34fc2d3b5', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(22, 'f54f58b31c740e2a5e130a92', '3', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', 'b0d03f34f42616f34fc2d3b5', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(23, '74c20744c134e42064a7279f', '2', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', 'b0d03f34f42616f34fc2d3b5', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(24, 'fd4ec8c465da58a9a8fbcfdd', '4', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', 'b0d03f34f42616f34fc2d3b5', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(25, '3f18d366240217d2e2c0dd00', '5', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', 'b0d03f34f42616f34fc2d3b5', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(26, 'd6e40e9e8bb72ade8f2044d3', '7', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', 'b0d03f34f42616f34fc2d3b5', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(27, '237ce4353049503078e0ec48', '7', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', 'b0d03f34f42616f34fc2d3b5', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(28, '069479d843dae9a13bc05fdf', '8', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', 'b0d03f34f42616f34fc2d3b5', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(29, '7d9e1ef9e8a4c02e7c0a8771', 'Awesome nrother', '2022 MAR 0', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', '7a97a8dac719e370e8334687', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(30, 'add81a81ce71459a4ff110ab', 'This is amazing brother', '2022 MAR 4', '3ec1e3144312a90089fb42f2', 'User1 User1', '', 'user_test', 'ca0a481fe7fe0ce2b143e622', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646904681763.jpeg', 0),
(32, '2453e21576efd2d2f7cb1c4e', 'Welcome blood', '2022 MAR 5', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', 'cc3224776093427dc20a2e3a', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(33, '5326c27d552962487befedef', 'Cool blood', '2022 MAR 5', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', 'cc3224776093427dc20a2e3a', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(34, '3e6e607faabf2cbfe7d217d1', 'hello', '2022 MAR 5', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', 'cc3224776093427dc20a2e3a', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(35, '3e7e7bb7cd58d195be961f6a', 'tree', '2022 MAR 6', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '5c727d7168e51c49d6262f4c', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(36, '956ad0470ea246734fbe966f', 'tree', '2022 MAR 6', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '5c727d7168e51c49d6262f4c', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(37, '7cb8c48689280d1876092e23', 'he4llo', '2022 MAR 6', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '5c727d7168e51c49d6262f4c', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(38, '385ce7596bb8ad36dabd40fc', 'tree', '2022 MAR 6', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '5c727d7168e51c49d6262f4c', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(39, 'b118aed64afc1e63c35a908f', 'Cool', '2022 MAR 6', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '5c727d7168e51c49d6262f4c', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(40, 'e4023fa9c28ac99fc56c63f1', 'hello', '2022 MAR 6', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '5c727d7168e51c49d6262f4c', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(41, '2a3e7056dc744a19e621b73e', 'tree', '2022 MAR 6', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', 'ca0a481fe7fe0ce2b143e622', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(42, 'af47a6c42b5c985e5fb08462', 'How fr', '2022-3-14T18:7:11:905', 'c2263ca46dce14a49f03674f', 'terry Leo', '', 'treeaaaaaa', 'e8d93c0f9d6e02b5e90daff1', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1647097667791.jpg', 0),
(43, '6218351b9782bc130446485a', 'see', '2022-3-14T18:9:29:719', 'c2263ca46dce14a49f03674f', 'terry Leo', '', 'treeaaaaaa', 'e8d93c0f9d6e02b5e90daff1', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1647097667791.jpg', 0),
(44, 'de0cc8f0c972aa963f5a4032', 'Tree', '2022-3-14T18:10:51:751', 'c2263ca46dce14a49f03674f', 'terry Leo', '', 'treeaaaaaa', 'b722f29c1170eb39344adf7d', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1647097667791.jpg', 0),
(45, '33d12078166fdbc38aa904b0', 'This is so cool brah', '2022-3-15T10:15:31:141', 'c2263ca46dce14a49f03674f', 'terry Leo', '', 'treeaaaaaa', 'd8d3182137ce99f237a40c7c', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1647097667791.jpg', 0),
(46, 'ed68233395c74a05b685191a', 'We love the app b rother', '2022-3-15T10:15:40:342', 'c2263ca46dce14a49f03674f', 'terry Leo', '', 'treeaaaaaa', 'd8d3182137ce99f237a40c7c', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1647097667791.jpg', 0),
(47, '09a9035f0d1cb1c639399344', 'Awesome', '2022-3-15T13:12:13:931', 'c2263ca46dce14a49f03674f', 'terry Leo', '', 'treeaaaaaa', 'a46639973fc74335a508a883', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1647097667791.jpg', 0),
(48, 'ec4896f9bd8ecde75078fbe4', 'cool nigga', '2022-3-20T7:11:23:10', 'c2263ca46dce14a49f03674f', 'terry Leo', '', 'treeaaaaaa', 'ae2871a6669b97b9692c378a', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1647097667791.jpg', 0),
(50, '602b0124bb43d57d0f54dab1', 'Good God', '2022-3-21T15:51:58:516', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', 'b0d03f34f42616f34fc2d3b5', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(51, '90c5a502dc73e3313aa1e24e', 'Awesome', '2022-03-22 21:43:57.284', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', 'da0b3920064442e415e6c8ea', NULL, NULL, '2', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 1),
(52, 'bdfe34b227b13efcfeee44d9', 'cool', '2022-03-22 21:45:17.950', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', 'da0b3920064442e415e6c8ea', NULL, NULL, '2,1', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 2),
(53, '2e59bdb8132fdfc653a046b0', 'hey', '2022-04-03 08:29:43.337', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '968915f278f017f5ea7a4da7', NULL, NULL, '1', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 1),
(54, 'd7d8814d9b68d7d90703d068', 'Lovely', '2022-04-03 08:29:47.661', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '968915f278f017f5ea7a4da7', NULL, NULL, '1', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 1),
(55, '6a0c61953db2bb045549d93b', 'hello wolrd', '2022-04-04 11:50:20.186', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', 'b69ddadbf5f4139b551d95c3', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(56, 'b47adb2e78bb86a3f649e8de', 'It\'s amazing ', '2022-04-04 17:52:39.439', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', 'b6e58379e08bea56f053c6da', NULL, NULL, '1', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 1),
(57, '3f15f3fd14e061f400f0f4d4', 'Call u tomorrow ', '2022-04-04 18:07:19.651', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', 'b6e58379e08bea56f053c6da', NULL, NULL, '1', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 1),
(58, 'c9eb4fc9a66a37b8c5a1f3ca', 'We love the app bro', '2022-04-05 15:03:09.593', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '73430d24be3025e89399da47', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(59, '1ee4dbf46f48b22607b45df4', 'dsdsds', '2022-04-05 15:04:14.707', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '73430d24be3025e89399da47', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(60, '18ecec04cafac963c1ca9dbb', 'Okay whats happen\r\nTOday\r\n', '2022-04-05 15:05:09.960', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '73430d24be3025e89399da47', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(61, '726a382ec0f81c8f6b7550aa', 'Hehe his app is cool brah', '2022-04-05 15:16:26.342', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', 'a88ef4d0114cb15ab9c08650', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(62, '5fe448b976dd25e318dbd323', 'Wee\r\nlive ettt', '2022-04-05 15:16:39.015', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', 'a88ef4d0114cb15ab9c08650', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(63, '1033679b8b8474012fc79886', 'awesome', '2022-04-09 05:56:58.718', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '3b817d56772e2bbfe208a581', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(64, '20ddb5c81d5f4ebc286444a5', 'Wel love the app\r\n\r\nso much', '2022-04-09 06:04:32.271', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '3b817d56772e2bbfe208a581', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(65, '22020dfe554cec389680fede', 'Thank goodness', '2022-04-09 06:04:40.077', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '3b817d56772e2bbfe208a581', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(66, '3762363e092e33f423fae4e3', 'It\'s awesome', '2022-04-09 06:04:45.738', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '3b817d56772e2bbfe208a581', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(67, 'f4bc672b99078e01ec83f2c7', 'WWe love ya', '2022-04-09 06:04:51.838', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '3b817d56772e2bbfe208a581', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(68, 'b39f079c940f1356034f1028', 'So much brother', '2022-04-09 06:04:57.175', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '3b817d56772e2bbfe208a581', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(70, '20af09fe8db75ffb228d7421', 'Cool bro', '2022-04-09 17:53:49.255', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', 'c42a032abae2a26ca29187c7', NULL, NULL, '1', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 1),
(71, '099171880396a461b87cbe0f', 'hope you love it ', '2022-04-09 18:07:02.262', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '2a8822aae2b1226791c94ff9', NULL, NULL, '1', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 1),
(72, '3959d47fce7eef83317d552f', 'Cool', '2022-04-17 10:42:29.046', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', '8f53655d5f0cff999bb2b4dd', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0),
(73, '530ebfa3bf3b93a42e93bc0d', 'Hello', '2022-04-17 19:12:32.188', '9627470f246cdb74266641dd', 'Gabriel Delight', '', 'deli', 'a894e00a215fd316da097ed5', NULL, NULL, '', NULL, 'none', NULL, 'plogapp-1646131942816.jpeg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `report_problem`
--

CREATE TABLE `report_problem` (
  `_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id` int(11) NOT NULL,
  `owner` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `report_problem`
--

INSERT INTO `report_problem` (`_id`, `id`, `owner`, `title`, `description`, `image`, `date`) VALUES
('e567de626ed21330407cb81b', 1, 'c2263ca46dce14a49f03674f', 'sds', 'sds', '', ''),
('83fff43b0b7198b6ea04f176', 2, 'c2263ca46dce14a49f03674f', 'sds', 'dsds', '', ''),
('335f59e022fc16cd1f805737', 3, 'c2263ca46dce14a49f03674f', 'Error in story', 'i need hge', 'plogapp-1647538820062.jpeg', ''),
('8653db77aeaf45dc968866f0', 4, 'c2263ca46dce14a49f03674f', 'Error in story', 'i need hge', 'plogapp-1647538975543.jpeg', '2022-3-17T18:42:55:548'),
('56af9438a469668fd12c4bbd', 5, 'c2263ca46dce14a49f03674f', '', '', '', '2022-3-17T19:1:26:709'),
('899169277bed3b4604d7b157', 6, 'c2263ca46dce14a49f03674f', 'dsd', 'fdfdf', '', '2022-3-17T19:22:19:842'),
('f73cca6ac5f110332ba49872', 7, 'c2263ca46dce14a49f03674f', 'dsd', 'fdfdf', '', '2022-3-17T19:22:20:613'),
('ecd0d799e237a42ce6373420', 8, 'c2263ca46dce14a49f03674f', 'dsd', 'fdfdf', '', '2022-3-17T19:22:20:726'),
('8aa62fc8d932a4803936f77b', 9, 'c2263ca46dce14a49f03674f', 'dsd', 'fdfdf', '', '2022-3-17T19:22:20:980'),
('2c20290b4a88bb985ce9a09f', 10, 'c2263ca46dce14a49f03674f', '', '', '', '2022-3-17T19:22:39:346'),
('b6303f9e0ea9f06fab70efa8', 11, 'c2263ca46dce14a49f03674f', 'sds', '', '', '2022-3-17T19:22:54:482'),
('a847d7aa1fe65603517a24fc', 12, 'c2263ca46dce14a49f03674f', 'sds', '', '', '2022-3-17T19:22:55:844'),
('a2cd387923b89eb690f920cd', 13, 'c2263ca46dce14a49f03674f', '', '', '', '2022-3-17T19:23:33:662'),
('f2ab60b22f86240b201e3f93', 14, 'c2263ca46dce14a49f03674f', 'sd', '', '', '2022-3-17T19:23:48:257'),
('1ae50f5a53b680de069c4bd6', 15, 'c2263ca46dce14a49f03674f', 'sds', '', '', '2022-3-17T19:24:11:183'),
('546ca6716354c9b476ec0283', 16, 'c2263ca46dce14a49f03674f', 'sds', '', '', '2022-3-17T19:24:11:979'),
('d547b11e8e6771af2ec1211a', 17, 'c2263ca46dce14a49f03674f', 'sds', '', '', '2022-3-17T19:24:12:216'),
('0a5c4dfddc4112a73b276393', 18, 'c2263ca46dce14a49f03674f', 'sds', '', '', '2022-3-17T19:24:31:400'),
('b896087be1113cf1bf27d06e', 19, 'c2263ca46dce14a49f03674f', 'sdsds', 'sdds', '', '2022-3-17T19:29:37:404'),
('dcc80e55927b2b7dc2d26671', 20, 'c2263ca46dce14a49f03674f', 'Test', 'treeeeeeeeeeee', '', '2022-3-17T19:46:29:162'),
('cd698c62ca06158029e8115b', 21, 'c2263ca46dce14a49f03674f', 'help', 'Sample help', 'plogapp-1647542994452.jpeg', '2022-3-17T19:49:54:845');

-- --------------------------------------------------------

--
-- Table structure for table `sentchatnotification`
--

CREATE TABLE `sentchatnotification` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `ownerName` varchar(255) DEFAULT NULL,
  `receiverName` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `receiverId` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sharepost`
--

CREATE TABLE `sharepost` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) DEFAULT NULL,
  `sortDate` longtext NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `postType` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `postImageId` varchar(255) DEFAULT NULL,
  `possterName` varchar(255) DEFAULT NULL,
  `posterNickName` varchar(255) DEFAULT NULL,
  `sharedPosterNickName` varchar(255) DEFAULT NULL,
  `posterGenderType` varchar(255) DEFAULT NULL,
  `verified` varchar(255) DEFAULT NULL,
  `reaction` varchar(255) DEFAULT NULL,
  `isLike` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `commentlength` longtext DEFAULT NULL,
  `Initcomment` longtext DEFAULT NULL,
  `hideLastComment` longtext DEFAULT NULL,
  `lastCommentAvatar` longtext DEFAULT NULL,
  `commentImage` longtext DEFAULT NULL,
  `commentName` longtext DEFAULT NULL,
  `verifiedComment` longtext DEFAULT NULL,
  `commentWidth` longtext DEFAULT NULL,
  `commentHeight` longtext DEFAULT NULL,
  `sharedPostAvatar` longtext DEFAULT NULL,
  `sharedPostDate` longtext DEFAULT NULL,
  `sharedPostDescription` longtext DEFAULT NULL,
  `sharedPostImage` longtext DEFAULT NULL,
  `sharedPostVideo` longtext DEFAULT NULL,
  `mainOwner` longtext DEFAULT NULL,
  `verifiedSharedPost` longtext DEFAULT NULL,
  `sharedPostOwnerName` varchar(255) DEFAULT NULL,
  `sharedPostLink` longtext DEFAULT NULL,
  `sharedPostType` longtext DEFAULT NULL,
  `shareLength` longtext DEFAULT NULL,
  `posterFollower` longtext DEFAULT NULL,
  `posterFollowing` longtext DEFAULT NULL,
  `posterBio` varchar(255) DEFAULT NULL,
  `reactionLength` int(11) DEFAULT NULL,
  `isDisabled` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `shareAvatar` varchar(255) DEFAULT NULL,
  `sharePostUrl` varchar(255) DEFAULT NULL,
  `ownerPrimaryid` int(11) DEFAULT NULL,
  `tag_list` longtext NOT NULL,
  `views` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sharepost`
--

INSERT INTO `sharepost` (`id`, `_id`, `sortDate`, `description`, `image`, `video`, `postType`, `date`, `postImageId`, `possterName`, `posterNickName`, `sharedPosterNickName`, `posterGenderType`, `verified`, `reaction`, `isLike`, `owner`, `commentlength`, `Initcomment`, `hideLastComment`, `lastCommentAvatar`, `commentImage`, `commentName`, `verifiedComment`, `commentWidth`, `commentHeight`, `sharedPostAvatar`, `sharedPostDate`, `sharedPostDescription`, `sharedPostImage`, `sharedPostVideo`, `mainOwner`, `verifiedSharedPost`, `sharedPostOwnerName`, `sharedPostLink`, `sharedPostType`, `shareLength`, `posterFollower`, `posterFollowing`, `posterBio`, `reactionLength`, `isDisabled`, `avatar`, `shareAvatar`, `sharePostUrl`, `ownerPrimaryid`, `tag_list`, `views`) VALUES
(1, 'eb841e24f21b557bec628a23', '2022-03-02 12:29:59.622', 'Shared video', NULL, NULL, 'sharevideo', ' 2 MAR,  2022 at 12:29:59 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deligad', 'deligad', NULL, NULL, '1', NULL, '9627470f246cdb74266641dd', '1', 'Good ine', 'block', 'plogapp-1646131942816.jpeg', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', '9627470f246cdb74266641dd', ' 1 MAR,  2022 at 12:14:19 PM', '', NULL, NULL, '9627470f246cdb74266641dd', NULL, 'Gabriel Delight', 'plogapp-1646133259251.mp4', 'video', NULL, NULL, NULL, 'Hello I love Plogapp', 1, NULL, 'plogapp-1646131942816.jpeg', 'plogapp-1646131942816.jpeg', '748e7b816d660b6c2ac69802', 1, '', '2'),
(2, '0696354db7e2c6be85bbedd3', '2022-03-11 18:18:55.020', 'Awesome', NULL, NULL, 'shareimage', ' 11 MAR,  2022 at 6:18:55 PM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'plog', NULL, NULL, '1', NULL, '9627470f246cdb74266641dd', '2', 'Lovely', 'block', 'plogapp-1646131942816.jpeg', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 'c2585b15e1bbc09bb86000e8', ' 1 MAR,  2022 at 12:53:53 PM', '', 'plogapp-1646135633879.jpeg', NULL, 'c2585b15e1bbc09bb86000e8', NULL, 'Plog app', NULL, 'image', NULL, NULL, NULL, 'Hello I love Plogapp', 1, NULL, 'plogapp-1646131942816.jpeg', 'plogapp-1646132550991.jpeg', '7e321f8fd96adb575ad502c3', 1, '', ''),
(3, 'c3e590c6cb9df8b339fbbad4', '2022-03-12 10:32:01.955', 'I love to share this', NULL, NULL, 'shareimage', ' 12 MAR,  2022 at 10:32:01 AM', '9627470f246cdb74266641dd', 'Gabriel Delight', 'deli', 'deligad', NULL, NULL, '1', NULL, '9627470f246cdb74266641dd', '1', 'dsdsdsdsd', 'block', 'plogapp-1646131942816.jpeg', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', '9627470f246cdb74266641dd', ' 1 MAR,  2022 at 12:23:10 PM', 'Robot', 'plogapp-1646133790862.jpeg', NULL, '9627470f246cdb74266641dd', NULL, 'Gabriel Delight', NULL, 'image', NULL, NULL, NULL, 'Hello I love Plogapp', 1, NULL, 'plogapp-1646131942816.jpeg', 'plogapp-1646131942816.jpeg', '261e68a0ac16f480ef24de45', 1, '', ''),
(5, '565d7acd54d605165b271839', '2022-03-14 18:32:52.745', '#plogapp and www.plogapp.com', NULL, NULL, 'sharevideo', '2022-3-14T18:32:52:739', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'treeaaaaaa', NULL, NULL, '1,4', NULL, 'c2263ca46dce14a49f03674f', '2', 'heh', 'block', 'plogapp-1647097667791.jpg', 'c2263ca46dce14a49f03674f', 'terry Leo', 'null', '20', '20', 'c2263ca46dce14a49f03674f', '2022-3-14T18:18:26:784', '', NULL, NULL, 'c2263ca46dce14a49f03674f', NULL, 'terry Leo', 'plogapp-1647278306269.mp4', 'video', '1', NULL, NULL, '', 2, NULL, 'plogapp-1647097667791.jpg', 'plogapp-1647097667791.jpg', '49345c95f5eb0208392595df', 4, '', '2'),
(6, 'de56906e8e4a1c098a98aed3', '2022-03-14 18:46:39.920', '', NULL, NULL, 'shareimage', '2022-3-14T18:46:39:904', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'plog', NULL, NULL, '1', NULL, 'c2263ca46dce14a49f03674f', '1', 'Greetings ', 'block', 'plogapp-1646131942816.jpeg', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', 'c2585b15e1bbc09bb86000e8', ' 1 MAR,  2022 at 12:54:58 PM', '', 'plogapp-1646135698155.jpeg', NULL, 'c2585b15e1bbc09bb86000e8', NULL, 'Plog app', NULL, 'image', NULL, NULL, NULL, '', 1, NULL, 'plogapp-1647097667791.jpg', 'plogapp-1646132550991.jpeg', '10a2323b8354be56bcd238fb', 4, '', ''),
(7, 'ce33de0c01a761a4f5d9fbd7', '2022-03-20 17:43:29.111', '', NULL, NULL, 'sharesharevideo', '2022-3-20T17:43:29:95', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'treeaaaaaa', NULL, NULL, NULL, NULL, 'c2263ca46dce14a49f03674f', NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, NULL, 'c2263ca46dce14a49f03674f', '2022-3-14T18:32:52:739', '#plogapp and www.plogapp.com', NULL, NULL, 'c2263ca46dce14a49f03674f', NULL, 'terry Leo', 'plogapp-1647278306269.mp4', 'sharevideo', NULL, NULL, NULL, 'This is very cool', NULL, NULL, 'plogapp-1647097667791.jpg', 'plogapp-1647097667791.jpg', '565d7acd54d605165b271839', 4, '', ''),
(8, 'b1ae77c57ebf6cbcd7a8f4bf', '2022-03-20 18:34:03.194', '', NULL, NULL, 'shareimage', '2022-3-20T18:34:3:186', 'c2263ca46dce14a49f03674f', 'terry Leo', 'treeaaaaaa', 'treeaaaaaa', NULL, NULL, NULL, NULL, 'c2263ca46dce14a49f03674f', NULL, NULL, 'none', NULL, NULL, NULL, NULL, NULL, NULL, 'c2263ca46dce14a49f03674f', '2022-3-18T12:29:26:555', '', 'plogapp-1647602966447.jpeg', NULL, 'c2263ca46dce14a49f03674f', NULL, 'terry Leo', NULL, 'image', NULL, NULL, NULL, 'This is very cool', NULL, NULL, 'plogapp-1647097667791.jpg', 'plogapp-1647097667791.jpg', '401baddfcca4b3d417beaa2e', 4, '', ''),
(9, '21d01217495d43f93946fe49', '2022-04-01 20:43:21.821', 'Sharing thsi content', NULL, NULL, 'sharevideo', '2022-04-01 20:43:21.821', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'plog', 'plog', NULL, NULL, '2', NULL, 'c2585b15e1bbc09bb86000e8', '1', 'Hello', 'block', 'plogapp-1646132550991.jpeg', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'null', '20', '20', 'c2585b15e1bbc09bb86000e8', '2022-04-01 20:40:27.637', '', 'plogapp1648842032969.png', NULL, 'c2585b15e1bbc09bb86000e8', NULL, 'Plog app', 'plogapp-1648842027417.mp4', 'video', NULL, NULL, NULL, 'I am 0plog', 1, NULL, 'plogapp-1646132550991.jpeg', 'plogapp-1646132550991.jpeg', '559946f3e20fed74b80f7e1a', 2, '', '1'),
(10, 'fb3da22e2d916cc05f9b074a', '2022-04-04 14:19:17.734', 'Awesome', NULL, NULL, 'sharetext', '2022-04-04 14:19:17.734', 'c2585b15e1bbc09bb86000e8', 'Plog app', 'plog', 'deli', NULL, NULL, '2,1', NULL, 'c2585b15e1bbc09bb86000e8', '1', 'Hell', 'block', 'plogapp-1646131942816.jpeg', '9627470f246cdb74266641dd', 'Gabriel Delight', 'null', '20', '20', '9627470f246cdb74266641dd', ' 11 MAR,  2022 at 8:13:39 PM', 'hello wolrd  how are you href=\'hello\' ', NULL, NULL, '9627470f246cdb74266641dd', NULL, 'Gabriel Delight', NULL, 'text', NULL, NULL, NULL, 'I am 0plog', 2, NULL, 'plogapp-1646132550991.jpeg', 'plogapp-1646131942816.jpeg', '3fab7977670f6b803f70fb4a', 2, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `story`
--

CREATE TABLE `story` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `sttoryImage` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `storyText` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `ownerName` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `withStory` varchar(255) DEFAULT NULL,
  `storyType` text NOT NULL,
  `viewers` varchar(255) DEFAULT NULL,
  `reaction` varchar(255) DEFAULT NULL,
  `isDisabled` varchar(255) DEFAULT NULL,
  `exprireStoryNextDay` varchar(255) DEFAULT NULL,
  `storyHour` varchar(255) DEFAULT NULL,
  `reactionLength` int(11) DEFAULT NULL,
  `background` text NOT NULL,
  `boldText` text NOT NULL,
  `fontFamily` text NOT NULL,
  `fontSize` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `story`
--

INSERT INTO `story` (`id`, `_id`, `avatar`, `caption`, `color`, `sttoryImage`, `image`, `storyText`, `video`, `owner`, `ownerName`, `date`, `withStory`, `storyType`, `viewers`, `reaction`, `isDisabled`, `exprireStoryNextDay`, `storyHour`, `reactionLength`, `background`, `boldText`, `fontFamily`, `fontSize`, `description`) VALUES
(62, '8c4e7332076967fe39351d62', 'plogapp-1646132550991.jpeg', NULL, NULL, NULL, 'plogapp1648808715024.png', 'hello thjis is just a txt', NULL, 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-01 11:25:16.205', NULL, 'text', '2,1', '1', 'true', '6', '11', 1, 'green', 'bolder', 'cursive', '30px', 'hello thjis is just a txt'),
(63, 'bbfff81932a7cb8862c53724', 'plogapp-1646132550991.jpeg', 'This is out plogapp logo', NULL, 'plogapp1648808839859.jpeg', 'plogapp1648808839859.jpeg', 'This is out plogapp logo', NULL, 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-01 11:27:19.944', NULL, 'image', '2,1', '1', 'true', '6', '11', 1, '', '', '', '', ''),
(64, '4ef67be99208d536aad4d8f8', 'plogapp-1646132550991.jpeg', '', NULL, NULL, 'plogapp1648808883492.png', '', 'plogapp1648808874564.mp4', 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-01 11:28:03.238', NULL, 'video', '2,1', '', 'true', '6', '11', 0, '', '', '', '', ''),
(65, '911b678a95ee02227d106c6b', 'plogapp-1646132550991.jpeg', NULL, NULL, NULL, 'plogapp1648808917471.png', 'hello word this ismt last other post ', NULL, 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-01 11:28:38.623', NULL, 'text', '2,1', '', 'true', '6', '11', 0, 'green', 'undefined', 'cursive', '30px', 'hello word this ismt last other post '),
(66, '216d573f62fd8d500723996a', 'plogapp-1646132550991.jpeg', NULL, NULL, NULL, 'plogapp1648836465051.png', 'Cool rat', NULL, 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-01 19:07:46.510', NULL, 'text', '2,1', '1,2', 'true', '6', '19', 2, 'undefined', 'undefined', 'undefined', 'undefined', 'Cool rat'),
(67, '34f24e38bce0e1ecdbf5b887', 'plogapp-1646132550991.jpeg', NULL, NULL, NULL, 'plogapp1648836528867.png', 'Hello world', NULL, 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-01 19:08:51.073', NULL, 'text', '2,1', '1,2', 'true', '6', '19', 2, 'undefined', 'undefined', 'undefined', 'undefined', 'Hello world'),
(68, '385a5ea36c1094d2e380dbb1', 'plogapp-1646132550991.jpeg', NULL, NULL, NULL, 'plogapp1648837503720.png', 'sdsdsds', NULL, 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-01 19:25:05.073', NULL, 'text', '2,1', '1,2', 'true', '6', '19', 2, 'undefined', 'undefined', 'undefined', 'undefined', 'sdsdsds'),
(69, '48090183f16596bde3585e4b', 'plogapp-1646132550991.jpeg', NULL, NULL, NULL, 'plogapp1648837616562.png', 'sample', NULL, 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-01 19:27:02.354', NULL, 'text', '2,1', '1,2', 'true', '6', '19', 2, 'cornflowerblue', 'undefined', 'undefined', 'undefined', 'sample'),
(70, '127f455590596b955182f08b', 'plogapp-1646131942816.jpeg', NULL, NULL, NULL, 'plogapp1649090708692.png', 'Hello Plogapp', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-04 17:45:12.210', NULL, 'text', '1,2', '1', 'true', '2', '17', 1, 'cornflowerblue', 'undefined', 'undefined', 'undefined', 'Hello Plogapp'),
(71, '5f8af33650ff6cd5b56bd324', 'plogapp-1646131942816.jpeg', '', NULL, 'plogapp1649090810723.jpeg', 'plogapp1649090810723.jpeg', '', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-04 17:46:50.744', NULL, 'image', '1', NULL, 'true', '2', '17', NULL, '', '', '', '', ''),
(72, '9b7e7057c21eae3eb64b50a2', 'plogapp-1646131942816.jpeg', '', NULL, NULL, 'plogapp1649091312428.png', '', 'plogapp1649091275296.mp4', '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-04 17:55:11.904', NULL, 'video', '1', NULL, 'true', '2', '17', NULL, '', '', '', '', ''),
(73, '3a62871e130dbd22e833e6e4', 'plogapp-1646132550991.jpeg', NULL, NULL, NULL, 'plogapp1649093554656.png', 'hello wolrd', NULL, 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-04 18:32:35.982', NULL, 'text', '2', NULL, 'true', '2', '18', NULL, 'cornflowerblue', 'undefined', 'undefined', 'undefined', 'hello wolrd'),
(74, '3f1f085547eca48e5a7ed564', 'plogapp-1646132550991.jpeg', NULL, NULL, NULL, 'plogapp1649093663994.png', 'dsdsd', NULL, 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-04 18:34:25.131', NULL, 'text', NULL, NULL, 'true', '2', '18', NULL, 'cornflowerblue', 'undefined', 'undefined', 'undefined', 'dsdsd'),
(75, '7d0003c22f095b12a39cec86', 'plogapp-1646132550991.jpeg', NULL, NULL, NULL, 'plogapp1649093769384.png', 'hello', NULL, 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-04 18:36:10.735', NULL, 'text', NULL, NULL, 'true', '2', '18', NULL, 'cornflowerblue', 'undefined', 'undefined', 'undefined', 'hello'),
(76, '07a10a34bd339c62a01ec710', 'plogapp-1646132550991.jpeg', NULL, NULL, NULL, 'plogapp1649093875188.png', 'Hello', NULL, 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-04 18:37:57.140', NULL, 'text', NULL, NULL, 'true', '2', '18', NULL, 'cornflowerblue', 'undefined', 'undefined', 'undefined', 'Hello'),
(77, '0903c18618b98fe20d2b6b5b', 'plogapp-1646132550991.jpeg', NULL, NULL, NULL, 'plogapp1649093941128.png', 'Cool here', NULL, 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-04 18:39:02.404', NULL, 'text', NULL, NULL, 'true', '2', '18', NULL, 'cornflowerblue', 'undefined', 'undefined', 'undefined', 'Cool here'),
(78, 'a8cce9a3fcd5c9cb85e930af', 'plogapp-1646132550991.jpeg', NULL, NULL, NULL, 'plogapp1649094034538.png', 'Cool', NULL, 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-04 18:40:35.770', NULL, 'text', NULL, NULL, 'true', '2', '18', NULL, 'cornflowerblue', 'undefined', 'undefined', 'undefined', 'Cool'),
(79, '05f8692e5e2cbd7cee018fa9', 'plogapp-1646132550991.jpeg', NULL, NULL, NULL, 'plogapp1649094094094.png', 'Test', NULL, 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-04 18:41:35.707', NULL, 'text', NULL, NULL, 'true', '2', '18', NULL, 'cornflowerblue', 'undefined', 'undefined', 'undefined', 'Test'),
(80, '42c6d18ab59308f753cb416a', 'plogapp-1646132550991.jpeg', NULL, NULL, NULL, 'plogapp1649094111766.png', 'Hahaha', NULL, 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-04 18:41:53.132', NULL, 'text', '2', NULL, 'true', '2', '18', NULL, 'cornflowerblue', 'undefined', 'undefined', 'undefined', 'Hahaha'),
(81, '4027859c619c36e0aa4f2680', 'plogapp-1646132550991.jpeg', '', NULL, NULL, 'plogapp1649094280194.png', '', 'plogapp1649094249760.mp4', 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-04 18:44:39.666', NULL, 'video', '2', NULL, 'true', '2', '18', NULL, '', '', '', '', ''),
(82, '50e386c0032699efe74ad1cc', 'plogapp-1646132550991.jpeg', '', NULL, NULL, 'plogapp1649094297324.mp4', '', 'plogapp1649094297324.mp4', 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-04 18:45:24.062', NULL, 'video', '2', NULL, 'true', '2', '18', NULL, '', '', '', '', ''),
(83, 'b59e262e725b1415b6b13edf', 'plogapp-1646132550991.jpeg', '', NULL, 'plogapp1649094607970.jpeg', 'plogapp1649094607970.jpeg', '', NULL, 'c2585b15e1bbc09bb86000e8', 'Plog app', '2022-04-04 18:50:08.060', NULL, 'image', NULL, NULL, 'true', '2', '18', NULL, '', '', '', '', ''),
(84, 'dde56f0e35b806594ebb90b2', 'plogapp-1646131942816.jpeg', NULL, NULL, NULL, 'plogapp1649148065160.png', 'hello', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-05 09:41:07.569', NULL, 'text', '1', NULL, 'false', '3', '9', NULL, 'cornflowerblue', 'undefined', 'undefined', 'undefined', 'hello'),
(85, '09e28eb5a902806159a6dafa', 'plogapp-1646131942816.jpeg', NULL, NULL, NULL, 'plogapp1649148085712.png', 'Sample here', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-05 09:41:28.016', NULL, 'text', '1', NULL, 'false', '3', '9', NULL, 'green', 'bolder', 'cursive', '20px', 'Sample here'),
(86, 'e590fe5e0190a518fe56ea3d', 'plogapp-1646131942816.jpeg', '', NULL, 'plogapp1649148250926.jpeg', 'plogapp1649148250926.jpeg', '', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-05 09:44:10.968', NULL, 'image', '1', NULL, 'false', '3', '9', NULL, '', '', '', '', ''),
(87, '2b66ce351f1f715c28ff4db9', 'plogapp-1646131942816.jpeg', '', NULL, 'plogapp1649148338152.jpeg', 'plogapp1649148338152.jpeg', '', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-05 09:45:38.186', NULL, 'image', '1', NULL, 'false', '3', '9', NULL, '', '', '', '', ''),
(88, 'd99c6504d27beb0dc3298e83', 'plogapp-1646131942816.jpeg', '', NULL, NULL, 'plogapp1649148450449.png', '', 'plogapp1649148446620.mp4', '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-05 09:47:30.016', NULL, 'video', '1', NULL, 'false', '3', '9', NULL, '', '', '', '', ''),
(89, '9b28304af045f325f606a27d', 'plogapp-1646131942816.jpeg', NULL, NULL, NULL, 'plogapp1649149076789.png', 'hey', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-05 09:57:58.493', NULL, 'text', '1', NULL, 'false', '3', '9', NULL, 'cornflowerblue', 'undefined', 'undefined', 'undefined', 'hey'),
(90, 'c288ce30e25e3ec01c4ad40d', 'plogapp-1646131942816.jpeg', '', NULL, 'plogapp1649149195268.jpeg', 'plogapp1649149195268.jpeg', '', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-05 09:59:55.293', NULL, 'image', '1', NULL, 'false', '3', '9', NULL, '', '', '', '', ''),
(91, 'a2b1737e3bfc25fc0194f159', 'plogapp-1646131942816.jpeg', '', NULL, 'plogapp1649149293214.jpeg', 'plogapp1649149293214.jpeg', '', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-05 10:01:33.251', NULL, 'image', NULL, NULL, 'true', '3', '10', NULL, '', '', '', '', ''),
(92, '4e3f69f29defd779a6875057', 'plogapp-1646131942816.jpeg', '', NULL, 'plogapp1649149302321.jpeg', 'plogapp1649149302321.jpeg', '', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-05 10:01:42.377', NULL, 'image', '1', NULL, 'true', '3', '10', NULL, '', '', '', '', ''),
(93, '633030121c60126bee6546f9', 'plogapp-1646131942816.jpeg', '', NULL, 'plogapp1649150005630.jpeg', 'plogapp1649150005630.jpeg', '', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-05 10:13:25.679', NULL, 'image', '1', NULL, 'true', '3', '10', NULL, '', '', '', '', ''),
(94, '4bc87e367e4fedf98c8deb66', 'plogapp-1646131942816.jpeg', '', NULL, 'plogapp1649150019279.jpeg', 'plogapp1649150019279.jpeg', '', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-05 10:13:39.303', NULL, 'image', NULL, NULL, 'true', '3', '10', NULL, '', '', '', '', ''),
(95, '709d1b9afce98b17ee44a795', 'plogapp-1646131942816.jpeg', '', NULL, NULL, 'plogapp1649150057080.png', '', 'plogapp1649150053732.mp4', '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-05 10:14:16.893', NULL, 'video', NULL, NULL, 'true', '3', '10', NULL, '', '', '', '', ''),
(96, 'ce0ef988e1f11ced83a756e0', 'plogapp-1646131942816.jpeg', '', NULL, NULL, 'plogapp1649150994998.png', '', 'plogapp1649150973601.mp4', '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-05 10:29:54.867', NULL, 'video', NULL, NULL, 'true', '3', '10', NULL, '', '', '', '', ''),
(97, '89526918ebb70734f711206b', 'plogapp-1646131942816.jpeg', '', NULL, NULL, 'plogapp1649151080410.png', '', 'plogapp1649151070168.webm', '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-05 10:31:20.180', NULL, 'video', NULL, NULL, 'true', '3', '10', NULL, '', '', '', '', ''),
(98, '96b15932238da5889bcac2f5', 'plogapp-1646131942816.jpeg', '', NULL, NULL, 'plogapp1649164007271.png', '', 'plogapp1649164002874.mp4', '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-05 14:06:45.926', NULL, 'video', '1', NULL, 'true', '3', '14', NULL, '', '', '', '', ''),
(99, '80bea514d12c2f35af887959', 'plogapp-1646131942816.jpeg', 'hellom \r\n\r\nThis is plogapp\r\n\r\nSupport plogapp', NULL, 'plogapp1649173369680.jpeg', 'plogapp1649173369680.jpeg', 'hellom \r\n\r\nThis is plogapp\r\n\r\nSupport plogapp', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-05 16:42:49.922', NULL, 'image', '1', NULL, 'true', '3', '16', NULL, '', '', '', '', ''),
(100, '9443bb71e538e42c7a1bfc3e', 'plogapp-1646131942816.jpeg', NULL, NULL, NULL, 'plogapp1649173522523.png', 'hello world\r\n\r\nhow are you \r\n\r\ndoing?', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-05 16:45:23.720', NULL, 'text', '1', NULL, 'true', '3', '16', NULL, 'cornflowerblue', 'undefined', 'undefined', 'undefined', 'hello world\r\n\r\nhow are you \r\n\r\ndoing?'),
(101, '406cd7fde6ee84eb4e764eb4', 'plogapp-1646131942816.jpeg', NULL, NULL, NULL, 'plogapp1649421959432.png', 'Hey what are you doing? ', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-08 13:46:01.217', NULL, 'text', '1', NULL, 'false', '6', '13', NULL, 'green', 'bolder', 'cursive', 'undefined', 'Hey what are you doing? '),
(102, '47ef872e5a86dd552d6f50bb', 'plogapp-1646131942816.jpeg', NULL, NULL, NULL, 'plogapp1649526778186.png', 'Hey', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-09 18:53:02.062', NULL, 'text', '1', NULL, 'false', '7', '18', NULL, 'cornflowerblue', 'undefined', 'undefined', 'undefined', 'Hey'),
(103, '4cd79ae01bbb9e281d4b5014', 'plogapp-1646131942816.jpeg', NULL, NULL, NULL, 'plogapp1649529878810.png', 'This is so bad brother', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-09 19:44:46.234', NULL, 'text', '1', NULL, 'false', '7', '19', NULL, 'tan', 'bolder', 'undefined', '40px', 'This is so bad brother'),
(104, 'b0543d346ec53ebad0820779', 'plogapp-1646131942816.jpeg', NULL, NULL, NULL, 'plogapp1649530275174.png', 'Hshjsks', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-09 19:51:19.482', NULL, 'text', '1', NULL, 'false', '7', '19', NULL, 'pink', 'undefined', 'undefined', '25px', 'Hshjsks'),
(105, '070536afd6bde229c96fa627', 'plogapp-1646131942816.jpeg', '', NULL, 'plogapp1649530323465.jpeg', 'plogapp1649530323465.jpeg', '', NULL, '9627470f246cdb74266641dd', 'Gabriel Delight', '2022-04-09 19:52:03.628', NULL, 'image', NULL, NULL, 'false', '7', '19', NULL, '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `todos`
--

CREATE TABLE `todos` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `completed` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `genderDescription` varchar(255) DEFAULT NULL,
  `phoneNumber` longtext NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `birthDay` longtext NOT NULL,
  `birthMonth` longtext NOT NULL,
  `birthYear` longtext NOT NULL,
  `bestSentence` longtext NOT NULL,
  `avatar` varchar(255) NOT NULL DEFAULT 'avatar.png',
  `verified` varchar(255) DEFAULT NULL,
  `coverPhoto` varchar(255) DEFAULT NULL,
  `isLike` varchar(255) DEFAULT NULL,
  `hasStory` varchar(255) DEFAULT NULL,
  `following` longtext DEFAULT '0',
  `follower` longtext DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `month` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  `activeStatus` varchar(255) DEFAULT NULL,
  `greenActive` varchar(255) DEFAULT NULL,
  `notifiicationLength` varchar(255) DEFAULT NULL,
  `chatNotification` varchar(255) DEFAULT NULL,
  `storyImg` varchar(255) DEFAULT NULL,
  `verificationCode` varchar(255) DEFAULT NULL,
  `hideWelcomeMsg` varchar(255) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `temporalEmail` varchar(255) DEFAULT NULL,
  `isDisabled` varchar(255) DEFAULT NULL,
  `followingLength` int(11) DEFAULT NULL,
  `followerLength` int(11) DEFAULT NULL,
  `interests` longtext NOT NULL,
  `country` longtext NOT NULL,
  `city` longtext NOT NULL,
  `town` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `_id`, `firstname`, `lastname`, `fullName`, `gender`, `genderDescription`, `phoneNumber`, `email`, `password`, `birthDay`, `birthMonth`, `birthYear`, `bestSentence`, `avatar`, `verified`, `coverPhoto`, `isLike`, `hasStory`, `following`, `follower`, `date`, `month`, `year`, `activeStatus`, `greenActive`, `notifiicationLength`, `chatNotification`, `storyImg`, `verificationCode`, `hideWelcomeMsg`, `token`, `temporalEmail`, `isDisabled`, `followingLength`, `followerLength`, `interests`, `country`, `city`, `town`) VALUES
(1, '9627470f246cdb74266641dd', 'Gabriel', 'Delight', 'deli', 'male', 'his', '08080025944', 'gabrieldelight08@gmail.com', '$2a$10$uZ.2LCQQAueb0fGJGbWHE.YeRHks7y6j/DQzASQFIOtNtd7CnydFC', '4', 'August', '2000', 'Hello I love Plogapp', 'plogapp-1646131942816.jpeg', NULL, 'plogapp1646727987467.jpeg', NULL, 'true', '', NULL, '1', 'March', '2022', NULL, NULL, '', '+1', 'plogapp1649530323465.jpeg', '624231', 'none', NULL, NULL, 'false', NULL, NULL, 'Movie Series,Sports,LifeStyle,Swimming,Eating,Running,TV news,Entertainment,Fashion&Beauty,Art and Culture,Dancing,Relationship,Health,Motoring', 'Nigeria', 'Port Harcourt', 'Town hall'),
(2, 'c2585b15e1bbc09bb86000e8', 'Plog', 'app', 'plog', 'male', 'his', '08080025944', 'plogappweb@gmail.com', '$2a$10$d1W2W1cGBGfYOMYWlwnCKOfLa6KtT2BbeNIWGUvkFgxqMk1/PuDgK', '4', 'August', '2000', 'I am 0plog', 'plogapp-1646132550991.jpeg', NULL, 'coverphoto2.jpg', NULL, 'false', '', NULL, '1', 'March', '2022', NULL, NULL, '13', '+1', 'undefined', '3030', 'none', NULL, NULL, 'false', NULL, NULL, 'Swimming,Eating,TV news,Entertainment,Art and Culture,Dancing', 'Nigeria', 'Niga', 'yen'),
(3, '3ec1e3144312a90089fb42f2', 'User1', 'User1', 'user_test', 'male', 'his', '', 'user1@gmail.com', '$2a$10$9m5D6kr5Ggn64oMHi9YHiOmRTs40.G3L6IlEYqgX4YjXHYdMfsOAK', '10', 'August', '1988', 'I love plogapp', 'plogapp-1646904681763.jpeg', NULL, 'coverphoto2.jpg', NULL, 'false', '', NULL, '5', 'March', '2022', NULL, NULL, '25', '+1', 'undefined', '4574', 'none', NULL, NULL, 'false', NULL, NULL, '', '', '', ''),
(4, 'c2263ca46dce14a49f03674f', 'terry', 'Leo', 'treeaaaaaa', 'female', 'his', '8080025944', 'john@gmail.com', '$2a$10$0rNFDlARNISsFA0I4sEhWuHBDY.tnfQ5ZijFaOBI8.7fgSxkBbkJm', '4', 'August', '2000', 'This is very cool', 'plogapp-1647097667791.jpg', NULL, 'coverphoto2.jpg', NULL, 'false', '', NULL, '12', 'March', '2022', NULL, NULL, '27', '+1', 'undefined', '9775', 'none', NULL, NULL, 'false', NULL, NULL, 'Sports,Running,TV news,Fashion&Beauty,Art and Culture,Dancing,Relationship', 'Nigeria', 'Port Harcourt', 'Rivers');

-- --------------------------------------------------------

--
-- Table structure for table `video_views`
--

CREATE TABLE `video_views` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `videoId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_owner` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `video_views`
--

INSERT INTO `video_views` (`id`, `_id`, `owner`, `videoId`, `video_owner`) VALUES
(17, '51b0c6d75a4eb1d897d0518b', 'c2263ca46dce14a49f03674f', '565d7acd54d605165b271839', 'c2263ca46dce14a49f03674f'),
(18, 'bc64ba138cf95ed99dc6f5a2', 'c2263ca46dce14a49f03674f', 'eb841e24f21b557bec628a23', '9627470f246cdb74266641dd'),
(19, '556b07a9feb0071d072471e0', '9627470f246cdb74266641dd', '49345c95f5eb0208392595df', 'c2263ca46dce14a49f03674f'),
(20, '497594b18f81e02430dfb098', 'c2585b15e1bbc09bb86000e8', '50aaf96632fd4f8153d75a5c', 'c2585b15e1bbc09bb86000e8'),
(21, 'e25488248e65a5f4c3647b1e', 'c2585b15e1bbc09bb86000e8', '559946f3e20fed74b80f7e1a', 'c2585b15e1bbc09bb86000e8'),
(22, 'e23af6891004eb39a46910b6', '9627470f246cdb74266641dd', '21d01217495d43f93946fe49', 'c2585b15e1bbc09bb86000e8'),
(23, 'fc70e1bd00e51f0c7bd95e27', '9627470f246cdb74266641dd', 'eb841e24f21b557bec628a23', '9627470f246cdb74266641dd'),
(24, '9f44425103e4ba294a0f025d', '9627470f246cdb74266641dd', '565d7acd54d605165b271839', 'c2263ca46dce14a49f03674f'),
(25, '352c5291700d5ed9a65b8483', '9627470f246cdb74266641dd', '3afe6e81275852a5f67638cc', '9627470f246cdb74266641dd'),
(26, 'd17b75d501445da1c3633305', '9627470f246cdb74266641dd', '748e7b816d660b6c2ac69802', '9627470f246cdb74266641dd'),
(27, 'aaee3a751fbdcb4794dd0b0d', '9627470f246cdb74266641dd', '92f0b824570cf1caf78c0d0a', '9627470f246cdb74266641dd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blocked_accouts`
--
ALTER TABLE `blocked_accouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chatnotification`
--
ALTER TABLE `chatnotification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chatreceiver`
--
ALTER TABLE `chatreceiver`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chatsender`
--
ALTER TABLE `chatsender`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `follower`
--
ALTER TABLE `follower`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `following`
--
ALTER TABLE `following`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `replies`
--
ALTER TABLE `replies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `report_problem`
--
ALTER TABLE `report_problem`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sentchatnotification`
--
ALTER TABLE `sentchatnotification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sharepost`
--
ALTER TABLE `sharepost`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `story`
--
ALTER TABLE `story`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `todos`
--
ALTER TABLE `todos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `video_views`
--
ALTER TABLE `video_views`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blocked_accouts`
--
ALTER TABLE `blocked_accouts`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `chatnotification`
--
ALTER TABLE `chatnotification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=809;

--
-- AUTO_INCREMENT for table `chatreceiver`
--
ALTER TABLE `chatreceiver`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=301;

--
-- AUTO_INCREMENT for table `chatsender`
--
ALTER TABLE `chatsender`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=302;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=171;

--
-- AUTO_INCREMENT for table `follower`
--
ALTER TABLE `follower`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `following`
--
ALTER TABLE `following`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=165;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT for table `replies`
--
ALTER TABLE `replies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `report_problem`
--
ALTER TABLE `report_problem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `sentchatnotification`
--
ALTER TABLE `sentchatnotification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sharepost`
--
ALTER TABLE `sharepost`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `story`
--
ALTER TABLE `story`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- AUTO_INCREMENT for table `todos`
--
ALTER TABLE `todos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `video_views`
--
ALTER TABLE `video_views`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
