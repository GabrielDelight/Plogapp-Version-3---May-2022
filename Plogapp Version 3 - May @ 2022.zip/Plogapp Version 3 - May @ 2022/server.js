const express = require('express');
require('events').EventEmitter.prototype._maxListeners = 500;
const path = require('path');
const hbs = require('hbs');
const http = require('http')
const https = require('https');
const app = express();
const socketio = require('socket.io');
const compression = require('compression')
const session = require('express-session')
const crypto = require('crypto')
const bodyParser = require('body-parser')
const cookieParser = require('cookie-parser');;
var cors = require('cors')
const fs = require('fs')
const limitter = require('express-rate-limit')

let hostname = 'plogapp.com'

let httpServer = http.createServer(app)
const server = https.createServer({
    key: fs.readFileSync(path.join(__dirname, './cert', 'key.pem')),
    cert: fs.readFileSync(path.join(__dirname, './cert', 'cert.pem'))
}, app);

app.use(compression({
    level: 9
}))

// app.use((req, res, next) => {
//     // console.log(req)
//     // console.log('http')
//     if (req.protocol == 'http') {
//         res.redirect(301, `https://${req.headers.host}${req.url}`)
//     }
//     next()
// })

// const server = https.createServer({
//     ca: fs.readFileSync('./cert/ssl/plogapp_com.ca-bundle'),
//     cert: fs.readFileSync('./cert/ssl/plogapp_com.crt'),
// }, app);

const io = socketio(server)





// Get routers **************************************************
const userRouter = require('./web-server/routers/rout');
const apoiPostRouter = require('./web-server/routers/appPosts')
const profilePost = require('./web-server/routers/profilePost')
const settingsRouers = require('./web-server/routers/settingsRouters');
const PostCreate = require('./web-server/routers/postRoute')(io);
const myProfileRoute = require('./web-server/routers/profileRoute');
const postContent = require('./web-server/routers/viewPostContent')(io);
const storyRouter = require('./web-server/routers/story')(io);
const replyRoute = require('./web-server/routers/replyRoute')(io);
const followingRote = require('./web-server/routers/following')(io);
const allUsers = require('./web-server/routers/allUsers')(io);
const chatRout = require('./web-server/routers/chatRout')(io)
const followerRout = require('./web-server/routers/follower')(io)
const searchRout = require('./web-server/routers/searchRout')
const dashboardRouter = require('./web-server/routers/dashBoard/dashboardRouter')
const activeRoute = require('./web-server/routers/activeRoute')(io)
const notification = require('./web-server/routers/notification')(io)
const sharePost = require('./web-server/routers/sharePostRouter')(io)
const viewSharePostRouterForImage = require('./web-server/routers/viewSharedPostImage')(io)
const reactors = require('./web-server/routers/reactor.')(io)
const hashTag = require('./web-server/routers/hashTag')
const hideMsgRouter = require('./web-server/routers/hideMsgRouter')(io)
const ideoCallRouter = require('./web-server/routers/videoCall')(io)
const seettingsRouter = require('./web-server/routers/updateRoute')(io)
const blockingRouter = require('./web-server/routers/blocking_router')
const marketRouter = require('./web-server/routers/market')
const videoRouter = require('./web-server/routers/videoRout')
const port = process.env.PORT;

// Configure and serving files
const publicDirPath = path.join(__dirname, '/web-server/web-folder/public');
const viewPath = path.join(__dirname, '/web-server/web-folder/views');
const partialDirctory = path.join(__dirname, '/web-server/web-folder/partials');

app.use(express.static(publicDirPath))
app.set('view engine', 'hbs')
app.set('views', viewPath)
hbs.registerPartials(partialDirctory)
hbs.registerHelper('ifCond', function (v1, v2, options) {
    if (v1 === v2) {
        return options.fn(this);
    }
    return options.inverse(this);
});


hbs.registerHelper('exists', function (variable, options) {
    if (typeof variable !== 'undefined') {
        return options.fn(this);
    }
});


app.use(express.json())
app.use(bodyParser.json())
app.use(express.urlencoded({
    extended: true
}))

// Set up cokies *************************
app.use(cookieParser());

app.use(cors())



// app.use(
//     limitter({
//         windowMs: 5000,
//         max: 5
//     })
// )


// COnfigure routers ******************************************
app.use(userRouter) //User routers
app.use(settingsRouers) //Settings routers 
app.use(PostCreate) //Creating post
app.use(myProfileRoute) //Profile route
app.use(postContent) //View post conetnt
app.use(storyRouter) //Story Router
app.use(replyRoute) //Reply Router
app.use(followingRote) //Following router
app.use(allUsers) //All users
app.use(chatRout) //Chat router
app.use(followerRout) //Followe router
app.use(searchRout) //Router
app.use(dashboardRouter)
app.use(activeRoute)
app.use(notification)
app.use(sharePost)
app.use(viewSharePostRouterForImage)
// app.use(groupChatRout)
app.use(reactors)
app.use(hashTag)
app.use(hideMsgRouter)
app.use(ideoCallRouter)
app.use(seettingsRouter)
app.use(apoiPostRouter)
app.use(profilePost)
app.use(blockingRouter)
app.use(marketRouter)
app.use(videoRouter)

app.get('*', (req, res) => {
    res.render('404Page')
})

server.listen(port, () => {
    console.log("Server runs on " + port)
})
// httpServer.listen(76)
// server.listen(port, () => {
//     console.log("Server runs on " + port)
// })


