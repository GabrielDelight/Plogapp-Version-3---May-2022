const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken')
const auth = require('./auth')
const multer = require('multer');
const mysql = require('mysql');
const crypto = require('crypto')
const sanitizeHtml = require('sanitize-html');
const nodemailer = require('nodemailer')
const dayjs = require('dayjs')
var relativeTime = require('dayjs/plugin/relativeTime')
const path = require('path');
dayjs.extend(relativeTime)
const { fullDateStr } = require('./dateFunction')
const { db } = require('./db') //Database
const fs = require('fs')
const util = require('util')
const unlineLinkFIle = util.promisify(fs.unlink)
const { uploadFile, getFileStream } = require('./s3')

// const Nexmo = require('nexmo')
const Vonage = require('@vonage/server-sdk')

const vonage = new Vonage({
    apiKey: '38a03027',
    apiSecret: '9vRkUOrBZac7EA6E'
}, { debug: true })



module.exports = function (io) {

    // Update user details ****************************
    router.get('/update', auth, async (req, res) => {
        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const userSQL = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        const user = userSQL[0]

        res.render('settings/update', {
            user: user,
        })
    })



    // socket function
    io.on('connection', async socket => {
        socket.on('deleteInfo', async (data) => {
            console.log(data)
            let token = data.jwt
            token = token.replace('auth_token=', '')
            const verifyToken = jwt.verify(token, process.env.JWT_SECRET);
            let token_user = verifyToken;
            console.log(token_user._id)
            console.log(data.deleteOwner)

            console.log(data.deleteOwner == token_user._id)
            if (data.deleteOwner !== token_user._id) {
                socket.emit('bioSuccess', 'Access Denied')
                return console.log('Access Denied')
            }


            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const userSQL = await User(`SELECT * FROM users WHERE _id='${data.deleteOwner}'`)
            const user = userSQL[0]
            const hash = await bcrypt.compare(data.deletePassword, user.password)
            if (!hash) {
                socket.emit('wrongPassword', 'Wrong password')
                return
            }
            socket.emit('showCnfirmBtn', 'block')
        })

        //@ confirm delete account --------
        socket.on('coinfirmPassword', async data => {
            let token = data.jwt
            token = token.replace('auth_token=', '')
            const verifyToken = jwt.verify(token, process.env.JWT_SECRET);
            let token_user = verifyToken;
            // console.log(data.userid == token_user._id)
            if (data.userid !== token_user._id) {
                socket.emit('bioSuccess', 'Access Denied')
                return console.log('Access Denied')
            }

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const userSQL = await User(`SELECT * FROM users WHERE _id='${data.userid}'`)
            const user = userSQL[0]
            // const user = await User.findById(data.userid)
            const hash = await bcrypt.compare(data.currentPassword, user.password)
            if (!hash) {
                socket.emit('wrongChangePass', 'Wrong password')
                return
            }

            // hash password
            const newPass = await bcrypt.hash(data.newPassword, 10)


            let sql = `UPDATE users SET password='${newPass}' WHERE _id='${data.userid}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            socket.emit('passwordSuccess')
        })


        // chnaging ur email address
        socket.on('emailInfo', async data => {
            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const userSQL = await User(`SELECT * FROM users WHERE _id='${data.userid}'`)
            const user = userSQL[0]
            // @ send 6 random digits to the givin email
            let code1 = Math.floor(Math.random() * 10)
            let code2 = Math.floor(Math.random() * 10)
            let code3 = Math.floor(Math.random() * 10)
            let code4 = Math.floor(Math.random() * 10)
            let code5 = Math.floor(Math.random() * 10)
            let code6 = Math.floor(Math.random() * 10)

            let code = [code1, code2, code3, code4, code5, code6]
            code = code.map(el => el.toString())
            code = code.toString().replace(/,/g, '')
            console.log(code)
            socket.emit('oldverifyEmail')
        })

        // verifying the email sent to the mail
        socket.on('emailVerificationCode', async data => {
            const user = await User.findById(data.userid) //user
            if (user.verificationCode !== data.code) {
                socket.emit('rejectCode', 'Invalid code, please check your email and confirm again')
                return
            }
            user.email = data.email
            user.verificationCode = ''
            await user.save()
            socket.emit('changeEmailSuccess')
        })

        // @ number section for modifying
        socket.on('numberInfo', async data => {
            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const userSQL = await User(`SELECT * FROM users WHERE _id='${data.userid}'`)
            const user = userSQL[0]
            // const user = await User.findById() //user
            // @ send 6 random digits to the givin email
            let code1 = Math.floor(Math.random() * 10)
            let code2 = Math.floor(Math.random() * 10)
            let code3 = Math.floor(Math.random() * 10)
            let code4 = Math.floor(Math.random() * 10)
            let code5 = Math.floor(Math.random() * 10)
            let code6 = Math.floor(Math.random() * 10)
            let code = [code1, code2, code3, code4, code5, code6]
            code = code.map(el => el.toString())
            code = code.toString().replace(/,/g, '')
            console.log(code)

            // use node mailer to send code here ****************

            let sql = `UPDATE users SET verificationCode='${code}' WHERE _id='${data.userid}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            // console.log(data.number)


            const from = "Plog App"
            const to = data.countryCode + data.number
            console.log(to)
            const text = 'Your Plogapp  verification code is: ' + code

            vonage.message.sendSms(from, to, text, (err, responseData) => {
                if (err) {
                    console.log(err);
                } else {
                    if (responseData.messages[0]['status'] === "0") {
                        console.log("Message sent successfully.");
                    } else {
                        console.log(`Message failed with error: ${responseData.messages[0]['error-text']}`);
                    }
                }
            })

            socket.emit('verifyNumber')

        })


        socket.on('confirmMobileCode', async data => {
            const user = await User.findById(data.userid) //user
            if (user.verificationCode !== data.code) {
                socket.emit('rejectPhoneCode', 'Invalid code, please check your phone and confirm again')
                return
            }
            user.phoneNumber = data.newNumber.toString()
            user.verificationCode = ''
            await user.save()
            socket.emit('changePhoneSuccess')

        })


        socket.on('nicknameInfo', async data => {

            let token = data.jwt
            token = token.replace('auth_token=', '')
            const verifyToken = jwt.verify(token, process.env.JWT_SECRET);
            let token_user = verifyToken;
            console.log(data.userid == token_user._id)
            if (data.userid !== token_user._id) {
                socket.emit('nicknameExist', 'Access Denied')
                return console.log('Access Denied')
            }

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return
                        }
                        resolve(result)
                    })
                })
            }

            const userSQL = await User(`SELECT * FROM users WHERE fullName='${data.newNickname}'`)

            if (userSQL.length == 0) {
                let sql = `UPDATE users SET fullName='${data.newNickname}' WHERE _id='${data.userid}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })
                socket.emit('nicknameSuccess', 'Nickname changed succesfuly.')
                return
            }

            socket.emit('nicknameExist', data.newNickname + ' has already been taken.')
        })


        socket.on('fullNameInfo', async data => {

            let token = data.jwt
            token = token.replace('auth_token=', '')
            const verifyToken = jwt.verify(token, process.env.JWT_SECRET);
            let token_user = verifyToken;
            console.log(data.userid == token_user._id)
            if (data.userid !== token_user._id) {
                socket.emit('bioSuccess', 'Access Denied')
                return console.log('Access Denied')
            }

            let sql = `UPDATE users SET firstname='${data.firstname}', lastname='${data.lastname}' WHERE _id='${data.userid}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            let sql2 = `UPDATE posts SET possterName='${data.firstname + ' ' + data.lastname}' WHERE owner='${data.userid}'`
            db.query(sql2, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            let sql3 = `UPDATE sharepost SET possterName='${data.firstname + ' ' + data.lastname}' WHERE owner='${data.userid}'`
            db.query(sql3, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            let sql4 = `UPDATE comments SET fullName='${data.firstname + ' ' + data.lastname}' WHERE owner='${data.userid}'`
            db.query(sql4, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            let sql5 = `UPDATE replies SET fullName='${data.firstname + ' ' + data.lastname}' WHERE owner='${data.userid}'`
            db.query(sql5, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            socket.emit('fullNameSuccess', 'You\'ve successfully chnaged your fullname.')
        })


        // @ gender +++++++++++++++++++--------------
        socket.on('genderInfo', async data => {

            let token = data.jwt
            token = token.replace('auth_token=', '')
            const verifyToken = jwt.verify(token, process.env.JWT_SECRET);
            let token_user = verifyToken;
            console.log(data.userid == token_user._id)
            if (data.userid !== token_user._id) {
                socket.emit('bioSuccess', 'Access Denied')
                return console.log('Access Denied')
            }


            let sql = `UPDATE users SET gender='${data.gender}' WHERE _id='${data.userid}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
                socket.emit('successInGender', 'You\'ve successfully chnaged your gender to ' + data.gender + '.')
            })
        })


        // bip
        socket.on('bioInfo', async data => {
            let token = data.jwt
            token = token.replace('auth_token=', '')
            const verifyToken = jwt.verify(token, process.env.JWT_SECRET);
            let user = verifyToken;
            // console.log(data.userid == user._id)
            if (data.userid !== user._id) {
                socket.emit('bioSuccess', 'Access Denied')
                return console.log('Access Denied')
            }




            function sanitizeString(text) {
                return sanitizeHtml(text, {
                    allowedTags: [],
                    allowedAttributes: {}
                });
            }
            let sql = `UPDATE users SET bestSentence='${sanitizeString(data.bio)}' WHERE _id='${data.userid}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })
            socket.emit('bioSuccess', 'You\'ve successfully chnaged your bio')
        })

    })


    router.get('/terms_and_use', async (req, res) => {
        res.render('form/terms_and_use')
    })

    router.get('/about', async (req, res) => {
        res.render('form/about_us')
    })


    // report a problem
    router.get('/report-problem', auth, async (req, res) => {
        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const userSQL = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        const user = userSQL[0]

        res.render('report_problem', {
            user
        })
    })


    router.get('/report', auth, async (req, res) => {
        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const userSQL = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        const user = userSQL[0]

        res.render('report', {
            user
        })
    })

    router.post('/get-user-report', auth, async (req, res) => {

        let sql = 'INSERT INTO report SET ?'

        const report = req.body
        db.query(sql, {
            ...report,
            _id: crypto.randomBytes(12).toString('hex')
        }, (error) => {
            if (error) {
                return console.log(error)
            }
            console.log('Post created')
        })

    })



    const send_image_storage = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/report',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
        }
    })

    const screenShot = multer({
        storage: send_image_storage
    })



    router.post('/report_screenshot', screenShot.single('upload'), auth, async (req, res) => {
        try {

            let day = new Date().getDate()
            let month = new Date().getMonth() + 1
            let year = new Date().getFullYear()
            let mili = new Date().getMilliseconds()

            let hours = new Date().getHours()
            let minutes = new Date().getMinutes()
            let seconds = new Date().getSeconds()

            let fullDateStr = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}:${mili}`


            let filename = ''
            if (req.file) {
                const file = req.file
                await uploadFile(file)
                await unlineLinkFIle(file.path)
                filename = req.file.filename
            }

            let problem = {
                owner: req.user._id,
                _id: crypto.randomBytes(12).toString('hex'),
                title: req.body.title,
                description: req.body.description,
                date: fullDateStr,
                image: filename
            }

            let sql = 'INSERT INTO report_problem SET ?'

            db.query(sql, problem, (error) => {
                if (error) {
                    return console.log(error)
                }
                console.log('Post created')
            })

            res.send({
                success: 'success'
            })
        } catch (error) {
            res.send({
                error: 'error'
            })
        }

    })



    //     let sql =
    // `CREATE TABLE report 
    // (_id VARCHAR(255),
    // id int AUTO_INCREMENT,
    // reporter Text,
    // title Text,
    // description Text,
    // type Text,
    // date Text,
    // PRIMARY KEY (id))`
    // db.query(sql, (error) => {
    //     if (error) {
    //         return console.log(error)
    //     }
    //     console.log('Table creayed')
    // })




    return router
}