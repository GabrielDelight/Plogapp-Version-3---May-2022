const router = require('express').Router()
// const User = require('../models/model');
const path = require('path');
const auth = require('./auth');
const multer = require('multer');
const mysql = require('mysql');
const crypto = require('crypto')
const fs = require('fs')
const util = require('util')


const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})



db.connect((error) => {
    if (error) {
        console.log(error)
    }
})

exports.db = db