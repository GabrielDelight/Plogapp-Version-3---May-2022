const router = require('express').Router();
const auth = require('./auth')
const multer = require('multer');
const path = require('path')
const mysql = require('mysql');
const crypto = require('crypto')
const sanitizeHtml = require('sanitize-html');
const dayjs = require('dayjs')
var relativeTime = require('dayjs/plugin/relativeTime')
dayjs.extend(relativeTime)
const { db } = require('./db') //Database
const { registerLimitter } = require('./expressEmitterDDos')

module.exports = function (io) {

    router.get('/shareLink/:id', auth,  async (req, res) => {
        res.redirect('/post-share-prod-link/' + req.params.id + '?postId=' + req.params.id + '&curUserId=' + req.user._id)
    })

    router.get('/post-share-prod-link/:id', auth, async (req, res) => {
        try {
            async function GETSQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const users = await GETSQL(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            const posts = await GETSQL(`SELECT * FROM sharepost WHERE _id='${req.params.id}'`)
            const comments = await GETSQL(`SELECT * FROM comments WHERE postId='${req.params.id}'`)

            const user = users[0]
            const post = posts[0]

            post.date = dayjs().to(post.date)
            comments.map(cur => cur.date = dayjs().to(cur.date))
            res.render('viewSharedPostImage-min', {
                user: user,
                postDetails: post,
                comment: comments
            })

        } catch (error) {
            console.log(error.message)
            res.render('404Page')
        }

    })


    // video router

    router.get('/sharedLinkVideo/:id', auth,  async (req, res) => {
        res.redirect('/post-video-share-prod-link/' + req.params.id + '?postId=' + req.params.id + '&curUserId=' + req.user._id)
    })

    router.get('/post-video-share-prod-link/:id', auth, async (req, res) => {
        try {
            async function GETSQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const users = await GETSQL(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            const posts = await GETSQL(`SELECT * FROM sharepost WHERE _id='${req.params.id}'`)
            const comments = await GETSQL(`SELECT * FROM comments WHERE postId='${req.params.id}'`)

            const user = users[0]
            const post = posts[0]

            post.date = dayjs().to(post.date)
            comments.map(cur => cur.date = dayjs().to(cur.date))
            res.render('viewSharedPostVideo-min', {
                user: user,
                postDetails: post,
                comment: comments
            })

        } catch (error) {
            console.log(error.message)
            res.render('404Page')
        }

    })



    // @ set up validation for image upload
    const storage = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/commentImages',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
        }
    })
    const upload = multer({
        // limits: 300000,
        storage: storage
    })



    // COmment
    router.post('/shareComment', auth, upload.single('uploadImg'), async (req, res) => {
        async function SQL(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        const userx = await SQL(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        let user = userx[0]


        let verify = user.verified
        let day = new Date().getDate()
        let month = new Date().getMonth() + 1
        let year = new Date().getFullYear()
        let mili = new Date().getMilliseconds()

        let hours = new Date().getHours()
        let minutes = new Date().getMinutes()
        let seconds = new Date().getSeconds()

        let fullDateStr = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}:${mili}`



        try {

            let id = req.body.redirectId
            const posts = await SQL(`SELECT * FROM sharepost WHERE _id='${id}'`)
            let post = posts[0]


            let image;
            let hideImage = 'none'
            if (req.file) {
                image = req.file.filename
                hideImage = 'block'
            }

            let redirectId = 'sharedLinkVideo/'

            if (post.postType == 'shareimage' || post.postType == 'sharetext') {
                redirectId = `shareLink/`
            }

            // Sanitizing my html
            const sanitizedComment = sanitizeHtml(req.body.comment, {
                allowedTags: [],
                allowedAttributes: {}
            });

            req.body.comment = sanitizedComment
            if (sanitizedComment == '') {
                console.log('Invalid string please try agaian later.')
                // res.send({
                //     errormsg: 'Invalid string please try agaian later.'
                // })
                return
            }


            const _id = crypto.randomBytes(12).toString('hex')

            const comment = {
                comment: sanitizedComment,
                _id,
                owner: user._id,
                postId: id,
                fullName: `${user.firstname} ${user.lastname}`,
                image,
                hideImage,
                date: new Date(new Date().getTime()),
                commentorNickName: user.fullName,
                verified: verify,
                post_url: redirectId,
                avatar: user.avatar,
                hideReply: 'none',
            }

            let sql = 'INSERT INTO comments SET ?'
            db.query(sql, comment, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            let updatesql = `UPDATE sharepost SET commentlength='${req.body.commentLength}' WHERE _id='${post._id}'`
            db.query(updatesql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            let updateLastCommentInPost = `UPDATE sharepost SET commentlength='${req.body.commentLength}',Initcomment='${req.body.comment}',commentImage='${user._id}',commentName='${user.firstname} ${user.lastname}',verifiedComment='${user.verified}',commentWidth='20',commentHeight='20',hideLastComment='block',lastCommentAvatar='${user.avatar}' WHERE _id='${posts[0]._id}'`

            db.query(updateLastCommentInPost, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // res.redirect('/' + redirectId + post._id)

            const checkowner = post.owner.toString() !== user._id.toString()
            if (checkowner) {
                const notification = {
                    owner: user._id,
                    _id: crypto.randomBytes(12).toString('hex'),
                    text: 'Commented on your post',
                    comment: req.body.comment,
                    eventId: id,
                    eventOwner: post.owner,
                    date: new Date(new Date().getTime()),
                    ownerName: `${user.firstname} ${user.lastname}`,
                    avatar: user.avatar,
                    urlLink: redirectId + id
                }

                let sql = 'INSERT INTO notification SET ?'
                db.query(sql, notification, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })




                let findNotifcationOwner = await SQL(`SELECT * FROM users WHERE _id='${post.owner}'`)
                let eventOwner = findNotifcationOwner[0]
                if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                    let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${post.owner}'`
                    db.query(sql, (error) => {
                        if (error) return console.log(error)
                    })
                    res.redirect('/' + redirectId + post._id)
                    return
                } else {
                    let count = parseInt(eventOwner.notifiicationLength)
                    count = count += 1
                    let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${post.owner}'`
                    db.query(sqlQueryForCOunt, (error) => {
                        if (error) return console.log(error)
                    })
                }


            }


            // io.emit('appendPostListener',)

            res.send(JSON.stringify({
                ...comment,
                mainuser_id: req.user._id,
                postId: req.body.redirectId
            }))



        } catch (error) {
            console.log(error)
            // res.redirect(`/shareLink/${id}`)
        }

    }, (error, req, res, next) => {
        res.redirect('/home')
    })





    // Delete comment
    router.get('/deleteSharedImage/:id', async (req, res) => {
        const comment = await Comment.findByIdAndDelete(req.params.id);
        await Reply.deleteMany({ mainCommentId: comment._id })
        res.redirect(`/shareLink/${comment.postId}`)

        // decrease the comment number by decrementng the vale
        const post = await SharedPost.findByIdAndUpdate({ _id: comment.postId })
        let len = parseInt(post.commentlength)
        let newLen = len -= 1 //decrementing
        post.commentlength = newLen
        await post.save()

    })

    return router
}