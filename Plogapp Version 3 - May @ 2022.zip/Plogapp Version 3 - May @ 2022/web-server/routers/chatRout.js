const router = require('express').Router();
const auth = require('./auth')
const multer = require('multer')
const path = require('path');
const mysql = require('mysql');
const crypto = require('crypto')
const fs = require('fs')
const util = require('util')
const sanitizeHtml = require('sanitize-html');
const unlineLinkFIle = util.promisify(fs.unlink)
const dayjs = require('dayjs')
var relativeTime = require('dayjs/plugin/relativeTime')
dayjs.extend(relativeTime)
const { uploadFile, getFileStream } = require('./s3')

const { db } = require('./db') //Datbase



module.exports = function (io) {

    router.get('/chat/:id', auth, async (req, res) => {
        async function SQLQUERRY(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        let user = userx[0]

        res.render('chat', {
            user,
        })
    })


    router.get('/chat', auth, async (req, res) => {
        async function SQLQUERRY(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        let user = userx[0]


        res.render('chat', {
            user
        })

    })

    // api to fetch list of chat
    router.get('/chat_messages_api/:id', auth, async (req, res) => {
        try {
            async function SQLQUERRY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = userx[0]

            const findUser2 = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.params.id}'`)
            let user2 = findUser2[0]


            const otherChat = await SQLQUERRY(`SELECT * FROM chatreceiver WHERE receiverId='${user._id}' AND owner='${req.params.id}'`)
            const myChat = await SQLQUERRY(`SELECT * FROM chatsender WHERE owner='${user._id}' AND receiverId='${req.params.id}'`)
            let allChat = myChat.concat(otherChat)

            let messages = allChat.sort((a, b) => {
                let c = new Date(a._id)
                let d = new Date(b._id)
                return c - d
            })

            res.send(messages)

            // Update the chat notification
            // @ check if the chat messages  has been read or not
            let sql = `UPDATE chatnotification SET chatReadColor='cornflowerblue' WHERE receiverId='${req.params.id}' AND owner='${req.user._id}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            // Update the chat mesaages sent 
            let sqlchatQuery = `UPDATE chatsender SET readChatColor='cornflowerblue' WHERE receiverId='${req.user._id}' AND owner='${req.params.id}'`
            db.query(sqlchatQuery, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // Remove the messages length if the user reads the message sent to him or her
            let removeUnreadmessageCOunter = `UPDATE chatnotification SET unreadLength='', displayMessageCounter='none', readType='read' WHERE receiverId='${req.user._id}' AND owner='${req.params.id}'`
            db.query(removeUnreadmessageCOunter, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            // Cheange to read
            // let sql_x = `UPDATE chatnotification SET readType='read' WHERE receiverId='${req.user._id}' AND owner='${req.params.id}'`
            // db.query(sql_x, (error) => {
            //     if (error) {
            //         return console.log(error)
            //     }
            // })
        } catch (error) {
            console.log(error)
            res.send('An error occured')
        }

    })

    // check when the user read the chat
    router.get('/check_messages_read/:id', auth, async (req, res) => {
        // console.log(req.params.id)
        // Update the chat message list 
        // @ check if the chat messages  has been read or not
        let sql = `UPDATE chatnotification SET chatReadColor='cornflowerblue' WHERE receiverId='${req.params.id}' AND owner='${req.user._id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)

            }

            // Remove the messages length if the user reads the message sent to him or her
            let removeUnreadmessageCOunter = `UPDATE chatnotification SET unreadLength='', displayMessageCounter='none' WHERE receiverId='${req.user._id}' AND owner='${req.params.id}'`
            db.query(removeUnreadmessageCOunter, (error) => {
                if (error) {
                    return console.log(error)
                }
            })
        })

    })


    // notification list api
    router.get('/messages-api', auth, async (req, res) => {
        try {
            async function SQLQUERY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            const userSQL = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            const user = userSQL[0]
            let chatNotification = await SQLQUERY(`SELECT * FROM chatnotification WHERE receiverId='${user._id}' ORDER BY id DESC`)
            chatNotification.map(cur => cur.date = dayjs().to(cur.date))
            res.send(chatNotification)
            // console.log(chatNotification[0])
        } catch (error) {
            console.log(error)
        }
    })


    // get all notifiation that is unread 
    router.get('/unread_messages', auth, async (req, res) => {
        try {
            async function SQLQUERY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            const userSQL = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            const user = userSQL[0]
            let unreadArr = []
            let chatNotification = await SQLQUERY(`SELECT * FROM chatnotification WHERE receiverId='${user._id}' ORDER BY id DESC`)
            for (i = 0; i < chatNotification.length; i++) {
                if (chatNotification[i].unreadLength == '') {
                    continue
                }
                unreadArr.push(chatNotification[i].unreadLength)

            }

            res.send({
                unreadCount: unreadArr.length
            })

        } catch (error) {
            console.log(error)
        }
    })

    // Workng with real time in socket io for the chat **********************************
    io.on('connection', (socket) => {

        // Check is user is online or not
        socket.on('user_is_online', data => {
            // console.log(data)
            socket.broadcast.emit('find_if_user_is_online', data)

            socket.on('error', function (err) {
                console.log(err);
            });
        })


        socket.on('user_is_active', data => {
            socket.broadcast.emit('say_user_is_active', data)
        })

        

        // Save chat to send to recipient and not appending to user that sent
        socket.on('saveChat', async (data) => {
            async function SQLQUERRY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.owner}'`)
            let user = userx[0]
            let randomChatId1x = crypto.randomBytes(12).toString('hex')
            let randomIdForReplyCHat = crypto.randomBytes(12).toString('hex')

            // Sanitize html 
            const sanitizeText = sanitizeHtml(data.message, {
                allowedTags: [],
                allowedAttributes: {}
            });
            data.message = sanitizeText

            if (data.message == '') return

            if (data.replyOldMessage == '') {
                //Send immediately to the browser                

                let newData = {
                    ...data,
                    randomChatId1x,
                    randomIdForReplyCHat,
                    avatar: user.avatar
                }

                io.emit('displayMessage', newData)


                const chatReceiver = {
                    ...data,
                    _id: new Date(),
                    randomId: randomChatId1x,
                    ownerName: user.firstname + ' ' + user.lastname,
                    pushChat: 'pushLeft',
                    hide: 'none',
                    hideOldReply: 'none',
                    hideVideo: 'none',
                    chatType: 'text',
                    hideAudio: 'none',
                    hideStory: 'none',
                    hideVoiceNote: 'none',
                    count: 1
                }

                let sql = 'INSERT INTO chatreceiver SET ?'
                db.query(sql, chatReceiver, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })


                // Send notification by adding "+1" to user details
                let sqlForUser = `UPDATE users SET chatNotification='+1' WHERE _id='${data.receiverId}'`
                db.query(sqlForUser, (error) => {
                    if (error) return console.log(error)
                })

                // send quick notification to all header icons
                socket.broadcast.emit('newMsg', 'New')

            } else {
                //Send Reply chat immediately to the receiver's page or browser
                io.emit('displayMessage', {
                    ...data,
                    randomId: randomChatId1x,
                })


                const ChatReceiver = {
                    ...data,
                    _id: new Date(),
                    randomId: randomIdForReplyCHat,
                    ownerName: user.firstname + ' ' + user.lastname,
                    pushChat: 'replyPushLeft',
                    hide: 'none',
                    hideVideo: 'none',
                    hideOldReply: 'block',
                    chatType: 'text',
                    hideAudio: 'none',
                    hideStory: 'none',
                    hideVoiceNote: 'none',
                    count: 1
                }

                let sql = 'INSERT INTO chatreceiver SET ?'
                db.query(sql, ChatReceiver, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })


                // Send notification by adding "+1" to user details
                let sqlForUser = `UPDATE users SET chatNotification='+1' WHERE _id='${data.receiverId}'`
                db.query(sqlForUser, (error) => {
                    if (error) return console.log(error)
                })

                // send quick notification to all header icons
                socket.broadcast.emit('newMsg', 'New')
            }


        })


        // Save chat to append to user that sent it ******************
        socket.on('myChat', async (data) => {

            // Sanitize html 
            const sanitizeText = sanitizeHtml(data.message, {
                allowedTags: [],
                allowedAttributes: {}
            });

            data.message = sanitizeText

            if (data.message == '') return

            async function SQLQUERRY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.owner}'`)
            let user = userx[0]

            const chatReeivers = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.receiverId}'`)
            let chatReeiver = chatReeivers[0]

            let randomId1ForNormalChat = crypto.randomBytes(12).toString('hex')
            let randomIdForReply = crypto.randomBytes(12).toString('hex')

            let newData = {
                ...data,
                randomId1ForNormalChat,
                randomIdForReply,
                avatar: user.avatar
            }

            io.emit('displayMessageForOwner', newData)
            if (data.replyOldMessage == '') {
                const Chatsender = {
                    ...data,
                    _id: new Date(),
                    randomId: randomId1ForNormalChat,
                    ownerName: user.firstname + ' ' + user.lastname,
                    pushChat: 'pushRight',
                    hide: 'none',
                    hideOldReply: 'none',
                    chatType: 'text',
                    hideVideo: 'none',
                    hideAudio: 'none',
                    hideStory: 'none',
                    hideVoiceNote: 'none',
                }


                let sql1 = 'INSERT INTO chatsender SET ?'
                db.query(sql1, Chatsender, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })

                //Chat notification  **********************************************************************
                // Deleteing old notification so it wont  dublicate for chat sender
                let sql3 = `DELETE FROM chatnotification WHERE owner='${data.owner}' AND receiverId='${data.receiverId}'`
                db.query(sql3, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                })


                // Deleteing old notification so it wont  dublicate for chat reciever
                let sql3_c = `DELETE FROM chatnotification WHERE owner='${data.receiverId}' AND receiverId='${data.owner}'`
                db.query(sql3_c, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                })

                // get the unread chat length
                const unreadChats = await SQLQUERRY(`SELECT * FROM chatsender WHERE receiverId='${data.receiverId}' AND owner='${data.owner}' AND readChatColor='gray'`)


                // make notification for chat receiver
                let randomId3 = crypto.randomBytes(12).toString('hex')
                // Save the chat notification
                const chatNotification = {
                    _id: randomId3,
                    owner: data.owner,
                    message: data.message,
                    date: new Date(new Date().getTime()),
                    receiverId: data.receiverId,
                    ownerName: data.ownerName,
                    replyOldMessage: data.replyOldMessage,
                    receiverName: data.receiverName,
                    lastChat: data.message,
                    avatar: user.avatar,
                    ownerName: user.firstname + ' ' + user.lastname,
                    unreadLength: unreadChats.length,
                    displayMessageCounter: 'block'
                }
                delete chatNotification.replyOldMessage

                let sql4 = 'INSERT INTO chatnotification SET ?'
                db.query(sql4, chatNotification, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })


                // make notification for chat sender
                let randomId4 = crypto.randomBytes(12).toString('hex')
                // Save the chat notification
                const chatNotificationTwo = {
                    _id: randomId4,
                    owner: data.receiverId,
                    receiverId: data.owner,
                    message: data.message,
                    date: new Date(new Date().getTime()),
                    ownerName: data.receiverName,
                    receiverName: data.ownerName,
                    replyOldMessage: data.replyOldMessage,
                    lastChat: data.message,
                    avatar: chatReeiver.avatar,
                    showCheckIcon: 'block',
                    // chatReadColor: 'cornflowerblue',

                    // ownerName: user.firstname + ' ' + user.lastname
                }
                delete chatNotificationTwo.replyOldMessage

                let sql4CHatTwo = 'INSERT INTO chatnotification SET ?'
                db.query(sql4CHatTwo, chatNotificationTwo, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })



                // appending chat notification 
                let updateMsgData = {
                    ...data,
                    avatar: user.avatar
                }
                io.emit('updateMessage', {
                    ...updateMsgData,
                    _id: chatNotification._id
                })

            } else {

                // Chat sending ==============================================
                const Chatsender = {
                    ...data,
                    _id: new Date(),
                    randomId: randomIdForReply,
                    ownerName: user.firstname + ' ' + user.lastname,
                    pushChat: 'replyPushRight',
                    hide: 'none',
                    hideVideo: 'none',
                    chatType: 'text',
                    hideOldReply: 'block',
                    hideAudio: 'none',
                    hideStory: 'none',
                    hideVoiceNote: 'none',
                }

                let sql5 = 'INSERT INTO chatsender SET ?'
                db.query(sql5, Chatsender, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })

                //Chat notification  **********************************************************************

                // Deleteing old notification so it wont  dublicate for chat sender
                let sql3 = `DELETE FROM chatnotification WHERE owner='${data.owner}' AND receiverId='${data.receiverId}'`
                db.query(sql3, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                })


                // Deleteing old notification so it wont  dublicate for chat reciever
                let sql3_c = `DELETE FROM chatnotification WHERE owner='${data.receiverId}' AND receiverId='${data.owner}'`
                db.query(sql3_c, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                })

                // make notification for chat sender
                let randomId3 = crypto.randomBytes(12).toString('hex')
                // Save the chat notification
                const chatNotification = {
                    _id: randomId3,
                    owner: data.owner,
                    message: data.message,
                    date: new Date(new Date().getTime()),
                    receiverId: data.receiverId,
                    ownerName: data.ownerName,
                    replyOldMessage: data.replyOldMessage,
                    receiverName: data.receiverName,
                    lastChat: data.message,
                    avatar: user.avatar,
                    ownerName: user.firstname + ' ' + user.lastname
                }
                delete chatNotification.replyOldMessage

                let sql4 = 'INSERT INTO chatnotification SET ?'
                db.query(sql4, chatNotification, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })


                // make notification for chat sender
                let randomId4 = crypto.randomBytes(12).toString('hex')
                // Save the chat notification
                const chatNotificationTwo = {
                    _id: randomId4,
                    owner: data.receiverId,
                    receiverId: data.owner,
                    message: data.message,
                    date: new Date(new Date().getTime()),
                    ownerName: data.receiverName,
                    receiverName: data.ownerName,
                    replyOldMessage: data.replyOldMessage,
                    lastChat: data.message,
                    avatar: chatReeiver.avatar,
                    // ownerName: user.firstname + ' ' + user.lastname
                }
                delete chatNotificationTwo.replyOldMessage

                let sql4CHatTwo = 'INSERT INTO chatnotification SET ?'
                db.query(sql4CHatTwo, chatNotificationTwo, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })

                // appending chat notification 
                io.emit('updateMessage', {
                    ...data,
                    _id: chatNotification._id
                })

            }

        })


        // Send typing to client browser ***********
        socket.on('sendTyping', (data) => {
            socket.broadcast.emit('showTyping', data)
        })

        socket.on('sendHideTyping', (data) => {
            socket.broadcast.emit('showHideTyping', data)
        })
        // ========================



        // Story selection for Story receiver
        socket.on('storyReceiver', async (data) => {
            try {
                async function SQLQUERRY(val) {
                    return new Promise((resolve, reject) => {
                        let sql = val
                        db.query(sql, (error, result) => {
                            if (error) {
                                return console.log(error)
                            }
                            resolve(result)
                        })
                    })
                }
                const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.owner}'`)
                let user = userx[0]
                // console.log(data)
                const chatReeivers = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.receiverId}'`)
                let chatReeiver = chatReeivers[0]
                // console.log(chatReeiver)

                // Sanitize html 
                const sanitizeText = sanitizeHtml(data.message, {
                    allowedTags: [],
                    allowedAttributes: {}
                });
                data.message = sanitizeText

                const ChatReceiver = {
                    ...data,
                    _id: new Date(),
                    ownerName: user.firstname + ' ' + user.lastname,
                    storyImageUrl: data.storyImageUrl,
                    pushChat: 'pushStoryLeft',
                    hide: 'none',
                    hideOldReply: 'none',
                    chatType: 'text',
                    hideVideo: 'none',
                    hideAudio: 'none',
                    hideStory: 'block',
                    hideVoiceNote: 'none',
                }


                let sql = 'INSERT INTO chatreceiver SET ?'
                db.query(sql, ChatReceiver, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })


                // Send notification by adding "+1" to user details
                let sqlForUser = `UPDATE users SET chatNotification='+1' WHERE _id='${data.receiverId}'`
                db.query(sqlForUser, (error) => {
                    if (error) return console.log(error)
                })

                //Chat notification  **********************************************************************
                // Deleteing old notification so it wont  dublicate for chat sender
                let sql3 = `DELETE FROM chatnotification WHERE owner='${data.owner}' AND receiverId='${data.receiverId}'`
                db.query(sql3, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                })


                // Deleteing old notification so it wont  dublicate for chat reciever
                let sql3_c = `DELETE FROM chatnotification WHERE owner='${data.receiverId}' AND receiverId='${data.owner}'`
                db.query(sql3_c, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                })

                // get the unread chat length
                const unreadChats = await SQLQUERRY(`SELECT * FROM chatsender WHERE receiverId='${data.receiverId}' AND owner='${data.owner}' AND readChatColor='gray'`)

                // make notification for chat sender
                let randomId3 = crypto.randomBytes(12).toString('hex')
                // Save the chat notification
                const chatNotification = {
                    _id: randomId3,
                    owner: data.owner,
                    message: data.message,
                    message_icon: 'fa fa-pencil',
                    date: new Date(new Date().getTime()),
                    receiverId: data.receiverId,
                    ownerName: data.ownerName,
                    replyOldMessage: data.replyOldMessage,
                    receiverName: data.receiverName,
                    lastChat: data.message,
                    avatar: user.avatar,
                    ownerName: user.firstname + ' ' + user.lastnam,
                    unreadLength: unreadChats.length,
                    displayMessageCounter: 'block'
                }
                delete chatNotification.replyOldMessage

                let sql4 = 'INSERT INTO chatnotification SET ?'
                db.query(sql4, chatNotification, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })



                // make notification for chat sender
                let randomId4 = crypto.randomBytes(12).toString('hex')
                // Save the chat notification
                const chatNotificationTwo = {
                    _id: randomId4,
                    owner: data.receiverId,
                    message: data.message,
                    date: new Date(new Date().getTime()),
                    receiverId: data.owner,
                    message_icon: 'fa fa-pencil',
                    showCheckIcon: 'block',
                    ownerName: data.receiverName,
                    lastChat: data.message,
                    receiverName: data.ownerName,
                    replyOldMessage: data.replyOldMessage,
                    avatar: chatReeiver.avatar,

                    // ownerName: user.firstname + ' ' + user.lastname
                }
                delete chatNotificationTwo.replyOldMessage

                let sql4CHatTwo = 'INSERT INTO chatnotification SET ?'
                db.query(sql4CHatTwo, chatNotificationTwo, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })


            } catch (error) {
                console.log('Error messages')
            }

        })


        // Message for Chat owner sending chat
        socket.on('storyOwner', async (data) => {
            async function SQLQUERRY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.owner}'`)
            let user = userx[0]

            // Sanitize html 
            const sanitizeText = sanitizeHtml(data.message, {
                allowedTags: [],
                allowedAttributes: {}
            });
            data.message = sanitizeText

            const Chatsender = {
                ...data,
                _id: new Date(),
                storyImageUrl: data.storyImageUrl,
                ownerName: user.firstname + ' ' + user.lastname,
                pushChat: 'pushStoryRight',
                hide: 'none',
                hideOldReply: 'none',
                chatType: 'text',
                hideVideo: 'none',
                hideAudio: 'none',
                hideStory: 'block',
                hideVoiceNote: 'none',
            }

            let sql4 = 'INSERT INTO chatsender SET ?'
            db.query(sql4, Chatsender, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

        })


    })



    let arrayOfDetails = []
    io.on('connection', (socket) => {
        socket.on('imageDetails', (data) => {
            arrayOfDetails.push(data)
        })

    })


    // Viewing up images for chat Sender
    router.get('/webStorage/chatImages/:key', auth, async (req, res) => {
        let key = req.params.key
        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        try {
            const CHatImagesSender = await User(`SELECT * FROM chatsender WHERE image='${key}'`)
            const CHatImagesReceiver = await User(`SELECT * FROM chatreceiver WHERE image='${key}'`)
            const chatsender = CHatImagesSender[0]
            const chatreceiver = CHatImagesReceiver[0]

            if (!chatsender && !chatreceiver) {
                const readStream = getFileStream('image-error.jpg')
                readStream.pipe(res)
                return
            }


            const readStream = getFileStream(key)
            readStream.pipe(res)
        } catch (error) {
            console.log('Error', error.message)
        }
    })


    // @ set up validation for image upload
    const storageForChatImages = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/chatImages',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + Date.now() + path.extname(file.originalname))
        }
    })
    const uploadForChatImages = multer({
        // limits: 300000,
        storage: storageForChatImages
    })



    router.post('/chatImageUpload/:id', auth, uploadForChatImages.single('uploads'), async (req, res) => {
        try {
            async function SQLQUERRY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            // const user = await User.findById(req.user)
            const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = userx[0]

            // const sencondUser = await User.findById(req.params.id)
            const sencondUsers = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.params.id}'`)
            let sencondUser = sencondUsers[0]

            let file = req.file
            await uploadFile(file).then(data => {
                // console.log(data)
            }).catch(err => {
                console.log(err)
            })
            await unlineLinkFIle(file.path)

            let data = {
                owner: user._id,
                ownerName: user.firstname + ' ' + user.lastname,
                receiverId: req.params.id,
                receiverName: sencondUser.firstname + ' ' + sencondUser.lastname,
            }

            // Sanitize html 
            const sanitizeText = sanitizeHtml(req.body.message, {
                allowedTags: [],
                allowedAttributes: {}
            });

            req.body.message = sanitizeText


            let randomChatId1 = crypto.randomBytes(12).toString('hex')
            const Chatsender = {
                ...data,
                _id: new Date(),
                randomId: randomChatId1,
                message: req.body.message,
                image: req.file.filename,
                pushChat: 'pushImgRight',
                chatType: 'image',
                hide: 'block',
                hideVideo: 'none',
                hideChatText: 'none',
                hideAudio: 'none',
                hideStory: 'none',
                hideVoiceNote: 'none',
            }

            let sql = 'INSERT INTO chatsender SET ?'
            db.query(sql, Chatsender, (error) => {
                if (error) {
                    return console.log(error)
                }
            })



            let randomChatId2 = crypto.randomBytes(12).toString('hex')
            const ChatReceiver = {
                ...data,
                _id: new Date(),
                randomId: randomChatId2,
                image: req.file.filename,
                pushChat: 'pushImgLeft',
                chatType: 'image',
                message: req.body.message,
                hide: 'block',
                hideChatText: 'none',
                hideVideo: 'none',
                hideAudio: 'none',
                hideStory: 'none',
                hideVoiceNote: 'none',
            }

            let sql2 = 'INSERT INTO chatreceiver SET ?'
            db.query(sql2, ChatReceiver, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // Send notification by adding "+1" to user details
            let sqlForUser = `UPDATE users SET chatNotification='+1' WHERE _id='${sencondUser._id}'`
            db.query(sqlForUser, (error) => {
                if (error) return console.log(error)
            })


            //Chat notification  **********************************************************************
            // Deleteing old notification so it wont  dublicate for chat sender
            let sql3 = `DELETE FROM chatnotification WHERE owner='${data.owner}' AND receiverId='${data.receiverId}'`
            db.query(sql3, (error, result) => {
                if (error) {
                    return console.log(error)
                }
            })


            // Deleteing old notification so it wont  dublicate for chat reciever
            let sql3_c = `DELETE FROM chatnotification WHERE owner='${data.receiverId}' AND receiverId='${data.owner}'`
            db.query(sql3_c, (error, result) => {
                if (error) {
                    return console.log(error)
                }
            })

            // get the unread chat length
            const unreadChats = await SQLQUERRY(`SELECT * FROM chatsender WHERE receiverId='${data.receiverId}' AND owner='${data.owner}' AND readChatColor='gray'`)

            // make notification for chat receiver
            let randomId3 = crypto.randomBytes(12).toString('hex')
            // Save the chat notification
            const chatNotification = {
                _id: randomId3,
                owner: data.owner,
                message: 'Photo',
                message_icon: 'fa fa-photo',
                date: new Date(new Date().getTime()),
                receiverId: data.receiverId,
                ownerName: data.ownerName,
                replyOldMessage: data.replyOldMessage,
                receiverName: data.receiverName,
                lastChat: 'Photo',
                avatar: user.avatar,
                ownerName: user.firstname + ' ' + user.lastname,
                unreadLength: unreadChats.length,
                displayMessageCounter: 'block'
            }
            delete chatNotification.replyOldMessage

            let sql4 = 'INSERT INTO chatnotification SET ?'
            db.query(sql4, chatNotification, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // make notification for chat sender
            let randomId4 = crypto.randomBytes(12).toString('hex')
            // Save the chat notification
            const chatNotificationTwo = {
                _id: randomId4,
                owner: data.receiverId,
                receiverId: data.owner,
                message: 'Photo',
                message_icon: 'fa fa-photo',
                date: new Date(new Date().getTime()),
                ownerName: data.receiverName,
                receiverName: data.ownerName,
                replyOldMessage: data.replyOldMessage,
                lastChat: 'Photo',
                avatar: sencondUser.avatar,
                showCheckIcon: 'block'
                // ownerName: user.firstname + ' ' + user.lastname
            }
            delete chatNotificationTwo.replyOldMessage

            let sql4CHatTwo = 'INSERT INTO chatnotification SET ?'
            db.query(sql4CHatTwo, chatNotificationTwo, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            // res.redirect('/chat/' + data.receiverId)
            let sendData = {
                chatsender: Chatsender._id,
                chatReceiver: ChatReceiver._id,
                randomChatId1,
                randomChatId2,
                image: req.file.filename,
                owner: req.user._id,
                message: req.body.message,
                receiverId: data.receiverId
            }

            io.emit('photoListen', sendData)


            res.send(JSON.stringify(sendData))
        } catch (error) {
            console.log(error)
            res.redirect('/chat/' + req.params.id)
        }

    }, async (error, req, res, next) => {
        console.log(error)
        res.redirect('/chat/' + req.params.id)
    })


    // send image immdiately
    io.on('connection', (socket) => {
        socket.on('imageSrc', (data) => {
            console.log(socket)
            socket.broadcast.emit('showImg', data)
        })
    })





    // Video upload ******************************************
    // @ set up validation for image upload
    const storageForChatVideos = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/chatVideos',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
        }
    })
    const uploadForChatVideos = multer({
        // limits: 300000,
        storage: storageForChatVideos
    })

    router.post('/videoChatUpload/:id', auth, uploadForChatVideos.single('uploads'), async (req, res) => {
        try {
            async function SQLQUERRY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            // const user = await User.findById(req.user)
            const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = userx[0]

            // const sencondUser = await User.findById(req.params.id)
            const sencondUsers = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.params.id}'`)
            let sencondUser = sencondUsers[0]

            // const user = await User.findById(req.user)
            // const sencondUser = await User.findById(req.params.id)

            let file = req.file
            await uploadFile(file)
            await unlineLinkFIle(file.path)


            let data = {
                owner: user._id,
                ownerName: user.firstname + ' ' + user.lastname,
                receiverId: req.params.id,
                receiverName: sencondUser.firstname + ' ' + sencondUser.lastname,
            }

            let randomChatId1 = crypto.randomBytes(12).toString('hex')

            const Chatsender = {
                ...data,
                _id: new Date(),
                randomId: randomChatId1,
                video: req.file.filename,
                pushChat: 'pushVideoRight',
                chatType: 'video',
                hide: 'none',
                hideVideo: 'block',
                hideAudio: 'none',
                hideStory: 'none',
                hideVoiceNote: 'none',
            }

            let sql = 'INSERT INTO chatsender SET ?'
            db.query(sql, Chatsender, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            let randomChatId2 = crypto.randomBytes(12).toString('hex')

            const ChatReceiver = {
                ...data,
                _id: new Date(),
                randomId: randomChatId2,
                video: req.file.filename,
                pushChat: 'pushVideoLeft',
                chatType: 'video',
                hide: 'none',
                hideVideo: 'block',
                hideAudio: 'none',
                hideStory: 'none',
                hideVoiceNote: 'none',
            }

            let sql2 = 'INSERT INTO chatreceiver SET ?'
            db.query(sql2, ChatReceiver, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            // **********************************************************************
            // Send notification by adding "+1" to user details
            let sqlForUser = `UPDATE users SET chatNotification='+1' WHERE _id='${sencondUser._id}'`
            db.query(sqlForUser, (error) => {
                if (error) return console.log(error)
            })


            //Chat notification  **********************************************************************
            // Deleteing old notification so it wont  dublicate for chat sender
            let sql3 = `DELETE FROM chatnotification WHERE owner='${data.owner}' AND receiverId='${data.receiverId}'`
            db.query(sql3, (error, result) => {
                if (error) {
                    return console.log(error)
                }
            })


            // Deleteing old notification so it wont  dublicate for chat reciever
            let sql3_c = `DELETE FROM chatnotification WHERE owner='${data.receiverId}' AND receiverId='${data.owner}'`
            db.query(sql3_c, (error, result) => {
                if (error) {
                    return console.log(error)
                }
            })

            // make notification for chat receiver
            // get the unread chat length
            const unreadChats = await SQLQUERRY(`SELECT * FROM chatsender WHERE receiverId='${data.receiverId}' AND owner='${data.owner}' AND readChatColor='gray'`)

            let randomId3 = crypto.randomBytes(12).toString('hex')
            // Save the chat notification
            const chatNotification = {
                _id: randomId3,
                owner: data.owner,
                message: 'Video',
                message_icon: 'fa fa-camera',
                date: new Date(new Date().getTime()),
                receiverId: data.receiverId,
                ownerName: data.ownerName,
                replyOldMessage: data.replyOldMessage,
                receiverName: data.receiverName,
                lastChat: 'Video',
                avatar: user.avatar,
                ownerName: user.firstname + ' ' + user.lastname,
                unreadLength: unreadChats.length,
                displayMessageCounter: 'block'
            }
            delete chatNotification.replyOldMessage

            let sql4 = 'INSERT INTO chatnotification SET ?'
            db.query(sql4, chatNotification, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // make notification for chat sender
            let randomId4 = crypto.randomBytes(12).toString('hex')
            // Save the chat notification
            const chatNotificationTwo = {
                _id: randomId4,
                owner: data.receiverId,
                receiverId: data.owner,
                message: 'Video',
                message_icon: 'fa fa-camera',
                date: new Date(new Date().getTime()),
                ownerName: data.receiverName,
                receiverName: data.ownerName,
                replyOldMessage: data.replyOldMessage,
                lastChat: 'Video',
                avatar: sencondUser.avatar,
                showCheckIcon: 'block',

                // ownerName: user.firstname + ' ' + user.lastname
            }
            delete chatNotificationTwo.replyOldMessage

            let sql4CHatTwo = 'INSERT INTO chatnotification SET ?'
            db.query(sql4CHatTwo, chatNotificationTwo, (error) => {
                if (error) {
                    return console.log(error)
                }
            })




            let sendData = {
                chatsender: Chatsender._id,
                chatReceiver: ChatReceiver._id,
                randomChatId1,
                randomChatId2,
                video: req.file.filename,
                message: req.body.message,
                owner: req.user._id,
                receiverId: data.receiverId
            }

            io.emit('videoListen', sendData)

            res.send(JSON.stringify(sendData))
            // res.redirect('/chat/' + data.receiverId)
        } catch (error) {
            console.log(error)
            res.redirect('/chat/' + req.params.id)
        }

    }, async (error, req, res, next) => {
        console.log(error)
        res.redirect('/chat/' + req.params.id)
    })

    // Upload chat video cover photo

    const postCoverForVideo = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/CHATuploadVideoCoverPost',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + Date.now() + '.png')
        }
    })
    const uploadVideoCoverPost = multer({
        // limits: 300000,
        storage: postCoverForVideo
    })


    router.post('/upload-chat-video-cover-photo', auth, uploadVideoCoverPost.single('uploads'), async (req, res) => {
        try {


            let file = req.file
            await uploadFile(file)
            await unlineLinkFIle(file.path)

            // Update chat sendeer image cover photo
            let sql = `UPDATE chatsender SET image='${req.file.filename}' WHERE randomId='${req.body.chatsenderId}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
                console.log('Updated edit post')
            })

            // Update chat receiver image cover photo
            let sql2 = `UPDATE chatreceiver SET image='${req.file.filename}' WHERE randomId='${req.body.chatReceiverId}'`
            db.query(sql2, (error) => {
                if (error) {
                    return console.log(error)
                }
                console.log('Updated edit post')
            })


            res.send({
                success: 'success',
            })
        } catch (error) {

        }
    })





    // Servingn up videos 
    router.get('/webStorage/chatVideos/:key', auth, async (req, res) => {
        try {

            let key = req.params.key

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const CHatImagesVideoSender = await User(`SELECT * FROM chatsender WHERE video='${key}'`)
            const CHatVideoReceiver = await User(`SELECT * FROM chatreceiver WHERE video='${key}'`)
            const chatsender = CHatImagesVideoSender[0]
            const chatreceiver = CHatVideoReceiver[0]

            if (!chatsender && !chatreceiver) {
                const readStream = getFileStream('image-error.jpg')
                readStream.pipe(res)
                return
            }

            const readStream = getFileStream(key)
            readStream.pipe(res)


        } catch (error) {
            console.log('Error', error.message)
        }
    })



    // send audio immdiately
    io.on('connection', (socket) => {
        socket.on('sendVideo', (data) => {
            socket.broadcast.emit('showVideo', data)
        })
    })


    // Music / Audio upload
    const storageForChatAudio = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/chatAudio',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
        }
    })

    const uploadForChatAudio = multer({
        // limits: 300000,
        storage: storageForChatAudio
    })

    router.post('/chatMusicUpload/:id', auth, uploadForChatAudio.single('uploads'), async (req, res) => {
        try {
            async function SQLQUERRY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            // const user = await User.findById(req.user)
            const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = userx[0]

            // const sencondUser = await User.findById(req.params.id)
            const sencondUsers = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.params.id}'`)
            let sencondUser = sencondUsers[0]

            let file = req.file
            await uploadFile(file)
            await unlineLinkFIle(file.path)

            let data = {
                owner: user._id,
                ownerName: user.firstname + ' ' + user.lastname,
                receiverId: req.params.id,
                receiverName: sencondUser.firstname + ' ' + sencondUser.lastname,
            }

            let randomChatId1 = crypto.randomBytes(12).toString('hex')

            const Chatsender = {
                ...data,
                _id: new Date(),
                date: new Date(new Date().getTime()),
                randomId: randomChatId1,
                audio: req.file.filename,
                pushChat: 'pushAudioRight',
                chatType: 'audio',
                hide: 'none',
                hideVideo: 'none',
                hideAudio: 'block',
                hideStory: 'none',
                voiceNoteTime: req.body.voiceNoteTime,
                hideVoiceNote: 'none',
            }

            let sql = 'INSERT INTO chatsender SET ?'
            db.query(sql, Chatsender, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            let randomChatId2 = crypto.randomBytes(12).toString('hex')
            const ChatReceiver = {
                ...data,
                _id: new Date(),
                randomId: randomChatId2,
                date: new Date(new Date().getTime()),
                audio: req.file.filename,
                pushChat: 'pushAudioLeft',
                chatType: 'audio',
                hide: 'none',
                hideVideo: 'none',
                hideAudio: 'block',
                hideStory: 'none',
                hideVoiceNote: 'none',
                voiceNoteTime: req.body.voiceNoteTime
            }

            let sql2 = 'INSERT INTO chatreceiver SET ?'
            db.query(sql2, ChatReceiver, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // Send notification by adding "+1" to user details
            let sqlForUser = `UPDATE users SET chatNotification='+1' WHERE _id='${sencondUser._id}'`
            db.query(sqlForUser, (error) => {
                if (error) return console.log(error)
            })

            //Chat notification  **********************************************************************
            // Deleteing old notification so it wont  dublicate for chat sender
            let sql3 = `DELETE FROM chatnotification WHERE owner='${data.owner}' AND receiverId='${data.receiverId}'`
            db.query(sql3, (error, result) => {
                if (error) {
                    return console.log(error)
                }
            })


            // Deleteing old notification so it wont  dublicate for chat reciever
            let sql3_c = `DELETE FROM chatnotification WHERE owner='${data.receiverId}' AND receiverId='${data.owner}'`
            db.query(sql3_c, (error, result) => {
                if (error) {
                    return console.log(error)
                }
            })

            // get the unread chat length
            const unreadChats = await SQLQUERRY(`SELECT * FROM chatsender WHERE receiverId='${data.receiverId}' AND owner='${data.owner}' AND readChatColor='gray'`)
            // make notification for chat receiver
            let randomId3 = crypto.randomBytes(12).toString('hex')
            // Save the chat notification
            const chatNotification = {
                _id: randomId3,
                owner: data.owner,
                message: 'Audio',
                message_icon: 'fa fa-headphones',
                date: new Date(new Date().getTime()),
                receiverId: data.receiverId,
                ownerName: data.ownerName,
                replyOldMessage: data.replyOldMessage,
                receiverName: data.receiverName,
                lastChat: 'Audio',
                avatar: user.avatar,
                ownerName: user.firstname + ' ' + user.lastname,
                unreadLength: unreadChats.length,
                displayMessageCounter: 'block'
            }
            delete chatNotification.replyOldMessage

            let sql4 = 'INSERT INTO chatnotification SET ?'
            db.query(sql4, chatNotification, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // make notification for chat sender
            let randomId4 = crypto.randomBytes(12).toString('hex')
            // Save the chat notification
            const chatNotificationTwo = {
                _id: randomId4,
                owner: data.receiverId,
                receiverId: data.owner,
                message: 'Audio',
                message_icon: 'fa fa-headphones',
                date: new Date(new Date().getTime()),
                ownerName: data.receiverName,
                receiverName: data.ownerName,
                replyOldMessage: data.replyOldMessage,
                lastChat: 'Audio',
                avatar: sencondUser.avatar,
                showCheckIcon: 'block',
                // ownerName: user.firstname + ' ' + user.lastname
            }
            delete chatNotificationTwo.replyOldMessage

            let sql4CHatTwo = 'INSERT INTO chatnotification SET ?'
            db.query(sql4CHatTwo, chatNotificationTwo, (error) => {
                if (error) {
                    return console.log(error)
                }
            })




            let sendData = {
                chatsenderId: {
                    randomid: Chatsender.randomId
                },
                chatReveiverId: {
                    randomid: ChatReceiver.randomId
                },
                date: 'new',
                audio: req.file.filename,
                owner: req.user._id,
                message: req.body.message,
                receiverId: data.receiverId,
                voiceNoteTime: ChatReceiver.voiceNoteTime
            }

            io.emit('audioListen', sendData)
            res.send(sendData)

            // If i type over rie the notification message
            // res.redirect('/chat/' + data.receiverId)

        } catch (error) {
            console.log(error)
            const sencondUser = await User.findById(req.params.id)
            res.redirect('/chat/' + sencondUser._id)
        }

    }, async (error, req, res, next) => {
        console.log(error)
        const sencondUser = await User.findById(req.params.id)
        res.redirect('/chat/' + sencondUser._id)
    })


    // Servingn up chat ausio or music 
    router.get('/webStorage/chatAudio/:key', auth, async (req, res) => {
        try {

            let key = req.params.key

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const CHatAudioSender = await User(`SELECT * FROM chatsender WHERE audio='${key}'`)
            const CHatAudioReceiver = await User(`SELECT * FROM chatreceiver WHERE audio='${key}'`)
            const chatsender = CHatAudioSender[0]
            const chatreceiver = CHatAudioReceiver[0]

            if (!chatsender && !chatreceiver) {
                const readStream = getFileStream('image-error.jpg')
                readStream.pipe(res)
                return
            }

            const readStream = getFileStream(key)
            readStream.pipe(res)


        } catch (error) {
            console.log('Error', error.message)
        }
    })


    // send audio immdiately
    io.on('connection', (socket) => {
        socket.on('sendAudio', (data) => {
            socket.broadcast.emit('showAudio', data)
        })
    })


    io.on('connection', (socket) => {
        // Read chat notification
        socket.on('readChat', async (data) => {
            let sql = `UPDATE chatnotification SET chatReadColor='cornflowerblue' WHERE _id='${data}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })
        })

        // clear chat red notification
        socket.on('removeChatNotification', async (data) => {
            try {
                let sql = `UPDATE users SET chatNotification='' WHERE _id='${data.userId}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })

            } catch (error) {
                console.log(error.message)
            }
        })
    })


    // ****************************************************************
    // ******************************************************************************************
    // Voice note script
    // Music / Audio upload
    const storageForVoiceNote = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/voiceNote',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
        }
    })

    const uploadForVoiceNote = multer({
        storage: storageForVoiceNote
    })

    router.post('/voiceNoteUpload/:id', auth, uploadForVoiceNote.single('uploads'), async (req, res) => {
        try {
            async function SQLQUERRY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            // const user = await User.findById(req.user)
            const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = userx[0]

            // const sencondUser = await User.findById(req.params.id)
            const sencondUsers = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.params.id}'`)
            let sencondUser = sencondUsers[0]

            let file = req.file
            await uploadFile(file)
            await unlineLinkFIle(file.path)


            let data = {
                owner: user._id,
                ownerName: user.firstname + ' ' + user.lastname,
                receiverId: req.params.id,
                receiverName: sencondUser.firstname + ' ' + sencondUser.lastname,
                date: new Date(new Date().getTime())
            }

            let randomChatId1 = crypto.randomBytes(12).toString('hex')

            const Chatsender = {
                ...data,
                _id: new Date(),
                randomId: randomChatId1,
                voiceNote: req.file.filename,
                pushChat: 'pushAudioRight',
                chatType: 'voiceNote',
                hide: 'none',
                hideVideo: 'none',
                hideAudio: 'none',
                hideStory: 'none',
                hideVoiceNote: 'block',
                voiceNoteTime: req.body.voiceNoteTime,
                chatSenderImage: user.avatar,
                chatReceiverImage: sencondUser.avatar
            }

            let sql = 'INSERT INTO chatsender SET ?'
            db.query(sql, Chatsender, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            let randomChatId2 = crypto.randomBytes(12).toString('hex')
            const ChatReceiver = {
                ...data,
                _id: new Date(),
                randomId: randomChatId2,
                voiceNote: req.file.filename,
                pushChat: 'pushAudioLeft',
                chatType: 'voiceNote',
                hide: 'none',
                hideVideo: 'none',
                hideAudio: 'none',
                hideStory: 'none',
                hideVoiceNote: 'block',
                voiceNoteTime: req.body.voiceNoteTime,
                chatSenderImage: user.avatar,
                chatReceiverImage: sencondUser.avatar
            }

            let sql2 = 'INSERT INTO chatreceiver SET ?'
            db.query(sql2, ChatReceiver, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // Send notification by adding "+1" to user details
            let sqlForUser = `UPDATE users SET chatNotification='+1' WHERE _id='${sencondUser._id}'`
            db.query(sqlForUser, (error) => {
                if (error) return console.log(error)
            })


            //Chat notification  **********************************************************************
            // Deleteing old notification so it wont  dublicate for chat sender
            let sql3 = `DELETE FROM chatnotification WHERE owner='${data.owner}' AND receiverId='${data.receiverId}'`
            db.query(sql3, (error, result) => {
                if (error) {
                    return console.log(error)
                }
            })


            // Deleteing old notification so it wont  dublicate for chat reciever
            let sql3_c = `DELETE FROM chatnotification WHERE owner='${data.receiverId}' AND receiverId='${data.owner}'`
            db.query(sql3_c, (error, result) => {
                if (error) {
                    return console.log(error)
                }
            })

            // get the unread chat length
            const unreadChats = await SQLQUERRY(`SELECT * FROM chatsender WHERE receiverId='${data.receiverId}' AND owner='${data.owner}' AND readChatColor='gray'`)
            // make notification for chat sender
            let randomId3 = crypto.randomBytes(12).toString('hex')
            // Save the chat notification
            const chatNotification = {
                _id: randomId3,
                owner: data.owner,
                message: req.body.voiceNoteTime,
                message_icon: 'fa fa-microphone',
                date: new Date(new Date().getTime()),
                receiverId: data.receiverId,
                ownerName: data.ownerName,
                replyOldMessage: data.replyOldMessage,
                receiverName: data.receiverName,
                lastChat: req.body.voiceNoteTime,
                avatar: user.avatar,
                ownerName: user.firstname + ' ' + user.lastname,
                unreadLength: unreadChats.length,
                displayMessageCounter: 'block'
            }
            delete chatNotification.replyOldMessage

            let sql4 = 'INSERT INTO chatnotification SET ?'
            db.query(sql4, chatNotification, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // make notification for chat sender
            let randomId4 = crypto.randomBytes(12).toString('hex')
            // Save the chat notification
            const chatNotificationTwo = {
                _id: randomId4,
                owner: data.receiverId,
                receiverId: data.owner,
                message: req.body.voiceNoteTime,
                message_icon: 'fa fa-microphone',
                date: new Date(new Date().getTime()),
                ownerName: data.receiverName,
                receiverName: data.ownerName,
                replyOldMessage: data.replyOldMessage,
                lastChat: req.body.voiceNoteTime,
                avatar: sencondUser.avatar,
                showCheckIcon: 'block',
                // ownerName: user.firstname + ' ' + user.lastname
            }
            delete chatNotificationTwo.replyOldMessage

            let sql4CHatTwo = 'INSERT INTO chatnotification SET ?'
            db.query(sql4CHatTwo, chatNotificationTwo, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            let sendData = {
                chatsenderId: {
                    delteId: new Date(),
                    randomId: randomChatId1,
                    tableName: 'chatreceiver'
                },
                chatReveiverId: {
                    delteId: new Date(),
                    tableName: 'chatsender',
                    randomId: randomChatId2,
                },
                voiceNote: req.file.filename,
                voiceNoteTime: req.body.voiceNoteTime,
                chatSenderImage: user.avatar,
                chatReceiverImage: sencondUser.avatar,
                owner: req.user._id,
                date: new Date(new Date().getTime()),
                receiverId: data.receiverId,
                // randomId: data.randomId
            }

            console.log(sendData)

            io.emit('voiceNoteListen', sendData)

            res.send(JSON.stringify(sendData))




        } catch (error) {
            console.log(error)
        }

    }, async (error, req, res, next) => {
        console.log(error)
    })


    // Servingn up chat voice note 
    router.get('/webStorage/voiceNote/:key', auth, async (req, res) => {
        try {

            let key = req.params.key

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const CHatVoiceNoteSender = await User(`SELECT * FROM chatsender WHERE voiceNote='${key}'`)
            const CHatVoiceNoteReceiver = await User(`SELECT * FROM chatreceiver WHERE voiceNote='${key}'`)
            const chatsender = CHatVoiceNoteSender[0]
            const chatreceiver = CHatVoiceNoteReceiver[0]

            if (!chatsender && !chatreceiver) {
                const readStream = getFileStream('image-error.jpg')
                readStream.pipe(res)
                return
            }

            const readStream = getFileStream(key)
            readStream.pipe(res)


        } catch (error) {
            console.log('Error', error.message)
        }
    })




    // Delete chat from db
    router.get('/deleteAllChat/:id', auth, async (req, res) => {
        try {
            let sql6 = `DELETE FROM chatsender WHERE owner='${req.user._id}' AND receiverId='${req.params.id}'`
            db.query(sql6, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            let sql = `DELETE FROM chatreceiver WHERE receiverId='${req.user._id}' AND owner='${req.params.id}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            res.redirect('/chat/' + req.params.id)
        } catch (error) {
            console.log(error)
            // res.redirect('/home')
        }

    })

    // Delete single chat
    router.post('/deleteMessage', auth, async (req, res) => {
        let sql = `DELETE FROM chatsender WHERE randomId='${req.body.data}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })


        let sql2 = `DELETE FROM chatreceiver WHERE randomId='${req.body.data}'`
        db.query(sql2, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        res.redirect('/chat/' + req.params.id)
    })


    // Delete single chat image 
    router.post('/deleteImg/:id', auth, async (req, res) => {
        let sql = `DELETE FROM chatsender WHERE randomId='${req.body.data}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        let sqlx = `DELETE FROM chatreceiver WHERE randomId='${req.body.data}'`
        db.query(sqlx, (error) => {
            if (error) {
                return console.log(error)
            }
        })


        res.redirect('/chat/' + req.params.id)
    })

    // @ DELETE CHAT NOTIFICATION 
    // delete chat message from chat notification or chat message
    router.get('/deletemessage/:id/:owner', auth, async (req, res) => {


        let sql = `DELETE FROM chatnotification WHERE _id='${req.params.id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })


        let sql6 = `DELETE FROM chatsender WHERE owner='${req.user._id}' AND receiverId='${req.params.owner}'`
        db.query(sql6, (error) => {
            if (error) {
                return console.log(error)
            }
        })


        let sql7 = `DELETE FROM chatreceiver WHERE receiverId='${req.user._id}' AND owner='${req.params.owner}'`
        db.query(sql7, (error) => {
            if (error) {
                return console.log(error)
            }
        })





        // let sql5 = `DELETE FROM chatsender WHERE WHERE _id='${req.params.id}'`
        // db.query(sql5, (error) => {
        //     if (error) {
        //         return console.log(error)
        //     }
        // })

        res.redirect('/home')

    })


    // Delete single chat video 
    router.get('/deletevideo/:id/:receiverId', auth, async (req, res) => {
        let sql5 = `DELETE FROM chatsender WHERE randomId='${req.params.id}'`
        db.query(sql5, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        let sql6 = `DELETE FROM chatreceiver WHERE randomId='${req.params.id}'`
        db.query(sql6, (error) => {
            if (error) {
                return console.log(error)
            }
        })


        async function SQLQUERRY(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        const findChat = await SQLQUERRY(`SELECT * FROM chatsender WHERE _id='${req.params.id}'`)
        let chat = findChat[0]

        if (findChat.length != 0) {
            // fs.unlink('./web-server/web-folder/public/webStorage/chatVideos/' + chat.video, (error) => {
            //     if (!error) {
            //         console.log('Deleted successfully')
            //     }
            // })




        }
        res.redirect('/chat/' + req.params.receiverId)
    })


    // Deleteing audio
    // Delete single chat image 
    router.post('/deleteAudio', auth, async (req, res) => {
        let sql = `DELETE FROM chatsender WHERE randomId='${req.body.data}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })
        let sqlx = `DELETE FROM chatreceiver WHERE randomId='${req.body.data}'`
        db.query(sqlx, (error) => {
            if (error) {
                return console.log(error)
            }
        })
        // if(req.body.deleteType == 'multiple'){

        // }

        async function SQLQUERRY(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)

                })
            })
        }


        res.redirect('/chat/' + req.params.id)
    })


    // Delete voice note
    router.post('/delete-voice-note', auth, async (req, res) => {
        try {
            let sql = `DELETE FROM chatsender WHERE randomId='${req.body.id}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })
            let sqlx = `DELETE FROM chatreceiver WHERE randomId='${req.body.id}'`
            db.query(sqlx, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            res.send({
                success: 'deleted'
            })
        } catch (error) {
            res.send({
                denied: 'false'
            })
        }


    })

    return router
}