const router = require('express').Router();
const multer = require('multer');
const auth = require('./auth')
const path = require('path');
const mysql = require('mysql');
const crypto = require('crypto')
const sanitizeHtml = require('sanitize-html');
const dayjs = require('dayjs')
var relativeTime = require('dayjs/plugin/relativeTime')
dayjs.extend(relativeTime)
const fs = require('fs')
const util = require('util')
const { db } = require('./db') //Database
const unlineLinkFIle = util.promisify(fs.unlink)
const { uploadFile, getFileStream } = require('./s3')
const { registerLimitter } = require('./expressEmitterDDos')


// @ set up validation for image upload
const storage = multer.diskStorage({
    destination: './web-server/web-folder/public/webStorage/postImages',
    filename: function (req, file, cb) {
        cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
    }
})
const upload = multer({
    // limits: 300000,
    storage: storage
})

module.exports = function (io) {

    router.post('/createPost', auth, upload.array('uploads', 900), async (req, res) => {

        try {

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = `SELECT * FROM users WHERE _id='${val}'`
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await User(req.user._id)
            let user = userx[0]



            // Generate random text
            const _id = crypto.randomBytes(12).toString('hex')

            let verify = user.verified
            let sortDate = new Date()

            // Sanitizing my html
            const clean = sanitizeHtml(req.body.description, {
                allowedTags: [],
                allowedAttributes: {}
            });
            req.body.description = clean


            if (req.body.checkPost == '') {
                let fullName = `${user.firstname} ${user.lastname}`
                const post = {
                    ...req.body,
                    _id,
                    date: new Date(new Date().getTime()),
                    sortDate,
                    postImageId: user._id,
                    possterName: fullName,
                    owner: user._id,
                    ownerPrimaryid: user.id,
                    posterNickName: user.fullName,
                    postType: 'text',
                    posterBio: user.bestSentence,
                    verified: verify,
                    hideLastComment: 'none',
                    avatar: user.avatar,
                    posterBio: user.bestSentence,
                    posterFollower: user.followerLength,
                    posterFollowing: user.followingLength,
                    posterNickName: user.fullName
                }
                // @ Delete unwanted properties in req.body
                delete post.uploads
                delete post.checkPost


                let sql = 'INSERT INTO posts SET ?'
                db.query(sql, post, (error) => {
                    if (error) {
                        return console.log(error)
                    }

                    // console.log('Post created')
                })

                res.send(JSON.stringify({
                    success: 'textPosted',
                    ...post,
                    taggedUsers: []
                }))


                tagGlobalFunction()
                // Tag function
                function tagGlobalFunction() {
                    // Tag users ***********************************************************
                    let tagListArray = req.body.tag_list.split(',')
                    tagListArray.map(async cur => {
                        async function SQLQUERY(val) {
                            return new Promise((resolve, reject) => {
                                let sql = val
                                db.query(sql, (error, result) => {
                                    if (error) {
                                        return console.log(error)
                                    }
                                    resolve(result)
                                })
                            })
                        }

                        let foundUsers = await SQLQUERY(`SELECT * FROM users WHERE id='${cur}'`)
                        // console.log(foundUsers)
                        for (i = 0; i < foundUsers.length; i++) {
                            let url = 'viewImagePostDetails/'
                            let randomId = crypto.randomBytes(12).toString('hex')

                            // Send notification    
                            const notification = {
                                owner: req.user._id,
                                _id: randomId,
                                text: 'Tagged you on a post',
                                comment: post.description,
                                eventId: post._id,
                                eventOwner: foundUsers[i]._id,
                                date: new Date(new Date().getTime()),
                                ownerName: `${user.firstname} ${user.lastname}`,
                                urlLink: url + post._id,
                                readStatus: 'fa fa-tags',
                                avatar: user.avatar
                            }
                            // console.log(notification)
                            let sqlnoty = 'INSERT INTO notification SET ?'
                            db.query(sqlnoty, notification, (error) => {
                                if (error) {
                                    return console.log(error)
                                }
                                console.log('Created a new Nitification')
                            })



                            try {
                                let findNotifcationOwner = await SQLQUERY(`SELECT * FROM users WHERE _id='${foundUsers[i]._id}'`)

                                let foundIds = foundUsers[i]._id

                                findNotifcationOwner.forEach(async cur => {
                                    if (cur.notifiicationLength == '' || cur.notifiicationLength == null) {
                                        let sqlxtrd = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${foundIds}'`
                                        db.query(sqlxtrd, (error) => {
                                            if (error) return console.log(error)
                                        })
                                        return
                                    } else {
                                        let count = parseInt(cur.notifiicationLength)
                                        count = count += 1
                                        let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${foundIds}'`
                                        db.query(sqlQueryForCOunt, (error) => {
                                            if (error) return console.log(error)
                                        })
                                    }

                                })

                            } catch (error) {
                                console.log('Error occured')
                            }
                        }

                    })
                }

                // res.redirect('/viewImagePostDetails/' + post._id)



            } else if (req.body.checkPost == 'image') {
                let len = 0;
                let hideSLides

                let fileId2 = '';
                let fileId3 = '';
                if (req.files.length === 1) {
                    fileId2 = ''
                    fileId3 = ''
                    hideSLides = 'none'
                    len = 1
                }
                else if (req.files.length === 2) {
                    fileId3 = ''
                    len = 2
                    fileId2 = req.files[1].filename
                }
                else if (req.files.length >= 3) {
                    len = 3
                    fileId2 = req.files[1].filename
                    fileId3 = req.files[2].filename
                }


                let fullName = `${user.firstname} ${user.lastname}`

                const post = {
                    ...req.body,
                    _id,
                    sortDate: new Date(),
                    image: req.files[0].filename,
                    image1: fileId2,
                    image2: fileId3,
                    imageLength: len,
                    date: new Date(new Date().getTime()),
                    postImageId: user._id, //Use id to fetch image
                    possterName: fullName,
                    posterNickName: user.fullName,
                    hideSLides,
                    owner: user._id,
                    ownerPrimaryid: user.id,
                    postType: req.body.checkPost,
                    posterBio: user.bestSentence,
                    hideLastComment: 'none',
                    avatar: user.avatar,
                    verified: verify
                }

                // @ Delete unwanted properties in req.body
                delete post.uploads
                delete post.checkPost

                let file = req.files[0]
                let s3Img = await uploadFile(file)
                console.log(s3Img)
                await unlineLinkFIle(file.path)


                let sql = 'INSERT INTO posts SET ?'
                db.query(sql, post, (error) => {
                    if (error) {
                        return console.log(error)
                    }

                    console.log('Post created')
                })




                res.send(JSON.stringify({
                    success: 'imageUpload',
                    user_id: req.user._id,
                    ...post
                }))


                tagGlobalFunction()
                // Tag function
                function tagGlobalFunction() {
                    // Tag users ***********************************************************
                    let tagListArray = req.body.tag_list.split(',')
                    tagListArray.map(async cur => {
                        async function SQLQUERY(val) {
                            return new Promise((resolve, reject) => {
                                let sql = val
                                db.query(sql, (error, result) => {
                                    if (error) {
                                        return console.log(error)
                                    }
                                    resolve(result)
                                })
                            })
                        }

                        let foundUsers = await SQLQUERY(`SELECT * FROM users WHERE id='${cur}'`)
                        // console.log(foundUsers)
                        for (i = 0; i < foundUsers.length; i++) {
                            let url = 'viewImagePostDetails/'
                            let randomId = crypto.randomBytes(12).toString('hex')

                            // Send notification    
                            const notification = {
                                owner: req.user._id,
                                _id: randomId,
                                text: 'Tagged you on a post',
                                comment: post.description,
                                eventId: post._id,
                                eventOwner: foundUsers[i]._id,
                                date: new Date(new Date().getTime()),
                                ownerName: `${user.firstname} ${user.lastname}`,
                                urlLink: url + post._id,
                                readStatus: 'fa fa-tags',
                                avatar: user.avatar
                            }
                            // console.log(notification)
                            let sqlnoty = 'INSERT INTO notification SET ?'
                            db.query(sqlnoty, notification, (error) => {
                                if (error) {
                                    return console.log(error)
                                }
                                console.log('Created a new Nitification')
                            })



                            try {
                                let findNotifcationOwner = await SQLQUERY(`SELECT * FROM users WHERE _id='${foundUsers[i]._id}'`)

                                let foundIds = foundUsers[i]._id

                                findNotifcationOwner.forEach(async cur => {
                                    if (cur.notifiicationLength == '' || cur.notifiicationLength == null) {
                                        let sqlxtrd = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${foundIds}'`
                                        db.query(sqlxtrd, (error) => {
                                            if (error) return console.log(error)
                                        })
                                        return
                                    } else {
                                        let count = parseInt(cur.notifiicationLength)
                                        count = count += 1
                                        let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${foundIds}'`
                                        db.query(sqlQueryForCOunt, (error) => {
                                            if (error) return console.log(error)
                                        })
                                    }

                                })

                            } catch (error) {
                                console.log('Error occured')
                            }
                        }

                    })
                }
                // res.redirect('/viewImagePostDetails/' + post._id)
            }
        } catch (error) {
            console.log(error)
            // res.send(error)
        }


    }, (error, req, res, next) => {
        res.send(error)
        res.redirect('/home')
    })


    // view post image 1
    router.get('/webStorage/postImages/:key', auth, async (req, res) => {
        try {

            let key = req.params.key

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const postSQL = await User(`SELECT * FROM posts WHERE image='${key}'`)
            const sharePostSQL = await User(`SELECT * FROM sharepost WHERE image='${key}'`)
            const post = postSQL[0]
            const sharepost = sharePostSQL[0]


            if (postSQL.length == 0 && sharePostSQL.length == 0) {
                const readStream = getFileStream('image-error.jpg')
                readStream.pipe(res)
                return
            }

            const readStream = getFileStream(key)
            readStream.pipe(res)


        } catch (error) {
            console.log('Error', error.message)
        }
    })


    // View post image 2

    router.get('/webStorage/postImages2/:key', auth, async (req, res) => {
        try {

            let key = req.params.key

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const postSQL = await User(`SELECT * FROM posts WHERE image1='${key}'`)
            const post = postSQL[0]
            if (postSQL.length == 0) {
                const readStream = getFileStream('image-error.jpg')
                readStream.pipe(res)
                return
            }

            const readStream = getFileStream(post.image1)
            readStream.pipe(res)


        } catch (error) {
            console.log('Error', error.message)
        }
    })

    // view post image 3

    router.get('/webStorage/postImages3/:key', auth, async (req, res) => {
        try {

            let key = req.params.key

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const postSQL = await User(`SELECT * FROM posts WHERE image2='${key}'`)
            const post = postSQL[0]
            if (postSQL.length == 0) {
                const readStream = getFileStream('image-error.jpg')
                readStream.pipe(res)
                return
            }

            const readStream = getFileStream(post.image2)
            readStream.pipe(res)


        } catch (error) {
            console.log('Error', error.message)
        }
    })

    const send_image_storage = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/postImages',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
        }
    })

    const photo2Storage = multer({
        storage: send_image_storage
    })

    router.post('/add_post_image_two', photo2Storage.single('uploads'), auth, async (req, res) => {
        async function SQLQUERY(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        // Chech if there's a second image 
        let findImage2 = await SQLQUERY(`SELECT * FROM posts WHERE _id='${req.body.postId}'`)
        findImage2 = findImage2[0]
        if (findImage2.image1 == '') {
            let sql = `UPDATE posts SET image1='${req.file.filename}', imageLength='2', hideSLides='block' WHERE _id='${req.body.postId}'`
            db.query(sql, async (error) => {
                if (error) {
                    return console.log(error)
                }
                console.log('Updated edit post')

                let file = req.file
                let s3Img = await uploadFile(file)
                console.log(s3Img)
                await unlineLinkFIle(file.path)
            })

            res.send(JSON.stringify({
                image1Success: 'success'
            }))
            return
        }

        let sql = `UPDATE posts SET image2='${req.file.filename}', imageLength='3', hideSLides='block' WHERE _id='${req.body.postId}'`
        db.query(sql, async (error) => {
            if (error) {
                return console.log(error)
            }
            let file = req.file
            let s3Img = await uploadFile(file)
            console.log(s3Img)
            await unlineLinkFIle(file.path)

            console.log('Added third image in a post')
        })
        res.send(JSON.stringify({
            image2Success: 'success'
        }))



    })


    const photo3Storage = multer({
        storage: send_image_storage
    })
    // 
    router.post('/add_post_image_three', photo3Storage.single('uploads'), auth, async (req, res) => {
        async function SQLQUERY(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        // Chech if there's a second image 
        let findImage2 = await SQLQUERY(`SELECT * FROM posts WHERE _id='${req.body.postId}'`)
        findImage2 = findImage2[0]
        if (findImage2.image1 == '') {
            let sql = `UPDATE posts SET image1='${req.file.filename}', imageLength='2', hideSLides='block' WHERE _id='${req.body.postId}'`
            db.query(sql, async (error) => {
                if (error) {
                    return console.log(error)
                }

                console.log('Added first image in a post')
                let file = req.file
                let s3Img = await uploadFile(file)
                await unlineLinkFIle(file.path)


            })
            res.send(JSON.stringify({
                image1Success: 'success'
            }))
            return
        }


        let sql = `UPDATE posts SET image2='${req.file.filename}', imageLength='3', hideSLides='block' WHERE _id='${req.body.postId}'`
        db.query(sql, async (error) => {
            if (error) {
                return console.log(error)
            }
            console.log('Added third image in a post')
            let file = req.file
            let s3Img = await uploadFile(file)
            await unlineLinkFIle(file.path)

        })
        res.send(JSON.stringify({
            image2Success: 'success'
        }))


    })




    // @ set up validation for image upload
    const videoStorage = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/postVideos',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
        }
    })
    const videoUpload = multer({
        // limits: 300000,
        storage: videoStorage
    })


    router.post('/videoUpload', videoUpload.single('uploads'), auth, async (req, res) => {
        try {
            console.log(req.body)
            console.log(req.file)




            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = `SELECT * FROM users WHERE _id='${val}'`
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await User(req.user._id)
            let user = userx[0]

            // Generate random text
            const _id = crypto.randomBytes(12).toString('hex')

            let day = new Date().getDate()
            let month = new Date().getMonth() + 1
            let year = new Date().getFullYear()
            let mili = new Date().getMilliseconds()

            let hours = new Date().getHours()
            let minutes = new Date().getMinutes()
            let seconds = new Date().getSeconds()

            let fullDateStr = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}:${mili}`


            let verify = user.verified

            // const user = await User.findById(req.user) //Get user to store unique id    
            let fullName = `${user.firstname} ${user.lastname}`
            const post = {
                ...req.body,
                _id,
                sortDate: new Date(),
                video: req.file.filename,
                date: new Date(new Date().getTime()),
                postImageId: user._id,
                possterName: fullName,
                owner: user._id,
                ownerPrimaryid: user.id,
                video: req.file.filename,
                postType: 'video',
                posterNickName: user.fullName,
                verified: verify,
                avatar: user.avatar,
                hideLastComment: 'none',
                posterBio: user.bestSentence,
                posterFollower: user.followerLength,
                posterFollowing: user.followingLength,
                posterNickName: user.fullName
            }



            const file = req.file
            await uploadFile(file)
            await unlineLinkFIle(file.path)


            let sql = 'INSERT INTO posts SET ?'
            db.query(sql, post, (error) => {
                if (error) {
                    return console.log(error)
                }

                console.log('Post created')
            })

            res.send({
                success: 'success',
                _id
            })
            // res.redirect('/viewVideoPostDetails/' + post._id)

        } catch (error) {
            console.log(error.message)
            res.redirect('/home')
        }

    }, (error, req, res, next) => {
        res.redirect('/home')
    })



    const postCoverForVideo = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/uploadVideoCoverPost',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + Date.now() + '.png')
        }
    })
    const uploadVideoCoverPost = multer({
        // limits: 300000,
        storage: postCoverForVideo
    })


    router.post('/upload-post-video-cover-photo', uploadVideoCoverPost.single('uploads'), auth, async (req, res) => {
        console.log(req.file)
        console.log(req.body)

        const file = req.file
        await uploadFile(file)
        await unlineLinkFIle(file.path)


        let sql = `UPDATE posts SET image='${req.file.filename}' WHERE _id='${req.body.postId}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }

            res.send({
                success: req.body
            })


        })
    })




    // Servingn up videos 
    router.get('/webStorage/postVideos/:key', auth, async (req, res) => {
        try {

            let key = req.params.key

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const PostVideo = await User(`SELECT * FROM posts WHERE video='${key}'`)
            const video = PostVideo[0]
            if (PostVideo.length == 0) {
                const readStream = getFileStream('image-error.jpg')
                readStream.pipe(res)
                return
            }

            let videox = 'https://plogapp.s3.amazonaws.com/' + key
            res.send(videox)
            // const readStream = getFileStream(video.video)
            // readStream.pipe(res)



        } catch (error) {
            console.log('Error', error.message)
        }
    })





    // Edit post router
    router.post('/editPost', async (req, res) => {
        try {
            async function POST(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            const clean = sanitizeHtml(req.body.newDescription, {
                allowedTags: [],
                allowedAttributes: {}
            });
            req.body.newDescription = clean

            let posts = await POST(`SELECT * FROM posts WHERE _id='${req.body.postId}'`)
            if (posts.length > 0) {
                posts = posts[0]

                let sql = `UPDATE posts SET description='${req.body.newDescription}' WHERE _id='${req.body.postId}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('Updated edit post')
                })

                let redirectId = 'viewVideoPostDetails/'
                console.log(posts)
                console.log(req.bodyb)

                if (posts.postType == 'image' || posts.postType == 'text') {
                    redirectId = `viewImagePostDetails/`
                }
                console.log(posts)

                return res.redirect('/' + redirectId + req.body.postId)
            }

            let sql = `UPDATE sharepost SET description='${req.body.newDescription}' WHERE _id='${req.body.postId}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
                try {

                    console.log('Updated share edit post')

                    posts = posts[0]

                    let url = 'viewImagePostDetails/'
                    if (posts.postType == 'video') url = 'viewVideoPostDetails/'

                    return res.redirect('/' + redirectId + req.body.postId)
                } catch (error) {
                    res.render('404Page')
                }
            })

        } catch (error) {
            console.log(error)
            res.render('404Page')
        }

    })


    // Reaction on post
    io.on('connection', (socket) => {
        let day = new Date().getDate()
        let month = new Date().getMonth() + 1
        let year = new Date().getFullYear()
        let mili = new Date().getMilliseconds()

        let hours = new Date().getHours()
        let minutes = new Date().getMinutes()
        let seconds = new Date().getSeconds()

        let fullDateStr = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}:${mili}`

        socket.on('reactionDetails', async (data) => {
            try {
                let userId = data.userId;
                let postId = data.postId;

                async function GETSQL(val) {
                    return new Promise((resolve, reject) => {
                        let sql = val
                        db.query(sql, (error, result) => {
                            if (error) {
                                return console.log(error)
                            }
                            resolve(result)
                        })
                    })
                }
                const userx = await GETSQL(`SELECT * FROM users WHERE _id='${userId}'`)
                const posts = await GETSQL(`SELECT * FROM posts WHERE _id='${postId}'`)
                let user = userx[0]
                let post = posts[0]

                // if (userx.length < 1) return
                // if (posts.length < 1) return


                // Function for reaction
                async function notificationFunction() {

                    // set notifcation
                    if (userId.toLocaleString() !== post.owner.toLocaleString()) {
                        let url = 'viewImagePostDetails/'
                        if (post.postType == 'video') url = 'viewVideoPostDetails/'

                        let randomId = crypto.randomBytes(12).toString('hex')

                        // Send notification    
                        const notification = {
                            owner: userId,
                            _id: randomId,
                            text: 'Reacted to your post',
                            comment: post.description,
                            eventId: post._id,
                            eventOwner: post.owner,
                            date: new Date(new Date().getTime()),
                            ownerName: `${user.firstname} ${user.lastname}`,
                            urlLink: url + post._id,
                            readStatus: 'fa fa-question',
                            avatar: user.avatar
                        }

                        let sql = 'INSERT INTO notification SET ?'
                        db.query(sql, notification, (error) => {
                            if (error) {
                                return console.log(error)
                            }
                            console.log('Created a new Nitification')
                        })


                        let findNotifcationOwner = await GETSQL(`SELECT * FROM users WHERE _id='${post.owner}'`)
                        let eventOwner = findNotifcationOwner[0]
                        if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                            let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${post.owner}'`
                            db.query(sql, (error) => {
                                if (error) return console.log(error)
                            })
                            return
                        } else {
                            let count = parseInt(eventOwner.notifiicationLength)
                            count = count += 1
                            let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${post.owner}'`
                            db.query(sqlQueryForCOunt, (error) => {
                                if (error) return console.log(error)
                            })
                        }
                    }
                }



                // @ if post reaction is empty add the first value to it
                if (post.reaction == '' || post.reaction == null) {
                    let sql = `UPDATE posts SET reaction='${user.id}', reactionLength='${1}' WHERE _id='${post._id}'`
                    db.query(sql, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                    })
                    notificationFunction()

                    return
                }

                const reaction = post.reaction.split(',')
                let newReaction = reaction.map(el => {
                    return parseInt(el)
                })

                let index = newReaction.indexOf(user.id)

                // @ remove like
                if (index > -1) {
                    console.log('remove')
                    newReaction.splice(index, 1)

                    let sql = `UPDATE posts SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE _id='${post._id}'`
                    db.query(sql, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                    })
                    return
                }

                // @ add like
                newReaction.push(user.id)
                let sql = `UPDATE posts SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE _id='${post._id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })

                notificationFunction()
            } catch (error) {
                console.log(error)
            }
        })

    })




    // Reactions in comments ********************************
    io.on('connection', (socket) => {
        try {
            likeGlobalFUnction()
        } catch (error) {
            console.log(error.message)
            console.log("an error occured")
        }

        function likeGlobalFUnction() {


            socket.on('commentLikeDetails', async (data) => {
                let userId = data.ownerId;
                let commentId = data.commentId
                // return
                async function GETSQL(val) {
                    return new Promise((resolve, reject) => {
                        let sql = val
                        db.query(sql, (error, result) => {
                            if (error) {
                                return console.log(error)
                            }
                            resolve(result)
                        })
                    })
                }
                const userx = await GETSQL(`SELECT * FROM users WHERE _id='${userId}'`)
                const comments = await GETSQL(`SELECT * FROM comments WHERE _id='${commentId}'`)
                let user = userx[0]
                let comment = comments[0]

                if (userx.length < 1) return
                if (comments.length < 1) return

                // Notification ****************
                async function notificationFunction() {
                    try {
                        // Send notification    
                        const findPostOwner = await GETSQL(`SELECT * FROM posts WHERE _id='${comment.postId}'`)
                        let findPost = findPostOwner[0]
                        let postLink = 'viewImagePostDetails/'
                        if (findPost.postType == 'video') {
                            postLink = 'viewVideoPostDetails/'
                        }

                        let randomId = crypto.randomBytes(12).toString('hex')
                        if (userId.toString() != comment.owner.toString()) {
                            const notification = {
                                owner: userId,
                                _id: randomId,
                                text: 'Reacted to your comment',
                                comment: comment.comment,
                                eventId: comment._id,
                                eventOwner: comment.owner,
                                date: new Date(new Date().getTime()),
                                ownerName: `${user.firstname} ${user.lastname}`,
                                urlLink: postLink + comment.postId,
                                readStatus: 'fa fa-question',
                                avatar: user.avatar
                            }

                            let sql = 'INSERT INTO notification SET ?'
                            db.query(sql, notification, (error) => {
                                if (error) {
                                    return console.log(error)
                                }
                                console.log('Created a new Nitification')
                            })

                            let findNotifcationOwner = await GETSQL(`SELECT * FROM users WHERE _id='${comment.owner}'`)
                            let eventOwner = findNotifcationOwner[0]
                            if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                                let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${comment.owner}'`
                                db.query(sql, (error) => {
                                    if (error) return console.log(error)
                                })
                                return
                            } else {
                                let count = parseInt(eventOwner.notifiicationLength)
                                count = count += 1
                                let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${comment.owner}'`
                                db.query(sqlQueryForCOunt, (error) => {
                                    if (error) return console.log(error)
                                })
                            }

                            return
                        }

                    } catch (error) {
                        const findPosts = await GETSQL(`SELECT * FROM sharepost WHERE _id='${comment.postId}'`)
                        let findPost = findPosts[0]
                        let postLink = ''
                        if (findPost.postType == 'text' || findPost.postType == 'photo') postLink = 'shareLink/' + comment.postId
                        else if (findPost.postType == 'video') postLink = 'sharedLinkVideo/' + comment.postId

                        let randomId = crypto.randomBytes(12).toString('hex')
                        if (userId.toString() != comment.owner.toString()) {
                            const notification = {
                                owner: userId,
                                _id: randomId,
                                text: 'Reacted to your comment',
                                comment: comment.comment,
                                eventId: comment._id,
                                eventOwner: comment.owner,
                                date: new Date(new Date().getTime()),
                                ownerName: `${user.firstname} ${user.lastname}`,
                                urlLink: postLink,
                                readStatus: 'fa fa-question',
                                avatar: user.avatar
                            }

                            let sql = 'INSERT INTO notification SET ?'
                            db.query(sql, notification, (error) => {
                                if (error) {
                                    return console.log(error)
                                }
                            })

                            let findNotifcationOwner = await GETSQL(`SELECT * FROM users WHERE _id='${comment.owner}'`)
                            let eventOwner = findNotifcationOwner[0]
                            if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                                let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${comment.owner}'`
                                db.query(sql, (error) => {
                                    if (error) return console.log(error)
                                    console.log('Notification added1')
                                })
                                return
                            } else {
                                let count = parseInt(eventOwner.notifiicationLength)
                                count = count += 1
                                let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${comment.owner}'`
                                db.query(sqlQueryForCOunt, (error) => {
                                    if (error) return console.log(error)
                                    console.log('Notification added2')
                                })
                            }
                        }
                    }

                }


                // @ if post reaction is empty add the first value to it
                if (comment.reaction == '' || comment.reaction == null) {
                    let sql = `UPDATE comments SET reaction='${user.id}', reactionLength='${1}' WHERE _id='${comment._id}'`
                    db.query(sql, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                    })
                    notificationFunction()
                    return
                }

                const reaction = comment.reaction.split(',')
                let newReaction = reaction.map(el => {
                    return parseInt(el)
                })
                console.log(data)

                let index = newReaction.indexOf(user.id)

                // @ remove like
                if (index > -1) {
                    newReaction.splice(index, 1)

                    let sql = `UPDATE comments SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE _id='${comment._id}'`
                    db.query(sql, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                    })
                    return
                }

                // @ add like
                newReaction.push(user.id)
                let sql = `UPDATE comments SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE _id='${comment._id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })
                notificationFunction()
            })
        }



        // @ getting replies from db ************************************************
        router.get('/fetch_replies_for_comment/:id', auth, async (req, res) => {
            try {
                // const replies = await Reply.find({ mainCommentId: id })

                async function SQL(val) {
                    return new Promise((resolve, reject) => {
                        let sql = val
                        db.query(sql, (error, result) => {
                            if (error) {
                                return console.log(error)
                            }
                            resolve(result)
                        })
                    })
                }

                const replies = await SQL(`SELECT * FROM replies WHERE mainCommentId='${req.params.id}'`)
                if (replies.length < 1) return

                replies.map(cur => cur.date = dayjs().to(cur.date))
                res.send(replies)



            } catch (error) {
                console.log('Error')
            }
        })
        // socket.on('commentId', async (id) => {

        // })


        // fetch users for mention

        router.get('/fetche_users_for_post', auth, async (req, res) => {
            try {
                async function User(val) {
                    return new Promise((resolve, reject) => {
                        let sql = val
                        db.query(sql, (error, result) => {
                            if (error) {
                                return res.redirect('/login')
                            }
                            resolve(result)
                        })
                    })
                }

                let users = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
                let user = users[0]

                let pareamsFollowers = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
                pareamsFollowers = pareamsFollowers[0]
                // console.log(pareamsFollowers.following)
                // let following = pareamsFollowers.following.split(',')
                // following = [...new Set(following)]
                let findFollowings = await User(`SELECT * FROM following WHERE owner='${req.user._id}'`)
                console.log(findFollowings.length)
                let following = []
                let followingUniqueId = []
                findFollowings.map(cur => {
                    following.push(cur.following_id)
                    followingUniqueId.push(cur.id)
                })
                // console.log(following)
                let followingUniqyeId = []

                // @ get user following
                let newFollowingsArr = []
                for (i = 0; i < following.length; i++) {
                    const findusers = await User(`SELECT * FROM users WHERE _id='${following[i]}' ORDER BY id DESC`)
                    findusers.forEach(val => {
                        newFollowingsArr.push(val)
                        followingUniqyeId.push(val.id)
                    })
                }

                // console.log(followingUniqyeId)
                user.following = followingUniqyeId.toString()

                // console.log()

                const followingOwner = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)

                //@ Create suggestion fot user to follow____________________
                const allUsers = await User(`SELECT * FROM users`)
                let myFolloingArr = user.following + user.id
                let notFollowingIdsArray = []
                for (i = 0; i < allUsers.length; i++) {
                    if (!myFolloingArr.includes(allUsers[i].id)) {
                        notFollowingIdsArray.push(allUsers[i].id)
                    }
                }

                let newUserTOFollow = []
                for (i = 0; i < notFollowingIdsArray.length; i++) {
                    const fetchUsersToFollow = await User(`SELECT * FROM users WHERE id='${notFollowingIdsArray[i]}'`)
                    fetchUsersToFollow.forEach(val => {
                        newUserTOFollow.push(val)
                    })
                }



                // try and remove heavey data 
                let fetchedFollowingsArr = []
                newFollowingsArr.forEach(val => {
                    val.coverPhoto = undefined
                    val.storyImg = undefined
                    val.password = undefined
                    val.hasStory = undefined
                    val.gender = undefined
                    val.phoneNumber = undefined
                    val.email = undefined
                    val.bestSentence = undefined
                    val.date = undefined
                    val.genderDescription = undefined
                    val.month = undefined
                    val.month = undefined
                    val.year = undefined
                    val.activeStatus = undefined
                    val.greenActive = undefined
                    val.notifiicationLength = undefined
                    val.createdAt = undefined
                    val.token = undefined
                    val.updatedAt = undefined
                    val.hideWelcomeMsg = undefined
                    val.chatNotification = undefined
                    fetchedFollowingsArr.push(val)
                })
                res.send(fetchedFollowingsArr)

            } catch (err) {
                console.log('Error', err)
            }
        })

        // Searching for users to mention or for tags

        router.post('/mentionInputRoute', auth, async (req, res) => {

            // res.send(JSON.stringify(req.body))

            async function SQLQUERRY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            const Allusers = await SQLQUERRY(`SELECT * FROM users`)
            const curUser = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = curUser[0]
            // console.log(req.body.text)
            // get all the usernames @
            let searchTerm = req.body.text
            searchTerm = searchTerm.replace('@', '')
            let arrofnames = []
            for (i = 0; i < Allusers.length; i++) {
                if (Allusers[i].fullName.includes(searchTerm)) {
                    arrofnames.push(Allusers[i].fullName)
                }
            }

            // get all the users that matched
            let foundUsersArray = []
            for (i = 0; i < arrofnames.length; i++) {
                const foundUsers = await SQLQUERRY(`SELECT * FROM users WHERE fullName='${arrofnames[i]}'`)
                foundUsers.forEach(val => {
                    foundUsersArray.push(val)
                })
            }

            // console.log(foundUsersArray)
            res.send(JSON.stringify(foundUsersArray))

        })


        socket.on('mentionInput', async data => {
            // async function SQLQUERRY(val) {
            //     return new Promise((resolve, reject) => {
            //         let sql = val
            //         db.query(sql, (error, result) => {
            //             if (error) {
            //                 return console.log(error)
            //             }
            //             resolve(result)
            //         })
            //     })
            // }

            // const Allusers = await SQLQUERRY(`SELECT * FROM users`)
            // const curUser = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.userId}'`)
            // let user = curUser[0]

            // // get all the usernames @
            // let arrofnames = []
            // for (i = 0; i < Allusers.length; i++) {
            //     if (Allusers[i].fullName.includes(data.text)) {
            //         arrofnames.push(Allusers[i].fullName)
            //     }
            // }

            // // get all the users that matched
            // let foundUsersArray = []
            // for (i = 0; i < arrofnames.length; i++) {
            //     const foundUsers = await SQLQUERRY(`SELECT * FROM users WHERE fullName='${arrofnames[i]}'`)
            //     foundUsers.forEach(val => {
            //         foundUsersArray.push(val)
            //     })
            // }

            // // console.log(foundUsersArray)
            // socket.emit('readyToMentionUsers', {
            //     fetchedMentioned: foundUsersArray,
            //     id: user._id
            // })
        })

    })


    // fetch users to mention 





    router.get('/deletePost/:id', async (req, res) => {
        try {
            // let post = await Post.findById(req.params.id);

            async function POST(val) {
                return new Promise((resolve, reject) => {
                    let sql = `SELECT * FROM posts WHERE _id='${val}'`
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const posts = await POST(req.params.id)
            let post = posts[0]
            console.log(post)

            let sql = `DELETE FROM posts WHERE _id='${req.params.id}'`
            db.query(sql, (error, result) => {
                if (error) {
                    return console.log(error)
                }
                console.log('Deleted successful')
            })

            res.redirect('/home')
        } catch (error) {
            console.log(error)
            res.render('404Page')
        }

    })


    // let sqlQ = `
    // ALTER TABLE
    // posts
    // CONVERT TO CHARACTER SET utf8mb4
    // COLLATE utf8mb4_unicode_ci;`

    // db.query(sqlQ, (error) => {
    //     if (error) return console.log(error)
    // })


    return router
}

