const router = require('express').Router();
const multer = require('multer');
const auth = require('./auth')

const mysql = require('mysql');
const crypto = require('crypto')


const { db } = require('./db') //Database




module.exports = function (io) {
    router.post('/sharePost', auth, async (req, res) => {
        // Set created date

        let day = new Date().getDate()
        let month = new Date().getMonth() + 1
        let year = new Date().getFullYear()
        let mili = new Date().getMilliseconds()

        let hours = new Date().getHours()
        let minutes = new Date().getMinutes()
        let seconds = new Date().getSeconds()

        let fullDateStr = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}:${mili}`



        async function SQL(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const userx = await SQL(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        let user = userx[0]


        const posts = await SQL(`SELECT * FROM posts WHERE _id='${req.body.postLink}'`)
        const post = posts[0]


        // const user = await User.findById(req.user) //Get user to store unique id    
        // let post = await Post.findById(req.body.postLink)
        let fullName = `${user.firstname} ${user.lastname}`

        const _id = crypto.randomBytes(12).toString('hex')
        let sortDate = new Date()
        if (post) {
            let shareData = {
                _id,
                description: req.body.sharedPostDescription,
                mainOwner: post.owner,
                date: new Date(new Date().getTime()),
                sortDate,
                posterNickName: user.fullName,
                sharedPosterNickName: post.posterNickName,
                postType: 'share' + post.postType,
                sharedPostImage: post.image,
                sharedPostDescription: post.description,
                sharedPostDate: post.date,
                sharedPostAvatar: post.postImageId,
                sharePostUrl: post._id,
                sharedPostLink: post.video,
                verifiedSharedPost: post.verified,
                sharedPostOwnerName: post.possterName,
                sharedPostType: post.postType,
                posterGenderType: post.posterGenderType,
                postImageId: user._id, //Use id to fetch image
                possterName: fullName,
                owner: user._id,
                ownerPrimaryid: user.id,
                verified: user.verified,
                avatar: user.avatar,
                hideLastComment: 'none',
                shareAvatar: post.avatar,
                posterBio: user.bestSentence,
                posterFollower: user.followerLength,
                posterFollowing: user.followingLength,
                posterNickName: user.fullName
                // lastCommentAvatar: user.avatar
            }

            // console.log(shareData)

            let sql = 'INSERT INTO sharepost SET ?'
            db.query(sql, shareData, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            // increment post share length
            let len = parseInt(post.shareLength) || 0
            len = len += 1

            let sql2 = `UPDATE posts SET shareLength='${len}' WHERE _id='${post._id}'`
            db.query(sql2, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            res.redirect('/home')
            return
        } else {
            // let sharedPost = await SharedPost.findById(req.body.postLink)
            const sharedPosts = await SQL(`SELECT * FROM sharepost WHERE _id='${req.body.postLink}'`)
            const sharedPost = sharedPosts[0]

            let shareData = {
                _id,
                sortDate: new Date(),
                description: req.body.sharedPostDescription,
                mainOwner: sharedPost.owner,
                date: new Date(new Date().getTime()),
                postType: 'share' + sharedPost.postType,
                posterNickName: user.fullName,
                sharedPosterNickName: sharedPost.posterNickName,
                sharedPostImage: sharedPost.sharedPostImage,
                sharedPostDescription: sharedPost.description,
                sharedPostDate: sharedPost.date,
                sharedPostAvatar: sharedPost.postImageId,
                sharedPostLink: sharedPost.sharedPostLink,
                verifiedSharedPost: sharedPost.verified,
                sharedPostOwnerName: sharedPost.possterName,
                sharedPostType: sharedPost.postType,
                sharedPostVideo: sharedPost.sharedPostVideo,
                posterGenderType: sharedPost.posterGenderType,
                postImageId: user._id, //Use id to fetch image
                sharePostUrl: sharedPost._id,
                possterName: fullName,
                owner: user._id,
                ownerPrimaryid: user.id,
                verified: user.verified,
                avatar: user.avatar,
                hideLastComment: 'none',
                shareAvatar: sharedPost.avatar,
                posterBio: user.bestSentence,
                posterFollower: user.followerLength,
                posterFollowing: user.followingLength,
                posterNickName: user.fullName
                // lastCommentAvatar: user.avatar
            }

            let sql = 'INSERT INTO sharepost SET ?'
            db.query(sql, shareData, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            // increment post share length
            let len = parseInt(sharedPost.shareLength) || 0
            len = len += 1

            let sql2 = `UPDATE sharepost SET shareLength='${len}' WHERE _id='${sharedPost._id}'`
            db.query(sql2, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            res.redirect('/home')
        }
    })







    // shearing a shared post

    router.get('/deleteSharedPost/:id', async (req, res) => {
        let sql = `DELETE  FROM sharepost WHERE _id='${req.params.id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })
        res.redirect('/home')

    })

    // Reaction on post
    io.on('connection', (socket) => {
        socket.on('reactionToSharedPost', async (data) => {
            let userId = data.userId;
            let postId = data.postId;

            async function GETSQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await GETSQL(`SELECT * FROM users WHERE _id='${userId}'`)
            const posts = await GETSQL(`SELECT * FROM sharepost WHERE _id='${postId}'`)
            let user = userx[0]
            let post = posts[0]


            async function notificationFunction() {
                // Set created date

                let day = new Date().getDate()
                let month = new Date().getMonth() + 1
                let year = new Date().getFullYear()
                let mili = new Date().getMilliseconds()

                let hours = new Date().getHours()
                let minutes = new Date().getMinutes()
                let seconds = new Date().getSeconds()

                let fullDateStr = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}:${mili}`



                if (userId.toLocaleString() !== post.owner.toLocaleString()) {
                    let url = 'viewImagePostDetails/'
                    if (post.postType == 'video') url = 'viewVideoPostDetails/'

                    let randomId = crypto.randomBytes(12).toString('hex')

                    let objData = {
                        owner: userId,
                        _id: randomId,
                        text: 'Reacted to your post',
                        comment: post.description,
                        eventId: post._id,
                        eventOwner: post.owner,
                        date: new Date(new Date().getTime()),
                        readStatus: 'fa fa-question',
                        ownerName: `${user.firstname} ${user.lastname}`,
                        avatar: user.avatar,
                        urlLink: 'shareLink/' + post._id,
                        modifyMethod: function () {
                            if (post.postType === 'video') {
                                this.urlLink = 'sharedLinkVideo/' + post._id
                            }
                        }
                    }
                    objData.modifyMethod()

                    const notification = {
                        ...objData
                    }

                    let sql = 'INSERT INTO notification SET ?'
                    db.query(sql, notification, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                        console.log('Created a new Nitification')
                    })

                    let findNotifcationOwner = await GETSQL(`SELECT * FROM users WHERE _id='${post.owner}'`)
                    let eventOwner = findNotifcationOwner[0]
                    if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                        let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${post.owner}'`
                        db.query(sql, (error) => {
                            if (error) return console.log(error)
                        })
                        return
                    } else {
                        let count = parseInt(eventOwner.notifiicationLength)
                        count = count += 1
                        let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${post.owner}'`
                        db.query(sqlQueryForCOunt, (error) => {
                            if (error) return console.log(error)
                        })
                    }
                }
            }


            // @ if post reaction is empty add the first value to it
            if (post.reaction == '' || post.reaction == null) {
                let sql = `UPDATE sharepost SET reaction='${user.id}', reactionLength='${1}' WHERE _id='${post._id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })

                notificationFunction()

                return
            }

            const reaction = post.reaction.split(',')
            let newReaction = reaction.map(el => {
                return parseInt(el)
            })

            let index = newReaction.indexOf(user.id)

            // @ remove like
            if (index > -1) {
                newReaction.splice(index, 1)
                let sql = `UPDATE sharepost SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE _id='${post._id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })
                return
            }

            // @ add like
            newReaction.push(user.id)
            let sql = `UPDATE sharepost SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE _id='${post._id}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            notificationFunction()




        })

    })




    return router
}

