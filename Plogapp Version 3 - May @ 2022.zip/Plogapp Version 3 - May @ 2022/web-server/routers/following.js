const router = require('express').Router();
// const User = require('../models/model')
// const Post = require('../models/postModel')
const auth = require('./auth')
const mysql = require('mysql');
const crypto = require('crypto')

const { db } = require('./db') //Database
const { registerLimitter } = require('./expressEmitterDDos')


module.exports = function (io) {
    let publickParams = []
    router.get('/following/:id', auth,  async (req, res) => {
        try {

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            let users = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = users[0]

            let pareamsFollowers = await User(`SELECT * FROM users WHERE _id='${req.params.id}'`)
            pareamsFollowers = pareamsFollowers[0]
         
            
            let findFollowings = await User(`SELECT * FROM following WHERE owner='${req.params.id}'`)
            let following = []
            let followingUniqueId = []
            findFollowings.map(cur => {
                following.push(cur.following_id)
                followingUniqueId.push(cur.id)
            })
            // console.log(following)
            let followingUniqyeId = []

            // @ get user following
            let newFollowingsArr = []
            for (i = 0; i < following.length; i++) {
                const findusers = await User(`SELECT * FROM users WHERE _id='${following[i]}' ORDER BY id DESC`)
                findusers.forEach(val => {
                    newFollowingsArr.push(val)
                    followingUniqyeId.push(val.id)
                })
            }

            // console.log(followingUniqyeId)
            user.following = followingUniqyeId.toString()

            // console.log()

            const followingOwner = await User(`SELECT * FROM users WHERE _id='${req.params.id}'`)

           
     

            res.render('following-min', {
                user,
                followingUsers: newFollowingsArr,
                followingOwner: followingOwner[0],
            })

        } catch (error) {
            console.log(error)
            res.render('404Page')
        }
    })


    // Following Ruter

    router.get('/following_api', auth,  async (req, res) => {
        try {

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            let users = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = users[0]

            let pareamsFollowers = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            pareamsFollowers = pareamsFollowers[0]
         
            
            let findFollowings = await User(`SELECT * FROM following WHERE owner='${req.user._id}'`)
            let following = []
            let followingUniqueId = []
            findFollowings.map(cur => {
                following.push(cur.following_id)
                followingUniqueId.push(cur.id)
            })
            // console.log(following)
            let followingUniqyeId = []

            // @ get user following
            let newFollowingsArr = []
            for (i = 0; i < following.length; i++) {
                const findusers = await User(`SELECT * FROM users WHERE _id='${following[i]}' ORDER BY id DESC`)
                findusers.forEach(val => {
                    newFollowingsArr.push(val)
                    followingUniqyeId.push(val.id)
                })
            }

            // console.log(followingUniqyeId)
            user.following = followingUniqyeId.toString()

         
            res.send(newFollowingsArr)
            

        } catch (error) {
            console.log(error)
            res.render('404Page')
        }
    })



    return router
}

