const router = require('express').Router();
const auth = require('./auth')
const multer = require('multer');
const path = require('path')
const mysql = require('mysql');
const crypto = require('crypto')
const fs = require('fs')
const util = require('util')
const sanitizeHtml = require('sanitize-html');
const dayjs = require('dayjs')
var relativeTime = require('dayjs/plugin/relativeTime')
dayjs.extend(relativeTime)
const unlineLinkFIle = util.promisify(fs.unlink)
// const { fullDateStr } = require('./dateFunction')
const { uploadFile, getFileStream } = require('./s3')
const { registerLimitter } = require('./expressEmitterDDos')


const { db } = require('./db') //Database



module.exports = function (io) {

    router.get('/viewImagePostDetails/:id', auth,  async (req, res) => {
        res.redirect('/post-prod/' + req.params.id + '?postId=' + req.params.id + '&curUserId=' + req.user._id)
    })

    router.get('/post-prod/:id', auth,  async (req, res) => {
        try {
            async function SQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            
            const userx = await SQL(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = userx[0]

            const post = await SQL(`SELECT * FROM posts WHERE _id='${req.params.id}'`)

            post[0].date = dayjs().to(post[0].date)
            res.render('viewFullImage-min', {
                user: user,
                postDetails: post[0],
            })

        } catch (error) {
            console.log(error.message)
            res.render('404Page')
        }

    })


    // Fetch comments for post
    router.get('/fetch-post-comments/:id', auth, async (req, res) => {
        try {
            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = `SELECT * FROM users WHERE _id='${val}'`
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await User(req.user._id)
            let user = userx[0]

            async function SQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            // const post = await SQL(`SELECT * FROM posts WHERE _id='${req.params.id}'`)
            const comments = await SQL(`SELECT * FROM comments WHERE postId='${req.params.id}'`)

            // post[0].date = dayjs().to(post[0].date)

            // Find new comment
            const newComment = await SQL(`SELECT * FROM comments WHERE owner='${req.user._id}'AND postId='${req.params.id}'`)
            if(newComment.length > 0){
                comments.unshift(newComment[newComment.length - 1])
                comments.pop()
            }
            comments.map(cur => cur.date = dayjs().to(cur.date))

            res.send(comments)

        } catch (error) {
            console.log(error)
            res.render('404Page')
        }
    })




    // Fetch comments for post
    router.get('/fetch-post-comments-reverse/:id/:commentId', auth, async (req, res) => {
        console.log(req.body)

        try {
            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = `SELECT * FROM users WHERE _id='${val}'`
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await User(req.user._id)
            let user = userx[0]

            async function SQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            const post = await SQL(`SELECT * FROM posts WHERE _id='${req.params.id}'`)
            const comments = await SQL(`SELECT * FROM comments WHERE postId='${req.params.id}'`)
            // Find new comment
            const newComment = await SQL(`SELECT * FROM comments WHERE _id='${req.params.commentId}'`)
            console.log(newComment[0])
            comments.unshift(newComment[0])

            post[0].date = dayjs().to(post[0].date)
            comments.map(cur => cur.date = dayjs().to(cur.date))


            res.send(comments)

        } catch (error) {
            console.log(error.message)
            res.render('404Page')
        }
    })





    // video

    router.get('/viewVideoPostDetails/:id', auth,  async (req, res) => {
        res.redirect('/post-prod-video-watch/' + req.params.id + '?postId=' + req.params.id + '&curUserId=' + req.user._id)
    })


    router.get('/post-prod-video-watch/:id', auth,  async (req, res) => {
        try {

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = `SELECT * FROM users WHERE _id='${val}'`
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await User(req.user._id)
            let user = userx[0]

            async function SQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            const post = await SQL(`SELECT * FROM posts WHERE _id='${req.params.id}'`)
            const comments = await SQL(`SELECT * FROM comments WHERE postId='${req.params.id}'`)
            post[0].date = dayjs().to(post[0].date)
            comments.map(cur => cur.date = dayjs().to(cur.date))
            res.render('viewFullVideo-min', {
                user: user,
                postDetails: post[0],
                comment: comments,
            })

        } catch (error) {
            console.log(error.message)
            res.render('404Page')
        }

    })



    // @ set up validation for image upload
    const storage = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/commentImages',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
        }
    })
    const upload = multer({
        // limits: 300000,
        storage: storage
    })


    router.get('/saveReplyComment', (req, res) => {
        console.log(req.body)
    })

    // COmment
    router.post('/getComment', auth, upload.single('uploadImg'),  async (req, res) => {

        async function SQL(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        const userx = await SQL(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        let user = userx[0]

        let day = new Date().getDate()
        let month = new Date().getMonth() + 1
        let year = new Date().getFullYear()
        let mili = new Date().getMilliseconds()

        let hours = new Date().getHours()
        let minutes = new Date().getMinutes()
        let seconds = new Date().getSeconds()

        let fullDateStr = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}:${mili}`


        try {
            let verify = user.verified

            let id = req.body.redirectId
            const posts = await SQL(`SELECT * FROM posts WHERE _id='${id}'`)
            let post = posts[0]


            let image;
            let hideImage = 'none'
            if (req.file) {
                image = req.file.filename
                hideImage = 'block'
            }

            let redirectId = 'viewVideoPostDetails/'

            if (post.postType == 'image' || post.postType == 'text') {
                redirectId = `viewImagePostDetails/`
            }

            // Sanitizing my html
            const sanitizedComment = sanitizeHtml(req.body.comment, {
                allowedTags: [],
                allowedAttributes: {}
            });

            req.body.comment = sanitizedComment
            if (sanitizedComment == '') {
                console.log('Invalid string please try agaian later.')
                res.send({
                    errormsg: 'Invalid string please try agaian later.'
                })
                return
            }

            const _id = crypto.randomBytes(12).toString('hex')

            const comment = {
                comment: sanitizedComment,
                _id,
                owner: user._id,
                postId: id,
                fullName: `${user.firstname} ${user.lastname}`,
                image,
                hideImage,
                date: new Date(new Date().getTime()),
                commentorNickName: user.fullName,
                verified: verify,
                avatar: user.avatar,
                post_url: redirectId,
                hideReply: 'none',
            }

            let sql = 'INSERT INTO comments SET ?'
            db.query(sql, comment, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            if (req.file) {
                let file = req.files[0]
                await uploadFile(file)
                await unlineLinkFIle(file.path)
            }

            const comments = await SQL(`SELECT * FROM comments WHERE postId='${req.body.redirectId}'`)



            let updateLastCommentInPost = `UPDATE posts SET commentlength='${req.body.commentLength}',Initcomment='${req.body.comment}',commentImage='${user._id}',commentName='${user.firstname} ${user.lastname}',verifiedComment='${user.verified}',commentWidth='20',commentHeight='20',hideLastComment='block',lastCommentAvatar='${user.avatar}' WHERE _id='${posts[0]._id}'`

            db.query(updateLastCommentInPost, (error) => {
                if (error) {
                    return console.log(error)
                }
            })




            // res.redirect('/' + redirectId + post._id)

            const checkowner = post.owner.toString() !== user._id.toString()
            if (checkowner) {
                const notification = {
                    owner: user._id,
                    _id: crypto.randomBytes(12).toString('hex'),
                    text: 'Commented on your post',
                    comment: req.body.comment,
                    eventId: id,
                    eventOwner: post.owner,
                    date: new Date(new Date().getTime()),
                    ownerName: `${user.firstname} ${user.lastname}`,
                    avatar: user.avatar,
                    urlLink: redirectId + id
                }

                let sql = 'INSERT INTO notification SET ?'
                db.query(sql, notification, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('Created a new Nitification')
                })


                let findNotifcationOwner = await SQL(`SELECT * FROM users WHERE _id='${post.owner}'`)
                let eventOwner = findNotifcationOwner[0]
                if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                    let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${post.owner}'`
                    db.query(sql, (error) => {
                        if (error) return console.log(error)
                    })
                    return
                } else {
                    let count = parseInt(eventOwner.notifiicationLength)
                    count = count += 1
                    let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${post.owner}'`
                    db.query(sqlQueryForCOunt, (error) => {
                        if (error) return console.log(error)
                    })
                }
            }



            comment.date = dayjs().to(comment.date)
            res.send(JSON.stringify({
                ...comment,
                mainuser_id: req.user._id,
                postId: req.body.redirectId
            }))


        } catch (error) {
            console.log(error)
        }

    }, (error, req, res, next) => {
        res.redirect('/home')
    })


    // serving up comment image
    // view post image 1
    router.get('/webStorage/commentImages/:key', auth,  async (req, res) => {
        try {

            let key = req.params.key

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const commentsSQL = await User(`SELECT * FROM comments WHERE image='${key}'`)
            const comments = commentsSQL[0]
            if (commentsSQL.length == 0) {
                const readStream = getFileStream('image-error.jpg')
                readStream.pipe(res)
                return
            }

            const readStream = getFileStream(comments.image)
            readStream.pipe(res)


        } catch (error) {
            console.log('Error', error.message)
        }
    })




    // Show someone is typing
    io.on('connection', socket => {
        socket.on('isTyoingInPost', data => {
            socket.broadcast.emit('istypingResult', {
                ...data
            })
        })


        socket.on('cancelIsTyping', data => {
            socket.broadcast.emit('istypingResult', {
                ...data
            })
        })
    })



    // Delete comment
    router.post('/delete-comment',  async (req, res) => {
        try {
            async function SQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            const comment = await SQL(`SELECT * FROM comments WHERE _id='${req.body.id}'`)


            let sql = `DELETE  FROM comments WHERE _id='${req.body.id}'`
            db.query(sql, (error, result) => {
                if (error) {
                    return console.log(error)
                }
                console.log('Comments Deleted successful')
            })



            
            let posts;
            const unsharedposts = await SQL(`SELECT * FROM posts WHERE _id='${comment[0].postId}'`)
            const shareposts = await SQL(`SELECT * FROM sharepost WHERE _id='${comment[0].postId}'`)
            if(unsharedposts.length > 0){
                posts = unsharedposts
            }

            if(shareposts.length > 0){
                posts = shareposts
            }


            if (posts.length > 0) {
                let post = posts[0]
                const allcomments = await SQL(`SELECT * FROM comments WHERE postId='${post._id}'`)
                let updatesql = `UPDATE posts SET commentLength='${allcomments.length}' WHERE id='${post.id}'`
                db.query(updatesql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                    return res.send({
                        success: 'delete'
                    })
                })
            }







        } catch (error) {
            console.log(error)
        }

    })



    return router

}