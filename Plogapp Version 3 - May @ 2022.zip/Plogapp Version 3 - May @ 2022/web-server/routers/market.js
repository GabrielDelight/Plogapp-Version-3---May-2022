const router = require('express').Router()
const auth = require('./auth')
const mysql = require('mysql');
const crypto = require('crypto')

const { db } = require('./db') //Database

router.get('/promote', auth, async (req, res) => {
    res.render('promote')
})
module.exports = router