const express = require('express')
const router = new express.Router()
const auth = require('./auth')
const mysql = require('mysql');
const crypto = require('crypto')
const { db } = require('./db') //Database



router.get('/hashTag/:query', auth, async (req, res) => {

    async function SQLQUERRY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return console.log(error)
                }
                resolve(result)
            })
        })
    }
    const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    let user = userx[0]


    let tag = '#' + req.params.query


    // const post = await Post.find();
    const post = await SQLQUERRY(`SELECT * FROM posts`)
    let postDescription = []

    for (i = 0; i < post.length; i++) {
        if (post[i].description == undefined || post[i].description == null || post[i].description == '') {
            continue
        }

        postDescription.push(post[i].description)
    }


    let tagDesscription = []
    for (i = 0; i < postDescription.length; i++) {
        if (postDescription[i].includes(tag)) {
            tagDesscription.push(postDescription[i])
        }
    }

    let hashTagVideo = []
    let hashTagText = []
    let hashTagPhoto = []
    for (i = 0; i < tagDesscription.length; i++) {
        const getPostsPhoto = await SQLQUERRY(`SELECT * FROM posts WHERE postType='image' AND description='${tagDesscription[i]}'`)
        getPostsPhoto.forEach(val => hashTagPhoto.push(val))

        const getPostsText = await SQLQUERRY(`SELECT * FROM posts WHERE postType='text' AND description='${tagDesscription[i]}'`)
        getPostsText.forEach(val => hashTagText.push(val))

        const getPosts = await SQLQUERRY(`SELECT * FROM posts WHERE postType='video' AND description='${tagDesscription[i]}'`)
        getPosts.forEach(val => hashTagVideo.push(val))

    }


    // get tag lengthFFF
    let lengthOfTags = hashTagText.length + hashTagPhoto.length + hashTagVideo.length


    //@ Create suggestion fot user to follow____________________
    const allUsers = await SQLQUERRY(`SELECT * FROM users`)
    let myFolloingArr = user.following + user.id
    let notFollowingIdsArray = []
    for (i = 0; i < allUsers.length; i++) {
        if (!myFolloingArr.includes(allUsers[i].id)) {
            notFollowingIdsArray.push(allUsers[i].id)
        }
    }

    let newUserTOFollow = []
    for (i = 0; i < notFollowingIdsArray.length; i++) {
        const fetchUsersToFollow = await SQLQUERRY(`SELECT * FROM users WHERE id='${notFollowingIdsArray[i]}'`)
        fetchUsersToFollow.forEach(val => {
            newUserTOFollow.push(val)
        })
    }

    newUserTOFollow = newUserTOFollow.splice(0, 4)
    newUserTOFollow = newUserTOFollow.sort(() => Math.random() - 0.5)
    // @_______________________________________________________

    // @ get four (4) post 
    let allPostsSuggestedPost = await SQLQUERRY(`SELECT * FROM posts WHERE postType='image'`)
    allPostsSuggestedPost = allPostsSuggestedPost.sort(() => Math.random() - 0.5)
    allPostsSuggestedPost = allPostsSuggestedPost.splice(0, 2)



    
    res.render('hashTag', {
        user,
        tagname: req.params.query,
        text: hashTagText,
        image: hashTagPhoto,
        video: hashTagVideo,
        suggestedArr: newUserTOFollow,
        posts: allPostsSuggestedPost,
        lengthOfTags,
        hashTitle: tag
    })





})



router.get('/hashtag-rout/:query', auth, async (req, res) => {

    async function SQLQUERRY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return console.log(error)
                }
                resolve(result)
            })
        })
    }
    const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    let user = userx[0]


    let tag = '#' + req.params.query


    // const post = await Post.find();
    const post = await SQLQUERRY(`SELECT * FROM posts`)
    let postDescription = []

    for (i = 0; i < post.length; i++) {
        if (post[i].description == undefined || post[i].description == null || post[i].description == '') {
            continue
        }

        postDescription.push(post[i].description)
    }


    let tagDesscription = []
    for (i = 0; i < postDescription.length; i++) {
        if (postDescription[i].includes(tag)) {
            tagDesscription.push(postDescription[i])
        }
    }

    let hashTagVideo = []
    let hashTagText = []
    let hashTagPhoto = []
    for (i = 0; i < tagDesscription.length; i++) {
        const getPostsPhoto = await SQLQUERRY(`SELECT * FROM posts WHERE postType='image' AND description='${tagDesscription[i]}'`)
        getPostsPhoto.forEach(val => hashTagPhoto.push(val))

        const getPostsText = await SQLQUERRY(`SELECT * FROM posts WHERE postType='text' AND description='${tagDesscription[i]}'`)
        getPostsText.forEach(val => hashTagText.push(val))

        const getPosts = await SQLQUERRY(`SELECT * FROM posts WHERE postType='video' AND description='${tagDesscription[i]}'`)
        getPosts.forEach(val => hashTagVideo.push(val))

    }


    // get tag lengthFFF
    let lengthOfTags = hashTagText.length + hashTagPhoto.length + hashTagVideo.length

    
    let newArr  = [...hashTagVideo, ...hashTagText,...hashTagPhoto]

    res.send(newArr)

    // console.log(newArr)


})

// mentioning
router.get('/mention/:id', async (req, res) => {
    try {
        async function SQLQUERRY(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const users = await SQLQUERRY(`SELECT * FROM users WHERE fullName='${req.params.id}'`)
        res.redirect('/profile/' + users[0]._id)
    } catch (error) {
        res.render('404Page')
    }
})

module.exports = router