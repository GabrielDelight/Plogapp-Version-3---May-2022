
const NodeCache = require('node-cache')
const cache = new NodeCache();


function duration(req, res, next) {
    console.log(req.method)
    return
    // if (req.method !== 'GET') {
    //     console.log('Can not cache a non-get request')
    //     return next()
    // }

    // const key = req.originalUrl;
    // const cacheResponse = cache.get(key)
    // if (cacheResponse) {
    //     console.log('Cache hit for ' + key)
    //     res.send(cacheResponse)
    // } else {
    //     console.log('Cash miss for key')
    //     res.originalSend = res.send;
    //     res.send = body => {
    //         res.originalSend(body)
    //         cache.set(key, body, duration)
    //     };
    //     next()
    // }
}

exports.duration = duration