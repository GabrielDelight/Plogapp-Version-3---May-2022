const express = require('express');
const app = express();
const limitter = require('express-rate-limit')

const registerLimitter = limitter({
    windowMs:   60 * 60 * 24 * 1000,
    max: 100,
    standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
    legacyHeaders: false, // Disable the `X-RateLimit-*` headers
})

exports.registerLimitter = registerLimitter