const router = require('express').Router();
const multer = require('multer')
const auth = require('./auth');
const path = require('path');
const mysql = require('mysql')
const crypto = require('crypto');
const fs = require('fs')
const util = require('util')
const sanitizeHtml = require('sanitize-html');
const unlineLinkFIle = util.promisify(fs.unlink)
const { fullDateStr } = require('./dateFunction')
const { uploadFile, getFileStream } = require('./s3')
const { db } = require('./db') //Database
const dayjs = require('dayjs')
var relativeTime = require('dayjs/plugin/relativeTime')
dayjs.extend(relativeTime)



// @ set up validation for image upload
const storage = multer.diskStorage({
    destination: './web-server/web-folder/public/webStorage/stories',
    filename: function (req, file, cb) {
        cb(null, 'plogapp' + Date.now() + path.extname(file.originalname))
    }
})
const upload = multer({
    // limits: 300000,
    storage: storage
})




const videoUpload = multer({
    limits: 600000,
    fileFilter(req, file, cb) {
        if (!file.originalname.match(/\.(mp4|MP4|ogg|OGG)/)) {
            return cb(new Error('FIle must be a video'))
        }
        cb(undefined, true)
    }
})


module.exports = function (io) {
    // Auto delete story
    setTimeout(async () => {
        async function GETSQL(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const storyies = await GETSQL(`SELECT * FROM story `)


        storyies.forEach(async val => {
            if (val.storyHour == new Date().getHours() && val.exprireStoryNextDay == new Date().getDay()) {
                let sql = `UPDATE story SET isDisabled='true' WHERE id='${val.id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })
            }
        })
    }, 1000);



    router.post('/uploadStatusPhoto', auth, upload.single('uploads'), async (req, res) => {
        console.log(req.body)
        try {
            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = `SELECT * FROM users WHERE _id='${val}'`
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await User(req.user._id)
            let user = userx[0]

            let storyHour = new Date().getHours()
            let exprireStoryNextDay = new Date().getDay()
            exprireStoryNextDay = exprireStoryNextDay += 1

            // const user = await User.findById(req.user)
            let name = `${user.firstname} ${user.lastname}`
            const timex = new Date().toLocaleTimeString()

            const _id = crypto.randomBytes(12).toString('hex')

            // Sanitizing my html
            let sanitizedText = sanitizeHtml(req.body.storyText, {
                allowedTags: [],
                allowedAttributes: {}
            });

            console.log(sanitizedText)
            req.body.storyText = sanitizedText

            const story = {
                _id,
                caption: req.body.storyText,
                color: req.body.color,
                image: req.file.filename,
                sttoryImage: req.file.filename,
                date: new Date(new Date().getTime()),
                owner: user._id,
                ownerName: name,
                isDisabled: 'false',
                storyType: 'image',
                storyText: req.body.storyText,
                avatar: user.avatar,
                storyHour,
                exprireStoryNextDay
            }


            let sql = 'INSERT INTO story SET ?'
            db.query(sql, story, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            let file = req.file
            await uploadFile(file)
            await unlineLinkFIle(file.path)


            let sql2 = `UPDATE users SET hasStory='true',storyImg='${req.file.filename}', hasStory='true' WHERE _id='${user._id}'`
            db.query(sql2, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            res.send(JSON.stringify({
                succes: 'Success'
            }))

        } catch (error) {
            console.log(error)
            res.redirect('/home')
        }

    }, (error, req, res, next) => {
        console.log(error)
        res.redirect('/home')
    })




    const storageForVideoCover = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/TextCoverPhoto',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + Date.now() + '.png')
        }
    })
    const uploadVideoCover = multer({
        // limits: 300000,
        storage: storageForVideoCover
    })



    // Upload story for text
    router.post('/upload-story-text', uploadVideoCover.single('uploads'), auth, async (req, res) => {

        try {
            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = `SELECT * FROM users WHERE _id='${val}'`
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await User(req.user._id)
            let user = userx[0]
            
            if(req.body.description == "") return
            let storyHour = new Date().getHours()
            let exprireStoryNextDay = new Date().getDay()
            exprireStoryNextDay = exprireStoryNextDay += 1

            let name = `${user.firstname} ${user.lastname}`
            const timex = new Date().toLocaleTimeString()

            const _id = crypto.randomBytes(12).toString('hex')

            let file = req.file
            await uploadFile(file)
            await unlineLinkFIle(file.path)


            let sanitizedText = sanitizeHtml(req.body.description, {
                allowedTags: [],
                allowedAttributes: {}
            });
            
            req.body.description = sanitizedText
            
            let story = {
                _id,
                avatar: user.avatar,
                date: new Date(new Date().getTime()),
                owner: user._id,
                storyHour,
                exprireStoryNextDay,
                ownerName: name,
                isDisabled: 'false',
                image: req.file.filename,
                description: req.body.description,
                storyText: req.body.description,
                fontFamily: (req.body.fontFamily == undefined) ? '' : req.body.fontFamily,
                background: (req.body.background == undefined) ? '' : req.body.background,
                fontSize: (req.body.fontSize == undefined) ? 'cornflowerblue' : req.body.fontSize,
                boldText: (req.body.boldText == undefined) ? '' : req.body.boldText,
                storyType: 'text'
            }

            let sql = 'INSERT INTO story SET ?'
            db.query(sql, story, (error) => {
                if (error) {
                    return console.log(error)
                }




                let sql2 = `UPDATE users SET hasStory='true',storyImg='${req.file.filename}', hasStory='true' WHERE _id='${user._id}'`
                db.query(sql2, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })

                res.send(JSON.stringify({
                    succes: 'Success'
                }))
            })


            console.log(req.body)

        } catch (error) {
            console.log(error.message)
        }
    })



    // Upload story for video
    router.post('/upload-story-video', upload.single('uploads'), auth, async (req, res) => {

        try {
            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = `SELECT * FROM users WHERE _id='${val}'`
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await User(req.user._id)
            let user = userx[0]

            let storyHour = new Date().getHours()
            let exprireStoryNextDay = new Date().getDay()
            exprireStoryNextDay = exprireStoryNextDay += 1

            let file = req.file
            await uploadFile(file)
            await unlineLinkFIle(file.path)
            let name = `${user.firstname} ${user.lastname}`
            const _id = crypto.randomBytes(12).toString('hex')
            
            let sanitizedText = sanitizeHtml(req.body.storyText, {
                allowedTags: [],
                allowedAttributes: {}
            });

            req.body.storyText = sanitizedText

            let story = {
                _id,
                caption: req.body.storyText,
                color: req.body.color,
                image: req.file.filename,
                video: req.file.filename,
                date: new Date(new Date().getTime()),
                owner: user._id,
                ownerName: name,
                isDisabled: 'false',
                storyType: 'video',
                storyText: req.body.storyText,
                avatar: user.avatar,
                storyHour,
                exprireStoryNextDay
            }

            let sql = 'INSERT INTO story SET ?'
            db.query(sql, story, (error) => {
                if (error) {
                    return console.log(error)
                }

                let sql2 = `UPDATE users SET hasStory='true',storyImg='${user.avatar}', hasStory='true' WHERE _id='${user._id}'`
                db.query(sql2, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })

                res.send(JSON.stringify({
                    _id,
                    succes: 'Success'
                }))
            })

        } catch (error) {
            console.log(error.message)
        }
    })





    router.post('/upload-story-video-cover', uploadVideoCover.single('uploads'), auth, async (req, res) => {
        try {
            console.log(req.file)
            console.log(req.body)
            let file = req.file
            await uploadFile(file)
            await unlineLinkFIle(file.path)

            let sql2 = `UPDATE users SET hasStory='true',storyImg='${req.file.filename}', hasStory='true' WHERE _id='${req.user._id}'`
            db.query(sql2, (error) => {
                if (error) {
                    return console.log(error)
                }
            })



            let sql3 = `UPDATE story SET image='${req.file.filename}' WHERE _id='${req.body.storyId}'`
            db.query(sql3, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            res.send({
                success: 'success'
            })


        } catch (error) {
            console.log(error)
        }
    })






    router.post('/deleteStory', async (req, res) => {
        try {
            async function GETSQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const storyies = await GETSQL(`SELECT * FROM story WHERE _id='${req.body.storyId}'`)

            // Set the story diablity to true
            let sql = `UPDATE story SET isDisabled='true' WHERE id='${storyies[0].id}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            const allSTory = await GETSQL(`SELECT * FROM story WHERE _id='${req.body.storyId}' AND isDisabled='false'`)

            console.log(allSTory)



            res.redirect('/home')
        } catch (error) {
            res.redirect('/home')
        }

    })


    router.post('/viewStory', auth, async (req, res) => {
        console.log(req.body)
        try {
            let data = req.body
            async function STORY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            const stories = await STORY(`SELECT * FROM story WHERE owner='${data.ownerId}' AND isDisabled='false' `)
            const storyOwner = await STORY(`SELECT * FROM users WHERE _id='${data.ownerId}'`)

            let story = stories[0]
            // console.log(story)

            // if there is no story delete the user story image and set the use hasStory to false
            if (!story) {
                let sql2 = `UPDATE users SET hasStory='false', storyImg='undefined' WHERE id='${storyOwner[0].id}'`
                db.query(sql2, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })

                console.log('No story')
                return
            }

            stories.map(cur => cur.date = dayjs().to(cur.date))

            res.send(JSON.stringify({
                story: stories,
                id: data.ownerId
            }))



            // VIEWERS============================================
            const users = await STORY(`SELECT * FROM users WHERE _id='${data.viewerId}'`)

            // First check if the views is empty
            if (story.viewers == '' || story.viewers == null) {
                let sql = `UPDATE story SET viewers='${users[0].id}' WHERE _id='${stories[0]._id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('1st views added')
                })

                return
            }

            let viewersArr = story.viewers.split(',')
            let newViewersArr = viewersArr.map(el => {
                return parseInt(el)
            })

            let index = newViewersArr.indexOf(users[0].id)
            if (index < 0) {
                newViewersArr.push(users[0].id)
                console.log('add to viewers', newViewersArr)
                let sql = `UPDATE story SET viewers='${newViewersArr}' WHERE _id='${stories[0]._id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })

            }

        } catch (error) {
            console.log(error)
        }
    })


    io.on('connection', (socket) => {
        socket.on('socketStory', async (data) => {
            // try {

            //     async function STORY(val) {
            //         return new Promise((resolve, reject) => {
            //             let sql = val
            //             db.query(sql, (error, result) => {
            //                 if (error) {
            //                     return console.log(error)
            //                 }
            //                 resolve(result)
            //             })
            //         })
            //     }

            //     const stories = await STORY(`SELECT * FROM story WHERE owner='${data.ownerId}' AND isDisabled='false' `)
            //     const storyOwner = await STORY(`SELECT * FROM users WHERE _id='${data.ownerId}'`)

            //     let story = stories[0]
            //     // console.log(story)

            //     // if there is no story delete the user story image and set the use hasStory to false
            //     if (!story) {
            //         let sql2 = `UPDATE users SET hasStory='false', storyImg='undefined' WHERE id='${storyOwner[0].id}'`
            //         db.query(sql2, (error) => {
            //             if (error) {
            //                 return console.log(error)
            //             }
            //         })

            //         console.log('No story')
            //         return
            //     }


            //     // @ send the story
            //     socket.emit('story', {
            //         story: stories,
            //         id: data.ownerId
            //     })



            //     // VIEWERS============================================
            //     const users = await STORY(`SELECT * FROM users WHERE _id='${data.viewerId}'`)

            //     // First check if the views is empty
            //     if (story.viewers == '' || story.viewers == null) {
            //         let sql = `UPDATE story SET viewers='${users[0].id}' WHERE _id='${stories[0]._id}'`
            //         db.query(sql, (error) => {
            //             if (error) {
            //                 return console.log(error)
            //             }
            //             console.log('1st views added')
            //         })

            //         return
            //     }

            //     let viewersArr = story.viewers.split(',')
            //     let newViewersArr = viewersArr.map(el => {
            //         return parseInt(el)
            //     })

            //     let index = newViewersArr.indexOf(users[0].id)
            //     if (index < 0) {
            //         newViewersArr.push(users[0].id)
            //         console.log('add to viewers', newViewersArr)
            //         let sql = `UPDATE story SET viewers='${newViewersArr}' WHERE _id='${stories[0]._id}'`
            //         db.query(sql, (error) => {
            //             if (error) {
            //                 return console.log(error)
            //             }
            //         })

            //     }

            // } catch (error) {
            //     console.log(error)
            // }
        })




        // Saving viewers id to story array ==================================
        socket.on('sendIdToSaveForViewers', async (data) => {
            try {

                // VIEWERS============================================
                async function STORY(val) {
                    return new Promise((resolve, reject) => {
                        let sql = val
                        db.query(sql, (error, result) => {
                            if (error) {
                                return console.log(error)
                            }
                            resolve(result)
                        })
                    })
                }


                console.log(data)

                const users = await STORY(`SELECT * FROM users WHERE _id='${data.userId}'`)
                const stories = await STORY(`SELECT * FROM story WHERE _id='${data.storyId}'`)
                let story = stories[0]
                // First check if the views is empty
                if (story.viewers == '' || story.viewers == null) {
                    let sql = `UPDATE story SET viewers='${users[0].id}' WHERE _id='${data.storyId}'`
                    db.query(sql, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                        console.log('1st views added')
                    })

                    return
                }

                let viewersArr = story.viewers.split(',')
                let newViewersArr = viewersArr.map(el => {
                    return parseInt(el)
                })

                let index = newViewersArr.indexOf(users[0].id)
                if (index < 0) {
                    newViewersArr.push(users[0].id)
                    console.log('add to viewers', newViewersArr)
                    let sql = `UPDATE story SET viewers='${newViewersArr}' WHERE _id='${data.storyId}'`
                    db.query(sql, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                    })

                }

            } catch (error) {
                console.log(error)
            }
        })


        // =============================================================

        // fetching my story viewers 
        socket.on('fetchViewers', async (id) => {
            try {


                async function STORY(val) {
                    return new Promise((resolve, reject) => {
                        let sql = val
                        db.query(sql, (error, result) => {
                            if (error) {
                                return console.log(error)
                            }
                            resolve(result)
                        })
                    })
                }

                const stories = await STORY(`SELECT * FROM story WHERE _id='${id}'`)
                if (stories.length == 0) return

                let viewers = stories[0].viewers.split(',').map(val => parseInt(val))

                let fetchedUsers = []
                for (i = 0; i < viewers.length; i++) {
                    const views = await STORY(`SELECT * FROM users WHERE id='${viewers[i]}'`)
                    fetchedUsers.push(views)
                }

                let newViewsArr = []
                fetchedUsers.forEach(val => {
                    val.forEach(cur => newViewsArr.push(cur))
                })

                let storyViewers = []
                newViewsArr.forEach(val => {
                    val.password = undefined
                    val.hasStory = undefined
                    val.gender = undefined
                    val.phoneNumber = undefined
                    val.email = undefined
                    val.bestSentence = undefined
                    val.date = undefined
                    val.genderDescription = undefined
                    val.month = undefined
                    val.month = undefined
                    val.year = undefined
                    val.activeStatus = undefined
                    val.greenActive = undefined
                    val.notifiicationLength = undefined
                    val.createdAt = undefined
                    val.token = undefined
                    val.updatedAt = undefined
                    val.hideWelcomeMsg = undefined
                    val.chatNotification = undefined
                    val.fullName = undefined
                    storyViewers.push(val)
                })

                socket.emit('fetchedViewers', storyViewers)
            } catch (error) {
                console.log(error)
            }
        })
    })




    // story reaction
    io.on('connection', (socket) => {
        socket.on('storyReactionDetails', async (data) => {
            try {
                let userId = data.userId;
                let storyId = data.storyId;


                async function GETSQL(val) {
                    return new Promise((resolve, reject) => {
                        let sql = val
                        db.query(sql, (error, result) => {
                            if (error) {
                                return console.log(error)
                            }
                            resolve(result)
                        })
                    })
                }
                const userx = await GETSQL(`SELECT * FROM users WHERE _id='${userId}'`)
                const stories = await GETSQL(`SELECT * FROM story WHERE _id='${storyId}'`)
                let user = userx[0]
                let story = stories[0]

                // @ if post reaction is empty add the first value to it
                if (story.reaction == '' || story.reaction == null) {
                    let sql = `UPDATE story SET reaction='${user.id}', reactionLength='${1}' WHERE id='${story.id}'`
                    db.query(sql, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                    })

                    return
                }

                const reaction = story.reaction.split(',')
                let newReaction = reaction.map(el => {
                    return parseInt(el)
                })

                let index = newReaction.indexOf(user.id)

                // @ remove like
                if (index > -1) {
                    newReaction.splice(index, 1)

                    let sql = `UPDATE story SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE id='${story.id}'`
                    db.query(sql, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                    })
                    return
                }

                // @ add like
                newReaction.push(user.id)
                console.log(newReaction)
                let sql = `UPDATE story SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE id='${story.id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })

            } catch (error) {
                console.log(error)
            }
        })

    })



    return router
}

