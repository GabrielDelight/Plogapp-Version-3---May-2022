const router = require('express').Router();
const auth = require('./auth')
const mysql = require('mysql')
const dayjs = require('dayjs')
var relativeTime = require('dayjs/plugin/relativeTime')
dayjs.extend(relativeTime)

const { db } = require('./db') //Database



router.get('/search', auth, async (req, res) => {
    async function User(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return console.log(error)
                }
                resolve(result)
            })
        })
    }
    const userx = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    let user = userx[0]


    res.render('search', {
        user,
        hideDiv: 'none',
    })
})



router.post('/search', auth, async (req, res) => {
    // Serach for users
    async function User(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return console.log(error)
                }
                resolve(result)
            })
        })
    }
    const userx = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    let user = userx[0]

    let search = req.body.search
    search = search.replace('@', '').toLowerCase()
    let allusers = await User(`SELECT * FROM users`)

    // Chnage full name to lower case
    allusers.map(cur => cur.fullName = cur.fullName.toLowerCase())

    let addWithNames = []
    for (i = 0; i < allusers.length; i++) {
        if (allusers[i].fullName.includes(search)) {
            addWithNames.push(allusers[i].fullName)
        }
    }

    let arrWithUsers = []
    for (i = 0; i < addWithNames.length; i++) {
        let foundUsers = await User(`SELECT * FROM users WHERE fullName='${addWithNames[i]}'`)
        foundUsers.forEach(cur => {
            arrWithUsers.push(cur)
        })
    }



    // Search for post
    let posts = await User(`SELECT * FROM posts`)
    // Chnage full name to lower case
    posts.map(cur => cur.description = cur.description.toLowerCase())

    let postDescriptionArray = []
    postDescriptionArray.map(cur => {
        cur.description = cur.description.replace(/"/g, "hey")
        return
    })
    for (i = 0; i < posts.length; i++) {
        if (posts[i].description.includes(search.toLowerCase())) {
            postDescriptionArray.push(posts[i].description.toLowerCase())
        }
    }
    // Search for post
    let postText = []
    for (i = 0; i < postDescriptionArray.length; i++) {
        let foundPostText = await User(`SELECT * FROM posts WHERE postType='text' AND description="${postDescriptionArray[i].toString().replace(/"/g, "'")}"`)
        foundPostText.forEach(cur => {
            postText.push(cur)
        })
    }


    let postImage = []
    for (i = 0; i < postDescriptionArray.length; i++) {
        let foundpostImage = await User(`SELECT * FROM posts WHERE postType='image' AND description="${postDescriptionArray[i].toString().replace(/"/g, "'")}"`)
        foundpostImage.forEach(cur => {
            postImage.push(cur)
        })
    }


    let postVideo = []
    for (i = 0; i < postDescriptionArray.length; i++) {
        let foundpostVideo = await User(`SELECT * FROM posts WHERE postType='video' AND description="${postDescriptionArray[i].toString().replace(/"/g, "'")}"`)
        foundpostVideo.forEach(cur => {
            postVideo.push(cur)
        })
    }

    // Search for share post 
    const sharepost = await User(`SELECT * FROM sharepost`)

    let sharepostDescriptionArray = []
    sharepostDescriptionArray.map(cur => {
        cur.description = cur.description.replace(/"/g, "'")
        return
    })
    for (i = 0; i < sharepost.length; i++) {
        if (sharepost[i].description.includes(search.toLowerCase())) {
            sharepostDescriptionArray.push(sharepost[i].description.toLowerCase())
        }
    }
    // Search for post
    let sharedPostText = []
    for (i = 0; i < sharepostDescriptionArray.length; i++) {
        let foundPostTextshare = await User(`SELECT * FROM sharepost WHERE postType='sharetext' AND description="${sharepostDescriptionArray[i].toString().replace(/"/g, "'")}"`)
        foundPostTextshare.forEach(cur => {
            sharedPostText.push(cur)
        })
    }


    let photoShare = []
    for (i = 0; i < sharepostDescriptionArray.length; i++) {
        let foundpostImageshare = await User(`SELECT * FROM sharepost WHERE postType='shareimage' AND description="${sharepostDescriptionArray[i].toString().replace(/"/g, "'")}"`)
        foundpostImageshare.forEach(cur => {
            photoShare.push(cur)
        })
    }


    let videoShare = []
    for (i = 0; i < sharepostDescriptionArray.length; i++) {
        let foundpostVideoshare = await User(`SELECT * FROM sharepost WHERE postType='sharevideo' AND description="${sharepostDescriptionArray[i].toString().replace(/"/g, "'")}"`)
        foundpostVideoshare.forEach(cur => {
            videoShare.push(cur)
        })
    }








    let arr = []
    postText.forEach(cur => {
        arr.push(cur)
    })

    postImage.forEach(cur => {
        arr.push(cur)
    })

    postVideo.forEach(cur => {
        arr.push(cur)
    })
    sharedPostText.forEach(cur => {
        arr.push(cur)
    })
    photoShare.forEach(cur => {
        arr.push(cur)
    })
    videoShare.forEach(cur => {
        arr.push(cur)
    })

    let postsData = arr.sort((a, b) => {
        let c = new Date(a.sortDate)
        let d = new Date(b.sortDate)
        return d - c
    })

    postsData.map(cur => cur.date = dayjs().to(cur.date))
    res.send({
        users: arrWithUsers,
        posts: postsData
    })

})
module.exports = router
