const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken')
const auth = require('./auth')
const multer = require('multer');
const path = require('path');
const mysql = require('mysql');
const crypto = require('crypto')
const nodemailer = require('nodemailer');
const { Console } = require('console');
const dayjs = require('dayjs')
var relativeTime = require('dayjs/plugin/relativeTime')
dayjs.extend(relativeTime)
const { db } = require('./db') //Datbase
const { registerLimitter } = require('./expressEmitterDDos')

const NodeCache = require('node-cache');
const myCache = new NodeCache({ stdTTL: 30 })

router.get('/fetching-post', auth,  async (req, res) => {
    try {
        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const userSQL = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        if (userSQL.length == 0) return res.redirect('/login')
        const user = userSQL[0]

        // SET the disabling of user to false
        let sql = `UPDATE users SET isDisabled='${false}' WHERE _id='${user._id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })


        // Get all users
        async function AllUsers(val) {
            return new Promise((resolve, reject) => {
                let sql = `SELECT * FROM users`
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const allUser = await AllUsers(req.user._id)
        const suggestedFollowers = await AllUsers(req.user._id)

        async function POST(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        // Get this user following ids to fix for the user.following 
        // @ 
        let getFollowingIds = []
        let findFollowings = await User(`SELECT * FROM following WHERE owner='${req.user._id}'`)
        findFollowings.map(cur => {
            getFollowingIds.push(cur.following_id)
        })

        let myFOllowingIds = []
        for (i = 0; i < getFollowingIds.length; i++) {
            const findusers = await User(`SELECT * FROM users WHERE _id='${getFollowingIds[i]}'`)
            findusers.map(cur => {
                myFOllowingIds.push(cur.id)
            })
        }

        user.following = myFOllowingIds.toString()


        let followingIds = user.following.split(',').map(val => parseInt(val))
        // @ add use id to follower id 
        followingIds.push(user.id)


        let postText = []
        let postPhoto = []
        let postVideo = []
        for (i = 0; i < followingIds.length; i++) {
            // For post text
            const followingPostText = await POST(`SELECT * FROM posts WHERE postType='text' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostText.forEach(val => {
                postText.push(val)
            })

            // For post image
            const followingPostImage = await POST(`SELECT * FROM posts WHERE postType='image' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostImage.forEach(val => {
                postPhoto.push(val)
            })

            // @ get post video
            const followingPostVideo = await POST(`SELECT * FROM posts WHERE postType='video' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostVideo.forEach(val => {
                postVideo.push(val)
            })
        }


        // @ get shared post from following
        let sharePostText = []
        let sharePostPhoto = []
        let sharePostVideo = []
        for (i = 0; i < followingIds.length; i++) {
            // For post text
            const followingPostTextSharePost = await POST(`SELECT * FROM sharepost WHERE postType='sharetext' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostTextSharePost.forEach(val => {
                sharePostText.push(val)
            })

            // For post image
            const followingPostImageSharePos = await POST(`SELECT * FROM sharepost WHERE postType='shareimage' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostImageSharePos.forEach(val => {
                sharePostPhoto.push(val)
            })

            // @ get post video
            const followingPostVideo = await POST(`SELECT * FROM sharepost WHERE postType='sharevideo' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostVideo.forEach(val => {
                sharePostVideo.push(val)
            })

        }

        let followingStories = []
        // Get stories from followrs         
        let followingStoriesIds = user.following.split(',').map(val => parseInt(val))
        for (i = 0; i < followingStoriesIds.length; i++) {
            const userWithStory = await POST(`SELECT * FROM users WHERE hasStory='true' AND id='${followingStoriesIds[i]}'`)
            userWithStory.forEach(val => {
                followingStories.push(val)
            })
        }

        // @ current user storirs
        const getUserStory = await POST(`SELECT * FROM users WHERE hasStory='true' AND _id='${user._id}'`)


        // Hide alert for posting or not
        // Hide alert for posting or not
        let hideEnptryPostDiv = 'none'
        if (
            postText.length < 1 &&
            postPhoto < 1 &&
            postVideo < 1 &&
            sharePostText < 1 &&
            sharePostPhoto < 1 &&
            sharePostVideo < 1
        ) {
            hideEnptryPostDiv = 'block'
        }



        //@ Create suggestion fot user to follow____________________
        const allUsers = await POST(`SELECT * FROM users`)
        let myFolloingArr = user.following + user.id
        let notFollowingIdsArray = []
        for (i = 0; i < allUsers.length; i++) {
            if (!myFolloingArr.includes(allUsers[i].id)) {
                notFollowingIdsArray.push(allUsers[i].id)
            }
        }

        let newUserTOFollow = []
        for (i = 0; i < notFollowingIdsArray.length; i++) {
            const fetchUsersToFollow = await POST(`SELECT * FROM users WHERE id='${notFollowingIdsArray[i]}'`)
            fetchUsersToFollow.forEach(val => {
                newUserTOFollow.push(val)
            })
        }

        newUserTOFollow = newUserTOFollow.sort(() => Math.random() - 0.5)
        newUserTOFollow = newUserTOFollow.splice(0, 4)
        // @_______________________________________________________

        // @ get four (4) post 
        let allPostsSuggestedPost = await POST(`SELECT * FROM posts WHERE postType='image'`)
        allPostsSuggestedPost = allPostsSuggestedPost.sort(() => Math.random() - 0.5)
        allPostsSuggestedPost = allPostsSuggestedPost.splice(0, 2)


        // get reaction
        let notification = await POST(`SELECT * FROM notification WHERE eventOwner='${user._id}' ORDER BY id DESC`)

        // get chat notification
        let chatNotification = await POST(`SELECT * FROM chatnotification WHERE receiverId='${user._id}' ORDER BY id DESC`)

        let sentChatNotification = await POST(`SELECT * FROM sentchatnotification WHERE owner='${user._id}' ORDER BY id DESC`)


        // let data = {
        //     ...postText,
        //     ...postPhoto,
        //     ...postVideo
        // }

        let arr = []
        postText.forEach(cur => {
            arr.push(cur)
        })

        postPhoto.forEach(cur => {
            arr.push(cur)
        })

        postVideo.forEach(cur => {
            arr.push(cur)
        })


        sharePostText.forEach(cur => {
            arr.push(cur)
        })

        sharePostPhoto.forEach(cur => {
            arr.push(cur)
        })
        sharePostVideo.forEach(cur => {
            arr.push(cur)
        })





        // arr = arr.sort(() => Math.random() - 0.5)
        arr = arr.sort(() => Math.random() - 0.5)
        // Add day js

        arr.map(cur => cur.date = dayjs().to(cur.date))
        
        res.send(arr)
        // usinf cache to fnd data
        // if (myCache.has("posts")) {            
        //     return res.send(myCache.get("posts"))
        // } else {            
        //     let jsonFIle = JSON.stringify(arr)
        //     myCache.set("posts", jsonFIle)
        //     res.send(jsonFIle)
        // }

        // Set cache 
    } catch (error) {
        console.log(error)
    }

})


router.get('/user_api/:id', auth,  async (req, res) => {
    try {
        async function SQLQUERY(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const userSQL = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.params.id}'`)
        const user = userSQL[0]
        user.password = undefined




        let paramsuUser = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.params.id}'`)
        let findFollowings = await SQLQUERY(`SELECT * FROM following WHERE owner='${req.user._id}'`)
        let following = []
        let followingUniqueId = []
        findFollowings.map(cur => {
            following.push(cur.following_id)
            followingUniqueId.push(cur.id)
        })
        // console.log(following)
        let followingUniqyeId = []

        // @ get user following
        let newFollowingsArr = []
        for (i = 0; i < following.length; i++) {
            const findusers = await SQLQUERY(`SELECT * FROM users WHERE _id='${following[i]}' ORDER BY id DESC`)
            findusers.forEach(val => {
                newFollowingsArr.push(val)
                followingUniqyeId.push(val.id)
            })
        }



        // Get user follower ids
        let newFollowersArr = []

        let findFollowers = await SQLQUERY(`SELECT * FROM follower WHERE follower_id='${req.params.id}'`)
        let followers = []
        let followersUniqueId = []
        findFollowers.map(cur => {
            followers.push(cur.owner)
            followersUniqueId.push(cur.id)
        })


        // @ get user followers
        for (i = 0; i < followers.length; i++) {
            const findusers = await SQLQUERY(`SELECT * FROM users WHERE _id='${followers[i]}' ORDER BY id DESC`)
            findusers.forEach(val => {
                newFollowersArr.push(val)
            })
        }


        res.send({
            user: user,
            follower: followers.length,
            following: followingUniqyeId.length
        })
    } catch (error) {
        console.log(error)
    }
})




module.exports = router
