const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken')
const auth = require('./auth')
const multer = require('multer');
const path = require('path');
const mysql = require('mysql');
const crypto = require('crypto')
const nodemailer = require('nodemailer');
const fs = require('fs')
const util = require('util')
const dayjs = require('dayjs')
var relativeTime = require('dayjs/plugin/relativeTime')
dayjs.extend(relativeTime)
const sanitizeHtml = require('sanitize-html');
const unlineLinkFIle = util.promisify(fs.unlink)
const { uploadFile, getFileStream } = require('./s3')
const { registerLimitter } = require('./expressEmitterDDos')
const { db } = require('./db')
// const fetch = require('node-fetch');


// @ set up validation for image upload
const storage = multer.diskStorage({
    destination: './web-server/web-folder/public/webStorage/avatar',
    filename: function (req, file, cb) {
        cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
    }
})


const upload = multer({
    // limits: 300000,
    storage: storage
})


// Home page route
router.get('/home', auth, async (req, res) => {
    try {
        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const userSQL = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        if (userSQL.length == 0) return res.redirect('/login')
        const user = userSQL[0]

        // SET the disabling of user to false
        let sql = `UPDATE users SET isDisabled='${false}' WHERE _id='${user._id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })


        // Get followers and following 
        const paramsuUser = await POST(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        let findFollowings = await User(`SELECT * FROM following WHERE owner='${req.user._id}'`)
        let following = []
        let followingUniqueId = []
        findFollowings.map(cur => {
            following.push(cur.following_id)
            followingUniqueId.push(cur.id)
        })
        // console.log(following)
        let followingUniqyeId = []

        // @ get user following
        let newFollowingsArr = []
        for (i = 0; i < following.length; i++) {
            const findusers = await User(`SELECT * FROM users WHERE _id='${following[i]}' ORDER BY id DESC`)
            findusers.forEach(val => {
                newFollowingsArr.push(val)
                followingUniqyeId.push(val.id)
            })
        }



        // Get user follower ids
        let newFollowersArr = []

        let findFollowers = await User(`SELECT * FROM follower WHERE follower_id='${req.user._id}'`)
        let followers = []
        let followersUniqueId = []
        findFollowers.map(cur => {
            followers.push(cur.owner)
            followersUniqueId.push(cur.id)
        })


        // @ get user followers
        for (i = 0; i < followers.length; i++) {
            const findusers = await User(`SELECT * FROM users WHERE _id='${followers[i]}' ORDER BY id DESC`)
            findusers.forEach(val => {
                newFollowersArr.push(val)
            })
        }


        user.following = followingUniqyeId.toString()

        let followingIds = user.following.split(',').map(val => parseInt(val))
        // @ add use id to follower id 
        followingIds.push(user.id)


        // Get all users
        async function AllUsers(val) {
            return new Promise((resolve, reject) => {
                let sql = `SELECT * FROM users`
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const allUser = await AllUsers(req.user._id)

        async function POST(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }


        let followingStories = []
        // Get stories from followrs         
        let followingStoriesIds = user.following.split(',').map(val => parseInt(val))
        for (i = 0; i < followingStoriesIds.length; i++) {
            const userWithStory = await POST(`SELECT * FROM users WHERE hasStory='true' AND id='${followingStoriesIds[i]}'`)
            userWithStory.forEach(val => {
                followingStories.push(val)
            })
        }

        // @ current user storirs
        const getUserStory = await POST(`SELECT * FROM users WHERE hasStory='true' AND _id='${user._id}'`)


        // Hide alert for posting or not
        // Hide alert for posting or not
        let hideEnptryPostDiv = 'none'

        

        res.render('index', {
            user: user,
            users: allUser,
            userStory: getUserStory[0],
            story: followingStories,        
            hideEnptryPostDiv,            
            cookies: req.cookies.auth_token,
        })

    } catch (error) {
        res.render('404Page')
        console.log(error)
    }

})



// notification list api
router.get('/notification-api', auth,  async (req, res) => {
    try {
        async function SQLQUERY(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        const userSQL = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        const user = userSQL[0]
        let notification = await SQLQUERY(`SELECT * FROM notification WHERE eventOwner='${user._id}' ORDER BY id DESC`)
        notification.map(cur => cur.date = dayjs().to(cur.date))
        res.send(notification)
    } catch (error) {
        console.log(error)
    }
})





// notification list api
// router.get('/sent-messages-api', auth, async (req, res) => {
//     try {
//         async function SQLQUERY(val) {
//             return new Promise((resolve, reject) => {
//                 let sql = val
//                 db.query(sql, (error, result) => {
//                     if (error) {
//                         return console.log(error)
//                     }
//                     resolve(result)
//                 })
//             })
//         }

//         const userSQL = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
//         const user = userSQL[0]
//         let sentChatNotification = await SQLQUERY(`SELECT * FROM sentchatnotification WHERE owner='${user._id}' ORDER BY id DESC`)
//         res.send(sentChatNotification)
//     } catch (error) {
//         console.log(error)
//     }
// })


// Get suggested people to follow
router.get('/suggested-to-follow-api', auth,  async (req, res) => {
    try {
        //@ Create suggestion fot user to follow____________________

        async function SQLQUERY(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const userSQL = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        const user = userSQL[0]
        // let myFolloingArr = user.following
        //@ Create suggestion fot user to follow____________________

        //@ Create suggestion for user to follow____________________
        const allUsers = await SQLQUERY(`SELECT * FROM users`)
        // Get this user following ids to fix for the user.following 
        // @ 
        let getFollowingIds = []
        let findFollowings = await SQLQUERY(`SELECT * FROM following WHERE owner='${req.user._id}'`)
        findFollowings.map(cur => {
            getFollowingIds.push(cur.following_id)
        })

        let myFOllowingIds = []
        for (i = 0; i < getFollowingIds.length; i++) {
            const findusers = await SQLQUERY(`SELECT * FROM users WHERE _id='${getFollowingIds[i]}'`)
            findusers.map(cur => {
                myFOllowingIds.push(cur.id)
            })
        }

        user.following = myFOllowingIds.toString()
        let myFolloingArr = user.id + ',' + user.following
        myFolloingArr = myFolloingArr.split(',').map(cur => parseInt(cur))

        let notFollowingIdsArray = []
        for (i = 0; i < allUsers.length; i++) {
            if (!myFolloingArr.includes(allUsers[i].id)) {
                notFollowingIdsArray.push(allUsers[i].id)
            }
        }


        let newUserTOFollow = []
        for (i = 0; i < notFollowingIdsArray.length; i++) {
            const fetchUsersToFollow = await SQLQUERY(`SELECT * FROM users WHERE id='${notFollowingIdsArray[i]}'`)
            fetchUsersToFollow.forEach(val => {
                newUserTOFollow.push(val)
            })
        }

        newUserTOFollow = newUserTOFollow.sort(() => Math.random() - 0.5)
        // newUserTOFollow = newUserTOFollow.splice(0, 50)

        let newFilteredArray = [... new Set(newUserTOFollow)]

        res.send(newFilteredArray)


    } catch (error) {
        console.log(error)
    }
})



// ROuter for sponsored post
router.get('/sponsored-post-rout-api', auth, async (req, res) => {
    try {
        //@ Create suggestion fot user to follow____________________

        async function SQLQUERY(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const userSQL = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        const user = userSQL[0]
        let allPostsSuggestedPost = await SQLQUERY(`SELECT * FROM posts WHERE postType='image'`)
        allPostsSuggestedPost = allPostsSuggestedPost.sort(() => Math.random() - 0.5)
        allPostsSuggestedPost = allPostsSuggestedPost.splice(0, 2)
        res.send(allPostsSuggestedPost)

    } catch (error) {
        console.log(error)
    }
})

// Craete rout **************************
router.get('/', (req, res) => {
    const token = req.cookies.auth_token
    if (token) {
        return res.redirect('/home')
    }

    res.render('welcomePage')
})


router.post('/welcomePage', (req, res) => {
    if (req.body.myCookie == '') {
        return res.redirect('/login')
    }
    res.cookie('auth_token', req.body.myCookie)
    res.redirect('/home')
})

router.get('/create',  (req, res) => {
    res.render('form/register')
})



// @Creating an account for users
router.post('/account_creation',  async (req, res) => {
    try {
        // // Check if email exist 
        async function SQLQUERY(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        const email = await SQLQUERY(`SELECT * FROM users WHERE email='${req.body.email}'`)
        if (email.length > 0) {
            console.log('Email aready exist')
            return res.send(JSON.stringify({ emailError: 'Email already exist' }))
        }


        const hashPassword = await bcrypt.hash(req.body.password, 10);

        let genderDescription = ''
        if (req.body.gender == 'female') {
            genderDescription = 'her'
        } else {
            genderDescription = 'his'
        }

        let date = new Date().getDate()
        let monthsArray = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        let month = new Date().getMonth();
        let newMonth = monthsArray[month];
        let year = new Date().getFullYear()


        // Generate random ids
        const _id = crypto.randomBytes(12).toString('hex')
        let firstname = req.body.firstname
        firstname = firstname.replace(/(<)|(>)/g, '')

        let lastname = req.body.lastname
        lastname = lastname.replace(/(<)|(>)/g, '')

        let fullName = req.body.fullName
        fullName = fullName.replace(/(<)|(>)/g, '')

        function sanitizeString(text) {
            return sanitizeHtml(text, {
                allowedTags: [],
                allowedAttributes: {}
            });
        }


        const user = {
            firstname: sanitizeString(firstname),
            lastname: sanitizeString(lastname),
            fullName: sanitizeString(fullName),
            email: sanitizeString(req.body.email),
            password: hashPassword,
            gender: sanitizeString(req.body.gender),
            genderDescription: sanitizeString(genderDescription),
            month: sanitizeString(newMonth),
            date: sanitizeString(date),
            _id,
            year: sanitizeString(year),
            avatar: 'avatar.png',
            coverPhoto: 'coverphoto2.jpg',
            following: '',
            following: '',
        };

        let sql = 'INSERT INTO users SET ?'
        db.query(sql, user, (error) => {
            if (error) {
                return console.log(error)
            }
            console.log('Created a new User')
        })

        const token = await jwt.sign({ _id: _id }, process.env.JWT_SECRET);
        res.cookie('auth_token', token)

        let findCreatedUser = await SQLQUERY(`SELECT * FROM users WHERE _id='${_id}'`)
        findCreatedUser = findCreatedUser[0]
        console.log(findCreatedUser)
        res.send(JSON.stringify(findCreatedUser))


    } catch (error) {
        console.log(error)
        return res.send(JSON.stringify({ error: 'Something went wrong please try again later' }))

    }


})


// confirm email address
// Confirm Email
router.get('/confirmemail/:id',  async (req, res) => {
    async function User(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    const userSQL = await User(`SELECT * FROM users WHERE _id='${req.params.id}'`)
    const user = userSQL[0]

    res.render('form/confirmEmail', {
        user
    })
})


// post request for confirming email
router.post('/confirmemail/:id',  async (req, res) => {
    async function User(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    const userSQL = await User(`SELECT * FROM users WHERE _id='${req.params.id}'`)
    const user = userSQL[0]

    let code = parseInt(req.body.code)
    console.log(user.verificationCode + " " + code)
    if (parseInt(user.verificationCode) === code) {
        // getnerate toke so we don't use req.params to find users just for hacckingpurposes
        // @ Send cookie
        const token = await jwt.sign({ _id: user._id }, process.env.JWT_SECRET);
        res.cookie('auth_token', token)
        return res.send({
            success: 'Success'
        })
    } else {
        return res.send({
            notMatch: 'Failed'
        })
    }
})




router.get('/nickname', auth,  async (req, res) => {
    res.render('form/nickname')
})


router.post('/submitNickname', auth,  async (req, res) => {
    try {
        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = `SELECT * FROM users WHERE _id='${val}'`
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const userx = await User(req.params.id)
        let user = userx[0]


        async function FindNickName(val) {
            return new Promise((resolve, reject) => {
                let sql = `SELECT * FROM users WHERE fullName='${val}'`
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const niackname = await FindNickName(req.body.nickname)

        if (niackname.length > 0) {
            // Nicename already exist
            return res.render('form/nickname', {
                user,
                error: 'This nickname has been used'
            })
        }

        function sanitizeString(text) {
            return sanitizeHtml(text, {
                allowedTags: [],
                allowedAttributes: {}
            });
        }
        req.body.nickname = req.body.nickname.replace(/ /g, "")

        // Update the nickname
        let sql = `UPDATE users SET fullName='${sanitizeString(req.body.nickname)}' WHERE _id='${req.user._id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
            console.log('Updated nickname')
        })
        res.redirect('/uploadProfile')

    } catch (error) {
        console.log(error.message)
        res.render('404Page')
    }
})


// Profile pic
router.get('/uploadProfile', auth,  async (req, res) => {
    try {
        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = `SELECT * FROM users WHERE _id='${val}'`
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const userx = await User(req.params.id)
        let user = userx[0]


        res.render('form/profilePicture', {
            user
        })
    } catch (error) {
        res.render('404Page')
    }
})



// Upload profile pic after creating an coount
router.post('/uploadProfile', auth, upload.single('uploads'),  async (req, res) => {
    try {
        let file = req.file
        await uploadFile(file)
        await unlineLinkFIle(file.path)

        function sanitizeString(text) {
            return sanitizeHtml(text, {
                allowedTags: [],
                allowedAttributes: {}
            });
        }

        if (sanitizeString(req.file.filename) == '') {
            res.redirect('/uploadProfile?errorMsg=errorOccured')
            return
        }

        let sql = `UPDATE users SET avatar='${sanitizeString(req.file.filename)}' WHERE _id='${req.user._id}'`
        db.query(sql, (error, result) => {
            if (error) {
                return console.log(error)
            }
            console.log('Updated successfully')
        })

        res.redirect('/bio')
    } catch (error) {
        res.redirect('/uploadProfile?errorMsg=errorOccured')
    }
})




// Create a bio 
router.get('/bio', auth,  async (req, res) => {
    res.render('form/bio')
})


router.post('/bio', auth,  async (req, res) => {
    try {

        function sanitizeString(text) {
            return sanitizeHtml(text, {
                allowedTags: [],
                allowedAttributes: {}
            });
        }

        let sql = `UPDATE users SET bestSentence='${sanitizeString(req.body.bio)}' WHERE _id='${req.user._id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
            console.log('Updated bio successfully')
        })

        res.redirect('/dateOfBirth')

    } catch (error) {
        console.log(error)
        // res.render('404Page')
        res.redirect('/bio?errorMsg=error')

    }

})


// Skip bio
router.get('/skipBio', auth,  async (req, res) => {
    res.redirect('/dateOfBirth')
})


// Date of birth
router.get('/dateOfBirth', auth,  async (req, res) => {
    res.render('form/birthDay')
})

router.post('/datOfBirth', auth,  async (req, res) => {
    try {

        function sanitizeString(text) {
            return sanitizeHtml(text, {
                allowedTags: [],
                allowedAttributes: {}
            });
        }

        let sql = `UPDATE users SET birthDay='${sanitizeString(req.body.day)}', birthMonth='${sanitizeString(req.body.month)}', birthYear='${sanitizeString(req.body.year)}' WHERE _id='${req.user._id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        // Send token to header 
        const token = await jwt.sign({ _id: req.user._id }, process.env.JWT_SECRET);
        res.cookie('auth_token', token)
        res.redirect('/home')

    } catch (error) {
        console.log(error)
        res.render('404Page')
    }
})




router.get('/login',  (req, res) => {
    res.render('form/login-min')
})

// LOGIN
router.post('/user_login_request',  async (req, res) => {
    try {
        async function findEmail(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        res.send(JSON.stringify({
                            error: 'An error occured please try again later',
                        }))
                        return
                    }
                    resolve(result)
                })
            })
        }


        const email = await findEmail(`SELECT * FROM users WHERE email='${req.body.email}'`)
        console.log(email)
        let user = email[0]
        // console.log(user)

        // @ id no user found
        if (email.length == 0) {
            res.send(JSON.stringify({
                error: 'Email could not be found',
                email: req.body.email
            }))
            return
        }


        // Compare password
        const verifyUser = await bcrypt.compare(req.body.password, user.password);
        if (!verifyUser) {
            res.send(JSON.stringify({
                error: 'Password is incorrect',
                email: req.body.email
            }))
            return

        }


        // Send token to header 
        const token = await jwt.sign({ _id: user._id }, process.env.JWT_SECRET);
        // Send cookie
        res.cookie('auth_token', token)
        // req.session.save()
        res.send(JSON.stringify(user))

    } catch (error) {
        console.log('error', error)
    }
})




// Forgotton password section *********************************
router.get('/findAccount',  async (req, res) => {
    res.render('form/findAccount')
})


// find account post router
router.post('/findAccount',  async (req, res) => {
    async function User(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    const userSQL = await User(`SELECT * FROM users WHERE email='${req.body.email}'`)
    const user = userSQL[0]

    if (userSQL.length < 1) {
        // If email is not found
        if (!user) {
            return res.send({
                notFound: 'not_found'
            })
        }
    }

    res.send({
        found: 'emailFound',
        user_id: user._id
    })
    // res.redirect('/foundAccount/' + user._id)
})

// FOUND account router
router.get('/foundAccount/:id',  async (req, res) => {
    try {

        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const userSQL = await User(`SELECT * FROM users WHERE _id='${req.params.id}'`)
        const user = userSQL[0]
        if (userSQL.length < 1) {
            return res.redirect('/login')
        }

        res.render('form/foundAccount', {
            user
        })
    } catch (error) {
        console.log(error)
        res.redirect('/login')
    }

})


router.get('/generateCode',  async (req, res) => {
    let sql = `UPDATE users SET verificationCode='${code}' WHERE _id='${req.params.id}'`
    db.query(sql, (error) => {
        if (error) {
            return console.log(error)
        }
    })
})

// get user api without authenticati0on
router.get('/user_with_auth/:id',  async (req, res) => {
    async function User(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    const userSQL = await User(`SELECT * FROM users WHERE _id='${req.params.id}'`)
    const user = userSQL[0]
    user.password = undefined
    res.send(user)
})


router.post('/update_reset_code', (req, res) => {
    let sql = `UPDATE users SET verificationCode='${req.body.code}'  WHERE _id='${req.body.owner}'`
    db.query(sql, (error) => {
        if (error) {
            return console.log(error)
        }

    })
    res.send({
        success: 'Success'
    })
})


// Generate 6 digit code
router.get('/forgotPassword/:id',  async (req, res) => {
    try {

        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const userSQL = await User(`SELECT * FROM users WHERE _id='${req.params.id}'`)
        const user = userSQL[0]
        if (!user || userSQL.length < 0) {
            return res.redirect('/login')
        }





        // Send email here


        res.render('form/forgotPassword', {
            user
        })
    } catch (error) {
        console.log(error)
        res.send({
            error: error
        })
    }
})



// Confrim code
router.post('/forgotPassword/:id',  async (req, res) => {
    async function User(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    const userSQL = await User(`SELECT * FROM users WHERE _id='${req.params.id}'`)
    const user = userSQL[0]

    let code = req.body.code
    console.log(user.verificationCode === code)
    if (user.verificationCode === code) {
        // getnerate toke so we don't use req.params to find users just for hacckingpurposes
        // @ Send cookie
        const token = await jwt.sign({ _id: user._id }, process.env.JWT_SECRET);
        res.cookie('auth_token', token)
        return res.redirect('/getNewPassword/' + user._id)
    } else {
        res.redirect('/forgotPassword/' + user._id + "?check=false")
    }
})


// Change password 
router.get('/getNewPassword/:id', auth,  async (req, res) => {

    async function User(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    const userSQL = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    const user = userSQL[0]

    res.render('form/changePassword', {
        user
    })
})

// Change password in forgot password restoration
router.post('/getNewPassword/:id', auth,  async (req, res) => {
    async function User(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    const userSQL = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    const user = userSQL[0]
    const password = req.body.password
    const confirmPassword = req.body.confirmPassword

    if (confirmPassword != password) {
        res.redirect('/getNewPassword/' + req.params.id + '?notmatch=notmatch')
        return
    }

    if (password.length <= 6) {
        res.redirect('/getNewPassword/' + req.params.id + '?shortpassword=shortpassword')
        return
    }

    const hashPassword = await bcrypt.hash(password, 10)


    let sql = `UPDATE users SET password='${hashPassword}',verificationCode=''  WHERE _id='${req.user._id}'`
    db.query(sql, (error) => {
        if (error) {
            return console.log(error)
        }
    })

    // Send cookie
    res.redirect('/home')

})




// Log out users *********************
router.get('/clearcookie', (req, res) => {
    res.clearCookie('auth_token').redirect('/login')
})


router.get('/tearms_condition', (req, res) => {
    res.render('form/terms_and_conditions')
})


async function getusernames(req, res, next) {
    try {
        const { username } = req.params
        const response = await fetch('https://api.github.com/users/' + usernames)
        res.send(response)
        next()
    } catch (error) {
        console.log(error)
    }
}

router.get('/github-profiles/:usernames', getusernames)

module.exports = router
