const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken')
const auth = require('./auth')
const multer = require('multer');
const path = require('path');
const mysql = require('mysql');
const crypto = require('crypto')
const nodemailer = require('nodemailer');
const fs = require('fs')
const util = require('util')
const dayjs = require('dayjs')
var relativeTime = require('dayjs/plugin/relativeTime')
dayjs.extend(relativeTime)
const sanitizeHtml = require('sanitize-html');
const unlineLinkFIle = util.promisify(fs.unlink)
const { uploadFile, getFileStream } = require('./s3')
const { registerLimitter } = require('./expressEmitterDDos')
const { db } = require('./db')

module.exports = function (io) {

    router.get('/video-calling', auth, async (req, res) => {
        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return
                    }
                    resolve(result)
                })
            })
        }

        let user = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        user = user[0]

        res.render('videoCallPage', {
            user
        })
    })

    router.post('/video-calling-received', auth, async (req, res) => {
        // console.log(req.body)

        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return
                    }
                    resolve(result)
                })
            })
        }

        let user = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        user = user[0]


        res.render('videoCallPage', {
            user,
            signaData: req.body.signaData
        })
    })

    router.get('/start-calling/:idd', auth, async (req, res) => {
        try {
            const user = await User.findById(req.user)
            const receiver = await User.findById(req.params.id)
            if (!receiver) {
                return res.render('404Page')
            }
            res.render('videoCalling', {
                user,
                receiver,
                peerType: 'init',
                title: 'Calling ' + user.firstname + ' ' + user.lastname,
            })

        } catch (error) {
            res.render('404Page')
            console.log(error.message)
        }
    })


    router.get('/incoming-call/:id', auth, async (req, res) => {
        try {
            const user = await User.findById(req.user)
            const caller = await User.findById(req.params.id)
            if (!caller) {
                return res.render('404Page')
            }
            res.render('incomingCall', {
                user,
                caller,
                title: 'Incoming call from ' + user.firstname + ' ' + user.lastname,
                peerType: 'not init'


            })

        } catch (error) {
            return res.render('404Page')
        }
    })





    io.on('connection', (socket) => {


        // @ (1) Check if user 2 jpined
        socket.on('check-is-user2-joined', data => {
            socket.broadcast.emit('check-if-user-two-exist', data)
        })

        // @ (2) FOund that user two is available 
        socket.on('user2-is-abailable', data => {
            socket.broadcast.emit('tell-user1-that-user-two-available', data)
        })

        // Sending signal for calling
        socket.on('send-calling-signal', async data => {
            try {
                async function User(val) {
                    return new Promise((resolve, reject) => {
                        let sql = val
                        db.query(sql, (error, result) => {
                            if (error) {
                                return
                            }
                            resolve(result)
                        })
                    })
                }

                let user = await User(`SELECT * FROM users WHERE _id='${data.callerId}'`)
                user = user[0]
                if (!user) return

                socket.broadcast.emit('find-video-receiver', {
                    dataSignal: data.dataSignal,
                    callerId: data.callerId,
                    callerName: user.firstname + ' ' + user.lastname,
                    callerImage: user.avatar,
                    receiverId: data.receiverId
                })
            } catch (error) {
                console.log(error)
            }
        })


        // Listening to rejected call
        socket.on('vc-rejected-call', data => {
            socket.broadcast.emit('user-busy-signal', data)
        })


        // When a user force quite call while calling
        socket.on('force-quit-call', data => {
            socket.broadcast.emit('force-quiting-call', data)
        })


        // send a signal that user 2 joined the call
        socket.on('receiver-join', data => {
            socket.broadcast.emit('signal-user-2-joined', data)
        })

        // Sending signal dat to user two 
        socket.on('signalData', data => {
            setTimeout(() => {
                socket.broadcast.emit('callerSignalData', data)
            }, 5000);
        })

        // User one now receiving the signal generated from user two 
        socket.on('sendData2SignalJson', data => {
            socket.broadcast.emit('dataDataGenByUser2', data)
        })


    })

    return router
}