const router = require('express').Router()
const auth = require('./auth');
const mysql = require('mysql');
const crypto = require('crypto')
const { db } = require('./db') //Datbase


module.exports = function (io) {
    let publickParams = []
    router.get('/follower/:id', auth, async (req, res) => {
        try {

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            let users = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = users[0]
            let followerUser = await User(`SELECT * FROM users WHERE _id='${req.params.id}'`)
            followerUser = followerUser[0]
            // console.log(followerUser)
            let newFollowersArr = []

            let findFollowers = await User(`SELECT * FROM follower WHERE follower_id='${req.params.id}'`)
            let followers = []
            let followersUniqueId = []
            findFollowers.map(cur => {
                followers.push(cur.owner)
                followersUniqueId.push(cur.id)
            })


            // @ get user followers
            for (i = 0; i < followers.length; i++) {
                const findusers = await User(`SELECT * FROM users WHERE _id='${followers[i]}' ORDER BY id DESC`)
                findusers.forEach(val => {
                    newFollowersArr.push(val)
                })
            }

            // Get this user following ids to fix for the user.following 
            // @ 
            let getFollowingIds = []
            let findFollowings = await User(`SELECT * FROM following WHERE owner='${req.params.id}'`)
            findFollowings.map(cur => {
                getFollowingIds.push(cur.following_id)
            })

            let myFOllowingIds = []
            for(i = 0; i < getFollowingIds.length; i++){
                const findusers = await User(`SELECT * FROM users WHERE _id='${getFollowingIds[i]}'`)
                findusers.map(cur => {
                    myFOllowingIds.push(cur.id)
                })
            }

            user.following = myFOllowingIds.toString()
            
            res.render('follower-min', {
                user,
                followerUser,
                followers: newFollowersArr,
                paramsId: req.params.id,

            })

        } catch (error) {
            conosle.log(error)
            res.render('404Page')
        }
    })


    io.on('connection', socket => {
        socket.on('sendUserIdToGetFollowers', async (xId) => {
            const userFollowers = await User.findById(xId.paramsId)
            let followerArr = userFollowers.follower;

            let idsArr = []
            followerArr.forEach(cur => {
                cur.forEach(val => {
                    idsArr.push(val)
                })
            })


            let getFollowers = ''
            let newUserArr = []
            for (i = 0; i < idsArr.length; i++) {
                getFollowers = await User.findById(idsArr[i]);
                newUserArr.push(getFollowers)
            }

            let filteredArr = []
            newUserArr.forEach(cur => {
                cur.coverPhoto = undefined
                cur.storyImg = undefined
                cur.password = undefined
                cur.hasStory = undefined
                cur.gender = undefined
                cur.phoneNumber = undefined
                cur.email = undefined
                cur.verified = undefined
                cur.date = undefined
                cur.genderDescription = undefined
                cur.month = undefined
                cur.month = undefined
                cur.year = undefined
                cur.activeStatus = undefined
                cur.greenActive = undefined
                cur.notifiicationLength = undefined
                cur.createdAt = undefined
                cur.token = undefined
                cur.updatedAt = undefined
                cur.hideWelcomeMsg = undefined
                cur.fullName = undefined
                filteredArr.push(cur)
            })

            let shuffledFollowers = filteredArr.sort(() => Math.random() - 0.5)

            socket.emit('follower-socket', shuffledFollowers)
        })
    })


    router.get('/follower-api', auth, async (req, res) => {
        try {
            let newParamsId = publickParams[publickParams.length - 1]
            let xId = newParamsId.toString()

            const user = await User.findById(req.user)
            const userFollowers = await User.findById(xId)

            let followerArr = userFollowers.follower;
            let idsArr = []
            followerArr.forEach(cur => {
                cur.forEach(val => {
                    idsArr.push(val)
                })
            })

            let getFollowers = ''
            let newUserArr = []
            for (i = 0; i < idsArr.length; i++) {
                getFollowers = await User.findById(idsArr[i]);
                newUserArr.push(getFollowers)
            }

            let filteredArr = []
            newUserArr.forEach(cur => {
                filteredArr.push(cur)
            })

            let shuffledFollowers = filteredArr.sort(() => Math.random() - 0.5)
            res.send(shuffledFollowers)
            publickParams = []

        } catch (error) {
            console.log('Error occured')
        }

    })

    return router
}