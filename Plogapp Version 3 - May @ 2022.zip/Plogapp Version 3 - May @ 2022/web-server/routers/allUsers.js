const router = require('express').Router();
const auth = require('./auth')
const mysql = require('mysql');
const crypto = require('crypto')

const { db } = require('./db') //Datbase
const { registerLimitter } = require('./expressEmitterDDos')
const NodeCache = require('node-cache');
const myCache = new NodeCache({ stdTTL: 35 })

module.exports = function (io) {
    router.get('/allUsers', auth, async (req, res) => {
        try {


            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const users = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            const user = users[0]

            //@ Create suggestion fot user to follow____________________
            const allUsers = await User(`SELECT * FROM users`)
            let myFolloingArr = user.following + user.id
            let notFollowingIdsArray = []
            for (i = 0; i < allUsers.length; i++) {
                if (!myFolloingArr.includes(allUsers[i].id)) {
                    notFollowingIdsArray.push(allUsers[i].id)
                }
            }


            // Get this user following ids to fix for the user.following 
            // @ 
            let getFollowingIds = []
            let findFollowings = await User(`SELECT * FROM following WHERE owner='${req.user._id}'`)
            findFollowings.map(cur => {
                getFollowingIds.push(cur.following_id)
            })

            let myFOllowingIds = []
            for (i = 0; i < getFollowingIds.length; i++) {
                const findusers = await User(`SELECT * FROM users WHERE _id='${getFollowingIds[i]}'`)
                findusers.map(cur => {
                    myFOllowingIds.push(cur.id)
                })
            }

            user.following = myFOllowingIds.toString()
            console.log(user.following = myFOllowingIds.toString())



        

            res.render('allUsers', {
                user,
                users,
                // allUsers: users,
                // suggestedArr: newUserTOFollow,
                // posts: allPostsSuggestedPost,
                // notification,
                // chatNotification,
                // sentChatNotification,

            })
        } catch (error) {
            conosle.log(error)
            res.render('404Page')
        }
    })



    router.post('/follow-unfollow', auth, async (req, res) => {
        try {
            console.log(req.body)
            let data = {
                followingId: req.body.followingId,
                userId: req.user._id
            }

            let id = data.followingId;
            let userId = data.userId
            // @ if user tries to follow himself
            if (id == userId) return console.log('Cant follow urseld')

            async function SQLQUERY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${userId}'`)
            user = user[0]

            // Check if am following the user or not
            const findFOllowing = await SQLQUERY(`SELECT * FROM following WHERE owner='${userId}' AND following_id='${id}'`)
            if (findFOllowing.length == 0) {
                // Add to following
                const followingData = {
                    owner: userId,
                    following_id: id,
                    date: new Date().toLocaleDateString(),
                };

                let sql = 'INSERT INTO following SET ?'
                db.query(sql, followingData, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('Started following a new user')

                    // Creat a follower for the secind user
                    const followerForSecondUser = {
                        owner: userId,
                        follower_id: id,
                        date: new Date().toLocaleDateString(),
                    };
                    let sql3 = 'INSERT INTO follower SET ?'
                    db.query(sql3, followerForSecondUser, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                        console.log('Created a follower for myself')
                    })

                })

                async function notificationFunction() {
                    // Send notification    
                    let randomId = crypto.randomBytes(12).toString('hex')
                    const notification = {
                        owner: user._id,
                        _id: randomId,
                        text: 'Started following you',
                        eventOwner: data.followingId,
                        date: new Date(new Date().getTime()),
                        ownerName: `${user.firstname} ${user.lastname}`,
                        urlLink: 'profile/' + user._id,
                        readStatus: 'fa fa-question',
                        avatar: user.avatar,
                        comment: ''
                    }

                    let sql = 'INSERT INTO notification SET ?'
                    db.query(sql, notification, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                        // console.log('Created a new Nitification')
                    })


                    let findNotifcationOwner = await SQLQUERY(`SELECT * FROM users WHERE _id='${data.followingId}'`)
                    let eventOwner = findNotifcationOwner[0]
                    if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                        let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${data.followingId}'`
                        db.query(sql, (error) => {
                            if (error) return console.log(error)
                        })
                        return
                    } else {
                        let count = parseInt(eventOwner.notifiicationLength)
                        count = count += 1
                        let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${data.followingId}'`
                        db.query(sqlQueryForCOunt, (error) => {
                            if (error) return console.log(error)
                        })
                    }

                }
                notificationFunction()

                return
            }

            // remove  following if found

            let sqldelete = `DELETE FROM following WHERE owner='${userId}' AND following_id='${id}'`
            db.query(sqldelete, (error, result) => {
                if (error) {
                    return console.log(error)
                }
                console.log('Deleted successful')
            })

            let sqldelete2 = `DELETE FROM follower WHERE owner='${userId}' AND follower_id='${id}'`
            db.query(sqldelete2, (error, result) => {
                if (error) {
                    return console.log(error)
                }
                console.log('Deleted successful')
            })


            res.send('succss')
        } catch (error) {
            console.log(error)
        }
    })

    /*
        io.on('connection', (socket) => {
            socket.on('followingDetails', async (data) => {
    
                let id = data.followingId;
                let userId = data.userId
                // @ if user tries to follow himself
                if (id == userId) return console.log('Cant follow urseld')
    
                async function SQLQUERY(val) {
                    return new Promise((resolve, reject) => {
                        let sql = val
                        db.query(sql, (error, result) => {
                            if (error) {
                                return console.log(error)
                            }
                            resolve(result)
                        })
                    })
                }
    
                let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${userId}'`)
                user = user[0]
                
                // Check if am following the user or not
                const findFOllowing = await SQLQUERY(`SELECT * FROM following WHERE owner='${userId}' AND following_id='${id}'`)
                console.log(findFOllowing)
                if (findFOllowing.length == 0) {
                    // Add to following
                    const followingData = {
                        owner: userId,
                        following_id: id,
                        date: new Date().toLocaleDateString(),
                    };
    
                    let sql = 'INSERT INTO following SET ?'
                    db.query(sql, followingData, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                        console.log('Started following a new user')
    
                        // Creat a follower for the secind user
                        const followerForSecondUser = {
                            owner: userId,
                            follower_id: id,
                            date: new Date().toLocaleDateString(),
                        };
                        let sql3 = 'INSERT INTO follower SET ?'
                        db.query(sql3, followerForSecondUser, (error) => {
                            if (error) {
                                return console.log(error)
                            }
                            console.log('Created a follower for myself')
                        })
    
                    })
    
                    async function notificationFunction() {
                        // Send notification    
                        let randomId = crypto.randomBytes(12).toString('hex')
                        const notification = {
                            owner: user._id,
                            _id: randomId,
                            text: 'Started following you',
                            eventOwner: data.followingId,
                            date: new Date(new Date().getTime()),
                            ownerName: `${user.firstname} ${user.lastname}`,
                            urlLink: 'profile/' + user._id,
                            readStatus: 'fa fa-question',
                            avatar: user.avatar,
                            comment: ''
                        }
    
                        let sql = 'INSERT INTO notification SET ?'
                        db.query(sql, notification, (error) => {
                            if (error) {
                                return console.log(error)
                            }
                            // console.log('Created a new Nitification')
                        })
    
    
                        let findNotifcationOwner = await SQLQUERY(`SELECT * FROM users WHERE _id='${data.followingId}'`)
                        let eventOwner = findNotifcationOwner[0]
                        if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                            let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${data.followingId}'`
                            db.query(sql, (error) => {
                                if (error) return console.log(error)
                            })
                            return
                        } else {
                            let count = parseInt(eventOwner.notifiicationLength)
                            count = count += 1
                            let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${data.followingId}'`
                            db.query(sqlQueryForCOunt, (error) => {
                                if (error) return console.log(error)
                            })
                        }
    
                    }
                    notificationFunction()
    
                    return
                }
    
                // remove  following if found
    
                let sqldelete = `DELETE FROM following WHERE owner='${userId}' AND following_id='${id}'`
                db.query(sqldelete, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('Deleted successful')
                })
    
                let sqldelete2 = `DELETE FROM follower WHERE owner='${userId}' AND follower_id='${id}'`
                db.query(sqldelete2, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('Deleted successful')
                })
    
    
    
    
            })
        })
    
    */


    router.get('/allusers-api', auth, async (req, res) => {
        try {

            async function SQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const allUsers = await SQL(`SELECT * FROM users`)
            // const user = allUsers[0]

            allUser = allUsers.sort(() => Math.random() - 0.5)

            // remover binary data
            let newAllUsersArray = []
            allUsers.forEach(async cur => {
                if (cur.bestSentence == null) {
                    cur.bestSentence = 'Plogapp user'
                }

                if (cur.followerLength == null) {
                    cur.followerLength = 0
                }

                cur.bestSentence = cur.bestSentence.substr(0, 50)


                cur.coverPhoto = undefined
                cur.storyImg = undefined
                cur.password = undefined
                cur.hasStory = undefined
                cur.gender = undefined
                cur.phoneNumber = undefined
                cur.email = undefined
                cur.date = undefined
                cur.genderDescription = undefined
                cur.month = undefined
                cur.month = undefined
                cur.year = undefined
                cur.activeStatus = undefined
                cur.greenActive = undefined
                cur.notifiicationLength = undefined
                cur.createdAt = undefined
                cur.token = undefined
                cur.updatedAt = undefined
                cur.hideWelcomeMsg = undefined
                cur.chatNotification = undefined
                newAllUsersArray.push(cur)
            })


            // res.send(newAllUsersArray)

            if (myCache.has("all-users")) {
                console.log('fetching from cached')
                return res.send(myCache.get("all-users"))
            } else {            
                let jsonFIle = JSON.stringify(newAllUsersArray)
                myCache.set("all-users", jsonFIle)
                console.log('fetcing fromapi')
                res.send(jsonFIle)
            }

        } catch (error) {
            console.log('error')
        }
    })


    // Firnds
    // @ When both users follow them selves
    router.get('/friends_api', auth, async (req, res) => {
        try {
            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            let users = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = users[0]


            let findFollowings = await User(`SELECT * FROM following WHERE owner='${req.user._id}'`)
            let followingUniqueId = []
            findFollowings.map(cur => {
                followingUniqueId.push(cur.following_id)
            })

            // console.log(followingUniqueId)

            let users_i_followed = []
            for (i = 0; i < followingUniqueId.length; i++) {
                let findusers = await User(`SELECT * FROM users WHERE _id='${followingUniqueId[i]}' ORDER BY id DESC`)
                findusers.forEach(val => {
                    users_i_followed.push(val)
                })
            }


            // Find users that follwed me and I follwed too 
            // @FOund friends

            let foundFriends = []
            for (i = 0; i < users_i_followed.length; i++) {
                let findFollowers = await User(`SELECT * FROM follower WHERE follower_id='${req.user._id}' AND owner='${users_i_followed[i]._id}'`)
                findFollowers.forEach(val => {
                    foundFriends.push(val.owner)
                })
            }


            let fetchedUsersForFrineds = []
            for (i = 0; i < foundFriends.length; i++) {
                let findusers = await User(`SELECT * FROM users WHERE _id='${foundFriends[i]}' ORDER BY id DESC`)
                findusers.forEach(val => {
                    fetchedUsersForFrineds.push(val)
                })
            }

            // res.send(fetchedUsersForFrineds)

            if (myCache.has("my-friends")) {
                console.log('fetching from cached')
                return res.send(myCache.get("my-friends"))
            } else {            
                let jsonFIle = JSON.stringify(fetchedUsersForFrineds)
                myCache.set("my-friends", jsonFIle)
                console.log('fetcing fromapi')
                res.send(jsonFIle)
            }


        } catch (error) {
            console.log(error)
        }

    })



    return router
}