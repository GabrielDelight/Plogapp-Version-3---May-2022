const router = require('express').Router();
const multer = require('multer')
const auth = require('./auth')
const mysql = require('mysql');
const crypto = require('crypto')
const { db } = require('./db') //Database

router.get('/profile', auth,  async (req, res) => {
    res.redirect('/profile/' + req.user._id)
})

router.get('/profile/:id', auth,  async (req, res) => {
    try {
        async function POST(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        const userSQL = await POST(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        const user = userSQL[0]


        let paramsuUser = []
        let findUserById = await POST(`SELECT * FROM users WHERE _id='${req.params.id}'`)
        if (findUserById.length !== 0) {
            paramsuUser.push(findUserById[0])
        }

        if (paramsuUser.length == 0) {
            let findUserBynickname = await POST(`SELECT * FROM users WHERE fullName='${req.params.id}'`)
            if(findUserBynickname.length == 0){
                return res.render('404Page')
            }
            paramsuUser.push(findUserBynickname[0])
        }


        let findFollowings = await POST(`SELECT * FROM following WHERE owner='${req.params.id}'`)
        // console.log(followingUniqyeId)

        let following = []
        let followingUniqueId = []
        findFollowings.map(cur => {
            following.push(cur.following_id)
            followingUniqueId.push(cur.id)
        })
        let followingUniqyeId = []
        
        // @ get user following
        let newFollowingsArr = []
        for (i = 0; i < following.length; i++) {
            const findusers = await POST(`SELECT * FROM users WHERE _id='${following[i]}' ORDER BY id DESC`)
            findusers.forEach(val => {
                newFollowingsArr.push(val)
                followingUniqyeId.push(val.id)
            })
        }


        
    
        // Get user follower ids
        let newFollowersArr = []
        let findFollowers = await POST(`SELECT * FROM follower WHERE follower_id='${req.params.id}'`)
        let followers = []
        let followersUniqueId = []
        findFollowers.map(cur => {
            followers.push(cur.owner)
            followersUniqueId.push(cur.id)
        })
        

        // @ get user followers
        let paramUserFollowrsIds = []
        for (i = 0; i < followers.length; i++) {
            const findusers = await POST(`SELECT * FROM users WHERE _id='${followers[i]}' ORDER BY id DESC`)
            findusers.forEach(val => {
                newFollowersArr.push(val)
                paramUserFollowrsIds.push(val.id)
            })
        }

        paramsuUser.follower = paramUserFollowrsIds.toString()
        


        // @ get post likes
        const postLength = await POST(`SELECT * FROM posts WHERE owner='${req.params.id}'`)
        const sharePostLength = await POST(`SELECT * FROM sharepost WHERE owner='${req.params.id}'`)
        let postLikes = []
        if (postLength.length > 0) {
            postLength.forEach(cur => {
                if (cur.reactionLength != null) {
                    postLikes.push(cur.reactionLength)
                }
            })
        }

        if (sharePostLength.length > 0) {
            sharePostLength.forEach(cur => {
                if (cur.reactionLength != null) {
                    postLikes.push(cur.reactionLength)
                }
            })
        }
        if (postLikes.length == 0) postLikes = [0]
        postLikes = postLikes.map(val => parseInt(val)).reduce((a, b) => a + b)



        // @ Get all the params user comment
        let allComment = await POST(`SELECT * FROM comments WHERE owner='${req.params.id}' ORDER BY id DESC`)
        allComment = allComment.splice(0, 10)

        res.render('profile', {
            user,            
            paramsuUser: paramsuUser[0],
            paramsFollowers: paramsuUser.follower, 
            mainUser: user,
            // profileFOllowers: followersUniqueId,
            postLength: postLength.length + sharePostLength.length,
            totalLikes: postLikes,
            paramsComment: allComment,
            // suggestedArr: newUserTOFollow,
            // posts: allPostsSuggestedPost,
            followingLength: followingUniqyeId.length,
            followerLength: newFollowersArr.length,
        })

    } catch (error) {
        console.log(error)
        res.render('404Page')
    }

})

module.exports = router