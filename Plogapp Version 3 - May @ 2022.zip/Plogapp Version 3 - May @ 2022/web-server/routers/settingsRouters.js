const router = require('express').Router()
// const User = require('../models/model');
const path = require('path');
const auth = require('./auth');
const multer = require('multer');
const mysql = require('mysql');
const crypto = require('crypto')
const fs = require('fs')
const util = require('util')
const sanitizeHtml = require('sanitize-html');

const unlineLinkFIle = util.promisify(fs.unlink)

const { uploadFile, getFileStream } = require('./s3')


const { db } = require('./db') //Database



let monthsArray;
let month;
let newMonth;
let day = new Date().getDay();
let year = new Date().getFullYear();
let time = new Date().toLocaleTimeString();
monthsArray = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
month = new Date().getMonth();
newMonth = monthsArray[month];
let fullDateStr = ` ${day} ${newMonth},  ${year}`


// @ set up validation for image upload
const storageCoverPhoto = multer.diskStorage({
    destination: './web-server/web-folder/public/webStorage/coverPhoto',
    filename: function (req, file, cb) {
        cb(null, 'plogapp' + Date.now() + path.extname(file.originalname))
    }
})
const uploadCover = multer({
    // limits: 300000,
    storage: storageCoverPhoto
})

router.get('/readme', auth, async (req, res) => {
    const user = await User.findById(req.user)
    res.render('settings/readme', {
        user: user
    })
})




// Upload image route

router.get('/myphoto', auth, async (req, res) => {
    const user = await User.findById(req.user)
    res.render('settings/myphoto', {
        user: user
    })
})



// Uploadfing avatar
const avatarStorage = multer.diskStorage({
    destination: './web-server/web-folder/public/webStorage/avatar',
    filename: function (req, file, cb) {
        cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
    }
})
const avatarUpload = multer({
    // limits: 300000,
    storage: avatarStorage
})


// view avatar
router.get('/webStorage/avatar/:key', auth, async (req, res) => {
    try {

        let key = req.params.key

        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const userSQL = await User(`SELECT * FROM users WHERE avatar='${key}'`)
        const user = userSQL[0]
        if (userSQL.length == 0 || user.avatar == '') {
            const readStream = getFileStream('avatar.png')
            readStream.pipe(res)
            return
        }

        const readStream = getFileStream(user.avatar)
        readStream.pipe(res)


    } catch (error) {
        console.log('Error', error.message)
    }
})


router.post('/myphoto', auth, avatarUpload.single('uploads'), async (req, res) => {
    try {
        async function SQL(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        let file = req.file
        await uploadFile(file)
        await unlineLinkFIle(file.path)
        const userSQL = await SQL(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        const user = userSQL[0]

        function sanitizeString(text) {
            return sanitizeHtml(text, {
                allowedTags: [],
                allowedAttributes: {}
            });
        }


        let sql = `UPDATE users SET avatar='${sanitizeString(req.file.filename)}' WHERE _id='${user._id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })


        let sqlForPost = `UPDATE posts SET avatar='${sanitizeString(req.file.filename)}' WHERE owner='${user._id}'`
        db.query(sqlForPost, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        let alluserPostShared = `UPDATE sharePost SET avatar='${sanitizeString(req.file.filename)}' WHERE owner='${user._id}'`
        db.query(alluserPostShared, (error) => {
            if (error) {
                return console.log(error)
            }
        })


        let allUserComments = `UPDATE comments SET avatar='${sanitizeString(req.file.filename)}' WHERE owner='${user._id}'`
        db.query(allUserComments, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        let alluserReplies = `UPDATE replies SET avatar='${sanitizeString(req.file.filename)}' WHERE owner='${user._id}'`
        db.query(alluserReplies, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        res.redirect('/profile/' + user._id)

    } catch (error) {
        console.log(error.message)
    }
}, async (error, req, res, next) => {
    const user = await User.findById(req.user)

    res.render('settings/myphoto', {
        user,
        error: error.message
    })
})





router.get('/webStorage/coverPhoto/:key', auth, async (req, res) => {
    try {

        let key = req.params.key

        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const userSQL = await User(`SELECT * FROM users WHERE coverPhoto='${key}'`)
        const user = userSQL[0]
        if (userSQL.length == 0) {
            let coverPhoto = ''
            let random = Math.floor(Math.random() * 100)
            if (random <= 40) coverPhoto = 'coverphoto3.jpg'
            if (random > 40 && random < 60) coverPhoto = 'coverphoto1.jpg'
            if (random > 60) coverPhoto = 'coverphoto2.jpg'

            const readStream = getFileStream(coverPhoto)
            readStream.pipe(res)
            return
        }

        const readStream = getFileStream(user.coverPhoto)
        readStream.pipe(res)


    } catch (error) {
        console.log('Error', error.message)
    }
})


router.post('/coverPhoto', uploadCover.single('uploads'), auth, async (req, res) => {
    try {
        const file = req.file
        await uploadFile(file)
        await unlineLinkFIle(file.path)
        let sql = `UPDATE users SET coverPhoto='${req.file.filename}' WHERE _id='${req.user._id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        res.redirect('/profile/' + req.user._id)

    } catch (error) {
        console.log(error.message)
        res.redirect('/profile/' + user._id)
    }
}, (error, req, res, next) => {
    res.redirect('/profile/' + req.user._id)
})



//=========================================================
router.get('/mobileNav', auth, async (req, res) => {
    async function SQL(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    const userSQL = await SQL(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    const user = userSQL[0]

    res.render('mobileNavs-min', {
        user,
    })
})

// Updatng profile in plogapp
// Saving  on plogaapp
router.get('/profile_ease_edit', auth, async (req, res) => {
    async function SQL(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    const userSQL = await SQL(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    const user = userSQL[0]

    // if (user.interests == '' &&
    //     user.country == '' &&
    //     user.currentCity == '' &&
    //     user.phoneNumber == '' &&
    //     user.bestSentence == '' &&
    //     user.homeTown == '') {
    //     return res.send({
    //         updateProfile: 'all'
    //     })
    // }

    if (user.interests == '') {
        return res.send({
            updateProfile: 'interests'
        })
    }


    if (user.country == '') {
        return res.send({
            updateProfile: 'country'
        })
    }

    if (user.phoneNumber == '') {
        return res.send({
            updateProfile: 'phone'
        })
    }

    if (user.bestSentence == '') {
        return res.send({
            updateProfile: 'bio'
        })
    }

  

    if (user.interests !== '' &&
        user.country !== '' &&
        user.currentCity !== '' &&
        user.phoneNumber !== '' &&
        user.bestSentence !== '' &&
        user.homeTown !== '') {
        return res.send({
            noUpdate: 'none'
        })
    }


})


router.post('/update_country', auth, async (req, res) => {
    try {
        function sanitizeString(text) {
            return sanitizeHtml(text, {
                allowedTags: [],
                allowedAttributes: {}
            });
        }

        let sql = `UPDATE users SET country='${sanitizeString(req.body.country)}',city='${sanitizeString(req.body.city)}',town='${sanitizeString(req.body.town)}'  WHERE _id='${req.user._id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }

            res.send({
                success: 'Good'
            })
        })

    } catch (error) {
        res.send({
            error: 'Something went wrong'
        })
        console.log(error)
    }
})



// Add fone number 
router.post('/update_phone_number', auth, async (req, res) => {
    try {
        function sanitizeString(text) {
            return sanitizeHtml(text, {
                allowedTags: [],
                allowedAttributes: {}
            });
        }
        let sql = `UPDATE users SET phoneNumber='${sanitizeString(req.body.phone)}'  WHERE _id='${req.user._id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }

            res.send({
                success: 'Good'
            })
        })

    } catch (error) {
        res.send({
            error: 'Something went wrong'
        })
        console.log(error)
    }
})


// Updating bio
router.post('/update_bio_api', auth, async (req, res) => {
    console.log('Hey')
    try {

        function sanitizeString(text) {
            return sanitizeHtml(text, {
                allowedTags: [],
                allowedAttributes: {}
            });
        }

        let sql = `UPDATE users SET bestSentence='${sanitizeString(req.body.bio)}'  WHERE _id='${req.user._id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }

            res.send({
                success: 'Good'
            })
        })

    } catch (error) {
        res.send({
            error: 'Something went wrong'
        })
        console.log(error)
    }
})

// Update interests
router.post('/update_user_interests', auth, async (req, res) => {
    try {
        let sql = `UPDATE users SET interests='${req.body.interests}'  WHERE _id='${req.user._id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }

            res.send({
                success: 'Good'
            })
        })

    } catch (error) {
        res.send({
            error: 'Something went wrong'
        })
        console.log(error)
    }
})






module.exports = router