const router = require('express').Router();
const multer = require('multer')
const auth = require('./auth')
const mysql = require('mysql');
const crypto = require('crypto')
const dayjs = require('dayjs')
var relativeTime = require('dayjs/plugin/relativeTime')
dayjs.extend(relativeTime)
const { db } = require('./db') //Database
const { registerLimitter } = require('./expressEmitterDDos')
const NodeCache = require('node-cache');
const myCache = new NodeCache({ stdTTL: 30 })


router.get('/profile_api/:id', auth,  async (req, res) => {
    try {

        async function POST(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        const userSQL = await POST(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        const user = userSQL[0]


        const textPost = await POST(`SELECT * FROM posts WHERE postType='text' AND owner='${req.params.id}'`)
        const photoPost = await POST(`SELECT * FROM posts WHERE postType='image' AND owner='${req.params.id}'`)
        const videoPost = await POST(`SELECT * FROM posts WHERE postType='video'AND owner='${req.params.id}'`)
        const sharedPostText = await POST(`SELECT * FROM sharepost WHERE postType='sharetext'AND owner='${req.params.id}'`)
        const sharedPostImage = await POST(`SELECT * FROM sharepost WHERE postType='shareimage'AND owner='${req.params.id}'`)
        const sharedPostVideo = await POST(`SELECT * FROM sharepost WHERE postType='sharevideo'AND owner='${req.params.id}'`)

        const paramsuUser = await POST(`SELECT * FROM users WHERE _id='${req.params.id}'`)


        // @ get post likes
        const postLength = await POST(`SELECT * FROM posts WHERE owner='${req.params.id}'`)
        const sharePostLength = await POST(`SELECT * FROM sharepost WHERE owner='${req.params.id}'`)
        let postLikes = []
        if (postLength.length > 0) {
            postLength.forEach(cur => {
                if (cur.reactionLength != null) {
                    postLikes.push(cur.reactionLength)
                }
            })
        }

        if (sharePostLength.length > 0) {
            sharePostLength.forEach(cur => {
                if (cur.reactionLength != null) {
                    postLikes.push(cur.reactionLength)
                }
            })
        }
        if (postLikes.length == 0) postLikes = [0]
        postLikes = postLikes.map(val => parseInt(val)).reduce((a, b) => a + b)



        // @ Get all the params user comment
        const allComment = await POST(`SELECT * FROM comments WHERE owner='${req.params.id}'`)


        //@ Create suggestion fot user to follow____________________
        const allUsers = await POST(`SELECT * FROM users`)
        let myFolloingArr = user.following + user.id
        let notFollowingIdsArray = []
        for (i = 0; i < allUsers.length; i++) {
            if (!myFolloingArr.includes(allUsers[i].id)) {
                notFollowingIdsArray.push(allUsers[i].id)
            }
        }

        let newUserTOFollow = []
        for (i = 0; i < notFollowingIdsArray.length; i++) {
            const fetchUsersToFollow = await POST(`SELECT * FROM users WHERE id='${notFollowingIdsArray[i]}'`)
            fetchUsersToFollow.forEach(val => {
                newUserTOFollow.push(val)
            })
        }

        newUserTOFollow = newUserTOFollow.sort(() => Math.random() - 0.5)
        newUserTOFollow = newUserTOFollow.splice(0, 4)
        // @_______________________________________________________

        // @ get four (4) post 
        let allPostsSuggestedPost = await POST(`SELECT * FROM posts WHERE postType='image'`)
        allPostsSuggestedPost = allPostsSuggestedPost.sort(() => Math.random() - 0.5)
        allPostsSuggestedPost = allPostsSuggestedPost.splice(0, 2)



        let arr = []
        textPost.forEach(cur => {
            arr.push(cur)
        })

        photoPost.forEach(cur => {
            arr.push(cur)
        })

        videoPost.forEach(cur => {
            arr.push(cur)
        })

        sharedPostText.forEach(cur => {
            arr.push(cur)
        })

        sharedPostImage.forEach(cur => {
            arr.push(cur)
        })
        sharedPostVideo.forEach(cur => {
            arr.push(cur)
        })



        // arr = arr.sort(() => Math.random() - 0.5)
        // arr = arr.sort(() => Math.random() - 0.5)

        let postsData = arr.sort((a, b) => {
            let c = new Date(a.sortDate)
            let d = new Date(b.sortDate)
            return d - c
        })
        postsData.map(cur => cur.date = dayjs().to(cur.date))
        res.send(postsData)

        // if (myCache.has("profile-posts")) {
        //     return res.send(myCache.get("profile-posts"))
        // } else {            
        //     let jsonFIle = JSON.stringify(postsData)
        //     myCache.set("profile-posts", jsonFIle)
        //     res.send(jsonFIle)
        // }



    } catch (error) {
        console.log(error)
        // res.render('404Page')
    }

})

module.exports = router

