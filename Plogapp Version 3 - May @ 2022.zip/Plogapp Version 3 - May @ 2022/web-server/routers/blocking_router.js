const router = require('express').Router()
const auth = require('./auth');
const mysql = require('mysql');
const crypto = require('crypto')
const { db } = require('./db') //Datbase



// first blocking router
router.get('/blocking_rout/:ownerId/:blockingId/', async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    console.log(error)
                    return
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE id='${req.params.ownerId}'`)
    let findDeleted = await SQLQUERY(`SELECT * FROM blocked_accouts WHERE owner_id='${req.params.ownerId}' AND blocked_ids='${req.params.blockingId}'`)



    if (findDeleted.length == 0) {
        let data = {
            owner_id: req.params.ownerId,
            blocked_ids: req.params.blockingId
        }

        // console.log(data)

        let sql = 'INSERT INTO blocked_accouts SET ?'
        db.query(sql, data, (error) => {
            if (error) {
                return console.log(error)
            }
            console.log('Recently blocked a user')
        })

        return res.send({
            message: 'blocked'
        })
    }

    let sqlDelQuery = `DELETE FROM blocked_accouts WHERE owner_id='${req.params.ownerId}' AND blocked_ids='${req.params.blockingId}'`
    db.query(sqlDelQuery, (error) => {
        if (error) {
            return console.log(error)
        }
        console.log('unblocked')
    })

    res.send({
        message: 'unblocked'
    })
})


router.get('/show_blocked_users/:ownerId/:blockingId', async (req, res) => {
    // console.log('Hello')
    // console.log(req.params)

    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    console.log(error)
                    return
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE id='${req.params.ownerId}'`)
    let findDeleted = await SQLQUERY(`SELECT * FROM blocked_accouts WHERE owner_id='${req.params.ownerId}' AND blocked_ids='${req.params.blockingId}'`)
    // console.log(findDeleted)
    if (findDeleted.length > 0) {
        return res.send({
            foundBlocked: findDeleted
        })
    }
    res.send({
        not_blocked: 'Not blocked'
    })
})


// ROuter to check if a user blocked me
router.get('/if_user_is_blocked/:ownerId/:blockingId', async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    console.log(error)
                    return
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE id='${req.params.ownerId}'`)
    let findBlocked = await SQLQUERY(`SELECT * FROM blocked_accouts WHERE owner_id='${req.params.blockingId}' AND blocked_ids='${req.params.ownerId}'`)
    // console.log(findBlocked)

    if (findBlocked.length > 0) {
        return res.send({
            foundBlocked: findBlocked
        })
    }
    res.send({
        not_blocked: 'Not blocked'
    })
})


// On blocked 
// @ checkif I block the user
router.get('/profile_blocked/:profileId', auth, async (req, res) => {
    // console.log(req.params)
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    console.log(error)
                    return
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE id='${req.params.ownerId}'`)
    let findBlocked = await SQLQUERY(`SELECT * FROM blocked_accouts WHERE owner_id='${req.user._id}' AND blocked_ids='${req.params.profileId}'`)
    // console.log(findBlocked)

    if (findBlocked.length > 0) {
        return res.send({
            foundBlocked: findBlocked
        })
    }
    res.send({
        not_blocked: 'Not blocked'
    })
})

// check if the use blocked me from his profile
// @ checkif I block the user
router.get('/profile_blocked_two/:ownerId/:profileId', async (req, res) => {
    // console.log(req.params)
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    console.log(error)
                    return
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE id='${req.params.ownerId}'`)
    let findBlocked = await SQLQUERY(`SELECT * FROM blocked_accouts WHERE owner_id='${req.params.profileId}' AND blocked_ids='${req.params.ownerId}'`)
    // console.log(findBlocked)

    if (findBlocked.length > 0) {
        return res.send({
            foundBlocked: findBlocked
        })
    }
    res.send({
        not_blocked: 'Not blocked'
    })
})


router.get('/fetch_blocked_users/:id', async (req, res) => {

    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    console.log(error)
                    return
                }
                resolve(result)
            })
        })
    }

    // let user = await SQLQUERY(`SELECT * FROM users WHERE id='${req.params.ownerId}'`)
    let findDeleted = await SQLQUERY(`SELECT * FROM blocked_accouts WHERE owner_id='${req.params.id}'`)
    // console.log(findDeleted)
    let blockedIdsArr = []
    findDeleted.map(cur => {
        blockedIdsArr.push(cur.blocked_ids)
    })

    let fetched_blocked_users = []
    for (i = 0; i < blockedIdsArr.length; i++) {
        let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${blockedIdsArr[i]}'`)
        user.map(cur => {
            fetched_blocked_users.push(cur)
        })
    }

    res.send(fetched_blocked_users)
    


})


module.exports = router
