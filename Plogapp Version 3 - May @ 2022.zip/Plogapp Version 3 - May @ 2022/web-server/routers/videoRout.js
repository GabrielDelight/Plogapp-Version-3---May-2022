const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken')
const auth = require('./auth')
const multer = require('multer');
const path = require('path');
const mysql = require('mysql');
const crypto = require('crypto')
const nodemailer = require('nodemailer');
const dayjs = require('dayjs')
var relativeTime = require('dayjs/plugin/relativeTime')
dayjs.extend(relativeTime)


const { db } = require('./db')
const { registerLimitter } = require('./expressEmitterDDos')
// const express = require('express')
// const app = express()
// app.use(registerLimitter)

router.get('/plogapp-watch', auth, async (req, res) => {
    async function User(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    const userSQL = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    if (userSQL.length == 0) return res.redirect('/login')
    const user = userSQL[0]

    let allPostsSuggestedPost = await User(`SELECT * FROM posts WHERE postType='image'`)
    allPostsSuggestedPost = allPostsSuggestedPost.sort(() => Math.random() - 0.5)
    allPostsSuggestedPost = allPostsSuggestedPost.splice(0, 2)

    allPostsSuggestedPost.map(cur => {
        cur.description = cur.description.toString().substr(0, 50)
    })

    res.render('videos', {
        user: user,
        posts: allPostsSuggestedPost,
    })
})



router.get('/fetching-video', auth,  async (req, res) => {
    try {
        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const userSQL = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        if (userSQL.length == 0) return res.redirect('/login')
        const user = userSQL[0]

        // SET the disabling of user to false
        let sql = `UPDATE users SET isDisabled='${false}' WHERE _id='${user._id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })


        // Get all users
        async function AllUsers(val) {
            return new Promise((resolve, reject) => {
                let sql = `SELECT * FROM users`
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const allUser = await AllUsers(req.user._id)
        const suggestedFollowers = await AllUsers(req.user._id)

        async function POST(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        // Get this user following ids to fix for the user.following 
        // @ 
        let getFollowingIds = []
        let findFollowings = await User(`SELECT * FROM following WHERE owner='${req.user._id}'`)
        findFollowings.map(cur => {
            getFollowingIds.push(cur.following_id)
        })

        let myFOllowingIds = []
        for (i = 0; i < getFollowingIds.length; i++) {
            const findusers = await User(`SELECT * FROM users WHERE _id='${getFollowingIds[i]}'`)
            findusers.map(cur => {
                myFOllowingIds.push(cur.id)
            })
        }

        user.following = myFOllowingIds.toString()


        let followingIds = user.following.split(',').map(val => parseInt(val))
        // @ add use id to follower id 
        followingIds.push(user.id)


        let postText = []
        let postPhoto = []
        let postVideo = []
        for (i = 0; i < followingIds.length; i++) {
            // For post text
            const followingPostText = await POST(`SELECT * FROM posts WHERE postType='text' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostText.forEach(val => {
                postText.push(val)
            })

            // For post image
            const followingPostImage = await POST(`SELECT * FROM posts WHERE postType='image' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostImage.forEach(val => {
                postPhoto.push(val)
            })

            // @ get post video
            const followingPostVideo = await POST(`SELECT * FROM posts WHERE postType='video' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostVideo.forEach(val => {
                postVideo.push(val)
            })
        }


        // @ get shared post from following
        let sharePostText = []
        let sharePostPhoto = []
        let sharePostVideo = []
        for (i = 0; i < followingIds.length; i++) {
            // For post text
            const followingPostTextSharePost = await POST(`SELECT * FROM sharepost WHERE postType='sharetext' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostTextSharePost.forEach(val => {
                sharePostText.push(val)
            })

            // For post image
            const followingPostImageSharePos = await POST(`SELECT * FROM sharepost WHERE postType='shareimage' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostImageSharePos.forEach(val => {
                sharePostPhoto.push(val)
            })

            // @ get post video
            const followingPostVideo = await POST(`SELECT * FROM sharepost WHERE postType='sharevideo' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostVideo.forEach(val => {
                sharePostVideo.push(val)
            })

        }

        let followingStories = []
        // Get stories from followrs         
        let followingStoriesIds = user.following.split(',').map(val => parseInt(val))
        for (i = 0; i < followingStoriesIds.length; i++) {
            const userWithStory = await POST(`SELECT * FROM users WHERE hasStory='true' AND id='${followingStoriesIds[i]}'`)
            userWithStory.forEach(val => {
                followingStories.push(val)
            })
        }

        // @ current user storirs
        const getUserStory = await POST(`SELECT * FROM users WHERE hasStory='true' AND _id='${user._id}'`)


        // Hide alert for posting or not
        // Hide alert for posting or not
        let hideEnptryPostDiv = 'none'
        if (
            postText.length < 1 &&
            postPhoto < 1 &&
            postVideo < 1 &&
            sharePostText < 1 &&
            sharePostPhoto < 1 &&
            sharePostVideo < 1
        ) {
            hideEnptryPostDiv = 'block'
        }



        //@ Create suggestion fot user to follow____________________
        const allUsers = await POST(`SELECT * FROM users`)
        let myFolloingArr = user.following + user.id
        let notFollowingIdsArray = []
        for (i = 0; i < allUsers.length; i++) {
            if (!myFolloingArr.includes(allUsers[i].id)) {
                notFollowingIdsArray.push(allUsers[i].id)
            }
        }

        let newUserTOFollow = []
        for (i = 0; i < notFollowingIdsArray.length; i++) {
            const fetchUsersToFollow = await POST(`SELECT * FROM users WHERE id='${notFollowingIdsArray[i]}'`)
            fetchUsersToFollow.forEach(val => {
                newUserTOFollow.push(val)
            })
        }

        newUserTOFollow = newUserTOFollow.sort(() => Math.random() - 0.5)
        newUserTOFollow = newUserTOFollow.splice(0, 4)
        // @_______________________________________________________

        // @ get four (4) post 
        let allPostsSuggestedPost = await POST(`SELECT * FROM posts WHERE postType='image'`)
        allPostsSuggestedPost = allPostsSuggestedPost.sort(() => Math.random() - 0.5)
        allPostsSuggestedPost = allPostsSuggestedPost.splice(0, 2)




        let arr = []
        postVideo.forEach(cur => {
            arr.push(cur)
        })
        sharePostVideo.forEach(cur => {
            arr.push(cur)
        })


        // arr = arr.sort(() => Math.random() - 0.5)
        arr = arr.sort(() => Math.random() - 0.5)
        arr.map(cur => cur.date = dayjs().to(cur.date))
        res.send(arr)

    } catch (error) {
        console.log(error)
    }

})

router.get('/user_api/:id', auth, async (req, res) => {
    try {
        async function SQLQUERY(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const userSQL = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.params.id}'`)
        const user = userSQL[0]
        user.password = undefined




        let paramsuUser = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.params.id}'`)
        let findFollowings = await SQLQUERY(`SELECT * FROM following WHERE owner='${req.user._id}'`)
        let following = []
        let followingUniqueId = []
        findFollowings.map(cur => {
            following.push(cur.following_id)
            followingUniqueId.push(cur.id)
        })
        // console.log(following)
        let followingUniqyeId = []

        // @ get user following
        let newFollowingsArr = []
        for (i = 0; i < following.length; i++) {
            const findusers = await SQLQUERY(`SELECT * FROM users WHERE _id='${following[i]}' ORDER BY id DESC`)
            findusers.forEach(val => {
                newFollowingsArr.push(val)
                followingUniqyeId.push(val.id)
            })
        }



        // Get user follower ids
        let newFollowersArr = []

        let findFollowers = await SQLQUERY(`SELECT * FROM follower WHERE follower_id='${req.params.id}'`)
        let followers = []
        let followersUniqueId = []
        findFollowers.map(cur => {
            followers.push(cur.owner)
            followersUniqueId.push(cur.id)
        })


        // @ get user followers
        for (i = 0; i < followers.length; i++) {
            const findusers = await SQLQUERY(`SELECT * FROM users WHERE _id='${followers[i]}' ORDER BY id DESC`)
            findusers.forEach(val => {
                newFollowersArr.push(val)
            })
        }


        res.send({
            user: user,
            follower: followers.length,
            following: followingUniqyeId.length
        })
    } catch (error) {
        console.log(error)
    }
})


// @ creating vides on video
router.post('/create-video-views', auth, async (req, res) => {
    try {
        async function SQLQUERY(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        // @ Find the particular video
        let video
        let find_video = await SQLQUERY(`SELECT * FROM posts WHERE _id='${req.body.videoId}'`)
        video = find_video[0]
        if (find_video.length < 1) {
            let share_video = await SQLQUERY(`SELECT * FROM sharepost WHERE _id='${req.body.videoId}'`)
            if (share_video.length > 0){
                video = share_video[0]
            }
        }



        // console.log(video)

        let video_views = await SQLQUERY(`SELECT * FROM video_views WHERE videoId='${req.body.videoId}' AND owner='${req.user._id}'`)
        // @ Check if video already exist
        if (video_views.length > 0) return


        const views = {
            videoId: req.body.videoId,
            owner: req.user._id,
            _id: crypto.randomBytes(12).toString('hex'),
            video_owner: video.owner
        }

        // console.log(views)
        let sql2 = 'INSERT INTO video_views SET ?'
        db.query(sql2, views, async (error) => {
            if (error) {
                return console.log(error)
            }
            let allVideoViews = await SQLQUERY(`SELECT * FROM video_views WHERE  videoId='${req.body.videoId}'`)

            let dbtable = 'posts'
            if(video.postType == 'sharevideo') {
                dbtable = 'sharepost'
            }

            let sql = `UPDATE ${dbtable} SET views='${allVideoViews.length}' WHERE _id='${req.body.videoId}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)                    
                }
            })

        })
    } catch (error) {
        console.log(error.message)
    }
})


module.exports = router



// function getYesterdayDate() {
//   return new Date(new Date().getTime() - 24*60*60*1000);
// }

// console.log(getYesterdayDate());