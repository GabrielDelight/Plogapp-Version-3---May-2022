const router = require('express').Router();
const auth = require('./auth')
const multer = require('multer')
const path = require('path')
const mysql = require('mysql');
const crypto = require('crypto')
const sanitizeHtml = require('sanitize-html');
const dayjs = require('dayjs')
var relativeTime = require('dayjs/plugin/relativeTime')
dayjs.extend(relativeTime)
const fs = require('fs')
const util = require('util')

const unlineLinkFIle = util.promisify(fs.unlink)
// const { fullDateStr } = require('./dateFunction')
const { uploadFile, getFileStream } = require('./s3')
const { db } = require('./db') //Database
const { registerLimitter } = require('./expressEmitterDDos')





module.exports = function (io) {
    // Reply message
    router.get('/replyComment/:id', auth,  async (req, res) => {
        try {
            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const users = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = users[0]

            const comments = await User(`SELECT * FROM comments WHERE _id='${req.params.id}'`)
            const replies = await User(`SELECT * FROM replies WHERE mainCommentId='${comments[0]._id}'`)
            comments[0].date = dayjs().to(comments[0].date)
            replies.map(cur => cur.date = dayjs().to(cur.date))
            res.render('replyPage', {
                data: comments[0],
                user: user,
                replies: replies,
                users
            })

        } catch (error) {
            console.log(error)
            res.render('404Page')
        }

    })

    // @ set up validation for image upload
    const storage = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/commentImages',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
        }
    })
    const upload = multer({
        // limits: 300000,
        storage: storage
    })


    // Creating a reply commetn
    router.post('/saveReplyComment', auth, upload.single('uploadImg'),  async (req, res) => {
        try {

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const users = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = users[0]

            const comments = await User(`SELECT * FROM comments WHERE _id='${req.body.mainCommentId}'`)
            let commentOwner = comments[0]


            let day = new Date().getDate()
            let month = new Date().getMonth() + 1
            let year = new Date().getFullYear()
            let mili = new Date().getMilliseconds()

            let hours = new Date().getHours()
            let minutes = new Date().getMinutes()
            let seconds = new Date().getSeconds()

            let fullDateStr = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}:${mili}`



            // const commentData = await Comment.findById(req.body.mainCommentId)

            let owner = user._id;
            let fullName = `${user.firstname} ${user.lastname}`;
            let comment = req.body.comment;
            let mainCommentId = req.body.mainCommentId

            let image
            let hidePhoto = 'none'
            if (req.file) {
                image = req.file.filename
                hidePhoto = 'block'
            }


            // Sanitizing my html
            let sanitizedComment = sanitizeHtml(req.body.comment, {
                allowedTags: [],
                allowedAttributes: {}
            });

            req.body.comment = sanitizedComment
            if (sanitizedComment == '') {
                console.log('')
                res.redirect(`/replyComment/${req.body.mainCommentId}?errorMsg=invalid`)
                return
            }

            comment = sanitizedComment


            const _id = crypto.randomBytes(12).toString('hex')

            const saveReply = {
                date: new Date(new Date().getTime()),
                owner,
                _id,
                comment,
                fullName,
                mainCommentId,
                image,
                hidePhoto,
                commentorNickName: user.fullName,
                verified: user.verified,
                avatar: user.avatar
            }

            let sql = 'INSERT INTO replies SET ?'
            db.query(sql, saveReply, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            if (req.file) {
                let file = req.file
                await uploadFile(file)
                await unlineLinkFIle(file.path)
            }


            // Counting numbers of replies in a comment
            const allReplies = await User(`SELECT * FROM replies WHERE mainCommentId='${req.body.mainCommentId}'`)
            let updateRepliesLength = `UPDATE comments SET replylength='${allReplies.length}' WHERE _id='${comments[0]._id}'`
            db.query(updateRepliesLength, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // Add last replies in comment
            let updateLastComment = `UPDATE comments SET lastPostOwnerId='${user._id}',lastReplyAvatar='${user.avatar}',lastReplyName='${user.firstname} ${user.lastname}',lastReplyVerified='${user.verified}',lastReplyText='${req.body.comment}',hideReply='block' WHERE _id='${comments[0]._id}'`

            db.query(updateLastComment, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            const checkowner = commentOwner.owner.toString() !== user._id.toString()
            if (checkowner) {
                const notification = {
                    owner: user._id,
                    _id: crypto.randomBytes(12).toString('hex'),
                    text: 'Replied to your comment',
                    comment: req.body.comment,
                    eventId: mainCommentId,
                    eventOwner: commentOwner.owner,
                    date: new Date(new Date().getTime()),
                    ownerName: `${user.firstname} ${user.lastname}`,
                    avatar: user.avatar,
                    urlLink: `replyComment/${mainCommentId}`
                }

                let sql = 'INSERT INTO notification SET ?'
                db.query(sql, notification, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })


                let findNotifcationOwner = await User(`SELECT * FROM users WHERE _id='${commentOwner.owner}'`)
                let eventOwner = findNotifcationOwner[0]
                if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                    let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${commentOwner.owner}'`
                    db.query(sql, (error) => {
                        if (error) return console.log(error)
                    })
                    res.redirect(`/replyComment/${mainCommentId}`)
                    return
                } else {
                    let count = parseInt(eventOwner.notifiicationLength)
                    count = count += 1
                    let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${commentOwner.owner}'`
                    db.query(sqlQueryForCOunt, (error) => {
                        if (error) return console.log(error)
                    })
                }

                res.redirect(`/replyComment/${mainCommentId}`)
                return

            }



            res.redirect(`/replyComment/${mainCommentId}`)
        } catch (error) {
            console.log(error)
            res.redirect(`/replyComment/${mainCommentId}`)
        }

    })

    // Serving up replies images routers
    router.get('/webStorage/commentImages/:key', auth,  async (req, res) => {
        try {

            let key = req.params.key

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const Replies = await User(`SELECT * FROM replies WHERE image='${key}'`)
            const replies = Replies[0]
            if (Replies.length == 0) {
                const readStream = getFileStream('image-error.jpg')
                readStream.pipe(res)
                return
            }

            const readStream = getFileStream(replies.avatar)
            readStream.pipe(res)


        } catch (error) {
            console.log('Error', error.message)
        }
    })



    // SServer upload image
    router.get('/uploadForReply/:id',  async (req, res) => {
        const reply = await Reply.findById(req.params.id);
        res.set('Content-Type', 'image/png')
        res.send(reply.image)

    })


    // Reaction 
    io.on('connection', (socket) => {
        socket.on('reactionForReplyDetails',  async (data) => {
            let userId = data.userId;
            let replyId = data.commentId;
            // return   
            console.log(data)

            async function GETSQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await GETSQL(`SELECT * FROM users WHERE _id='${userId}'`)
            const replies = await GETSQL(`SELECT * FROM replies WHERE _id='${replyId}'`)
            let user = userx[0]
            let reply = replies[0]


            async function notificationFunction() {

                // const getCommentId = await Comment.findById(reply.mainCommentId) //to get comment link 
                const getCommentId = await GETSQL(`SELECT * FROM comments WHERE _id='${reply.mainCommentId}'`)
                const checkowner = reply.owner.toString() !== user._id.toString()
                if (checkowner) {
                    // Send notification    
                    let randomId = crypto.randomBytes(12).toString('hex')

                    const notification = {
                        owner: userId,
                        _id: randomId,
                        text: 'Reacted to your comment',
                        comment: reply.comment,
                        eventId: reply._id,
                        eventOwner: reply.owner,
                        date: new Date(new Date().getTime()),
                        avatar: user.avatar,
                        ownerName: `${user.firstname} ${user.lastname}`,
                        urlLink: 'replyComment/' + getCommentId[0]._id

                    }

                    let sql = 'INSERT INTO notification SET ?'
                    db.query(sql, notification, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                        console.log('Created a new Nitification')
                    })


                    let findNotifcationOwner = await GETSQL(`SELECT * FROM users WHERE _id='${reply.owner}'`)
                    let eventOwner = findNotifcationOwner[0]
                    if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                        let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${reply.owner}'`
                        db.query(sql, (error) => {
                            if (error) return console.log(error)
                        })
                        return
                    } else {
                        let count = parseInt(eventOwner.notifiicationLength)
                        count = count += 1
                        let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${reply.owner}'`
                        db.query(sqlQueryForCOunt, (error) => {
                            if (error) return console.log(error)
                        })
                    }

                }
            }


            // @ if post reaction is empty add the first value to it
            if (reply.reaction == '' || reply.reaction == null) {
                let sql = `UPDATE replies SET reaction='${user.id}', reactionLength='${1}' WHERE _id='${reply._id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('Likeed')
                })
                notificationFunction()
                return
            }


            const reaction = reply.reaction.split(',')
            let newReaction = reaction.map(el => {
                return parseInt(el)
            })

            let index = newReaction.indexOf(user.id)

            // @ remove like
            if (index > -1) {
                newReaction.splice(index, 1)

                let sql = `UPDATE replies SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE _id='${reply._id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })
                return
            }

            // @ add like
            newReaction.push(user.id)
            let sql = `UPDATE replies SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE _id='${reply._id}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })
            notificationFunction()

        })
    })


    // Delete my reply *********************************
    router.get('/deleteMyReply/:id',  async (req, res) => {

        async function SQL(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        const replies = await SQL(`SELECT * FROM replies WHERE _id='${req.params.id}'`)
        const comment = await SQL(`SELECT * FROM comments WHERE _id='${replies[0].mainCommentId}'`)


        let sql = `DELETE  FROM replies WHERE _id='${req.params.id}'`
        db.query(sql, (error, result) => {
            if (error) {
                return console.log(error)
            }
        })

        res.redirect(`/replyComment/${comment[0]._id}`)

        const decreaseComment = await SQL(`SELECT * FROM replies WHERE mainCommentId='${replies[0].mainCommentId}'`)

        let updatesql = `UPDATE comments SET replyLength='${decreaseComment.length}' WHERE id='${comment[0].id}'`
        db.query(updatesql, (error) => {
            if (error) {
                return console.log(error)
            }
        })

    })


    // load comments in background
    io.on('connection', (socket) => {
        socket.on('send_comment_id',  async (commentId) => {
            async function GETSQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            let returnedData = {}
            // const userx = await GETSQL(`SELECT * FROM  WHERE _id='${userId}'`)
            const comment = await GETSQL(`SELECT * FROM comments WHERE _id='${commentId}'`)
            const replies = await GETSQL(`SELECT * FROM replies WHERE mainCommentId='${commentId}'`)

            returnedData.comment = comment
            returnedData.replies = replies

            // console.log(returnedData.comment)

            socket.emit('fetched_items', returnedData)
        })
    })


    router.post('/testShit', (req, res) => {
        console.log(req.body)
    })


    return router
}