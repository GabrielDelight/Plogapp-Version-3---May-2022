const dayjs = require('dayjs')
var relativeTime = require('dayjs/plugin/relativeTime')
dayjs.extend(relativeTime)

let = {}

// function fullDateStr() {


setInterval(() => {
    let day = new Date().getDate()
    let month = new Date().getMonth() + 1
    let year = new Date().getFullYear()
    let mili = new Date().getMilliseconds()

    let hours = new Date().getHours()
    let minutes = new Date().getMinutes()
    let seconds = new Date().getSeconds()

    let fullDateStr = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}:${mili}`
}, 1000);

// return new Date().toLocaleTimeString()
// }

// console.log(fullDateStr())
// exports.fullDateStr = fullDateStr()