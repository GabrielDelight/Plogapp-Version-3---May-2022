const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken')
const auth = require('./auth')
const multer = require('multer');
const path = require('path');
const mysql = require('mysql');
const crypto = require('crypto')
const nodemailer = require('nodemailer');

const { db } = require('./db') //Datbase


// @ set up validation for image upload
const storage = multer.diskStorage({
    destination: './web-server/web-folder/public/webStorage/avatar',
    filename: function (req, file, cb) {
        cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
    }
})
const upload = multer({
    // limits: 300000,
    storage: storage
})


router.get('/homex', auth, async (req, res) => {
    console.log('posts fromm api')
    try {
        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const userSQL = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        if (userSQL.length == 0) return res.redirect('/login')
        const user = userSQL[0]

        // SET the disabling of user to false
        let sql = `UPDATE users SET isDisabled='${false}' WHERE _id='${user._id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })


        // Get all users
        async function AllUsers(val) {
            return new Promise((resolve, reject) => {
                let sql = `SELECT * FROM users`
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const allUser = await AllUsers(req.user._id)
        const suggestedFollowers = await AllUsers(req.user._id)

        async function POST(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }


        let followingIds = user.following.split(',').map(val => parseInt(val))
        // @ add use id to follower id 
        followingIds.push(user.id)


        let postText = []
        let postPhoto = []
        let postVideo = []
        for (i = 0; i < followingIds.length; i++) {
            // For post text
            const followingPostText = await POST(`SELECT * FROM posts WHERE postType='text' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostText.forEach(val => {
                postText.push(val)
            })

            // For post image
            const followingPostImage = await POST(`SELECT * FROM posts WHERE postType='image' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostImage.forEach(val => {
                postPhoto.push(val)
            })

            // @ get post video
            const followingPostVideo = await POST(`SELECT * FROM posts WHERE postType='video' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostVideo.forEach(val => {
                postVideo.push(val)
            })
        }


        // @ get shared post from following
        let sharePostText = []
        let sharePostPhoto = []
        let sharePostVideo = []
        for (i = 0; i < followingIds.length; i++) {
            // For post text
            const followingPostTextSharePost = await POST(`SELECT * FROM sharepost WHERE postType='text' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostTextSharePost.forEach(val => {
                sharePostText.push(val)
            })

            // For post image
            const followingPostImageSharePos = await POST(`SELECT * FROM sharepost WHERE postType='image' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostImageSharePos.forEach(val => {
                sharePostPhoto.push(val)
            })

            // @ get post video
            const followingPostVideo = await POST(`SELECT * FROM sharepost WHERE postType='video' AND ownerPrimaryId='${followingIds[i]}'`)
            followingPostVideo.forEach(val => {
                sharePostVideo.push(val)
            })

        }

        let followingStories = []
        // Get stories from followrs         
        let followingStoriesIds = user.following.split(',').map(val => parseInt(val))
        for (i = 0; i < followingStoriesIds.length; i++) {
            const userWithStory = await POST(`SELECT * FROM users WHERE hasStory='true' AND id='${followingStoriesIds[i]}'`)
            userWithStory.forEach(val => {
                followingStories.push(val)
            })
        }

    //    console.log('hello')


        // res.render('index', {
        //     story: followingStories,
        //     video: postVideo,
        //     image: postPhoto,
        //     text: postText,
        //     sharedPostText: sharePostText,
        //     sharedPostImage: sharePostPhoto,
        //     sharedPostVideo: sharePostVideo,
            
        // })
    } catch (error) {
        console.log(error)
    }

})

module.exports = router