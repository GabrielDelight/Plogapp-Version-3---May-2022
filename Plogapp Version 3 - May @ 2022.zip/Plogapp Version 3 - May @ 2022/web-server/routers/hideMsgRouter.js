const router = require('express').Router()
const mysql = require('mysql');
const crypto = require('crypto')

const { db } = require('./db') //Database


module.exports = function (io) {

    io.on('connection', (socket) => {
        socket.on('hideWelcomeMsg', async (data) => {
            let sql = `UPDATE users SET hideWelcomeMsg='${data.display}' WHERE _id='${data.id}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })
        })
    })


    return router
}