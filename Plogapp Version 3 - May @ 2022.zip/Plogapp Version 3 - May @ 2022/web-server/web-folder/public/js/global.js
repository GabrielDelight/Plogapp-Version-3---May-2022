

{

// export default  'Hello'

    function toggleSettngs(){
        document.querySelector('.setting_container').classList.toggle('toggleSettings')
        document.querySelector('body').classList.toggle('bodyToggle')
    }

    let shortcut = document.querySelector('.short_cut_btn');
    shortcut.addEventListener('click', () => {
        console.log('Hello')
        let x = document.querySelector('.short_cut_navs')
        x.style.display = 'block'

       
    })

}