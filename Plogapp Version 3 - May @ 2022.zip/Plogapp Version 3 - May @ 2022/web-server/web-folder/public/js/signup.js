let btn = document.getElementById('signup');
let firstname = document.getElementById('firstname');
let lastname = document.getElementById('lastname');
let email = document.getElementById('email');
// let number = document.getElementById('number');
let password = document.getElementById('password');
let confiemPass = document.getElementById('confiemPass');
let errorMessage = document.getElementById('errorMessage');
let fullNameValue = document.getElementById('fullName')
let gender = document.getElementById('gender')

// error handler variable
let firstnameErr = document.getElementById('firstnameErr')
let lastnameErr = document.getElementById('lastnameErr')
let emailErr = document.getElementById('emailErr')
let selectErr = document.getElementById('selectErr')
let passwordErr = document.getElementById('passwordErr')
let password2Err = document.getElementById('password2Err')

// @ button function
function buttonFunction(boo) {
    if (boo == true) {
        createbtn.disabled = true
        createbtn.style.backgroundColor = 'gray'
    } else {
        createbtn.disabled = false
        createbtn.style.backgroundColor = 'cornflowerblue'
    }
}

let firstnameTyping = document.getElementById('firstname')
firstnameTyping.addEventListener('input', e => {
    if (firstname.value.length >= 16) {
        firstname.value = firstname.value.substr(0, 16)
        firstnameErr.textContent = 'The average first name is about 16 letters.'
        return
    } else {
        firstnameErr.textContent = ''
    }

})

let lastnameTyping = document.getElementById('lastname')
lastnameTyping.addEventListener('input', e => {
    if (lastname.value.length >= 16) {
        lastname.value = lastname.value.substr(0, 16)
        lastnameErr.textContent = 'The average last name is about 16 letters.'
        return
    } else {
        lastnameErr.textContent = ''
    }

})


// validatying firstname
firstname.addEventListener('input', e => {
    let s = firstname.value;
    let punctuationless = s.replace(/[.,\/#!$%@<>,?:';'`""\^&\*;:{}=\-_`~()]/g, "");
    let finalString = punctuationless.replace(/\s{2,}/g, " ");
    finalString = finalString.replace(/ /g, '')
    finalString = finalString.replace(/]/g, '')
    finalString = finalString.replace(/\[/, '')
    firstname.value = finalString
})

// validatying last name
lastname.addEventListener('input', e => {
    let s = lastname.value;
    let punctuationless = s.replace(/[.,\/#!$%@<>,?:';'`""\^&\*;:{}=\-_`~()]/g, "");
    let finalString = punctuationless.replace(/\s{2,}/g, " ");
    finalString = finalString.replace(/ /g, '')
    finalString = finalString.replace(/]/g, '')
    finalString = finalString.replace(/\[/, '')
    lastname.value = finalString
})

// email validatort
email.addEventListener('input', e => {
    console.log(validateEmail(email.value))
    console.log(email.value)
    if (!validateEmail(email.value)) {
        emailErr.textContent = 'Invalid email address'
    } else {
        emailErr.textContent = ''

    }
})

function validateEmail(email) {
    var re = /\S+@\S+\.\S+/;
    return re.test(email);
}

// verifying password
function checkPassLength() {
    if (password.value.length <= 6) {
        passwordErr.textContent = 'Password is too short'
        return
    } else if (password.value == '123456' || password.value == 'password' || password.value == 'qwerty' || password.value == '111111' || password.value == '00000000' || password.value == '123456789' || password.value == 'abc123') {
        passwordErr.textContent = 'Password is too easy'
        return
    } else {
        passwordErr.textContent = ''
    }
}
password.addEventListener('input', e => {
    checkPassLength()
})


function comparingPassword() {
    if (confiemPass.value !== password.value) {
        password2Err.textContent = 'Password did not match'
        return
    } else {
        password2Err.textContent = ''
    }
}

confiemPass.addEventListener('input', e => {
    comparingPassword()
})


btn.addEventListener('click', (e) => {

    let code1 = Math.floor(Math.random() * 10)
    let code2 = Math.floor(Math.random() * 10)
    let code3 = Math.floor(Math.random() * 10)
    let code4 = Math.floor(Math.random() * 10)
    let code = [code1, code2, code3, code4]
    code = code.map(el => el.toString())
    code = code.toString().replace(/,/g, '')

    let fullName = firstname.value +'_'+ code
    fullNameValue.value = fullName.toLowerCase()
    console.log(fullNameValue.value)


    if (firstname.value.trim() == '') {
        clearInputError()
        firstnameErr.textContent = 'First name is required'
        return
    }

    if (firstname.value.length >= 8) {
        clearInputError()
        firstnameErr.textContent = 'The average first name is about 6 letters.'
        return
    }

    if (lastname.value.trim() == '') {
        clearInputError()
        lastnameErr.textContent = 'Last name is required'
        return
    }

    if (email.value.trim() == '') {
        clearInputError()
        emailErr.textContent = 'Email is required'
        return
    }

    if (validateEmail(email.value) == false) {
        clearInputError()
        emailErr.textContent = 'Invalid email address'
        return
    }

    if (gender.value.trim() == '') {
        clearInputError()
        selectErr.textContent = 'Gender is required'
        return
    }

    if (password.value.trim() == '') {
        clearInputError()
        passwordErr.textContent = 'Password is required'
        return
    }

    // Validating password 
    checkPassLength()

    if (confiemPass.value.trim() == '') {
        clearInputError()
        password2Err.textContent = 'Confirm password is required'
        return
    }

    //  comparing password
    comparingPassword()



    if (confiemPass.value !== password.value) {
        clearInputError()
        password2Err.textContent = 'Your password did not match'
        return
    }


    function clearInputError() {
        // remover text
        let input = document.querySelectorAll('input')
        for (i = 0; i < input.length; i++) {
            input[i].addEventListener('input', (e) => {
                // e.target.parentElement.children[0].textContent = ''
            })
        }

    }




    buttonFunction(true)
    createbtn.value = 'Please wait...'



    let formData = {
        firstname: firstname.value,
        lastname: lastname.value,
        email: email.value,
        password: password.value,
        gender: gender.value,
        fullName
    }
    let url = '/account_creation'
    fetch(url, {
        method: 'POST',
        headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
    })

        .then(res => res.json())
        .then(data => {
            buttonFunction(true)

            if (data.emailError) {
                buttonFunction(false)
                createbtn.value = 'Sign Up'
                emailErr.textContent = data.emailError
                return
            }


            // Send email to the mail

            createbtn.value = 'Successful'
            createbtn.style.backgroundColor = 'green'

            // console.log(data)
            // buttonFunction(false)



            setTimeout(() => {
                let a = document.createElement('a')
                a.href = '/confirmemail/' + data._id
                a.click()
            }, 1000);
        })
        .catch(error => {
            buttonFunction(false)
        })



})

// Accepting terms and conditions
let boo = true
let createbtn = document.getElementById('signup')
document.getElementById('checkteerms').addEventListener('click', e => {
    if (boo == false) {
        boo = true
        createbtn.disabled = false
        createbtn.style.backgroundColor = 'cornflowerblue'
        return
    } else {
        boo = false
        createbtn.disabled = true
        createbtn.style.backgroundColor = 'gray'
    }
})
