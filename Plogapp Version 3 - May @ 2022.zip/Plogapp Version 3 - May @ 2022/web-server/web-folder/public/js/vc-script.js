const socket = io()
const Peer = require('simple-peer')
const wrtc = require('wrtc')
const crypto = require('crypto')
let ramdomNumber = crypto.randomBytes(9).toString('hex')
var url = new URLSearchParams(location.search);
var callerId = url.get("callerId");
var receiverId = url.get("receiverId");
let callStatus = url.get('status')

// Set user id immediate in index.html div
document.getElementById('userId').textContent = callerId
let otherCam = document.getElementById('largeVideo')
let redialBtn = document.querySelector('.redial_call')
let quitCall = document.querySelector('.end_call')
let on_calling_state_div = document.querySelector('.on_calling_state_div')
let quit_ongoing_call = document.querySelector('.quit_ongoing_call')
let callingErrorStatus = document.querySelector('#callingErrorStatus')
let animateLoader = document.querySelectorAll('.animateLoader')

let vc_avatar = document.getElementById('vc_avatar');
let vc_nick_name = document.getElementById('vc_nick_name');
let vc_full_name = document.getElementById('vc_full_name');
let vc_full_name2 = document.getElementById('vc_full_name2');


let on_calling_avatar = document.getElementById('on_calling_avatar');
let on_callingFUllName = document.getElementById('on_callingFUllName');

let user1SignalArray = []


navigator.mediaDevices.getUserMedia({
    video: true,
    audio: true,
    audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
        googEchoCancellation: true,
        googAutoGainControl: true,
        googNoiseSuppression: true,
        googHighpassFilter: true,
        googTypingNoiseDetection: true,
        googNoiseReduction: true,
        volume: 1.0,
    },
}).then(stream => {
    function myCamFun(stream) {
        let video = document.getElementById('myCam')
        video.srcObject = stream
        video.play()
    }


    let peer = new Peer({
        initiator: callStatus === 'host',
        trickle: false,
        stream: stream,
        wrtc: wrtc
    })


    if (callStatus === 'host') {
        // socket.emit('send-calling-signal', {
        //     dataSignal: JSON.stringify({ "type": "offer", "sdp": "v=0\r\no=- 4504400830254737726 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0 1 2\r\na=extmap-allow-mixed\r\na=msid-semantic: WMS MVFI1hcqlHkQB4JC1aN3Kq5Oa1N14QhX6LJN\r\nm=audio 62315 UDP/TLS/RTP/SAVPF 111 63 103 104 9 0 8 106 105 13 110 112 113 126\r\nc=IN IP4 160.152.51.46\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=candidate:1174899823 1 udp 2122260223 192.168.1.124 62315 typ host generation 0 network-id 1 network-cost 10\r\na=candidate:142897311 1 tcp 1518280447 192.168.1.124 9 typ host tcptype active generation 0 network-id 1 network-cost 10\r\na=candidate:3343878875 1 udp 1686052607 160.152.51.46 62315 typ srflx raddr 192.168.1.124 rport 62315 generation 0 network-id 1 network-cost 10\r\na=ice-ufrag:z5gL\r\na=ice-pwd:7Rx288/i2U28YUw8QLlsoGsG\r\na=fingerprint:sha-256 8A:40:42:32:D5:62:DB:D7:45:F5:3D:C2:B0:B1:23:E9:63:33:47:2B:F9:61:89:EC:65:58:E6:1A:8F:DB:B6:98\r\na=setup:actpass\r\na=mid:0\r\na=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid\r\na=sendrecv\r\na=msid:MVFI1hcqlHkQB4JC1aN3Kq5Oa1N14QhX6LJN 59d296da-948d-47f9-8e44-000f9d1e7fad\r\na=rtcp-mux\r\na=rtpmap:111 opus/48000/2\r\na=rtcp-fb:111 transport-cc\r\na=fmtp:111 minptime=10;useinbandfec=1\r\na=rtpmap:63 red/48000/2\r\na=fmtp:63 111/111\r\na=rtpmap:103 ISAC/16000\r\na=rtpmap:104 ISAC/32000\r\na=rtpmap:9 G722/8000\r\na=rtpmap:0 PCMU/8000\r\na=rtpmap:8 PCMA/8000\r\na=rtpmap:106 CN/32000\r\na=rtpmap:105 CN/16000\r\na=rtpmap:13 CN/8000\r\na=rtpmap:110 telephone-event/48000\r\na=rtpmap:112 telephone-event/32000\r\na=rtpmap:113 telephone-event/16000\r\na=rtpmap:126 telephone-event/8000\r\na=ssrc:379726642 cname:LCO3F3Bo6xuZP2Ij\r\na=ssrc:379726642 msid:MVFI1hcqlHkQB4JC1aN3Kq5Oa1N14QhX6LJN 59d296da-948d-47f9-8e44-000f9d1e7fad\r\na=ssrc:379726642 mslabel:MVFI1hcqlHkQB4JC1aN3Kq5Oa1N14QhX6LJN\r\na=ssrc:379726642 label:59d296da-948d-47f9-8e44-000f9d1e7fad\r\nm=video 62316 UDP/TLS/RTP/SAVPF 96 97 98 99 100 101 127 121 125 107 108 109 124 120 123 119 35 36 41 42 114 115 116\r\nc=IN IP4 160.152.51.46\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=candidate:1174899823 1 udp 2122260223 192.168.1.124 62316 typ host generation 0 network-id 1 network-cost 10\r\na=candidate:142897311 1 tcp 1518280447 192.168.1.124 9 typ host tcptype active generation 0 network-id 1 network-cost 10\r\na=candidate:3343878875 1 udp 1686052607 160.152.51.46 62316 typ srflx raddr 192.168.1.124 rport 62316 generation 0 network-id 1 network-cost 10\r\na=ice-ufrag:z5gL\r\na=ice-pwd:7Rx288/i2U28YUw8QLlsoGsG\r\na=fingerprint:sha-256 8A:40:42:32:D5:62:DB:D7:45:F5:3D:C2:B0:B1:23:E9:63:33:47:2B:F9:61:89:EC:65:58:E6:1A:8F:DB:B6:98\r\na=setup:actpass\r\na=mid:1\r\na=extmap:14 urn:ietf:params:rtp-hdrext:toffset\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:13 urn:3gpp:video-orientation\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:5 http://www.webrtc.org/experiments/rtp-hdrext/playout-delay\r\na=extmap:6 http://www.webrtc.org/experiments/rtp-hdrext/video-content-type\r\na=extmap:7 http://www.webrtc.org/experiments/rtp-hdrext/video-timing\r\na=extmap:8 http://www.webrtc.org/experiments/rtp-hdrext/color-space\r\na=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid\r\na=extmap:10 urn:ietf:params:rtp-hdrext:sdes:rtp-stream-id\r\na=extmap:11 urn:ietf:params:rtp-hdrext:sdes:repaired-rtp-stream-id\r\na=sendrecv\r\na=msid:MVFI1hcqlHkQB4JC1aN3Kq5Oa1N14QhX6LJN d3673976-d103-4b70-bac9-9ebd14d4a90c\r\na=rtcp-mux\r\na=rtcp-rsize\r\na=rtpmap:96 VP8/90000\r\na=rtcp-fb:96 goog-remb\r\na=rtcp-fb:96 transport-cc\r\na=rtcp-fb:96 ccm fir\r\na=rtcp-fb:96 nack\r\na=rtcp-fb:96 nack pli\r\na=rtpmap:97 rtx/90000\r\na=fmtp:97 apt=96\r\na=rtpmap:98 VP9/90000\r\na=rtcp-fb:98 goog-remb\r\na=rtcp-fb:98 transport-cc\r\na=rtcp-fb:98 ccm fir\r\na=rtcp-fb:98 nack\r\na=rtcp-fb:98 nack pli\r\na=fmtp:98 profile-id=0\r\na=rtpmap:99 rtx/90000\r\na=fmtp:99 apt=98\r\na=rtpmap:100 VP9/90000\r\na=rtcp-fb:100 goog-remb\r\na=rtcp-fb:100 transport-cc\r\na=rtcp-fb:100 ccm fir\r\na=rtcp-fb:100 nack\r\na=rtcp-fb:100 nack pli\r\na=fmtp:100 profile-id=2\r\na=rtpmap:101 rtx/90000\r\na=fmtp:101 apt=100\r\na=rtpmap:127 H264/90000\r\na=rtcp-fb:127 goog-remb\r\na=rtcp-fb:127 transport-cc\r\na=rtcp-fb:127 ccm fir\r\na=rtcp-fb:127 nack\r\na=rtcp-fb:127 nack pli\r\na=fmtp:127 level-asymmetry-allowed=1;packetization-mode=1;profile-level-id=42001f\r\na=rtpmap:121 rtx/90000\r\na=fmtp:121 apt=127\r\na=rtpmap:125 H264/90000\r\na=rtcp-fb:125 goog-remb\r\na=rtcp-fb:125 transport-cc\r\na=rtcp-fb:125 ccm fir\r\na=rtcp-fb:125 nack\r\na=rtcp-fb:125 nack pli\r\na=fmtp:125 level-asymmetry-allowed=1;packetization-mode=0;profile-level-id=42001f\r\na=rtpmap:107 rtx/90000\r\na=fmtp:107 apt=125\r\na=rtpmap:108 H264/90000\r\na=rtcp-fb:108 goog-remb\r\na=rtcp-fb:108 transport-cc\r\na=rtcp-fb:108 ccm fir\r\na=rtcp-fb:108 nack\r\na=rtcp-fb:108 nack pli\r\na=fmtp:108 level-asymmetry-allowed=1;packetization-mode=1;profile-level-id=42e01f\r\na=rtpmap:109 rtx/90000\r\na=fmtp:109 apt=108\r\na=rtpmap:124 H264/90000\r\na=rtcp-fb:124 goog-remb\r\na=rtcp-fb:124 transport-cc\r\na=rtcp-fb:124 ccm fir\r\na=rtcp-fb:124 nack\r\na=rtcp-fb:124 nack pli\r\na=fmtp:124 level-asymmetry-allowed=1;packetization-mode=0;profile-level-id=42e01f\r\na=rtpmap:120 rtx/90000\r\na=fmtp:120 apt=124\r\na=rtpmap:123 H264/90000\r\na=rtcp-fb:123 goog-remb\r\na=rtcp-fb:123 transport-cc\r\na=rtcp-fb:123 ccm fir\r\na=rtcp-fb:123 nack\r\na=rtcp-fb:123 nack pli\r\na=fmtp:123 level-asymmetry-allowed=1;packetization-mode=1;profile-level-id=4d001f\r\na=rtpmap:119 rtx/90000\r\na=fmtp:119 apt=123\r\na=rtpmap:35 H264/90000\r\na=rtcp-fb:35 goog-remb\r\na=rtcp-fb:35 transport-cc\r\na=rtcp-fb:35 ccm fir\r\na=rtcp-fb:35 nack\r\na=rtcp-fb:35 nack pli\r\na=fmtp:35 level-asymmetry-allowed=1;packetization-mode=0;profile-level-id=4d001f\r\na=rtpmap:36 rtx/90000\r\na=fmtp:36 apt=35\r\na=rtpmap:41 AV1/90000\r\na=rtcp-fb:41 goog-remb\r\na=rtcp-fb:41 transport-cc\r\na=rtcp-fb:41 ccm fir\r\na=rtcp-fb:41 nack\r\na=rtcp-fb:41 nack pli\r\na=rtpmap:42 rtx/90000\r\na=fmtp:42 apt=41\r\na=rtpmap:114 red/90000\r\na=rtpmap:115 rtx/90000\r\na=fmtp:115 apt=114\r\na=rtpmap:116 ulpfec/90000\r\na=ssrc-group:FID 1524004325 3995529570\r\na=ssrc:1524004325 cname:LCO3F3Bo6xuZP2Ij\r\na=ssrc:1524004325 msid:MVFI1hcqlHkQB4JC1aN3Kq5Oa1N14QhX6LJN d3673976-d103-4b70-bac9-9ebd14d4a90c\r\na=ssrc:1524004325 mslabel:MVFI1hcqlHkQB4JC1aN3Kq5Oa1N14QhX6LJN\r\na=ssrc:1524004325 label:d3673976-d103-4b70-bac9-9ebd14d4a90c\r\na=ssrc:3995529570 cname:LCO3F3Bo6xuZP2Ij\r\na=ssrc:3995529570 msid:MVFI1hcqlHkQB4JC1aN3Kq5Oa1N14QhX6LJN d3673976-d103-4b70-bac9-9ebd14d4a90c\r\na=ssrc:3995529570 mslabel:MVFI1hcqlHkQB4JC1aN3Kq5Oa1N14QhX6LJN\r\na=ssrc:3995529570 label:d3673976-d103-4b70-bac9-9ebd14d4a90c\r\nm=application 62317 UDP/DTLS/SCTP webrtc-datachannel\r\nc=IN IP4 160.152.51.46\r\na=candidate:1174899823 1 udp 2122260223 192.168.1.124 62317 typ host generation 0 network-id 1 network-cost 10\r\na=candidate:142897311 1 tcp 1518280447 192.168.1.124 9 typ host tcptype active generation 0 network-id 1 network-cost 10\r\na=candidate:3343878875 1 udp 1686052607 160.152.51.46 62317 typ srflx raddr 192.168.1.124 rport 62317 generation 0 network-id 1 network-cost 10\r\na=ice-ufrag:z5gL\r\na=ice-pwd:7Rx288/i2U28YUw8QLlsoGsG\r\na=fingerprint:sha-256 8A:40:42:32:D5:62:DB:D7:45:F5:3D:C2:B0:B1:23:E9:63:33:47:2B:F9:61:89:EC:65:58:E6:1A:8F:DB:B6:98\r\na=setup:actpass\r\na=mid:2\r\na=sctp-port:5000\r\na=max-message-size:262144\r\n" }),
        //     callerId: callerId,
        //     receiverId: receiverId
        // })


        peer.on('signal', function (data) {
            console.log(data)
            // Pushing user 1 signal to an array
            user1SignalArray.unshift(data)

            myCamFun(stream) //Open caller user cam

            socket.emit('send-calling-signal', {
                dataSignal: JSON.stringify(data),
                callerId: callerId,
                receiverId: receiverId
            })

        })


    }


    // user 1 received the data  generated by user two
    socket.on('dataDataGenByUser2', data => {
        console.log('user 1 received the data  generated by user two ')
        if (callStatus == 'host' && data.callerId == callerId) {
            peer.signal(JSON.parse(data.dataSignal2))
        }
    })

    // Listen tosignal if both clint care connected 
    peer.on('stream', function (stream) {
        ConnectedCamFunction(stream)
    })

    // Connected cams if paired
    function ConnectedCamFunction(stream) {
        otherCam.srcObject = stream
        otherCam.play()
        document.querySelector('.on_calling_state_div').style.display = 'none'
        otherCam.muted = false
    }


    // listen to peer if an erro occured 
    peer.on('error', err => {
        console.log(err)
        alert('Disconnected')
    })



    // animation controller

    function toggleAnimation(bool) {
        if (!bool) {
            Array.from(animateLoader).forEach(elem => {
                elem.classList.add('pauseAnimation')
            })
            return
        }

        if (bool) {
            Array.from(animateLoader).forEach(elem => {
                elem.classList.remove('pauseAnimation')
            })
            return
        }

        if (bool == 'ongoing') {
            Array.from(animateLoader).forEach(elem => {
                elem.classList.remove('pauseAnimation')
                elem.style.backgroundColor = 'green'
            })
        }

    }

    // Using socket to send calling signal to other browser
    // cVcallingFunction()
    function cVcallingFunction() {
        if (user1SignalArray.length > 0) {
            console.log(user1SignalArray[0])
            socket.emit('send-calling-signal', {
                dataSignal: JSON.stringify(user1SignalArray[0]),
                callerId: callerId,
                receiverId: receiverId
            })

            quitCall.style.display = 'inline-flex'
            redialBtn.style.display = 'none'
            on_calling_state_div.style.display = 'block'

            // Animation
            toggleAnimation(true)
        }

    }

    // CLicking calling/redial button 
    redialBtn.addEventListener('click', e => {
        cVcallingFunction()
    })

    // Stop calling
    quitCall.addEventListener('click', e => {
        console.log('stop calling')
        redialBtn.style.display = 'inline-flex'
        quitCall.style.display = 'none'
        on_calling_state_div.style.display = 'none'

        toggleAnimation(false)
        // Quitting call
        // @ send signal to second user to quit the call
        socket.emit('force-quit-call', {
            callerId: callerId,
            receiverId: receiverId
        })

        history.back()

    })


    // Aborting on going streaming call i user are cinnected
    document.getElementById('abortingCall').addEventListener('click', e => {
        history.back()
    })



    // Listening to user busy 
    socket.on('user-busy-signal', data => {
        if (data.callerId == callerId) {

            callingErrorStatus.textContent = data.message
            callingErrorStatus.style.color = 'red'

            // Pause Animation
            toggleAnimation(false)

            setTimeout(() => {
                // Change icons
                redialBtn.style.display = 'inline-flex'
                quitCall.style.display = 'none'

                // hide the calling div
                on_calling_state_div.style.display = 'none'
                callingErrorStatus.textContent = ''
                alert('Call declined')
                history.back()
            }, 1000);

        }
    })


    // if user two joined the video call area
    // Listen, when a user joins the call
    if (callStatus == 'joined') {
        console.log('(USER TWO) I joined the call')

        myCamFun(stream) //Open receiver cam

        // socket.on('signaDataReceived:', data => {
        //     consle.log(data)
        // })
        const user1SigalData = document.getElementById('signaData').textContent

        let otherId = JSON.parse(user1SigalData)
        // console.log(otherId)
        peer.signal(otherId)

        // Listene to user 2 peard signal 
        peer.on('signal', function (data) {
            console.log(data)
            // Send it to user one to pair 
            socket.emit('sendData2SignalJson', {
                dataSignal2: JSON.stringify(data),
                callerId: callerId,
                receiverId: receiverId
            })
        })


        socket.emit('receiver-join', {
            callerId: callerId,
            receiverId: receiverId
        })

        // Hide anything hidable 
        on_calling_state_div.style.display = 'none'
        quit_ongoing_call.style.display = 'inline-flex'
        quitCall.style.display = 'none'
        toggleAnimation('ongoing')
    }

    socket.on('signal-user-2-joined', data => {
        if (data.callerId == callerId) {
            console.log('user 2 joined')

            // hide anything hidable
            on_calling_state_div.style.display = 'none'
            quit_ongoing_call.style.display = 'inline-flex'
            quitCall.style.display = 'none'
            toggleAnimation('ongoing')

        }
    })



}).catch(error => {
    console.log(error)
})


if (callStatus == 'host') {
    // using fetch to update all the user details
    fetch('/user_api/' + receiverId)
        .then(res => res.json())
        .then(data => {
            // console.log(data)
            vc_avatar.src = 'https://plogapp.s3.amazonaws.com/' + data.user.avatar
            vc_nick_name.textContent = '@' + data.user.fullName
            vc_full_name.textContent = data.user.firstname + ' ' + data.user.lastname
            vc_full_name2.textContent = '@' + data.user.fullName

            on_calling_avatar.src = 'https://plogapp.s3.amazonaws.com/' + data.user.avatar
            on_callingFUllName.textContent = data.user.firstname + ' ' + data.user.lastname
        }).catch(error => {
            console.log(error)
        })
}


if (callStatus == 'joined') {
    fetch('/user_api/' + callerId)
        .then(res => res.json())
        .then(data => {
            vc_avatar.src = 'https://plogapp.s3.amazonaws.com/' + data.user.avatar
            vc_nick_name.textContent = '@' + data.user.fullName
            vc_full_name.textContent = data.user.firstname + ' ' + data.user.lastname
            vc_full_name2.textContent = '@' + data.user.fullName
        }).catch(error => {
            console.log(error)
        })
}