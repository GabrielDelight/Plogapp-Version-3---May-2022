function animateNav(){
    document.querySelector('.show_navs').classList.toggle('push_right')
    
}
