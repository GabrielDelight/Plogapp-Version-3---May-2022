const socket = io()
// Validate for background upload

document.getElementById('btnCoverPhoto').addEventListener('click', (e) => {
    let input = document.getElementById('bgImage');
    if (input.value == '') {
        e.preventDefault()
    }

})

// Check if post is video or image
let check = document.querySelectorAll('#postType');
for (i = 0; i < check.length; i++) {
    let checkText = check[i].textContent
    if (checkText == 'image') {
        let x = check[i].parentElement.children[1]
        x.style.display = 'none'
    } else if (checkText == 'video') {
        let x = check[i].parentElement.children[0]
        x.style.display = 'none'
    }
}

// Hide those that need to be hidden
let userId = document.getElementById('paramsid').textContent;
let mainUserId = document.getElementById('mainUser').textContent;
let hide = document.querySelectorAll('#hideFomOthers');
for (i = 0; i < hide.length; i++) {
    if (!userId.includes(mainUserId)) {
        hide[i].style.display = 'none'
    }
}


let hideFromMe = document.querySelectorAll('#hideFromMe')
for (i = 0; i < hideFromMe.length; i++) {
    if (userId.includes(mainUserId)) {
        hideFromMe[i].style.display = 'none'
    }
}


// Show user is active or not
socket.emit('sendUserDetails', userId)
socket.emit('idForDisconnection', userId)



// background cover photo
let img = document.getElementById('coverPhotoLarge')
document.querySelector('.backgroundUploadFile').addEventListener('change', function () {
    if (this.files) {
        img.src = URL.createObjectURL(this.files[0]);
        document.querySelector('.previewTextWrapper').style.display = 'block'
    }

})




// Following 
let followingId = document.getElementById('idToFollow').textContent

let myId = document.getElementById('myid').textContent
let button = document.querySelector('#followBtn')
let message = document.getElementById('chatMessage')

// Hide button from if the profile belongs to the main owner in authentication
if (myId.includes(followingId)) {
    button.style.display = 'none'
    message.style.display = 'none'

} else {
    button.style.display = 'block'
    message.style.display = 'block'
}






let primaryidToFOllow = document.getElementById('primaryidToFOllow').textContent
let followersId = document.getElementById('profileFollowers').textContent
let paramsFollowers = document.getElementById('paramsFollowers').textContent
let primaryId = document.getElementById('primaryId').textContent

console.log(paramsFollowers)
console.log(myId)
console.log(paramsFollowers.includes(primaryId))

if (paramsFollowers.includes(primaryId)) {
    button.style.backgroundColor = 'white'
    button.style.color = '#4196ff'
    button.textContent = 'Following'
}

button.addEventListener('click', () => {

    let loader = document.getElementById('follLoader')
    button.style.display = 'none'
    loader.style.display = 'block'
    setTimeout(() => {
        loader.style.display = 'none'
        button.style.display = 'block'
        return
    }, 1000);

    let followingDetails = {
        followingId,
        userId: myId
    }

    // console.log(followingDetails)

    socket.emit('followingDetails', followingDetails)


    if (button.textContent == 'Follow') {
        button.style.color = 'white'
        button.style.backgroundColor = 'black'
        button.textContent = 'Following'

    } else {
        button.style.color = 'white'
        button.style.backgroundColor = '#4196ff'
        button.textContent = 'Follow'

    }



})



document.addEventListener('click', (e) => {

    if (e.target.className === 'view_profile_photo') {
        document.querySelector('.view_profile_photo').style.display = 'none'
    }
})

let correctPlural = document.querySelectorAll('#correctPlural')
for (i = 0; i < correctPlural.length; i++) {
    let num = correctPlural[i].children[1].textContent
    num = parseInt(num)
    num < 2 ? correctPlural[i].children[2].textContent : correctPlural[i].children[2].textContent += 's'
}

// toggle user comments 
function toggleuserLikes() {
    document.querySelector('.user_comment_container').classList.toggle('toggle_owner_comment')
}

document.getElementById('showComment').addEventListener('click', () => {
    toggleuserLikes()
})


document.querySelector('.user_comment_container').addEventListener('click', (e) => {
    if (e.target.className == 'user_comment_container toggle_owner_comment') {
        toggleuserLikes()
    }
})

document.getElementById('clickForToggleCommemnt').addEventListener('click', () => {
    toggleuserLikes()
})


// toggle for use rlikes container
function toggleuserComment() {
    document.querySelector('.profile_owner_like_container').classList.toggle('toggle_owner_likes')
}



document.querySelector('.profile_owner_like_container').addEventListener('click', (e) => {
    if (e.target.className == 'profile_owner_like_container toggle_owner_likes') {
        toggleuserComment()
    }
})

document.getElementById('clickForToggleLikes').addEventListener('click', () => {
    toggleuserComment()
})


// Copy link address
document.querySelector('.copy_profile_link').addEventListener('click', e => {
    document.getElementById('copyLinkInput').value = location.href
    document.getElementById('copyLinkInput').style.display = 'block'
    document.getElementById('copyLinkInput').select()
    document.execCommand('copy')
    document.getElementById('copyLinkInput').style.display = 'none'
    document.getElementById('copyIcon').style.backgroundColor = 'green'
    document.getElementById('actionCopy').textContent = 'Copied'


    setTimeout(() => {
        document.getElementById('copyIcon').style.backgroundColor = 'cornflowerblue'
        document.getElementById('actionCopy').textContent = 'Copy'
    }, 1200);

})

// View larget profile
function toggleLargeAvatar() {
    document.querySelector('.profile_picture_large_container').classList.toggle('hide_lrg_avatar')
}
// @ Open the image
document.getElementById('viewLargeAvayat').addEventListener('click', e => {
    toggleLargeAvatar()
})
// Close the image by clising on X
document.getElementById('closeLargeImg').addEventListener('click', e => {
    console.log('close')
    toggleLargeAvatar()
})

// uploading profile photo with fetch
document.getElementById("uploadImgBtn").addEventListener('click', e => {
    let input = document.getElementById("imageUpload")
    if (input.value == "") {
        document.getElementById('imageSuccessMessage').textContent = 'Please upload a photo'
        document.getElementById('imageSuccessMessage').style.color = 'red'
        return
    }
    document.getElementById('imageSuccessMessage').textContent = 'Uploading...'
    var f = input.files[0];
    var fileName = f.name.split('.')[0];
    var img = new Image();
    img.src = URL.createObjectURL(f);
    img.onload = function () {
        var canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        var ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        canvas.toBlob(function (blob) {
            const newImage = new File([blob], fileName + ".jpeg");
            let data = new FormData()
            data.append('uploads', newImage)

            fetch('/myphoto/', {
                method: 'POST',
                body: data
            })
                .then(res => {
                    console.log(res)
                    document.getElementById('viewLargeAvayat').src = URL.createObjectURL(newImage)
                    document.querySelector('.flex_img_main_avatar img').src = URL.createObjectURL(newImage)
                    document.getElementById('imageSuccessMessage').textContent = 'Image uploaded successfully'
                    document.getElementById('imageSuccessMessage').style.color = 'green'
                    document.querySelector('.upload_profile_pic').style.display = 'none'
                }).catch(err => {
                    console.log(err)
                    document.getElementById('imageSuccessMessage').textContent = 'Failed to upload image'
                    document.getElementById('imageSuccessMessage').style.color = 'red'
                })


        }, 'image/jpeg', 0.2);
    }


})




// Uploading cover photo
let imgPrevAvatar = document.getElementById('imageUploadPrev')
let ImgUploadbtn = document.getElementById('uploadImgBtn')
document.querySelector('.uploadImgAvatar').addEventListener('change', function () {
    if (this.files && this.files[0]) {
        // console.log(URL.createObjectURL(this.files[0]))
        // alert(URL.createObjectURL(this.files[0]).toString())
        imgPrevAvatar.src = URL.createObjectURL(this.files[0]);
        imgPrevAvatar.style.width = '250px'
        imgPrevAvatar.style.minHeight = '100%'
        ImgUploadbtn.style.backgroundColor = 'cornflowerblue'
    }
})

let imgFile = document.querySelector('.uploadImgAvatar')
document.getElementById('uploadImgBtn').addEventListener('click', (e) => {
    if (imgFile.value == '') {
        e.preventDefault()
        return
    } else {
        //e.target.style.display = 'none'

    }
})

document.querySelector('.upload_profile_pic').addEventListener('click', (e) => {
    if (e.target.className == 'upload_profile_pic') {
        e.target.style.display = 'none'
    }
})

document.getElementById("btnCoverPhoto").addEventListener('click', e => {
    let input = document.getElementById("bgImage")
    if (input.value == "") {        
        return
    }


    document.getElementById('btnCoverPhoto').textContent = 'Uploading...'
    document.getElementById('btnCoverPhoto').disabled = true
    
    var f = input.files[0];
    var fileName = f.name.split('.')[0];
    var img = new Image();
    img.src = URL.createObjectURL(f);
    img.onload = function () {
        var canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        var ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        canvas.toBlob(function (blob) {
            var newimage = new File([blob], fileName + ".jpeg");
            let data = new FormData()
            data.append('uploads', newimage)

            fetch('/coverPhoto/', {
                method: 'POST',
                body: data
            })
                .then(res => {
                    document.getElementById('coverPhotoLarge').src = URL.createObjectURL(newimage)
                    document.querySelector('.previewTextWrapper').style.display = 'none'
                    document.getElementById('btnCoverPhoto').textContent = 'Upload'
                    document.getElementById('btnCoverPhoto').disabled = false
                }).catch(err => {
                    document.getElementById('previewCoverPhotoText').textContent = 'Failed to upload image'
                    document.getElementById('previewCoverPhotoText').style.color = 'red'
                })


        }, 'image/jpeg', 0.4);
    }


})



// check if am blocked
// let user1Id = document.getElementById('mainUser').textContent
let user2Id = document.getElementById('paramsid').textContent

fetch('/profile_blocked/' + user2Id)
    .then(res => res.json())
    .then(data => {
        // console.log('If I blocked this user: ', data)
        if (data.foundBlocked) {
            console.log('You blocked this user')
            document.getElementById('append-container').style.display = 'none'
            document.querySelector('.post_loading_container').style.display = 'none'
            document.querySelector('.profile_block_message').style.display = 'block'
            return
        }

    })
    .catch(error => {
        console.log(error)
    })




let url4 = '/profile_blocked_two/' + mainUserId + "/" + userId
fetch(url4)
    .then(res => res.json())
    .then(data => {
        // console.log('If am blocked: ', data)
        if (data.foundBlocked) {
            document.getElementById('append-container').style.display = 'none'
            document.querySelector('.post_loading_container').style.display = 'none'
            document.querySelector('.profile_block_message').style.display = 'block'
            return
        }

    })
    .catch(error => {
        console.log(error)
    })



