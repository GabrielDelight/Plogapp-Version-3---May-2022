const socket = io()

let appendFollowing = document.getElementById('appendFollowing')
let users = document.querySelectorAll('.user_details_des');
let mainId = document.getElementById('mainId').textContent
let paramsId = document.getElementById('paramsId').textContent
let userFollowing = document.getElementById('userFollowing').textContent;
let increateFollowing = 10

// Hide current user from followers
let hideMe = document.querySelectorAll('.user_details_des');
for (i = 0; i < hideMe.length; i++) {
    if (hideMe[i].children[2].textContent.includes(mainId)) {
        hideMe[i].children[2].parentElement.parentElement.parentElement.style.display = 'none'
    }
}


let knowWhoFollows = document.querySelectorAll('.follow_div');
for (i = 0; i < knowWhoFollows.length; i++) {
    if (knowWhoFollows[i].textContent.includes(mainId)) {
        knowWhoFollows[i].parentElement.children[0].children[1].children[2].textContent = 'Followed you'
    }else {
        knowWhoFollows[i].parentElement.children[0].children[1].children[2].textContent = 'Following'
    }
}


// Make the following mechanism
let checkFollowing = document.querySelectorAll('.follow_div');
for (i = 0; i < checkFollowing.length; i++) {
    let id = checkFollowing[i].children[1].textContent
    let myFollowers = checkFollowing[i].children[2].textContent
    if (myFollowers.includes(id)) {
        checkFollowing[i].children[0].textContent = 'Following';
        checkFollowing[i].children[0].style.backgroundColor = 'white'        
    } else {
        checkFollowing[i].children[0].style.backgroundColor = 'cornflowerblue'
        checkFollowing[i].children[0].style.color = 'white'
        checkFollowing[i].children[0].textContent = 'Follow'
    }
}


// Follow and Unfollow
let followerBtn = document.querySelectorAll('#followerBtn')
for (i = 0; i < followerBtn.length; i++) {
    followerBtn[i].addEventListener('click', (e) => {
        let followingId = e.target.parentElement.children[5].textContent;
        let mainId = e.target.parentElement.children[3].textContent;

        // show loading button
        let button = e.target
        let loader = e.target.parentElement.children[4]
        button.style.display = 'none'
        loader.style.display = 'block'
        setTimeout(() => {
            loader.style.display = 'none'
            button.style.display = 'block'
            return
        }, 1000);


        fetch('/follow-unfollow', {
            method: 'POST',
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                followingId,
            })
        })
            .then(res => {
                return res.json()
            })

            .then(data => {
                console.log(data)
            })
            .catch(error => {
                console.log(error)
            })


            
        // let followingDetails = {
        //     followingId,
        //     userId: mainId
        // }
        // socket.emit('followingDetails', followingDetails)
        // Change buttonm performance or modify button
        if (e.target.textContent == 'Follow') {
            // e.target.classList.add('btnStyler')
            e.target.style.color = 'black'
            e.target.style.backgroundColor = 'white'
            e.target.style.border = '3px solid cornflowerblue'
            e.target.textContent = 'Following'
            e.target.style.padding = '7px'

        } else {
            e.target.style.backgroundColor = 'cornflowerblue'
            e.target.style.color = 'white'
            e.target.style.padding = '7px 18px'
            e.target.textContent = 'Follow'
        }
    })
}

// triming the over flowting   text
if (window.matchMedia("(max-width: 600px)").matches) {
    let trimBio = document.querySelectorAll('#userBio')
    let nickName = document.querySelectorAll('#nickName')
    trimMultiple(trimBio, 10)
    trimMultiple(nickName, 6)
    function trimMultiple(trim, num){
        for (i = 0; i < trim.length; i++) {
            let str = trim[i].textContent
            if(str.length > num){
                str = str.substr(0, num)
                trim[i].textContent = str + '...'
            }
        }

    }
}



// socket.emit('sendUserIdToGetFollowers', {
//     mainId,
//     paramsId
// })

// // fetch('/follower-api')
// //     .then(result => result.json())

// // // axios.get('/allusers-api')
// //     .then(res => {
//     socket.on('follower-socket', (res) => {
//         function showMoreFollowingFunction(val) {
//             // let data = res.data.splice(0, val)
//             let data = res.splice(0, val)
//             data.forEach(cur => {
//                 appendFollowing.innerHTML += `
//                     <div class="wrapper_for_all">
//                         <div class="wrap_user_div">
//                             <div class="user_img">
//                                 <a href="/profile/${cur._id}">
//                                     <img src="/userPostAvatar/${cur._id}" alt="">
//                                 </a>
//                             </div>
//                             <div class="user_details_des">
//                                 <a href="/profile/${cur._id}">
//                                     <p>${cur.firstname} ${cur.lastname} <span><i class="${cur.verified}"></i></span> </p>
//                                 </a>
//                                 <p id="followTExt">Follower</p>
//                                 <p style="display: none;">${cur._id}</p>
//                                 <p style="display: none;">${cur.following}</p>
                                
//                             </div>
//                         </div>
//                         <div class="follow_div">
//                             <button id="followerBtn" style="border: none;">Follower</button>
//                             <p style="display: none;">${cur._id}</p>
//                             <p style="display: none;">${userFollowing}</p>
//                             <p style="display: none;">${mainId}</p>
//                             <div class="loader"></div>
//                         </div>
//                     </div> `

//                 // Hide current user from followers
//                 let hideMe = document.querySelectorAll('.user_details_des');
//                 for (i = 0; i < hideMe.length; i++) {
//                     if (hideMe[i].children[2].textContent.includes(mainId)) {
//                         hideMe[i].children[2].parentElement.parentElement.parentElement.style.display = 'none'
//                     }
//                 }

//                 // Make the following mechanism
//                 let checkFollowing = document.querySelectorAll('.follow_div');
//                 for (i = 0; i < checkFollowing.length; i++) {
//                     let id = checkFollowing[i].children[1].textContent
//                     let myFollowers = checkFollowing[i].children[2].textContent
//                     if (myFollowers.includes(id)) {
//                         checkFollowing[i].children[0].textContent = 'Following';
//                         checkFollowing[i].children[0].style.backgroundColor = 'white'
//                         checkFollowing[i].style.color = 'black'
//                         checkFollowing[i].classList.add('btnStyler')
//                     } else {
//                         checkFollowing[i].children[0].style.backgroundColor = 'cornflowerblue'
//                         checkFollowing[i].children[0].style.color = 'white'
//                         checkFollowing[i].children[0].style.padding = '7px 18px'
//                         checkFollowing[i].children[0].textContent = 'Follow'
//                     }
//                 }


//                 // Follow and Unfollow
//                 let followerBtn = document.querySelectorAll('#followerBtn')
//                 for (i = 0; i < followerBtn.length; i++) {
//                     followerBtn[i].addEventListener('click', (e) => {
//                         let followingId = e.target.parentElement.children[1].textContent;
//                         let mainId = e.target.parentElement.children[3].textContent;

//                         // show loading button
//                         let button = e.target
//                         let loader = e.target.parentElement.children[4]
//                         button.style.display = 'none'
//                         loader.style.display = 'block'
//                         setTimeout(() => {
//                             loader.style.display = 'none'
//                             button.style.display = 'block'
//                             return
//                         }, 1000);


//                         let followingDetails = {
//                             followingId,
//                             userId: mainId
//                         }
//                         socket.emit('followingDetails', followingDetails)
//                         // Change buttonm performance or modify button
//                         if (e.target.textContent == 'Follow') {
//                             // e.target.classList.add('btnStyler')
//                             e.target.style.color = 'black'
//                             e.target.style.backgroundColor = 'white'
//                             e.target.style.border = '1px solid gray'
//                             e.target.textContent = 'Following'
//                             e.target.style.padding = '7px'

//                         } else {
//                             e.target.style.backgroundColor = 'cornflowerblue'
//                             e.target.style.color = 'white'
//                             e.target.style.padding = '7px 18px'
//                             e.target.textContent = 'Follow'
//                         }
//                     })
//                 }

//             })

//             if(data.length === 0 || data.length < 12 ){
//                 document.querySelector('.loading_data').style.display = 'none'
//             }
//         }

//         showMoreFollowingFunction(12)

//         window.onscroll = function () {
//             if ((window.innerHeight + window.pageYOffset) >= document.body.offsetHeight) {
//                 showMoreFollowingFunction(increateFollowing++)
//             }
//         }

//     })

//     // .catch(err => {
//     //     console.log(err, 'Error')
//     // })

