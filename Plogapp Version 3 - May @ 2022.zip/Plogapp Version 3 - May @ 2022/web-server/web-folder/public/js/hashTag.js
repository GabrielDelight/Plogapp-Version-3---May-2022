var victims = document.querySelectorAll('p.hashTag');
for (var i = 0; i < victims.length; i++) {
  if (victims[i].hasChildNodes) {
    var padLeft = document.createTextNode(" ");
    var padRight = document.createTextNode("");
    victims[i].appendChild(padRight);
    victims[i].insertBefore(padLeft, victims[i].firstChild);
  }
}
var siteURL = '/hashTag',
  entries = document.querySelectorAll('p.hashTag'),
  i;

var urlRegex = /(((https?:\/\/)|(www\.))[^\s]+)/g;

if (entries.length > 0) {
  for (i = 0; i < entries.length; i++) {
    if ((entries[i].innerHTML.indexOf("]") == -1) && (entries[i].innerHTML.indexOf("=") == -1)) {
      // @ For hansh tag and links
      entries[i].innerHTML = entries[i].innerHTML.replace(/((?!([\S]))[\S\s])#(\p{L}+)/gu, ' <a href="' + siteURL + '/$3" class="hashlink" title="">#$3</a>');
    }


    entries[i].innerHTML = entries[i].innerHTML.replace(urlRegex, function (url) {
      var hyperlink = url;
      if (!hyperlink.match('^https?:\/\/')) {
        hyperlink = 'http://' + hyperlink;
      }
      return '<a href="' + hyperlink + '" class="hashlink" target="_blank" >' + url + '</a>'
    })

  }
}