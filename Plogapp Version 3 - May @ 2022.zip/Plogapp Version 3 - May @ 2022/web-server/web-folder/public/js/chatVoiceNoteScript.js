// let socket = io()
// let sound = document.getElementById('sound')
// @ Recording voice note
function scrollUpUsers() {
    let x = document.querySelector('.main_chat_body_content')
    x.scrollTop = x.scrollHeight
}


// Playing voice note or video
//(1.) Set the loader to change height for all 
function toggleLoader() {
    let vcLoader = document.querySelectorAll('.init .animateLoader')
    for (i = 0; i < vcLoader.length; i++) {
        vcLoader[i].classList.add('pauseAnimation')
    }
}

setTimeout(() => {
    let vcLoader = document.querySelectorAll('.init .animateLoader')
    for (i = 0; i < vcLoader.length; i++) {
        vcLoader[i].classList.add('pauseAnimation')
    }
}, 6243);



// Main function when audio is clicked from the voice not on page
let globalVnAudio = document.getElementById('globalVnAudio')
let audioTiming = document.getElementById('audioTiming')
function playVnBtn(audio) {
    document.querySelector('.playing_voice_note').style.transform = 'scale(1)'
    globalVnAudio.src = audio

    globalVnAudio.play()

    setInterval(() => {
        let seconds = globalVnAudio.currentTime
        let minutes = Math.floor((seconds / 60))
        let secs = Math.floor((seconds % 60))
        audioTiming.textContent = minutes + ':' + secs


        if (globalVnAudio.currentTime == globalVnAudio.duration) {
            globalVnAudio.pause()
            document.querySelector('.playing_voice_note').style.transform = 'scale(0)'
            for (i = 0; i < playVoiceNote.length; i++) {
                playVoiceNote[i].style.color = 'white'
            }
        }

    }, 0);
}

// CLosing the palying voice note function
document.getElementById('closePlayingVn').addEventListener('click', e => {
    document.querySelector('.playing_voice_note').style.transform = 'scale(0)'
    globalVnAudio.pause()

    for (i = 0; i < playVoiceNote.length; i++) {
        playVoiceNote[i].style.color = 'white'
    }

})



// Deleting voice note 
// delete voice note function 
function deleteVoiceNoteFun(val) {
    console.log(val)
    fetch('/delete-voice-note', {
        method: 'POST',
        headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            id: val,
        })
    })
        .then(res => {
            return res.json()
        })
        .then(data => {

            if (data.success) {
                let ch_record_chat_list = document.querySelectorAll('.ch_record_chat_list')
                for (i = 0; i < ch_record_chat_list.length; i++) {
                    let x = ch_record_chat_list[i].classList[1].replace(/'/g, '') == val.toString()
                    if (x) {
                        ch_record_chat_list[i].innerHTML = '<small>Voice note deleted</small>'
                        ch_record_chat_list[i].style.textAlign = 'right'
                    }
                }
            }
        })
        .catch(error => {
            console.log(error)
        })

}








// Recording oice node function 
let vc_sec = document.getElementById('vc_sec')
let vc_min = document.getElementById('vc_min')
let downloadObj = {}
function firstGlobalFunction() {
    let sec = 0;
    let min = 0
    let intervalId = setInterval(() => {
        sec += 1

        if (sec >= 59) {
            sec = 0;
            min += 1
        }
        vc_sec.textContent = sec
        vc_min.textContent = min
        downloadObj.audioTime = min + ":" + sec
        if (min >= 2) {
            clearIntervalFunction()
            stopRecording()
        }
    }, 1000);


    function clearIntervalFunction() {
        clearInterval(intervalId)
        let vcLoader = document.querySelectorAll('.animateLoader')
        for (i = 0; i < vcLoader.length; i++) {
            // vcLoader[i].classList.toggle('pauseAnimation')
        }

    }

    document.getElementById('stopRecord').addEventListener('click', e => {
        clearIntervalFunction()
    })


    document.querySelector('.cancelVnRecorder').addEventListener('click', e => {
        clearIntervalFunction()
    })


}


async function getUserMedia(constraints) {
    if (navigator.mediaDevices) {
        return navigator.mediaDevices.getUserMedia(constraints)
    }

    let legacyApi = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia;

    if (legacyApi) {
        return new Promise(function (resolve, reject) {
            legacyApi.bind(navigator)(constraints, resolve, reject)
        })
    } else {
        alert('user api not supported')
    }
}


function startusingBrowserMicrophone(boolean) {
    getUserMedia({ audio: boolean }).then(stream => {
        handlerFunction(stream)
    })
}

function handlerFunction(stream) {
    rec = new MediaRecorder(stream);
    rec.ondataavailable = e => {
        audioChunks.push(e.data);
        if (rec.state == "inactive") {
            let blob = new Blob(audioChunks, { type: 'audio/mp3' });
            downloadObj.file = blob
            console.log(blob)
        }
    }
}

// Start recording
startusingBrowserMicrophone(true)
document.getElementById('startRecording').addEventListener('click', () => {
    let intervalCount = 0


    setTimeout(() => {
        document.querySelector('.vc_record_container').style.display = 'block'
        firstGlobalFunction()
        audioChunks = [];
        rec.start();

        socket.emit('sendTyping', {
            activity: 'recording audio...',
            receiverId: location.href.substr(-24, location.href.length),
            owner: myId,
        })
        let vcLoader = document.querySelectorAll('.animateLoader')
        for (i = 0; i < vcLoader.length; i++) {
            vcLoader[i].classList.remove('pauseAnimation')
        }

    }, intervalCount);

})

// Stop recording video function
function stopRecording(params) {
    rec.stop();
    socket.emit('sendTyping', {
        activity: '',
        receiverId: location.href.substr(-24, location.href.length),
        owner: myId,
    })
}


// Cancel recording and delete




// Stop recording and save 
document.getElementById('stopRecord').addEventListener('click', () => {
    sendVoiceNoteFunction(true)
})


document.querySelector('.cancelVnRecorder').addEventListener('click', e => {
    sendVoiceNoteFunction(false)
})

function sendVoiceNoteFunction(boo) {
    document.querySelector('.vc_record_container').style.display = 'none'
    // Stop recording function
    stopRecording()

    vc_sec.textContent = 0
    vc_min.textContent = 0
    if (!boo) return
    setTimeout(() => {
        document.querySelector('.sending_status').style.display = 'block';

        let data = new FormData()
        data.append('uploads', downloadObj.file)
        data.append('voiceNoteTime', downloadObj.audioTime)
        
        fetch('/voiceNoteUpload/' + location.href.substr(-24, location.href.length), {
            method: 'POST',
            body: data
        })
            .then(res => res.json())
            .then(data => {
                document.querySelector('.sending_status').style.display = 'none';
                let cur = data
                console.log(cur)
                let html =
                    `
                <div class="friend_chat_box pushAudioRight" id="chat_container_box">
                        <div class="ch_record_chat_list  '${cur.chatsenderId.randomId}'" style="display: ${cur.hideVoiceNote};">
                            <div class="vc_chat_hd">
                            <p style="font-size: 12px;"> <i class="fa fa-microphone" ></i> <small> ${cur.date}</small>-|-<small> ${cur.voiceNoteTime}</small> </p>
                    
                                <div class="cv_option_relative">
                                    <i class="fa fa-ellipsis-v" onclick="this.parentElement.children[1].style.display = 'block'"></i>
                    
                                    <div class="main_vc_chat_option" style="display: none;">
                                        <div class="vc_option_absolute_list">
                                            <div>
                                                <p id="deleteVoiceNoteBtn" onclick="deleteVoiceNoteFun('${cur.chatsenderId.randomId}')">Delete</p>
                                            </div>
                                            <div class="close_vc_option">
                                                <i onclick="this.parentElement.parentElement.parentElement.style.display = 'none'"
                                                    class="fa fa-close"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                    
                            </div>
                    
                            <div class="cv_sender_recievers_img">
                                <div class="audio_vc_loader">
                                    <div class="box init">
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                    
                                    </div>
                                </div>
                                <div class="vc_play_btn">
                                    <i id="playVoiceNote" onclick="playVnBtn('https://plogapp.s3.amazonaws.com/${cur.voiceNote}')" class="fa fa-circle"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                
                
                `


                appendChatMessages.insertAdjacentHTML('beforeend', html)
                scrollUpUsers()
                toggleLoader()
                changeIconbtn()

            }).catch(err => {
                document.querySelector('.sending_status').style.display = 'none';
                console.log(err)
            })

    }, 1000);
}




// document.getElementById('stopRecordingAudio').addEventListener('click', e => {
//     console.log('canceling record')
//     // sendVoiceNoteFunction(false)
//     document.querySelector('.vc_record_container').style.display = 'none'
//     // Stop recording function
//     // stopRecording()

//     vc_sec.textContent = 0
//     vc_min.textContent = 0

//     // getUserMedia({ audio: true }).then(stream => {
//     //     stream.getTracks().forEach(function (track) {
//     //         track.stop();
//     //     });
//     // })
// })


// Immediately append voice note to the secod user
socket.on('voiceNoteListen', (data) => {
    console.log(data)
    let cur = data
    if (data.receiverId === myId && data.owner === location.href.substr(-24, location.href.length)) {
        let html = `
        <div class="friend_chat_box pushAudioLeft" id="chat_container_box">
                        <div class="ch_record_chat_list  '${data.chatReveiverId.randomId}'" style="display: ${cur.hideVoiceNote};">
                            <div class="vc_chat_hd">
                                
                                <p style="font-size: 12px;"> <i class="fa fa-microphone" ></i> <small> ${cur.date}</small>-|-<small> ${cur.voiceNoteTime}</small> </p>
                    
                                <div class="cv_option_relative">
                                    <i class="fa fa-ellipsis-v" onclick="this.parentElement.children[1].style.display = 'block'"></i>
                    
                                    <div class="main_vc_chat_option" style="display: none;">
                                        <div class="vc_option_absolute_list">
                                            <div>
                                                <p id="deleteVoiceNoteBtn" onclick="deleteVoiceNoteFun('${data.chatReveiverId.randomId}')">Delete</p>
                                            </div>
                                            <div class="close_vc_option">
                                                <i onclick="this.parentElement.parentElement.parentElement.style.display = 'none'"
                                                    class="fa fa-close"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                    
                            </div>
                    
                            <div class="cv_sender_recievers_img">
                                <div class="audio_vc_loader">
                                    <div class="box init">
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                                        <div class="animateLoader"></div>
                    
                                    </div>
                                </div>
                                <div class="vc_play_btn">
                                    <i id="playVoiceNote" onclick="playVnBtn('https://plogapp.s3.amazonaws.com/${cur.voiceNote}')" class="fa fa-circle"></i>
                                </div>
                            </div>
                        </div>
                    </div>`

        appendChatMessages.insertAdjacentHTML('beforeend', html)
        scrollUpUsers()
        toggleLoader()
        changeIconbtn()

    }
})



// 2. chnage the play icon when 

function changeIconbtn() {
    let playVoiceNote = document.querySelectorAll('#playVoiceNote')
    for (i = 0; i < playVoiceNote.length; i++) {
        playVoiceNote[i].addEventListener('click', e => {
            let icon = e.target
            icon.style.color = 'cornflowerblue'
        })
    }

}