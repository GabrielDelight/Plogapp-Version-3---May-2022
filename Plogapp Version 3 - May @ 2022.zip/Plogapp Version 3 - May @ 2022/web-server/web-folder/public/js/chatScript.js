// (function () {

let input = document.getElementById('myInput');
let messageAppender = document.getElementById('appendChatMessages')
let myName = document.getElementById('myName').textContent
let myId = document.getElementById('myId').textContent
let replyInput = document.getElementById('replyInputForChat')


let chat_navigation_back_button = document.getElementById('backArrow')
chat_navigation_back_button.addEventListener('click', e => {
    document.querySelector('.mobile_nav_container').style.display = 'block'
})

function chatGlobalFunction(chatGlobalObject) {
    const socket = io()

    // document.querySelector('.chat_form_container').style.display = 'block'
    document.querySelector('.globalCHatHead').style.display = 'block'
    // document.querySelector('#HideEmptyConversation').style.display = 'none'



    document.getElementById('myInput').focus()

    // coming from chatnotification.js in let chatGlobalObject ={}
    let recepientId = chatGlobalObject.recipientId
    let receiverName = chatGlobalObject.receiverName


    // Date
    let monthsArray;
    let month;
    let newMonth;
    let day = new Date().getDate();
    let year = new Date().getFullYear();
    let time = new Date().toLocaleTimeString();
    // monthsArray = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    monthsArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
    month = new Date().getMonth();
    newMonth = monthsArray[month];
    let newYr = year.toString().substr(2)
    let fullDateStr = `${day}/${newMonth}/${newYr}`
    input.focus()
    let sendBtn = document.querySelector('.send_icon');
    sendBtn.style.display = 'none'
    document.addEventListener('input', () => {
        if (input.value == '') {
            sendBtn.style.display = 'none'
            document.querySelector('.v_n_recorder_div').style.display = 'block'
        } else {
            sendBtn.style.display = 'block'
            document.querySelector('.v_n_recorder_div').style.display = 'none'
        }
    })


    document.getElementById('btn').addEventListener('click', () => {
        submittingFUnction()
    })

    function submittingFUnction() {
        if (input.value.trim() == '') {
            return
        }

        //for mobile view set the textarea bottom to normal
        document.querySelector('.chat_form_container').style.bottom = '-5px'
        // console.log(chatGlobalObject)
        // Sending the chat that displays on receiver 
        let saveData = {
            owner: myId,
            message: input.value,
            date: fullDateStr,
            receiverId: chatGlobalObject.recipientId,
            ownerName: chatGlobalObject.receiverName,
            replyOldMessage: replyInput.value,
            receiverName
        }

        // console.log(saveData)

        socket.emit('saveChat', saveData)

        // sending my own chat
        let myChat = {
            owner: myId,
            message: input.value,
            date: fullDateStr,
            receiverId: chatGlobalObject.recipientId,
            ownerName: chatGlobalObject.receiverName,
            replyOldMessage: replyInput.value,
            receiverName
        }

        socket.emit('myChat', myChat)
        socket.emit('sendHideTyping', {
            activity: '',
            receiverId: recepientId,
            owner: myId,
        })

        sendBtn.style.display = 'none'
        document.querySelector('.v_n_recorder_div').style.display = 'block'
        document.getElementById('myInput').focus()
        input.value = ''
    }





    // Check is user is online or not
    setInterval(() => {
        socket.emit('user_is_online', {
            owner: myId,
            secondUser: chatGlobalObject.recipientId
        })

        document.getElementById('activeStatus').textContent = ''
    }, 10000);

    // return is user is alreay active
    socket.on('say_user_is_active', data => {
        console.log('Activw')
        if (data.owner == myId) {
            console.log('User is active')
            document.getElementById('activeStatus').textContent = data.status
        }
    })





    // ************************************************************************************************************************************
    // ************************************************************************************************************************************




    // Show typing
    oninput = function () {
        socket.emit('sendTyping', {
            activity: 'is typing...',
            receiverId: recepientId,
            owner: myId,
        })



        if (input.value == '') {
            socket.emit('sendHideTyping', {
                activity: '',
                receiverId: recepientId,
                owner: myId,
            })

            document.querySelector('.chat_form_container').style.bottom = '-5px'
        }

    }

    socket.on('showTyping', (data) => {
        if (data.receiverId === myId && data.owner === recepientId) {
            let typing = document.getElementById('typing')
            typing.textContent = data.activity
        }
    })



    // Hide  typing and show active
    socket.on('showHideTyping', (data) => {
        if (data.receiverId === myId && data.owner === recepientId) {
            let typing = document.getElementById('typing')
            typing.textContent = data.activity
        }
    })



    // ACtive status router
    // let userId = document.getElementById('socketId').textContent
    socket.emit('sendUserDetails', myId)
    socket.emit('idForDisconnection', myId)



    //chat image upoload
    let imageDetails = {
        owner: myId,
        message: input.value,
        ownerName: myName,
        date: fullDateStr,
        receiverId: recepientId,
        receiverName
    }
    socket.emit('imageDetails', imageDetails)


    // Chat emogi
    let emogi = document.querySelectorAll('#emogi')
    for (i = 0; i < emogi.length; i++) {
        emogi[i].addEventListener('click', (e) => {
            input.value += e.target.textContent
            sendBtn.style.display = 'block'
        })

    }

    // document.querySelector('.main_chat_body_content').scrollTop += 99989999999400
    setTimeout(() => {
        let element = document.querySelector('.main_chat_body_content')
        element.scrollTop = element.scrollHeight + element.clientHeight
    }, 2000);



    // confirm delete all message
    document.addEventListener('click', (e) => {
        if (e.target.classList == 'confirmDeleteChat') {
            document.querySelector('.confirmDeleteChat').style.display = 'none'
        }
    })

    document.getElementById('confirmDeleteChatbtn').addEventListener('click', e => {
        let receiverIdx = location.href.substr(-24, location.href.length)
        console.log(receiverIdx)
        let a = document.createElement('a')
        a.href = '/deleteAllChat/' + receiverIdx
        a.click()
    })





    // Search for chat
    let messageDiv = document.querySelectorAll('#searchQuery')
    let searchImput = document.getElementById('searchChat')
    document.addEventListener('input', (e) => {
        for (i = 0; i < messageDiv.length; i++) {
            let str = searchImput.value.toLowerCase()
            if (messageDiv[i].textContent.includes(str)) {
                messageDiv[i].parentElement.style.display = 'block'
            } else {
                messageDiv[i].parentElement.style.display = 'none'
            }
        }
    })


    let lastChatMsg = document.querySelectorAll('.chat_messages_details__ p')
    for (i = 0; i < lastChatMsg.length; i++) {
        let str = lastChatMsg[i].textContent
        lastChatMsg[i].textContent = str.substr(0, 17)
    }




    // Blocking script +++++++++++++++++++++++++
    // Url coming from settings.js
    let domainUrl = '/'
    // blocking a user
    let blckingId = location.href.substr(-24, location.href.length)

    let blockUser = document.querySelectorAll('#blockUser')
    for (i = 0; i < blockUser.length; i++) {
        blockUser[i].addEventListener("click", e => {
            let url = domainUrl + 'blocking_rout/' + myId + "/" + location.href.substr(-24, location.href.length)
            fetch(url)
                .then(res => res.json())
                .then(data => {
                    // console.log(data.message)
                    // if (data.message == 'unblocked') {
                    //     document.querySelector('.blocked_account_div').style.display = 'none'
                    //     // document.querySelector('.chat_form_container').style.display = 'block'
                    //     // eventsTxt.textContent = 'Unblock'
                    //     let blockUser = document.querySelectorAll('#blockUser')
                    //     for (i = 0; i < blockUser.length; i++) {
                    //         blockUser[i].textContent = 'Block'
                    //     }
                    //     return
                    // }

                    // document.querySelector('.blocked_account_div').style.display = 'block'
                    // document.querySelector('.chat_form_container').style.display = 'none'
                    // document.querySelector('.settings_controller').style.display = 'none'

                    // // eventsTxt.textContent = 'Unblock'
                    // let blockUser = document.querySelectorAll('#blockUser')
                    // for (i = 0; i < blockUser.length; i++) {
                    //     blockUser[i].textContent = 'Unblock'
                    // }

                })
                .catch(error => {
                    console.log(error)
                })
        })
    }


    // check if user is in block list
    // window.onload = function () {
    checkIfUserIBlock
    setInterval(checkIfUserIBlock, 2000)
    function checkIfUserIBlock() {

        let url2 = domainUrl + 'show_blocked_users/' + myId + "/" + location.href.substr(-24, location.href.length)
        
        fetch(url2)
            .then(res => res.json())
            .then(cur => {
                // console.log(cur)
                if (cur.foundBlocked) {
                    document.querySelector('.blocked_account_div').style.display = 'block'
                    document.querySelector('.chat_form_container').style.display = 'none'
                    document.querySelector('.settings_controller').style.display = 'none'

                    // eventsTxt.textContent = 'Unblock'
                    let blockUser = document.querySelectorAll('#blockUser')
                    for (i = 0; i < blockUser.length; i++) {
                        blockUser[i].textContent = 'Unblock'
                        blockUser[i].style.display = 'none'
                    }

                    
                    return
                }else {
                    document.querySelector('.blocked_account_div').style.display = 'none'
                    document.querySelector('.chat_form_container').style.display = 'block'
                    document.querySelector('.settings_controller').style.display = 'block'

                    // eventsTxt.textContent = 'Unblock'
                    let blockUser = document.querySelectorAll('#blockUser')
                    for (i = 0; i < blockUser.length; i++) {
                        blockUser[i].textContent = 'Block Chat'
                        blockUser[i].style.display = 'block'
                    }
                }
            })
            .catch(error => {
                console.log(error)
            })

    }



    // check if am blocked
    let url3 = domainUrl + 'if_user_is_blocked/' + myId + "/" + location.href.substr(-24, location.href.length)
    fetch(url3)
        .then(res => res.json())
        .then(data => {
            // console.log('If am blocked: ', data)
            if (data.foundBlocked) {
                setInterval(() => {
                    document.querySelector('.blocked_account_div').style.display = 'block'
                    document.querySelector('.chat_form_container').style.display = 'none'
                    document.querySelector('.settings_controller').style.display = 'none'

                    document.querySelector('#blockedPara').textContent = 'This user is is unavailable'
                    let blockUser = document.querySelectorAll('#blockUser')
                    for (i = 0; i < blockUser.length; i++) {
                        blockUser[i].style.display = 'none'
                    }
                }, 1000);
                return
            }


        })
        .catch(error => {
            console.log(error)
        })
    // }

    let OpenBlockList = document.querySelectorAll('#OpenBlockList')
    for (i = 0; i < OpenBlockList.length; i++) {
        OpenBlockList[i].addEventListener('click', e => {
            document.querySelector('.blocked_account_section').style.display = 'block'
            fetch('/fetch_blocked_users/' + myId)
                .then(res => res.json())
                .then(data => {
                    // console.log(data)
                    // console.log(data.length)
                    if (data.length < 1) {
                        document.getElementById('appendBlockedUsers').innerHTML = 'No blocked user found'
                        return
                    }
                    document.getElementById('appendBlockedUsers').innerHTML = ''
                    data.map(cur => {
                        document.getElementById('appendBlockedUsers').innerHTML += `
    
                                <div class="oveflow_div_container">
                                    <div class="blocked_user_div">
                                        <div class="block_profile_name">
                                            <div>
                                                <img id="imgPmody_prev2" src="/webStorage/avatar/${cur.avatar}" alt="">
                                            </div>
                                            <p>${cur.firstname}  ${cur.lastname}</p>
                                        </div>
                                        <div class="unblock_btn_blocked">
                                            <button id="unblockBtn">Unblock</button>
                                            <p style="display: none;">${cur.id}</p>
                                        </div>
                                    </div>
                                </div> `

                        let unblockBtn = document.querySelectorAll('#unblockBtn')
                        for (i = 0; i < unblockBtn.length; i++) {
                            unblockBtn[i].addEventListener('click', e => {
                                let blockedId = e.target.parentElement.children[1].textContent
                                let parentDiv = e.target.parentElement.parentElement
                                let url = domainUrl + 'blocking_rout/' + myId + "/" + recepientId

                                fetch(url)
                                    .then(res => res.json())
                                    .then(data => {


                                        // console.log(data.message)
                                        if (data.message == 'unblocked') {
                                            // console.log("User unblocked")
                                            parentDiv.style.display = 'none'
                                            return
                                        }

                                        // console.log('blocked the user')

                                    })
                                    .catch(error => {
                                        console.log(error)
                                    })
                            })
                        }

                    })
                })
                .catch(error => {
                    console.log(error)
                })
        })
    }

}

function pushOutIncomingMsg() {
    document.querySelector('.incloming_message').classList.toggle('pushOutIncomeing')
}


// /Append normal chat to my browser if I send 
socket.on('displayMessageForOwner', (data) => {
    // console.log(data)
    if (data.owner == myId) {
        if (data.replyOldMessage == '') {
            let html = `
                <div class="friend_chat_box pushRight" id="chat_container_box">
                    <div class="friends_image2"></div>
                    <div class="friend_chat_details"></div>
                    <div>
                        <div>
                            <div class="chat_text_box">
                                <p id="stylerColor" class="chatMessage">$message$</p>
                                <p style="display: none;">$randomId$</p>
                            </div>
                         </div>
                    </div>
                </div>`
            let validate = data.message
            validate = validate.replace(/</g, '')
            validate = validate.replace(/>/g, '')
            html = html.replace('$message$', validate);
            html = html.replace('$randomId$', data.randomId1ForNormalChat)
            messageAppender.insertAdjacentHTML('beforeend', html)


            scrollUpUsers()
            chatActivity()


        } else {
            // Append reply -chat
            let html = `
                <div class="friend_chat_box replyPushRight" id="chat_container_box">
                    <div class="friends_image2"></div>
                    <div class="friend_chat_details">
                            <div class="reply_old_text"><span>%replyingMessage%</span></div>
                            <div>
                                <div class="chat_text_box blueColor">
                                    <p id="stylerColor" class="hashTag chatMessage" style="font-size: 12px;">$message$</p>
                                    <p style="display: none;">$randomId$</p>
                                </div>
                            </div>
                    </div>
                </div>`

            let validate = data.message
            validate = validate.replace(/</g, '')
            validate = validate.replace(/>/g, '')

            html = html.replace('$message$', validate);
            html = html.replace('%replyingMessage%', replyInput.value);
            html = html.replace('$randomId$', data.randomIdForReply)



            messageAppender.insertAdjacentHTML('beforeend', html)
            console.log(data)
            socket.emit('sendHideTyping', {
                activity: '',
                receiverId: data.recepientId,
                owner: myId,
            })


            input.value = ''
            replyInput.value = ''
            // document.querySelector('.send_icon').sendBtn.style.display = 'none';


            scrollUpUsers()
            document.getElementById('myInput').focus()
            chatActivity()
            // close  the replying
            document.querySelector('.reply_chat_sample').style.display = 'none'
        }
    }
})



// APped chat to client ************************************************************************************************
let sound = document.getElementById('sound')
socket.on('displayMessage', (data) => {
    let receiverId = location.href.substr(-24, location.href.length)
    if (data.receiverId === myId && data.owner === receiverId) {
        if (data.replyOldMessage == '') {
            let newhtml = `
             <div class="friend_chat_box pushLeft" id="chat_container_box">
                 <div class="friends_image2"></div>
                 <div class="friend_chat_details">
                     <div class="date--name2"></div>
                     <div class="chat_text_box blueColor">
                         <p class="chatMessage">$message$</p>
                         <p style="display: none;">$randomId$</p>
                     </div>
                 </div>
             </div>
            `
            let validate = data.message
            validate = validate.replace(/</g, '')
            validate = validate.replace(/>/g, '')
            newhtml = newhtml.replace('$message$', validate)
            newhtml = newhtml.replace('$randomId$', data.randomChatId1x)
            messageAppender.insertAdjacentHTML('beforeend', newhtml)

            document.getElementById('myInput').focus()
            scrollUpUsers()
            sound.play()
            chatActivity()

        } else {
            // Logging chat with reply 
            let newhtml = `
             <div class="friend_chat_box replyPushLeft" id="chat_container_box">
                 <div class="friends_image2"></div>
                 <div class="friend_chat_details">
                     <div class="reply_old_text"><span>%replyingMessage%</span></div>
                     <div class="chat_text_box blueColor">
                         <p id="stylerColor" class="chatMessage">$message$</p>
                         <p style="display: none;">${data.randomIdForReplyCHat} hey</p>
                     </div>
                 </div>
             </div>
             `
            let validate = data.message
            validate = validate.replace(/</g, '')
            validate = validate.replace(/>/g, '')
            newhtml = newhtml.replace('$message$', validate)
            newhtml = newhtml.replace('%replyingMessage%', data.replyOldMessage)
            messageAppender.insertAdjacentHTML('beforeend', newhtml)

            document.getElementById('myInput').focus()

            scrollUpUsers()
            sound.play()
            chatActivity()

        }
        // console.log('Hello wolrd', readMessageFunction())
        console.log(window.navigator.onLine)
        socket.emit('checkCOnnection', {
            isOnline: window.navigator.onLine
        })
        // fetch('/check_messages_read/' + receiverId)
        //     .then(result => result.json())
        //     .then(data => {
        //         console.log(data)
        //     }).catch(error => {
        //         console.log(error)
        //     })


    }


    // Display incomming chat message
    if (data.receiverId == myId) {
        document.getElementById('incomingImg').src = '/webStorage/avatar/' + data.avatar
        document.getElementById('incomingName').textContent = data.ownerName
        document.getElementById('incomingMsg').textContent = data.message

        pushOutIncomingMsg()
        setTimeout(() => {
            pushOutIncomingMsg()
        }, 2000);

    }

})




// togglin upload container
function toggleUplaodFiles() {
    document.querySelector('.global_files_container').classList.toggle('toggle_upload_modal')
}

document.getElementById('openUpoadContainer').addEventListener('click', e => {
    // console.log("Hello")
    toggleUplaodFiles()
})

// opening and closing  chat files
document.querySelector('.global_files_container').addEventListener('click', (e) => {
    if (e.target.classList == 'global_files_container toggle_upload_modal') {
        toggleUplaodFiles()
    }
})



let optionBtn = document.getElementById('toggleChatDivOption')
let toggle_option_div = document.querySelector('.absolute_settings_div_wrapper')

function toggleChatDivOption(e) {
    toggle_option_div.classList.toggle('toggle_chat_option_div')
    // optionBtn.className = e
    // console.log(e)
}



optionBtn.addEventListener('click', e => {
    console.log(toggle_option_div.className)

    if (optionBtn.className == 'fa fa-close') {
        optionBtn.className = 'fa fa-ellipsis-v'
    } else {
        optionBtn.className = 'fa fa-close'
    }
    toggleChatDivOption()

    // if (toggle_option_div.classList == 'absolute_settings_div_wrapper light_dark_div toggle_chat_option_div    '){
    //     console.log('Same')
    //     return

    // }else {
    //     toggleChatDivOption('fa fa-close')
    // }
})



function reportFunction(){
    console.log('hello', )
    location.href = `/report?type=account&&victim=${location.href.substr(-24, location.href.length)}`
}
