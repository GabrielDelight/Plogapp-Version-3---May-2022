(function () {
    const socket = io()

    let commentLength = document.getElementById('commentLength')
    let appendComments = document.getElementById('appendComments')
    let myInput = document.getElementById('myInput')
    let redirectId = document.getElementById('redirectId')
    let uploadCommentImage = document.querySelector('.uploadCommentImage')
    let postId = document.getElementById('postId')


    // Display someone is typing
    myInput.oninput = function () {
        socket.emit('isTyoingInPost', {
            text: 'Someone is typing...',
            postId: postId.textContent
        })

        if (myInput.value == '') {
            socket.emit('cancelIsTyping', {
                text: 'All Comments',
                postId: postId.textContent
            })
        }
    }

    socket.on('istypingResult', data => {
        if (postId.textContent === data.postId) {
            document.getElementById('someONIsTyping').textContent = data.text
        }
    })

    function scrollUpUsers() {
        let x = document.querySelector('body')
        x.scrollTop = x.scrollHeight
    }

    // append post with and using fetch api
    let subMitBtn = document.querySelectorAll('#commentBtnIcon')
    for (i = 0; i < subMitBtn.length; i++) {
        subMitBtn[i].addEventListener('click', e => {
            if (myInput.value.trim() === '') return
            let data = new FormData()
            data.append('uploadImg', uploadCommentImage.files[0])
            data.append('comment', myInput.value)
            data.append('redirectId', redirectId.value)
            data.append('commentLength', commentLength.value)

            fetch('/getComment', {
                method: 'POST',
                body: data
            })
                .then(res => res.json())
                .then(data => {
                    if (data.errormsg) {
                        document.getElementById('errorMsg').textContent = data.errormsg
                        setTimeout(() => {
                            document.getElementById('errorMsg').textContent = ''
                        }, 4000);
                        return
                    }
                    commentLoaderFunction()
                }).catch(err => {
                    console.log(err)
                })

            myInput.value = ''
        })

    }


    let shareSubmiteBtn = document.querySelectorAll('#share_commentingOnnCharePost')
    for (i = 0; i < shareSubmiteBtn.length; i++) {
        shareSubmiteBtn[i].addEventListener('click', e => {
            let data = new FormData()
            data.append('uploadImg', uploadCommentImage.files[0])
            data.append('comment', myInput.value)
            data.append('redirectId', redirectId.value)
            data.append('commentLength', commentLength.value)

            fetch('/shareComment', {
                method: 'POST',
                body: data
            })
                .then(res => res.json())
                .then(data => {
                    commentLoaderFunction()
                    // appendCommentFunction(data)
                    // console.log('Success')
                }).catch(err => {
                    console.log(err)
                })

            myInput.value = ''
        })
    }


    mainPublickFunction()
    function mainPublickFunction() {
        // Check if post is video or image
        let check = document.querySelectorAll('#postType');
        for (i = 0; i < check.length; i++) {
            let checkText = check[i].textContent
            if (checkText == 'sharetext' || checkText == 'text') {
                let vid = check[i].parentElement.children[1]
                let img = check[i].parentElement.children[0]
                // vid.style.display = 'none'
                img.style.display = 'none'
                check[i].parentElement.parentElement.children[1].children[0].style.fontSize = '20px'
                document.querySelector('.slide_controls').style.display = 'none'
            }

        }




        // check of share post to remove image if post is text
        let shareedPostType = document.querySelectorAll('#sahrePostDiv')
        for (i = 0; i < shareedPostType.length; i++) {
            if (shareedPostType[i].textContent == 'text' || shareedPostType[i].textContent == 'sharetext') {
                document.querySelector('.sharedPhoto').style.display = 'none'
                shareedPostType[i].parentElement.children[0].style.display = 'none'

            }
        }



        // Validate form field
        let typer = document.querySelector('.send_icon_')
        typer.style.display = 'none'
        document.addEventListener('input', () => {
            let input = document.getElementById('myInput');
            if (input.value == '') {
                typer.style.display = 'none'
            } else {
                typer.style.display = 'block'
            }
        })

        // Hide Chat deleteBtn
        let deleteBtn = document.querySelectorAll('.comment_options');
        let myId = document.getElementById('myId').textContent;
        let confirmDelete = document.querySelectorAll('.delete_container');
        let hide = document.querySelectorAll('#deleteBtn');
        let closeDeleteBtn = document.querySelectorAll('#closeDeleteBtn');


        // Delete unwanted delte button
        for (i = 0; i < deleteBtn.length; i++) {
            let str = deleteBtn[i].textContent
            if (!str.includes(myId)) {
                deleteBtn[i].style.display = 'none'
            }
        }


        // Toggle delete button
        hide.forEach(cur => {
            cur.addEventListener('click', (e) => {
                let div = e.target.parentElement.children[2]
                div.classList.toggle('hideContainer')
            })
        })

        //CLose delete btn
        closeDeleteBtn.forEach((cur) => {
            cur.addEventListener('click', (e) => {
                let x = e.target.parentElement.parentElement
                x.classList.toggle('hideContainer')
            })
        })



        // Get length of comments to send to database
        let commentDiv = document.querySelectorAll('.comment_box');
        let inputWithLength = document.getElementById('commentLength')
        inputWithLength.value = (commentDiv.length + 1)



        // Shareing section
        let shareBtn = document.querySelectorAll('#shareBtn')
        for (i = 0; i < shareBtn.length; i++) {
            shareBtn[i].addEventListener('click', (e) => {
                document.querySelector('.share_model').style.display = 'block'
                //==================
                // Get the link
                let postLink = e.target.parentElement.children[1].textContent
                document.getElementById('postIdLink').value = postLink




                // close model
                document.addEventListener('click', (e) => {
                    if (e.target.classList == 'share_model') {
                        document.querySelector('.share_model').style.display = 'none'
                    }
                })
            })



            // video section
            let controller = document.querySelectorAll('#controller')
            for (i = 0; i < controller.length; i++) {
                controller[i].addEventListener('click', (e) => {

                    let pausebtn = e.target.parentElement.children[1]
                    let seeker = e.target.parentElement.nextElementSibling.children[0]
                    e.target.parentElement.children[0].style.display = 'none'
                    e.target.parentElement.children[1].style.display = 'block'

                    let video = e.target.parentElement.parentElement.parentElement.parentElement.children[0]
                    video.play()


                    pausebtn.addEventListener('click', () => {
                        video.pause()
                        e.target.parentElement.children[0].style.display = 'block'
                        e.target.parentElement.children[1].style.display = 'none'
                    })

                    setInterval(() => {
                        // Show play pause button when video is finished loading
                        if (video.currentTime === video.duration) {
                            e.target.parentElement.children[0].style.display = 'block'
                            e.target.parentElement.children[1].style.display = 'none'
                        }

                        // moveing seeker                
                        seeker.max = video.duration
                        seeker.value = video.currentTime

                    }, 0);


                })
            }


        }





        // let commentOptionIcon = document.querySelectorAll('#commentOptionIcon')
        // for (i = 0; i < commentOptionIcon.length; i++) {
        //     commentOptionIcon[i].addEventListener('click', (e) => {
        //         // Open comment option        

        //         let div = document.querySelectorAll('.comment_sub_wrap')
        //         for (j = 0; j < div.length; j++) {
        //             div[j].style.display = 'none'
        //         }

        //         e.target.parentElement.children[1].style.display = 'block'

        //     })
        // }

        // // Hide delete button 
        // let delBtn = document.querySelectorAll('#hideDeleteButton')
        // for (i = 0; i < delBtn.length; i++) {
        //     if (!delBtn[i].textContent.includes(myId)) {
        //         delBtn[i].parentElement.style.display = 'none'
        //     }
        // }


        // let coyComment = document.querySelectorAll('#copyComment')
        // for (i = 0; i < coyComment.length; i++) {
        //     coyComment[i].addEventListener('click', (e) => {
        //         // Open comment option
        //         let input = e.target.parentElement.children[1]
        //         input.style.display = 'block'
        //         input.select()
        //         document.execCommand('copy')
        //         input.style.display = 'none'
        //     })
        // }

        // let closeOption = document.querySelectorAll('#closeOption')
        // for (i = 0; i < closeOption.length; i++) {
        //     closeOption[i].addEventListener('click', (e) => {
        //         e.target.parentElement.parentElement.style.display = 'none'
        //     })
        // }

        // let checkRepliesLength = document.querySelectorAll('#checkRepliesLength')
        // for (i = 0; i < checkRepliesLength.length; i++) {
        //     let num = parseInt(checkRepliesLength[i].textContent)
        //     if (checkRepliesLength[i].textContent === '' || num < 1) {
        //         checkRepliesLength[i].parentElement.style.display = 'none'
        //     }
        // }


    


        // clicking fetch reaction modal
        // CLosing modal
        let appendReactors = document.getElementById('appendReactors')
        document.querySelector('.load_likes_modal').addEventListener('click', e => {
            if (e.target.className == 'load_likes_modal') {
                e.target.style.display = 'none'
                appendReactors.innerHTML = ''
            }
        })

        // clsoing from the x 
        document.querySelector('#closeReactorsPage').addEventListener('click', e => {
            document.querySelector('.load_likes_modal').style.display = 'none'
            appendReactors.innerHTML = ''
        })



        // clicking to fetch reactors on dm
        let fetchReactors = document.querySelectorAll('.fetchReactors')
        for (i = 0; i < fetchReactors.length; i++) {
            fetchReactors[i].addEventListener('click', e => {
                let postId = e.target.parentElement.parentElement.children[1].textContent
                if (postId.includes('comments')) {
                    return
                }
                document.querySelector('.load_likes_modal').style.display = 'block'
                socket.emit('sendPostIdForReaction', postId)
                document.querySelector('.likesReactionLoade').style.display = 'block' //show loader
            })
        }



        // fetch reactions for a post
        socket.on('reaction-users', (data) => {
            document.querySelector('.likesReactionLoade').style.display = 'none' //show loader
            for (i = 0; i < data.length; i++) {
                appendReactors.innerHTML += `<div class="div_flex">
                <a href="/profile/${data[i]._id}">
                <div class="reactor_wrapper">
                        <img id="userPostAvatar" src="https://plogapp.s3.amazonaws.com/${data[i].avatar}" alt="">
                        <div>
                            <h3 style="text-transform: capitalize;">${data[i].firstname} ${data[i].lastname} <span><i class="${data[i].verified}"></i></span></h3>
                        </div>
                    </div>
                    </a>
                    
                    <div class="icon_heart">
                        <i class="fa fa-heart"></i>
                    </div>
                </div>`
            }
        })



    }

    // Check if the post text is greater than 300 characters
    let post_description_text = document.querySelector('.post_description_text p')
    post_description_text.style.fontSize = '20px'
    if (post_description_text.textContent.length > 500) {
        post_description_text.style.fontSize = '13px'

    }






})()