(function () {
    const socket = io()
    let chatObject = {}
    let chatObjectImageArray = []
    let storyImg = document.getElementById('storyImg')
    let autoDownload = document.getElementById('autoClick')
    let storyDate = document.getElementById('storyDate')
    let storyName = document.getElementById('storyName')
    let userName = document.getElementById('userName')
    let ownerImg = document.getElementById('ownerImg')
    let leftSide = document.getElementById('leftSlide')
    let rightSlide = document.getElementById('rightSlide')
    let video_container = document.querySelector('.video_story_container')
    let storyVideoId = document.querySelector('#storyVideoId')
    let storyChatInput = document.getElementById('chatInput')
    let userId = document.getElementById('myIdForStory').textContent
    let primaryId = document.getElementById('primaryId').textContent
    let storyNavigator = document.querySelectorAll('.counter_box')
    let mssageSentAlert = document.querySelector('.mssageSentAlert')
    let saveStoryId = document.getElementById('saveStoryId')
    let storyDescription = document.getElementById('storyDescription')
    let blurBg = document.querySelector('#blurStoryImg')
    let storyVideoDescription = document.getElementById('viewStoryVideoDescription')



    function toggleStory() {
        document.querySelector('.global_story_container').classList.toggle('toggle_story')
    }

    // clocing the story
    document.getElementById('closeStory').addEventListener('click', (e) => {
        document.querySelector('.global_story_container').classList.toggle('toggle_story')
        storyVideoId.pause()
    })

    let storyBox = document.querySelectorAll('#storyBox')
    for (i = 0; i < storyBox.length; i++) {
        storyBox[i].addEventListener('click', (e) => {
            let ownerId = e.target.parentElement.children[1].textContent
            let viewerId = e.target.parentElement.children[2].textContent
            let sendData = {
                ownerId: ownerId.toString(),
                viewerId: viewerId.toString()
            }
            // socket.emit('socketStory', sendData) //sending id to fetch story

            fetch('/viewStory', {
                method: 'POST',
                headers: {
                    'Accept': 'application/json, text/plain, */*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(sendData)
            })

                .then(res => res.json())
                .then(data => {
                    // console.log(data)
                    viewStroryFunction(data.story)
                }).catch(err => {
                    console.log(err)
                })

            //Open story modal
            // document.querySelector('.global_story_container').style.display = 'block'
            toggleStory()

            // hide send message if its my story
            if (ownerId == userId) {
                document.querySelector('.send_message').style.display = 'none'
            } else {
                document.querySelector('.send_message').style.display = 'block'
            }

            if (ownerId != userId) {
                document.querySelector('.hideViews').style.display = 'none'
            } else {
                document.querySelector('.hideViews').style.display = 'block'
            }

        })
    }



    function viewStroryFunction(res) {
        console.log(res)
        let data = res.reverse()
        //return false if there is no data        
        if (data.length === 0) return


        let counter = 0;
        let lastItem = data[data.length - 1]
        let lastIndex = data.lastIndexOf(lastItem)
        document.querySelector('.story_container .loader_container').style.display = 'none'
        document.querySelector('.divCOunter').style.display = 'block'
        runStoryFunction()

        leftSide.addEventListener('click', (e) => {
            counter--
            runStoryFunction()
            runSaveFunction()
        })
        rightSlide.addEventListener('click', (e) => {
            counter++
            runStoryFunction()
            runSaveFunction()
        })

        function runSaveFunction() {
            // let newFetchedId = fetchStoryId.toString()
            socket.emit('sendIdToSaveForViewers', {
                storyId: data[counter]._id,
                userId: userId
            })
        }

        // getting length of story to
        for (i = data.length; i < storyNavigator.length; i++) {
            storyNavigator[i].style.display = 'none'
        }

        // this function is for the sliding image
        function runStoryFunction() {

            if (counter < 0) {
                counter = lastIndex
            }
            if (counter > lastIndex) {
                counter = 0
            }

            // call the reaction function
            runcStoryCheckFunction()
            // ***********************

            // Close story container            
            function closingStory() {
                counter = 0
                data = []
                // making all the story bav to display block again
                for (i = 0; i < storyNavigator.length; i++) {
                    storyNavigator[i].style.display = 'block'
                }
                document.querySelector('.story_container .loader_container').style.display = 'none'
                return

            }



            // clicking the global container to close
            document.addEventListener('click', (e) => {
                if (e.target.className === 'global_story_container toggle_story') {
                    closingStory()
                    // document.querySelector('.global_story_container').style.display = 'none'
                    toggleStory()
                }
            })

            // changing the background color for sory navigator
            // storyNavigator.classList.toggle('counter_toggle')        
            Array.from(storyNavigator).forEach(cur => {
                cur.style.backgroundColor = 'white'
            })

            try {
                // Changingthe images src 
                storyNavigator[counter].style.backgroundColor = 'gray'

                let stroyName = data[counter].ownerName
                storyName.textContent = stroyName.substr(0, 15)
                storyDate.textContent = data[counter].date
                saveStoryId.textContent = data[counter]._id
                document.getElementById('delStoryInput').value = data[counter]._id //Deleteing story

                ownerImg.src = 'https://plogapp.s3.amazonaws.com/' + data[counter].avatar


                if (data[counter].storyType == 'image') {


                    storyVideoId.pause()
                    storyImg.src = 'https://plogapp.s3.amazonaws.com/' + data[counter].image
                    blurBg.src = 'https://plogapp.s3.amazonaws.com/' + data[counter].image
                    storyDescription.textContent = data[counter].storyText

                    autoDownload.href = 'https://plogapp.s3.amazonaws.com/' + data[counter].avatar
                    storyImg.style.display = 'block'
                    video_container.style.display = 'none'

                    // Chat simage 
                    // chatObject.image = data[counter].image
                    // Pusing chat images to to the tip for users to use it.
                    chatObjectImageArray.unshift(data[counter].image)
                    
                    

                    document.querySelector('.story_text_large').style.display = 'none'
                    document.querySelector('.story_img_wrapper').style.display = 'block'
                    document.querySelector('.video_story_container').style.display = 'none'

                    return
                }


                if (data[counter].storyType == 'text') {
                    console.log(data[counter])
                    let storytext = document.getElementById('storyLargeText')
                    storytext.textContent = data[counter].description
                    storytext.style.fontWeight = data[counter].fontWeight
                    storytext.style.fontSize = data[counter].fontSize
                    
                    storytext.style.fontFamily = data[counter].fontFamily == 'undefined' ? 'Helvetica' : data[counter].fontFamily

                    document.querySelector('.story_text_large').style.backgroundColor = data[counter].background

                    // Chat simage 
                    // Pusing chat images to to the tip for users to use it.
                    chatObjectImageArray.unshift(data[counter].image)
                    

                    storyDescription.textContent = ''
                    storyVideoId.pause()
                    document.querySelector('.story_text_large').style.display = 'block'
                    document.querySelector('.story_img_wrapper').style.display = 'none'
                    document.querySelector('.video_story_container').style.display = 'none'
                }

                if (data[counter].storyType == 'video') {

                    document.querySelector('.story_text_large').style.display = 'none'
                    document.querySelector('.story_img_wrapper').style.display = 'none'
                    document.querySelector('.video_story_container').style.display = 'block'
                    // Chat simage 
                    // chatObject.image = data[counter].image
                    // Pusing chat images to to the tip for users to use it.
                    
                    chatObjectImageArray.unshift(data[counter].image)

                    storyVideoId.poster = 'https://plogapp.s3.amazonaws.com/' + data[counter].image
                    storyVideoId.src = 'https://plogapp.s3.amazonaws.com/' + data[counter].video
                    blurBg.src = 'https://plogapp.s3.amazonaws.com/' + data[counter].image
                    storyVideoId.play()
                    storyVideoDescription.textContent = data[counter].storyText
                    storyVideoId.backgroundColor = 'black'
                    // storyVideoId.play()
                    video_container.style.display = 'block'
                    storyImg.style.display = 'none'
                    storyDescription.textContent = ''
                    return
                }

                // sending 

            } catch (error) {
                console.log(error)
                document.getElementById('showerror').textContent = 'Error'
            }

        }


        // when the buttons are clicked check if the current story has a reaction from the user viewing it
        runcStoryCheckFunction() //I also called the function twice inside the slide fuction
        function runcStoryCheckFunction() {
            document.getElementById('storyLikeIcon').style.color = 'white' //defaultly set the heart icon the white
            document.getElementById('reactionLength').textContent = data[counter].reactionLength // show the reaction length
            document.getElementById('reactionIds').textContent = data[counter].reaction

            // chech if the user ui is alreay in the likes array

            let idsReaction = document.getElementById('reactionIds')
            let allHeartIds = idsReaction.textContent
            console.log(allHeartIds.includes(primaryId))
            if (allHeartIds.includes(primaryId)) {
                document.getElementById('storyLikeIcon').style.color = '#ff1ac3'
            } else {
                document.getElementById('storyLikeIcon').style.color = 'white'
            }
        }

        document.getElementById('storyLikeIcon').addEventListener('click', e => {
            let num = parseInt(e.target.parentElement.children[1].textContent) || 0

            // send the heart reaction ids
            let idObJData = {
                storyId: data[counter]._id,
                userId: userId
            }

            
            if (e.target.style.color === 'white') {
                e.target.style.color = '#ff1ac3'
                e.target.parentElement.children[1].textContent = num += 1
                socket.emit('storyReactionDetails', idObJData)
            }
            //  else {
            //     e.target.style.color = 'white'
            //     e.target.parentElement.children[1].textContent = num -= 1
            // }
        })

        function downloadStoryFunction() {

            // autoDownload.href = storyImg.src 
            // download the story image
            document.getElementById('downloadStory').addEventListener('click', e => {
                autoDownload.click()
                console.log(autoDownload.href)
            })
        }

        downloadStoryFunction()


        // send message to from story to chat ***********************

        storyChatInput.addEventListener('input', e => {
            if (storyChatInput.value == '') {
                document.getElementById('sendStoryMesg').style.display = 'none'
                return
            }
            document.getElementById('sendStoryMesg').style.display = 'block'

        })


        document.getElementById('sendStoryMesg').addEventListener('click', () => {
            if (chatInput.value.trim() == '') return
            let myChat = {
                owner: userId,
                message: storyChatInput.value,
                date: new Date(new Date().getTime()),
                receiverId: data[counter].owner,
                storyImageUrl: chatObjectImageArray[0],
                ownerName: userName.textContent.toLowerCase(),
                receiverName: data[counter].ownerName,
                replyOldMessage: '',
            }

            console.log(myChat)

            socket.emit('storyOwner', myChat) //Story owner
            socket.emit('storyReceiver', myChat) // Second chat for receiver

            chatInput.value = ''
            document.getElementById('sendStoryMesg').style.display = 'none'
            mssageSentAlert.style.display = 'block'
            setTimeout(() => {
                mssageSentAlert.style.display = 'none'
            }, 1000);

        })

    }


    let fetchStoryId = []
    // listening to socket data
    socket.on('story', (result) => {
        // let data = result.story


    })

    

    // clicking the eye icon to fetch stotary viewer
    document.getElementById('fetchMyStatusViewers').addEventListener('click', (e) => {
        document.querySelector('.story_viewers_container').style.display = 'block'
        let id = saveStoryId.textContent
        console.log(id)
        socket.emit('fetchViewers', id)
    })

    // listening to fetched users
    let storyAppender = document.getElementById('appendSToryViewers')
    socket.on('fetchedViewers', (data) => {

        // Show views length
        document.getElementById('storyViewsLength').textContent = data.length

        // Close story story
        document.querySelector('#closeDelStory').addEventListener('click', (e) => {
            data = []
            storyAppender.innerHTML = ''
            return

        })

        // Appending story length
         for (i = 0; i < data.length; i++) {
            storyAppender.innerHTML += `<div class="user_viewrs_wrapper">
                    <img id="ownerImg" src="https://plogapp.s3.amazonaws.com/${data[i].avatar}" alt="">
                    <div class="user_vierwer_name">
                        <a href="/profile/${data[i]._id}">
                            <p style="font-weight: bold;">${data[i].firstname}  ${data[i].lastname} <span><i class="${data[i].verified}"></i></span></p>
                            <p style="display: none">${data[i].followerLength} followers</p>

                        </a>
                    </div>
            </div>`
        }

    })



})()
