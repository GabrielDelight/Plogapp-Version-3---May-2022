{
    let toggleDarkModeButton = document.querySelectorAll('#toggleDarkMode')
    Array.prototype.slice.call(toggleDarkModeButton).forEach(cur => {
        cur.addEventListener('click', e => {
            let storage = localStorage.getItem('dark-mode-control')
            console.log(storage)
            if (storage == null) {
                localStorage.setItem('dark-mode-control', 'dark')
                // location.reload()

            } else {

                localStorage.removeItem('dark-mode-control')
                // location.reload()
            }
        })
    })

}

darkModeFunction()
function darkModeFunction() {

    setInterval(() => {
        let storage = localStorage.getItem('dark-mode-control')
        if(storage == 'dark'){
            updateToggleFunction()
        }

        if(storage == null){
            RemoveupdateToggleFunction()
        }
    }, (2000));

    function updateToggleFunction() {
        let bool = false
        let storage = localStorage.getItem('dark-mode-control')
        if (storage == 'dark') {
            bool = true
        }

        if (bool) {

            

            let mobileIcon = document.querySelectorAll('.toggle_icons_color')
            Array.from(mobileIcon).forEach(cur => {
                cur.classList.add('mobile_icon_dark_mode')
            })


            let global = document.querySelectorAll('*')
            Array.from(global).forEach(cur => {
                // cur.style.boxShadow = 'none'
                // cur.classList.add('toggle_dark_mode_div_body')
            })


            let page_header = document.querySelectorAll('.page_header')
            Array.from(page_header).forEach(cur => {
                cur.classList.add('toggle_dark_mode_div_blur')
            })

            // Remove article broder
            let article_border = document.querySelectorAll('article')
            Array.from(article_border).forEach(cur => {
                cur.classList.add('toggle_article_border')
            })


            let Hashtags = document.querySelectorAll('.post-text-container a')
            Array.from(Hashtags).forEach(cur => {
                // cur.style.color = 'red !important'
                // cur.classList.add('toggle_dark_mode_div_body')
            })

            // Light dark color 
            let darkDiv = document.querySelectorAll('.dark_div, article, .reply_old_text,  aside,  .side_content, .tolTipText, .post-container, .right_comment_sec, .comment_sub_wrap')
            Array.from(darkDiv).forEach(cur => {
                cur.classList.add('toggle_dark_mode_div')
            })

            let LightdarkDiv = document.querySelectorAll('.light_dark_div,  .side_content, .tolTipText, .post-container, .show_shot_profile, .story_list_container, img, .feed_main_holding_box, .loading_page,  .follower_head, .mobile_nav_container, .profile_details, .main_chat_body_content, .chat_header, .chat_form_container, .post_container--image, .poster_header_box, .files_wrapper, .vc_record_container, .conversation_skeleton')
            Array.from(LightdarkDiv).forEach(cur => {
                cur.classList.add('toggle_dark_mode_light_div')
            })


            // add cloasslist white to all elem
            let elem = document.querySelectorAll('i.fa-ellipsis-h, i.fa-ellipsis-v, i.fa-commenting-o, i.fa-gear, i.fa-arrow-left,i.fa-arrow-right, i.fa-refresh, i.post_options,a,  p, h1, h2, h3, h4, h5, h6, span, small, p#Suggbio, p#sugFollTxt, textarea, input, table, td, tr')
            Array.from(elem).forEach(cur => {
                // cur.style.color = '#e8e6e3'
                // cur.style.color = '#e8e6e3'
                cur.classList.add('toggle_dark_mode_text')
            })

            let bodyTag = document.querySelectorAll('body, main, #append-container, #page_wrap')
            Array.from(bodyTag).forEach(cur => {
                cur.classList.add('toggle_dark_mode_div_body')
            })

            let removeborder = document.querySelectorAll('.sugg_details img, .poster_avatar_div img, img')
            Array.from(removeborder).forEach(cur => {
                cur.classList.add('toggle_remove_border_dark_mode')
            })


            let inputToggle = document.querySelectorAll('textarea, input')
            Array.from(inputToggle).forEach(cur => {
                cur.classList.add('toggle_textare_input')
            })


            let ChatDarkMode = document.querySelectorAll('.replyPushLeft .blueColor p,  .pushLeft ')
            Array.from(ChatDarkMode).forEach(cur => {
                cur.classList.add('toggle_chat_dark_mode')
            })

        }

    }



    function RemoveupdateToggleFunction() {
     
            let global = document.querySelectorAll('*')
            Array.from(global).forEach(cur => {
                // cur.style.boxShadow = 'none'
                // cur.classList.add('toggle_dark_mode_div_body')
            })


            let Hashtags = document.querySelectorAll('.post-text-container a')
            Array.from(Hashtags).forEach(cur => {
                // cur.style.color = 'red !important'
                // cur.classList.add('toggle_dark_mode_div_body')
            })


            let page_header = document.querySelectorAll('.page_header')
            Array.from(page_header).forEach(cur => {
                cur.classList.remove('toggle_dark_mode_div_blur')
            })

            // Remove article broder
            let article_border = document.querySelectorAll('article')
            Array.from(article_border).forEach(cur => {
                cur.classList.remove('toggle_article_border')
            })

            // Light dark color 
            let darkDiv = document.querySelectorAll('.dark_div, article,.reply_old_text,  aside,  .side_content, .tolTipText, .post-container, .right_comment_sec, .comment_sub_wrap')
            Array.from(darkDiv).forEach(cur => {
                cur.classList.remove('toggle_dark_mode_div')
            })

            let LightdarkDiv = document.querySelectorAll('.light_dark_div,  .side_content, .tolTipText, .post-container, .show_shot_profile, .story_list_container, img, .feed_main_holding_box, .loading_page,  .follower_head, .mobile_nav_container, .profile_details, .main_chat_body_content, .chat_header, .chat_form_container, .post_container--image, .poster_header_box, .files_wrapper, .vc_record_container, .conversation_skeleton')
            Array.from(LightdarkDiv).forEach(cur => {
                cur.classList.remove('toggle_dark_mode_light_div')
            })


            // remove cloasslist white to all elem
            let elem = document.querySelectorAll('i.fa-commenting-o, i.fa-gear, i.fa-arrow-left, i.fa-refresh, i.post_options,a, i.fa-close, p, h1, h2, h3, h4, h5, h6, span, small, p#Suggbio, p#sugFollTxt, textarea, input, table, td, tr')
            Array.from(elem).forEach(cur => {
                // cur.style.color = '#e8e6e3'
                // cur.style.color = '#e8e6e3'
                cur.classList.remove('toggle_dark_mode_text')
            })

            let bodyTag = document.querySelectorAll('body, main, #append-container, #page_wrap')
            Array.from(bodyTag).forEach(cur => {
                cur.classList.remove('toggle_dark_mode_div_body')
            })

            let removeborder = document.querySelectorAll('.sugg_details img, .poster_avatar_div img, img')
            Array.from(removeborder).forEach(cur => {
                cur.classList.remove('toggle_remove_border_dark_mode')
            })


            let inputToggle = document.querySelectorAll('textarea, input')
            Array.from(inputToggle).forEach(cur => {
                cur.classList.remove('toggle_textare_input')
            })

            let ChatDarkMode = document.querySelectorAll('.replyPushLeft .blueColor p,  .pushLeft ')
            Array.from(ChatDarkMode).forEach(cur => {
                cur.classList.remove('toggle_chat_dark_mode')
            })
            
            let mobileIcon = document.querySelectorAll('.toggle_icons_color')
            Array.from(mobileIcon).forEach(cur => {
                cur.classList.remove('mobile_icon_dark_mode')
            })
        }


}


