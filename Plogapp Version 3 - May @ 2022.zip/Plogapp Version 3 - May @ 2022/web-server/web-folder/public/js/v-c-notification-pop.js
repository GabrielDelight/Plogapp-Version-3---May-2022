(function () {
    const socket = io()
    let receiverId = document.getElementById('userId').textContent
    let incoming_video_call_signal = document.querySelector('.incoming_video_call_signal')
    let callerAvatar = document.getElementById('callerAvatar')
    let callerName = document.getElementById('callerName')
    let audioRinging = document.getElementById('playRinging')

    
    let signaData = document.getElementById('signaData')
    let submit = document.getElementById('submit')
    let inputFormAction = document.getElementById('inputFormAction')
    

    socket.on('find-video-receiver', data => {
        if (data.receiverId == receiverId) {
            // Fill user details
            callerName.textContent = data.callerName
            callerAvatar.src = 'https://plogapp.s3.amazonaws.com/' + data.callerImage

            // Play sound

            audioRinging.play()
            audioRinging.pause()

            setTimeout(() => {
                audioRinging.play()
            }, 1000)


            // @ DO that later

            // @ Display the hidden calling div            
            incoming_video_call_signal.style.display = 'block'

            // PICKING THE CALL
            // If user answers the call : redirect the user to aother page
            document.getElementById('cv-acceptache-btn').addEventListener('click', e => {
                let a = document.createElement('a')
                let PerrGenData = JSON.stringify(data.dataSignal)
                // console.log(data)
                // a.href = '/video-calling?receiverId=' + data.receiverId + "&callerId=" + data.callerId + "&status=joined&signaData=" + PerrGenData


                signaData.value = PerrGenData
                inputFormAction.action = '/video-calling-received?receiverId=' + data.receiverId + "&callerId=" + data.callerId + "&status=joined"
                console.log(document.getElementById('inputFormAction'))
                
                submit.click()

                // a.click()
                audioRinging.pause()
            })

            // REJECTING THE CALL
            // if user is not answering 
            // We are using settimoit
            setTimeout(() => {
                quitigOrRejectionFunction('User is not answering')
                audioRinging.pause()
            }, 50000);

            // Check if the user rejects the call, send a signal that user reject the call
            document.getElementById('reject-cv-call-btn').addEventListener('click', e => {
                quitigOrRejectionFunction('Call declined')
                audioRinging.pause()
            })


            // Call rejection or not answering 
            function quitigOrRejectionFunction(message) {
                incoming_video_call_signal.style.display = 'none'
                // console.log('rejected')

                // Send signal for ejected video with socket
                socket.emit('vc-rejected-call', {
                    ...data,
                    message: message
                })
            }

        } else {

        }
    })


    // If a user force quite call do something'
    socket.on('force-quiting-call', data => {

        if (data.receiverId == receiverId) {


            // Pause the playing sound
            audioRinging.pause()
            // @ do that later

            // @ Hide the rining div the hidden calling div            
            incoming_video_call_signal.style.display = 'none'
        }
    })






})()
