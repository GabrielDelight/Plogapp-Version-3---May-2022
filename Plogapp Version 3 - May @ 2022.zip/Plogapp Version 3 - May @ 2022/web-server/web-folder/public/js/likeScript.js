
function LikingCommentsFunction() {
    // Linking comment 
    try {
        const socket = io();
        // Change all heart ito gray color
        let userId = document.getElementById('userId').textContent;
        let primaryId = document.getElementById('primaryId').textContent;


        let allHearts = document.querySelectorAll('#changeHeartCOlor');
        for (i = 0; i < allHearts.length; i++) {
            allHearts[i].style.color = 'gray'
        }

        // Change heart color if user has an id in reaction comment
        let reaction = document.querySelectorAll('.reactionGlobally');
        for (i = 0; i < reaction.length; i++) {
            let icon = reaction[i].children[0];
            let ids = reaction[i].children[3].textContent;

            if (ids.split(',').indexOf(primaryId) > -1) {
                icon.style.color = '#ff00bc'
                icon.classList = 'fa fa-heart'
            }

            // if (ids.includes(primaryId)) {
            //     icon.style.color = '#ff00bc'
            //     icon.classList = 'fa fa-heart'
            // }
        }


        // Clicking the heart icon

        for (i = 0; i < allHearts.length; i++) {
            allHearts[i].addEventListener('click', (e) => {
                try {
                    let heart = e.target.parentElement.children[0]
                    // if(!e.target.textContent.includes('fa fa-heart')) return
                    let ownerId = e.target.parentElement.children[1].textContent
                    // console.log(ownerId)
                    let commentId = e.target.parentElement.children[2].textContent
                    let numOfLikes = e.target.parentElement.children[0].children[0]
                    let newNumofLikes = parseInt(numOfLikes.textContent) || 0;


                    let commentLikeDetails = {
                        ownerId,
                        commentId
                    }

                    // console.log(ownerId)
                    // console.log(commentId)

                    socket.emit('commentLikeDetails', commentLikeDetails)
                    // console.log(commentLikeDetails)

                    // Start changing colors for hearts
                    if (heart.style.color == 'gray') {
                        heart.style.color = '#ff00bc';
                        numOfLikes.textContent = newNumofLikes += 1
                        numOfLikes.style.color = 'gray'
                        heart.classList = 'fa fa-heart'
                    } else {
                        heart.style.color = 'gray'
                        numOfLikes.textContent = newNumofLikes -= 1
                        numOfLikes.style.color = 'gray'
                        heart.classList = 'fa fa-heart-o'
                    }
                } catch (error) {
                }

            })
        }

    } catch (error) {
        conosle.log(error.message)
    }
}




