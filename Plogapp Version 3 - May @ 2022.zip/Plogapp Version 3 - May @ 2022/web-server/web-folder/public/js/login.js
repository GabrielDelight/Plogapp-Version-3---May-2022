let btn = document.getElementById('btn');
let email = document.getElementById('email');
let password = document.getElementById('password');
let errorMessage = document.getElementById('errorMessage');

document.addEventListener('keypress', e => {
    if (e.keyCode == 13 || e.charCode == 13) {
        loginFunction()
    }
})

btn.addEventListener('click', (e) => {
    loginFunction()
})



function loginFunction(){
    if (email.value.trim() == '') {
        errorMessage.textContent = 'Email is required'
        return
    }

    if (password.value.trim() == '') {
        errorMessage.textContent = 'Password is required'
        return
    }



    let formData = {
        email: email.value,
        password: password.value
    }

    let url = '/user_login_request'
    fetch(url, {
        method: 'POST',
        headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
    })

        .then(res => res.json())
        .then(data => {

            if (data.error) {
                errorMessage.textContent = data.error
                return
            }
            btn.disabled = true
            let a = document.createElement('a')
            a.href = '/home'
            a.click()
        })
        .catch(error => {
            errorMessage.textContent = "Something went wrong, please try again later."
            // console.log(error)
        })


}

localStorage.removeItem('safewatchpro')
