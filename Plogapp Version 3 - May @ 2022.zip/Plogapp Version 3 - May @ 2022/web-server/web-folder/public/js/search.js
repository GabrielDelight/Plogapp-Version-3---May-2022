function toggleSearch() {
    document.querySelector('.global_search_container').classList.toggle('toggle_search_container')
}

let openSearchBtn  = document.querySelectorAll('#toggleSearch')
for(i = 0; i < openSearchBtn.length; i++ ){
    openSearchBtn[i].addEventListener('click', e => {
        toggleSearch()
    })
}

document.getElementById('closeSearcg').addEventListener('click', e => {
    toggleSearch()
})



document.querySelector('.global_search_container').addEventListener('click', e => {
    if (e.target.className == 'global_search_container toggle_search_container') {
        toggleSearch()
    }
})
