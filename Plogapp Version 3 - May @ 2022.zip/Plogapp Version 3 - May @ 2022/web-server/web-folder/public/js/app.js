
// Video screipts ***********************************************************
// Check if post is video or image

var checkx = document.querySelectorAll('#postType');
for (i = 0; i < checkx.length; i++) {
    let checkText = checkx[i].textContent
    if (checkText == 'image') {
        let x = checkx[i].parentElement.children[1]
        x.style.display = 'none'
    } else if (checkText == 'video') {
        let x = checkx[i].parentElement.children[0]
        x.style.display = 'none'
    }
}

(function () {
    function toggleUploadImg() {
        document.querySelector('.upload_container').classList.toggle('toggle_upload_contaimer')
    }
    function craetPost() {
        // previewing the image            
        var image1 = document.querySelector('.imgPreview');
        var image2 = document.querySelector('.imgPreview2');
        var image3 = document.querySelector('.imgPreview3');
        var image4 = document.querySelector('.imgPreview4');

        image2.style.display = 'none'
        image3.style.display = 'none'
        image4.style.display = 'none'

        document.querySelector('.add_box').addEventListener('click', () => {
            // document.querySelector('.fileImg').click()
            toggleUploadImg()

            document.querySelector('.fileImg').addEventListener('change', function () {
                image2.style.display = 'block'
                image3.style.display = 'block'
                image4.style.display = 'block'


                if (this.files) {
                    document.getElementById('checkVideoOrImage').value = 'image'
                    if (this.files.length === 3 || this.files.length > 3) {
                        image1.src = URL.createObjectURL(this.files[0]);
                        image2.src = URL.createObjectURL(this.files[1]);
                        image3.src = URL.createObjectURL(this.files[2]);
                        image4.src = URL.createObjectURL(this.files[0]);
                        document.getElementById('checkVideoOrImage').value = 'image'


                    }
                    else if (this.files.length === 2) {
                        image1.src = URL.createObjectURL(this.files[0]);
                        image2.src = URL.createObjectURL(this.files[1]);
                        image3.src = URL.createObjectURL(this.files[0]);
                        image4.style.display = 'none'
                        document.getElementById('checkVideoOrImage').value = 'image'
                    }

                    else if (this.files.length === 1) {
                        image1.src = URL.createObjectURL(this.files[0]);
                        image2.style.display = 'none'
                        image3.style.display = 'none'
                        image4.style.display = 'none'
                        document.getElementById('checkVideoOrImage').value = 'image'
                    }
                }

            })

            image2.addEventListener('click', e => {
                image1.src = e.target.src
            })
            image3.addEventListener('click', e => {
                image1.src = e.target.src
            })
            image4.addEventListener('click', e => {
                image1.src = e.target.src
            })


        })

    }
    try {
        craetPost()
    } catch (error) {
        return
    }

    // Clicking the body
    let mainBody = document.querySelector('.upload_container');
    mainBody.addEventListener('click', (e) => {
        if (e.target.classList == 'upload_container toggle_upload_contaimer') {
            toggleUploadImg()
        }
    })

    document.querySelector('.click_ok').addEventListener('click', e => {
        toggleUploadImg()
    })

    document.querySelector('.close_uploader').addEventListener('click', e => {
        toggleUploadImg()
    })

})()


function validateFunction() {
    // Validate fileUpload
    let postObject = {}
    document.getElementById('uploadBtn').addEventListener('click', (e) => {
        e.preventDefault()
        let postButton = e.target
        let image = document.getElementById('imageFile');
        let video = document.getElementById('videoUpload')
        let text = document.getElementById('textarea')


        if (text.value.trim() == '' && image.value.trim() == '') {
            document.querySelector('.input_error_modal').style.display = 'block'
            return
        }


        e.target.style.display = 'none'
        document.querySelector('.postLoader').style.display = 'block'

        let textarea = document.getElementById('textarea')
        let checkVideoOrImage = document.getElementById('checkVideoOrImage')
        let tag_list_input = document.getElementById('tag_list_input')

        if (image.value.trim() == '') {

            fetch('/createPost', {
                method: 'POST',
                headers: {
                    'Accept': 'application/json, text/plain, */*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    description: textarea.value,
                    checkPost: checkVideoOrImage.value,
                    tag_list: tag_list_input.value,
                })
            })
                .then(res => {
                    return res.json()
                })
                .then(data => {
                    // console.log(data)
                    // console.log('success')
                    document.querySelector('.postLoader').style.display = 'none'
                    document.querySelector('.hideUsccessCheck').style.display = 'block'
                    setTimeout(() => {
                        document.getElementById('uploadBtn').style.display = 'block'
                        document.querySelector('.postLoader').style.display = 'none'
                        document.querySelector('.hideUsccessCheck').style.display = 'none'
                        location.href = '/viewImagePostDetails/' + data._id
                    }, 1000);
                }).catch(error => {
                    console.log(error)
                })

            return
        }

        var f = image.files[0];
        let compressRatio = 0.4
        // Check Check the compression ratio
        const units = ['bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

        function niceBytes(x) {

            let l = 0, n = parseInt(x, 10) || 0;

            while (n >= 1024 && ++l) {
                n = n / 1024;
            }

            return (Math.round(n.toFixed(n < 10 && l > 0 ? 1 : 0)) + '' + units[l]);
        }

        if (niceBytes(f.size).includes('MB') ||
            niceBytes(f.size).includes('GB') ||
            niceBytes(f.size).includes('PB') ||
            niceBytes(f.size).includes('EB') ||
            niceBytes(f.size).includes('YB') ||
            niceBytes(f.size).includes('TB')
        ) {

            compressRatio = 0.1
        } else {
            compressRatio = 0.4
        }


        var fileName = f.name.split('.')[0];
        var img = new Image();
        img.src = URL.createObjectURL(f);
        img.onload = function () {
            var canvas = document.createElement('canvas');
            canvas.width = img.width;
            canvas.height = img.height;
            var ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0);
            canvas.toBlob(function (blob) {
                var newImage = new File([blob], fileName + ".jpeg");
                let data = new FormData()
                data.append('uploads', newImage)
                data.append('description', textarea.value)
                data.append('checkPost', checkVideoOrImage.value)
                data.append('tag_list', tag_list_input.value)

                fetch('/createPost', {
                    method: 'POST',
                    body: data
                })
                    .then(res => res.json())
                    .then(result => {
                        console.log(result)
                        postObject.post_id = result._id
                        if (result.success) {
                            document.querySelector('.postLoader').style.display = 'none'
                            document.querySelector('.hideUsccessCheck').style.display = 'block'

                            if (result.success == 'textPosted') {
                                setTimeout(() => {
                                    let a = document.createElement('a')
                                    a.href = '/viewImagePostDetails/' + result._id
                                    a.click()
                                }, 1000);
                            } else {

                                setTimeout(() => {
                                    console.log('Image uploaded successfully')
                                    document.querySelector('.global_modifing_post').style.display = 'block'
                                    // https://plogapp.s3.amazonaws.com/
                                    document.getElementById('modify_uploaded_img').src = 'https://plogapp.s3.amazonaws.com/' + result.image
                                    document.getElementById('post_modi_des').textContent = result.description
                                    document.getElementById('autoCLickModifyImgView').href = "/viewImagePostDetails/" + result._id
                                    document.getElementById('autoClickoViewPost').href = "/viewImagePostDetails/" + result._id

                                    document.getElementById('uploadBtn').style.display = 'block'
                                    document.querySelector('.postLoader').style.display = 'none'
                                    document.querySelector('.hideUsccessCheck').style.display = 'none'
                                }, 1000);
                            }

                        }

                    }).catch(err => {
                        document.querySelector('.postLoader').style.display = 'none'
                        postButton.style.display = 'block'
                        console.log(err)
                        document.getElementById('postReturnMsg').textContent = 'An error occured please try again later'
                    })

            }, 'image/jpeg', compressRatio);
        }

        // @ Uploading multiple images after posting the first image

        let image1Picker = document.getElementById('img_modi_up')
        image1Picker.addEventListener('change', function () {
            document.getElementById('imgPmody_prev').src = URL.createObjectURL(this.files[0])
        })

        let image2Picker = document.getElementById('img_modi_up2')
        image2Picker.addEventListener('change', function () {
            document.getElementById('imgPmody_prev2').src = URL.createObjectURL(this.files[0])
        })

        // Adding image button
        document.getElementById('addIMage_Post').addEventListener('click', e => {
            document.querySelector('#hide_send_image_div_xd').style.display = 'block'
            e.target.style.display = 'none'
        })

        // AFter cghanging image
        document.getElementById('upload_modify_post').addEventListener('click', e => {
            modifyPostFunction(image1Picker, postObject, '/add_post_image_two/')
        })

        document.getElementById('upload_modify_post2').addEventListener('click', e => {
            modifyPostFunction(image2Picker, postObject, '/add_post_image_three/')
        })


        function modifyPostFunction(image, postData, url) {
            let f = image.files[0];
            let fileName = f.name.split('.')[0];
            let img = new Image();
            img.src = URL.createObjectURL(f);
            img.onload = function () {
                let canvas = document.createElement('canvas');
                canvas.width = img.width;
                canvas.height = img.height;
                let ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0);
                canvas.toBlob(function (blob) {
                    let newimage = new File([blob], fileName + ".jpeg");
                    let data = new FormData()
                    data.append('uploads', newimage)
                    data.append('postId', postData.post_id)

                    fetch(url, {
                        method: 'POST',
                        body: data
                    })
                        .then(res => res.json())
                        .then(result => {
                            console.log(result)
                            if (result.image2Success) {
                                document.getElementById('hide_send_image_div_xd').style.display = 'none'
                                setTimeout(() => {
                                    document.getElementById('hide_send_image_div_xd').innerHTML = 'Image uploaded'
                                }, 1000);
                            }

                            if (result.image1Success) {
                                document.getElementById('hide_send_image_div_xd0').style.display = 'none'
                                setTimeout(() => {
                                    document.getElementById('hide_send_image_div_xd0').innerHTML = 'Image uploaded'
                                }, 1000);
                            }

                        }).catch(err => {
                            console.log(err)
                        })

                }, 'image/jpeg', 0.4);
            }
        }
    })



    // Toggle icons for emogy for post
    function toggleEmogy() {
        document.querySelector('.icon_container').classList.toggle('hideIcons')
    }

    // Upload emogi
    let emogi = document.querySelectorAll('#emogi');
    let inputText = document.getElementById('textarea')

    for (i = 0; i < emogi.length; i++) {
        emogi[i].addEventListener('click', (e) => {
            inputText.value += e.target.textContent
        })
    }




    // Replace strings with emoji
    document.addEventListener('input', () => {
        function replaceEmogi(old, newText) {
            let input = inputText.value;
            input = input.replace(old, newText)
            inputText.value = input
        }
        replaceEmogi(':)', '😃')
        replaceEmogi(':(', '😑')
        replaceEmogi('B-)', '😎')
        // replaceEmogi('<', '&lt;')
        // replaceEmogi('>', '&gt;')

    })
}

try {
    validateFunction()
} catch (error) {
    console.log('Error-loading-content')
}

{
    // // STory 
    // let actualColor
    // let img = document.getElementById('previewStory');
    // let imgFile = document.querySelector('.uploadStory')
    // let text = document.getElementById('caption_text');
    // let caption = document.getElementById('caption')
    // let blue = document.querySelector('.color1');
    // let red = document.querySelector('.color2');
    // let green = document.querySelector('.color3');
    // let colorPicker = document.getElementById('colorPicker')


    // //Validate Upload file
    // document.getElementById('uploadStoryBtn').addEventListener('click', (e) => {
    //     if(imgFile.value == ''){
    //         e.preventDefault()
    //     }
    // })

    // File upload previewer
    // document.querySelector('.uploadStory').addEventListener('change', function(){
    //     if(this.files){
    //         img.src = URL.createObjectURL(this.files[0]);
    //     }
    // })

    // Preview captio
    // document.addEventListener('input', () => {        
    //     text.textContent = caption.value
    // })

    // Change color
    // blue.addEventListener('click', () => {
    //     text.style.color = 'blue'
    //     colorPicker.value = 'blue'
    // })
    // red.addEventListener('click', () => {
    //     text.style.color = 'red'
    //     colorPicker.value = 'red'
    // })
    // green.addEventListener('click', () => {
    //     text.style.color = 'green'
    //     colorPicker.value = 'green'
    // })

    // // Close and open story container
    // function toggleStory(){
    //     document.querySelector('.upload_story_container').classList.toggle('show')
    // }
    // document.addEventListener('click', (e) => {
    //     if(e.target.classList == 'story_relative'){         
    //         toggleStory()
    //     }
    // })   


    // Sort Shortcut story randomly
    // let storyToSort = document.querySelectorAll('.user_story_container')
    // let parentStory = document.getElementById('parentSToryAppend')
    // let storyArr = [];
    // for(i = 0; i < storyToSort.length;i++){
    //     storyArr.push(storyToSort[i])
    // }
    // let newSort = storyArr.sort(() => Math.random() - 0.5);
    // for(i = 0; i < newSort.length; i++){
    //     parentStory.insertAdjacentElement('beforeend', newSort[i])        
    // }

    // Story *****************************

    // document.querySelector('#openStoryContainer').addEventListener('click', e => {

    // })

    document.querySelector('#scrollStory').addEventListener('click', () => {
        let scrollStory = document.querySelector('.story_list_container')
        scrollStory.scrollLeft += 30
        document.querySelector('.clicking_screw_left').style.display = 'block'

    })

    document.querySelector('#scrollStoryLeft').addEventListener('click', () => {
        let scrollStory = document.querySelector('.story_list_container')
        scrollStory.scrollLeft -= 30

        if (scrollStory.scrollLeft == 0) {
            document.querySelector('.clicking_screw_left').style.display = 'none'
        }

    })

    // preview img
    let storyImg = document.querySelector('.storyImg')
    document.querySelector('.chooseStory').addEventListener('change', function () {
        if (this.files) {
            storyImg.src = URL.createObjectURL(this.files[0]);
            document.querySelector('.update_upload_story_container').style.display = 'block'
        }

    })





    // Shuffle story
    let storyDiv = document.querySelectorAll('#story_list')
    let storyCOntainer = document.querySelector('.story_images')
    let storyDivArr = []
    for (i = 0; i < storyDiv.length; i++) {
        storyDivArr.push(storyDiv[i])
    }
    let newStoryArr = storyDivArr.sort(() => Math.random() - 0.5)

    for (i = 0; i < newStoryArr.length; i++) {
        // storyCOntainer.insertAdjacentHTML('afterend', newStoryArr[i])
        storyCOntainer.appendChild(newStoryArr[i])
    }









    // ********************************




    // send active to database
    const socket = io()
    let userId = document.getElementById('socketId').textContent
    socket.emit('sendUserDetails', userId)
    socket.emit('idForDisconnection', userId)




    // togge mention
    function toggleMention() {
        document.querySelector('.mentioning_contaioner').classList.toggle('toggle_mention_new')
    }

    document.getElementById('mentionIcon').addEventListener('click', (e) => {
        // send id to socket and fetch followes
        // socket.emit('fetchFollowersForMention', userId)
        openMentionFunction()
        toggleMention()
        document.getElementById('appendMentionUsers').innerText = ''
        document.querySelector('.mentionLoade').style.display = 'block' //show loader
    })

    document.querySelector('.mentioning_contaioner').addEventListener('click', (e) => {
        if (e.target.className == 'mentioning_contaioner toggle_mention_new') {
            toggleMention()
            document.getElementById('appendMentionUsers').innerText = ''
            document.querySelector('.mentionLoade').style.display = 'block' //show loader
        }
    })

    function openMentionFunction(params) {
        // mentioning users
        fetch('/fetche_users_for_post')
            .then(res => res.json())
            .then(data => {
                if (data.length > 0) {
                    document.querySelector('.mentionLoade').style.display = 'none'
                }

                if (data.length == 0) {
                    document.querySelector('.mentionLoade').innerHTML = 'No follower found'
                }

                let appendMentionUsers = document.getElementById('appendMentionUsers')
                appendMentionUsers.innerHTML = ''
                // for (i = 0; i < data.length; i++) {
                data = data.splice(0, 10)
                data.map(cur => {
                    appendMentionUsers.innerHTML +=
                        `<div class="tag_list">
                            <img src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                            <div class="tag_list_name">
                                <p>${cur.firstname} ${cur.lastname}</p>
                                <p id="tagName">@${cur.fullName}</p>
                            </div>
                            <div class="clickable_tag_list">
                                <h4 style="display: none;">${cur.fullName}</h4>
                            </div>
                        </div>`

                    // mention a user 
                    let mentionVictim = document.querySelectorAll('.clickable_tag_list')
                    for (i = 0; i < mentionVictim.length; i++) {
                        mentionVictim[i].addEventListener('click', (e) => {
                            let inputText = document.getElementById('textarea')
                            inputText.value += '@'
                            inputText.value += e.target.children[0].textContent

                        })
                    }

                })

                // }
            })

    }


    // socket.on('readyToMentionUsers', result => {
    //     if (userId === result.id) {
    //         document.querySelector('.mentionLoade').style.display = 'none' //hide loader
    //         let appendMentionUsers = document.getElementById('appendMentionUsers')
    //         let data = result.fetchedMentioned
    //         appendMentionUsers.innerHTML = ''
    //         for (i = 0; i < data.length; i++) {
    //             appendMentionUsers.innerHTML += `<div class="tag_list">
    //                 <img src="/webStorage/avatar/${data[i].avatar}" alt="">
    //                     <div class="tag_list_name">
    //                         <p>${data[i].firstname} ${data[i].lastname}</p>
    //                         <p id="tagName">@${data[i].fullName}</p>
    //                     </div>
    //                     <div class="clickable_tag_list">
    //                         <h4 style="display: none;">${data[i].fullName}</h4>
    //                     </div>
    //                 </div>`

    //             // mention a user 
    //             let mentionVictim = document.querySelectorAll('.clickable_tag_list')
    //             for (i = 0; i < mentionVictim.length; i++) {
    //                 mentionVictim[i].addEventListener('click', (e) => {
    //                     let inputText = document.getElementById('textarea')
    //                     inputText.value += '@'
    //                     inputText.value += e.target.children[0].textContent

    //                 })
    //             }

    //         }

    //     }
    // })


    // typing to prompt out users
    document.getElementById('mentionInput').addEventListener('input', e => {

        fetch('/mentionInputRoute', {
            method: 'POST',
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                text: document.getElementById('mentionInput').value,
            })
        })
            .then(res => {
                return res.json()
            })

            .then(result => {
                let data = result
                appendMentionUsers.innerHTML = ''
                for (i = 0; i < data.length; i++) {
                    appendMentionUsers.innerHTML += `<div class="tag_list">
                    <img src="https://plogapp.s3.amazonaws.com/${data[i].avatar}" alt="">
                        <div class="tag_list_name">
                            <p>${data[i].firstname} ${data[i].lastname}</p>
                            <p id="tagName">@${data[i].fullName}</p>
                        </div>
                        <div class="clickable_tag_list">
                            <h4 style="display: none;">${data[i].fullName}</h4>
                        </div>
                    </div>`

                    // mention a user 
                    let mentionVictim = document.querySelectorAll('.clickable_tag_list')
                    for (i = 0; i < mentionVictim.length; i++) {
                        mentionVictim[i].addEventListener('click', (e) => {
                            let inputText = document.getElementById('textarea')
                            inputText.value += '@'
                            inputText.value += e.target.children[0].textContent

                        })
                    }

                }
            })

            .catch(error => {
                console.log(error, 'Error')
            })

    })



    // Script for welcome message
    document.addEventListener('click', (e) => {
        if (e.target.classList == 'welcome_container') {
            document.querySelector('.welcome_container').style.display = 'none'
            socket.emit('hideWelcomeMsg', {
                display: 'none',
                id: userId
            })
        }
    })

    document.querySelector('.getStrated').addEventListener('click', (e) => {
        document.querySelector('.welcome_wrapper').style.display = 'none'
        socket.emit('hideWelcomeMsg', {
            display: 'none',
            id: userId
        })
    })



}


// let videoFile = document.querySelector('.videoFile')
// document.querySelector('.submitBtn').addEventListener('click', (e) => {
//     if (videoFile.value == '') {
//         alert('Please Upload video')
//         e.preventDefault()
//     }

//     e.target.style.display = 'none'

// })

// Append hashtag to input
document.querySelector('#hash_tag').addEventListener('click', (e) => {
    let inputText = document.getElementById('textarea')
    inputText.value += '#'



})


if (window.matchMedia("(max-width: 700px)").matches) {
    let suggestedTofollow = document.querySelectorAll('#suggestedTofollow')
    for (i = 0; i < suggestedTofollow.length; i++) {
        let str = suggestedTofollow[i].textContent
        if (str.length > 16) {
            str = str.substr(0, 16)
            suggestedTofollow[i].textContent = str + '...'
        }
    }
}


let singularPara = document.querySelectorAll('#singularPara')
for (i = 0; i < singularPara.length; i++) {
    let checkNum = singularPara[i].parentElement.children[1].textContent
    checkNum = parseInt(checkNum)
    if (checkNum <= 1) {
        singularPara[i].textContent = checkNum + ' follower'
    }

}

/*
// Push notification
console.log(Notification.permission)

function showNotificationFunction() {
    const notification = new Notification("New notificationn from plogapp", {
        body: 'Hello a new maeeage just arrived',
        icon: '/images/logo/logo4.png'
    })
}
if (Notification.permission == 'granted') {
    showNotificationFunction()
} else if (Notification.permission !== 'denied') {
    Notification.requestPermission().then(data => {
        if(data == 'granted') {
            console.log(data)
            showNotificationFunction()        
        }
    }).catch(error => {
        console.log(error)
    })
}

*/

console.log("%c Error", "font-size: 100px;background: green;padding: 10px;border-radius: 20px;")
console.log("%c Please do not copy-paste any information from here and send to any user. They might hack your account if you do so. kindly close this console for your safty.", "font-size: 20px;background: green;padding: 10px;")