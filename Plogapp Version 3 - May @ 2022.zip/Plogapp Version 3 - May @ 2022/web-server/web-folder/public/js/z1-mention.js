// (function (win, doc) {
//     'use strict';
//     var mentionVictims = document.querySelectorAll('p.hashTag');
//     for (var i = 0; i < mentionVictims.length; i++) {
//         if (mentionVictims[i].hasChildNodes) {
//             var padLeft = document.createTextNode(" ");
//             var padRight = document.createTextNode("");
//             mentionVictims[i].appendChild(padRight);
//             mentionVictims[i].insertBefore(padLeft, mentionVictims[i].firstChild);
//         }
//     }
//     var siteURL = '/mention',
//         entries = doc.querySelectorAll('p.hashTag'),
//         i;
//     if (entries.length > 0) {
//         for (i = 0; i < entries.length; i = i + 1) {
//             if ((entries[i].innerHTML.indexOf("]") == -1) && (entries[i].innerHTML.indexOf("=") == -1)) {
//                 entries[i].innerHTML = entries[i].innerHTML.replace(/((?!([\S]))[\S\s])@(\p{L}+)/gu, ' <a href="' + siteURL + '/$3" class="hashlink" title="">@$3</a>');
//             }
//         }
//     }
// }(this, this.document));