{
    const socket = io()
    let videoReceiverId = document.getElementById('videoReceiver').textContent
    let videoCaller = document.getElementById('videoCaller').textContent
    
    // caller quitting the call
    document.getElementById('cancel_btn').addEventListener('click', e => {
        socket.emit('sendCallerQuitting', videoReceiverId)
        window.history.back()
    })

    document.getElementById('desconnect').addEventListener('click', e => {
        socket.emit('sendCallerQuitting', videoReceiverId)
        window.history.back()
    })

    

    // going back if receiver closes  the call or lsiten to  when caller quit the call
    socket.on('calcelRequest', data => {
        if(videoCaller == data){
            document.getElementById('showBusy').textContent = 'User busy'
            window.history.back()
        }
    })




}    
