let recepientId = {
    textContent: chatGlobalObject.recipientId
}

// Function for scrolling bottom
// let sound = document.getElementById('sound')
function scrollUpUsers() {
    let x = document.querySelector('.main_chat_body_content')
    x.scrollTop = x.scrollHeight
    // document.querySelector('.main_chat_body_content').scrollTop =
}

// Audio upload
addEventListener('click', (e) => {
    if (e.target.classList == 'audioContainer') {
        document.querySelector('.audioContainer').style.display = 'none'
    }
})







// select audio script
document.querySelector('#selectAudio').addEventListener('click', (e) => {
    document.querySelector('.audioContainer').style.display = 'block';
    toggleUplaodFiles()
})

// }
// })()

// ****************************************************************************************************
let audioInput = document.querySelector('.audioPicker')
let receiverId_ = location.href.substr(-24, (location.href.length))

let audioObj = {}
let getFakeAdio = document.getElementById('audioPreviewListen')
document.querySelector('#audioUpload').addEventListener('change', function () {
    if (this.files) {
        console.log(this.files[0])
        document.getElementById('fileName').textContent = this.files[0].name.substr(0, 19) + '...'
        document.getElementById('uploadBtn').disabled = false


        getFakeAdio.src = URL.createObjectURL(audioInput.files[0]);
        getFakeAdio.play()

        audioObj.audio = audioInput.files[0]
        setTimeout(() => {
            let seconds = getFakeAdio.duration
            let minutes = Math.floor((seconds / 60))
            let secs = Math.floor((seconds % 60))
            let audioFulltime = minutes + ':' + secs
            // console.log(audioFulltime)
            audioObj.duration = audioFulltime
            getFakeAdio.pause()
            getFakeAdio.src = ''
        }, 1000);



    }
})



document.getElementById('uploadBtn').addEventListener('click', (e) => {
    if (audioInput.value == '') {
        e.preventDefault()
    }
    else {
        e.preventDefault()
    }


    document.querySelector('.audioContainer').style.display = 'none';
    document.querySelector('.sending_status').style.display = 'block';

    let data = new FormData()
    data.append('uploads', audioObj.audio)
    data.append('voiceNoteTime', audioObj.duration)


    // data.append('message', message.value)
    // appendingImageUpload(input.files[0], message.value)
    fetch('/chatMusicUpload/' + location.href.substr(-24, location.href.length), {
        method: 'POST',
        body: data
    })
        .then(res => {
            document.querySelector('.sending_status').style.display = 'none';

        }).catch(err => {
            console.log(err)
        })
    // }
}, 1000);



socket.on('audioListen', (data) => {
    if (data.receiverId === myId && data.owner === location.href.substr(-24, location.href.length)) {
        let cur = data
        let html = `
                    <div class="friend_chat_box pushAudioLeft" id="chat_container_box">
                            <div class="ch_record_chat_list  '${data.chatReveiverId.randomid}'" style="display: ${cur.hideVoiceNote};">
                                <div class="vc_chat_hd">
                                <p style="font-size: 12px;"> <i class="fa fa-clock-o" ></i> <small> ${cur.date}</small>-|-<small> ${cur.voiceNoteTime}</small> </p>
                        
                                    <div class="cv_option_relative">
                                        <i class="fa fa-ellipsis-h" onclick="this.parentElement.children[1].style.display = 'block'"></i>
                        
                                        <div class="main_vc_chat_option" style="display: none;">
                                            <div class="vc_option_absolute_list">
                                                <div>
                                                    <p id="deleteVoiceNoteBtn" onclick="deleteVoiceNoteFun('${data.chatReveiverId.randomid}')">Delete</p>
                                                </div>
                                                <div class="close_vc_option">
                                                    <i onclick="this.parentElement.parentElement.parentElement.style.display = 'none'"
                                                        class="fa fa-close"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                        
                                </div>
                        
                                <div class="cv_sender_recievers_img">
                                    <div class="audio_vc_loader">
                                        <div class="box init">
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                                            <div class="animateLoader"></div>
                        
                                        </div>
                                    </div>
                                    <div class="vc_play_btn">
                                        <i id="playVoiceNote" onclick="playVnBtn('https://plogapp.s3.amazonaws.com/${cur.audio}')" class="fa fa-circle"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
        `
        appendChatMessages.insertAdjacentHTML('beforeend', html)
        scrollUpUsers()
        // playAudioFunction()
        toggleLoader()
        changeIconbtn()
        sound.play()
    }
})


// let myId = document.getElementById('myId').textContent
// Append audio to use that sent the audio
socket.on('audioListen', data => {

    if (data.owner == myId) {
        let cur = data
        let html = `
                    <div class="friend_chat_box pushAudioRight" id="chat_container_box">
                    <div class="ch_record_chat_list  '${cur.chatsenderId.randomid}'" style="display: ${cur.hideVoiceNote};">
                        <div class="vc_chat_hd">                            
                            <p style="font-size: 12px;"> <i class="fa fa-clock-o" ></i> <small> ${cur.date}</small>-|-<small> ${cur.voiceNoteTime}</small> </p>
                
                            <div class="cv_option_relative">
                                <i class="fa fa-ellipsis-h" onclick="this.parentElement.children[1].style.display = 'block'"></i>
                
                                <div class="main_vc_chat_option" style="display: none;">
                                    <div class="vc_option_absolute_list">
                                        <div>
                                            <p id="deleteVoiceNoteBtn" onclick="deleteVoiceNoteFun('${cur.chatsenderId.randomid}')">Delete</p>
                                        </div>
                                        <div class="close_vc_option">
                                            <i onclick="this.parentElement.parentElement.parentElement.style.display = 'none'"
                                                class="fa fa-close"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                
                        </div>
                
                        <div class="cv_sender_recievers_img">
                            <div class="audio_vc_loader">
                                <div class="box init">
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                                    <div class="animateLoader"></div>
                
                                </div>
                            </div>
                            <div class="vc_play_btn">
                                <i id="playVoiceNote" onclick="playVnBtn('https://plogapp.s3.amazonaws.com/${cur.audio}')" class="fa fa-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>

                `
        appendChatMessages.insertAdjacentHTML('beforeend', html)
        // let chatImage = document.querySelectorAll('#chatImage')
        // chatImage[chatImage.length - 1].src = URL.createObjectURL(file);
        scrollUpUsers()
        toggleLoader()
        changeIconbtn()
        // playAudioFunction()
    }

})

// playAudioFunction()
