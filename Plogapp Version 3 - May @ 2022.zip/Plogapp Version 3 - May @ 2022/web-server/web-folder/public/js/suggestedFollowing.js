(function () {

    const socket = io();
    let userId2 = document.getElementById('userId').textContent

    // Load sponsored posts ever 7 seconds 
    let count = 0
    setInterval(() => {
        setTimeout(() => {
            count++
            updateSpnsored()
        }, 5000);
    }, 7000);

    updateSpnsored()
    function updateSpnsored() {
        fetch('/sponsored-post-rout-api')
            .then(res => res.json())
            .then(data => {
                updateSponsoredPost(data)
            })
            .catch(error => {
                console.log(error)
            })
    }

    let randomText = ['Getting viral and sponsored by plogapp', 'Sponsored by plogapp reached so many people']
    function updateSponsoredPost(data) {
        let appendSponsored = document.querySelectorAll('#appendSponsored')
        Array.from(appendSponsored).forEach(element => {
            element.innerHTML = ''
            data.map((cur, index) => {
                let sponsored_skeleton = document.querySelectorAll('.sponsored_skeleton')
                Array.from(sponsored_skeleton).forEach(skeletion => {
                    skeletion.style.display = 'none'

                })


                element.innerHTML +=
                    `
                    <a href="/viewImagePostDetails/${cur._id}">
                        <div class="popular_post_wrapper">
                            <div class="main_relative_gtrs">
                                <div class="suggested_post_img">
                                    <img id="mainImgdex" src="https://plogapp.s3.amazonaws.com/${cur.image}">
                                </div>
                                <div class="poster_avatar_div">
                                    <img src="https://plogapp.s3.amazonaws.com/${cur.avatar}">
                                </div>
                            </div>
    
                            <div class="post_description">
                                <h5><span style="sugPostH4">${cur.possterName}</span> <span><i class="${cur.verified}"></i></span></h5>
    
                                <div class="add_line_height">
                                <p><span id="nickName"> @${cur.posterNickName}</span></p>
                                    <h5 id="postText" class="hashTag sponsored-text">${(cur.description == "") ? randomText[Math.floor(Math.random() * randomText.length)] : cur.description.substr(0, 50)} </h5>
                                    
                                </div>
                            </div>
                        </div>
                    </a>
                    
                    `
                darkModeFunction()


            })
        })
    }

})()



//Loop through people you may follow
suggestedTOFOllow()
setInterval(suggestedTOFOllow, 3000)
function suggestedTOFOllow() {
    let append_suggested_users = document.getElementById('append_suggested_users')
    fetch('/suggested-to-follow-api')
        .then(res => res.json())
        .then(result => {

            if (result.length >= 1) {
                document.querySelector('.suggested_animate').style.display = 'none'
            }
            let data = [...new Set(result)].splice(0, 4)

            append_suggested_users.innerHTML = ''
            data.map(cur => {
                append_suggested_users.innerHTML += `<div class="sugg_details">
                                <div class="sugg_del_des">
                                    <a href="/profile/${cur._id}">
                                        <div class="suggested_avatar">
                                            <img class="sharedProfile_pic" src="https://plogapp.s3.amazonaws.com/${cur.avatar}">
                                        </div>
                                    </a>
                                    <div class="sugg_detl">
                                        <a href="/profile/${cur._id}">
                                            <h4 style="text-transform: capitalize; color: black">${cur.firstname} ${cur.lastname} <span><i
                                                        class="${cur.verified}"></i></span></h4>
                                            <p style="display: none;" id="Suggbio">${cur.bestSentence}</p>
                                            <p style="display: none" class="sugg_nicname">@${cur.fullName}</p>
                                            <div>
                                                <p id="sugFollTxt">@${cur.fullName}</p>
                                                <p style="display: none;" id="sugFollTxt">${cur.followerLength} followers</p>
                                                <p style="display: none">${cur.followerLength}</p>
                                            </div>
                                        </a>
                                    </div>
                                </div>

                                <div class="follow_button">
                                    <button id="subFollowBtn">Follow</button>
                                    <p style="display: none;">${cur._id}</p>
                                    <div class="loader"></div>
                                </div>
                            </div>
                            
                            `

                darkModeFunction()


                let userId2 = document.getElementById('userId').textContent
                let btn = document.querySelectorAll('#subFollowBtn')
                for (i = 0; i < btn.length; i++) {
                    btn[i].addEventListener('click', (e) => {
                        let followingId = e.target.parentElement.children[1].textContent

                        // show loading button
                        let loader = e.target.parentElement.children[2]
                        let button = e.target
                        button.style.display = 'none'
                        loader.style.display = 'block'
                        setTimeout(() => {
                            loader.style.display = 'none'
                            button.style.display = 'block'
                            return
                        }, 1000);



                        fetch('/follow-unfollow', {
                            method: 'POST',
                            headers: {
                                'Accept': 'application/json, text/plain, */*',
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                followingId,
                            })
                        })
                            .then(res => {
                                return res.json()
                            })

                            .then(data => {
                                console.log(data)
                            })
                            .catch(error => {
                                console.log(error)
                            })


                        // let followingDetails = {
                        //     followingId,
                        //     userId: userId2
                        // }
                        // console.log(followingDetails)
                        // socket.emit('followingDetails', followingDetails)

                        // console.log(e.target.style.color)
                        if (e.target.textContent == 'Follow') {
                            e.target.style.backgroundColor = 'white'
                            e.target.style.color = 'cornflowerblue'
                            e.target.style.border = '3px solid cornflowerblue'
                            e.target.style.padding = '7px'
                            e.target.textContent = 'Following'

                        } else {
                            e.target.style.backgroundColor = 'cornflowerblue'
                            e.target.style.color = 'white'
                            e.target.style.padding = '7px 18px'
                            e.target.textContent = 'Follow'

                        }

                    })

                }
            })
        })
        .catch(error => {
            console.log(error)
        })
}
