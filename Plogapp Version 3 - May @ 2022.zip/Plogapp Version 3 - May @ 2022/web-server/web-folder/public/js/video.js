console.log('Hey222')
window.addEventListener('load', () => {

    function MainVideoPage() {
        let video = document.getElementById('publick_video');
        let range = document.getElementById('public_range');
        let control = document.getElementById('control');

        control.addEventListener('click', () => {
            if (video.paused) {
                video.play()

            } else {
                video.pause()
            }

            setInterval(() => {
                range.max = video.duration
                range.value = video.currentTime

            }, 0);

        })

        // Mute video
        document.getElementById('public_mute').addEventListener('click', () => {
            if (video.muted === false) {
                video.muted = true
            } else {
                video.muted = false
            }
        })

        document.getElementById('public_range').addEventListener('input', () => {
            range.max = video.duration;
            video.currentTime = range.value
        })


        // Skip frame 

        const skpeNum = 1
        const backword = document.getElementById('forwardVideo');
        backword.addEventListener('click', () => {
            video.currentTime += 2
            console.log("Helo")

        })

        const forward = document.getElementById('backwardVideo');
        forward.addEventListener('click', () => {
            video.currentTime -= 2
            console.log("Helo")

        })





    }
    MainVideoPage()





    const playVideo = () => {
        const video = document.querySelectorAll('.video_box');
        video.forEach((cur) => {
            cur.addEventListener('click', (e) => {
                // get the video src
                const video = document.getElementById('publick_video');
                const title = document.getElementById('video_title')
                const newVid = e.target.parentElement.children[0].children[0].src
                const newTitle = e.target.parentElement.nextElementSibling.children[1]
                video.src = newVid;
                video.play()
                title.textContent = newTitle.textContent


            })
        })
    }

    // Download video



    playVideo()





})    
