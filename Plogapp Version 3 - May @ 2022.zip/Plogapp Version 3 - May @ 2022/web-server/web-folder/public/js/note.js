let form = document.querySelector('.task_container');
document.querySelector('#addTask').addEventListener('click', () => {
    form.style.display = 'block'
})



let x = document.querySelector('.update_container');
let modifyBtn = document.querySelectorAll('#modyfyTask');
modifyBtn.forEach(cur => {
    cur.addEventListener('click', (e) => {
        x.style.display = 'block';
        let title, description, id;
        let inputTitle = document.getElementById('title')
        let inputDescription = document.getElementById('description')
        let inputId = document.getElementById('_id')

        
        title = e.target.parentElement.parentElement.parentElement.children[0].children[0].textContent;
        description = e.target.parentElement.parentElement.parentElement.children[1].children[0].textContent;
        id = e.target.parentElement.parentElement.parentElement.children[1].children[1].textContent;
        inputTitle.value = title;
        inputDescription.value = description
        inputId.value = id
    })
})
