(function () {
    const socket = io()
    LikingCommentsFunction()
    var url = new URLSearchParams(location.search);
    var receiverName = url.get("errorMsg");
    if (receiverName) {
        document.getElementById('errorMessage').innerHTML = 'Invald string please try again later'
        setTimeout(() => {
            document.getElementById('errorMessage').innerHTML = ''
        }, 3000);
        console.log('Error message')
    }

    let del = document.querySelectorAll('.comment_options');
    let Userid = document.getElementById('userId').textContent
    let primaryId = document.getElementById('primaryId').textContent
    for (i = 0; i < del.length; i++) {
        let textStr = del[i].textContent;
        if (!textStr.includes(Userid)) {
            del[i].style.display = 'none'
        }
    }

    let confirmDelete = document.querySelectorAll('.delete_container');
    let hide = document.querySelectorAll('#deleteBtn');
    let closeDeleteBtn = document.querySelectorAll('#closeDeleteBtn');



    hide.forEach(cur => {
        cur.addEventListener('click', (e) => {
            let div = e.target.parentElement.children[2]
            div.classList.toggle('hideContainer')
        })
    })

    closeDeleteBtn.forEach((cur) => {
        cur.addEventListener('click', (e) => {
            let x = e.target.parentElement.parentElement
            x.classList.toggle('hideContainer')
        })
    })

    // Get length of comments to send to database
    let commentDiv = document.querySelectorAll('#getlengthOfDive');
    let inputWithLength = document.getElementById('replyCommentLength')
    inputWithLength.value = (commentDiv.length + 1)


    // Globally change color to gray
    let allHearts = document.querySelectorAll('#changeHeartCOlor2');
    for (i = 0; i < allHearts.length; i++) {
        allHearts[i].style.color = 'gray'
    }

    // Change color if id is found
    let x = document.querySelectorAll('.reactionForReply')
    for (i = 0; i < x.length; i++) {
        let heart = x[i].children[0]
        let ids = x[i].children[3].textContent
        if (ids.split(',').indexOf(primaryId) > -1) {
            heart.style.color = '#ff00bc'
            heart.classList = 'fa fa-heart'
        }
        // if (ids.includes(primaryId)) {
        //     heart.style.color = '#ff00bc'
        //     heart.classList = 'fa fa-heart'
        // }
    }

    // Validate form fiel
    let typer = document.querySelector('.send_icon_')
    typer.style.display = 'none'
    document.addEventListener('input', () => {
        let input = document.getElementById('myInput');
        if (input.value == '') {
            typer.style.display = 'none'
        } else {
            typer.style.display = 'block'
        }
    })


    for (i = 0; i < x.length; i++) {
        x[i].addEventListener('click', (e) => {
            let heartIcon = e.target.parentElement.children[0]
            let numOfLikes = e.target.parentElement.children[0].children[0]
            let userId = e.target.parentElement.children[1].textContent
            let commentId = e.target.parentElement.children[2].textContent
            let reactionForReplyDetails = {
                userId,
                commentId
            }
            // Send detauls to database
            socket.emit('reactionForReplyDetails', reactionForReplyDetails)

            // Convert to number
            let newNumofLikes = parseInt(numOfLikes.textContent) || 0;


            // Change color when clicked
            if (heartIcon.style.color == 'gray') {
                heartIcon.style.color = '#ff00bc'
                heartIcon.classList = 'fa fa-heart'

                numOfLikes.textContent = newNumofLikes += 1
            } else {
                heartIcon.style.color = 'gray'
                numOfLikes.textContent = newNumofLikes -= 1
                heartIcon.classList = 'fa fa-heart-o'
            }

        })
    }


    let commentOptionIcon = document.querySelectorAll('#commentOptionIcon')
    for (i = 0; i < commentOptionIcon.length; i++) {
        commentOptionIcon[i].addEventListener('click', (e) => {
            // Open comment option        

            let div = document.querySelectorAll('.comment_sub_wrap')
            for (j = 0; j < div.length; j++) {
                div[j].style.display = 'none'
            }

            e.target.parentElement.children[1].style.display = 'block'

        })
    }

    // Hide delete button 
    let delBtn = document.querySelectorAll('#hideDeleteButton')
    for (i = 0; i < delBtn.length; i++) {
        if (!delBtn[i].textContent.includes(Userid)) {
            delBtn[i].parentElement.style.display = 'none'
        }
    }


    let coyComment = document.querySelectorAll('#copyComment')
    for (i = 0; i < coyComment.length; i++) {
        coyComment[i].addEventListener('click', (e) => {
            // Open comment option
            let input = e.target.parentElement.children[1]
            input.style.display = 'block'
            input.select()
            document.execCommand('copy')
            input.style.display = 'none'
        })
    }

    let closeOption = document.querySelectorAll('#closeOption')
    for (i = 0; i < closeOption.length; i++) {
        closeOption[i].addEventListener('click', (e) => {
            e.target.parentElement.parentElement.style.display = 'none'
        })
    }

})()

// reporting post

let reportCommentBtn = document.querySelectorAll('#reportCommentBtn')
Array.from(reportCommentBtn).forEach(cur => {
    if (cur.getAttribute('comment_owner').toString() == document.getElementById('userId').textContent) {
        cur.style.display = 'none'
    }
})


function reportPostFunction(e) {
    console.log(e)
    let type = e.getAttribute('type')
    let victim = e.getAttribute('victim')    
    location.href = `/report?type=${type}&&victim=${victim}`
}