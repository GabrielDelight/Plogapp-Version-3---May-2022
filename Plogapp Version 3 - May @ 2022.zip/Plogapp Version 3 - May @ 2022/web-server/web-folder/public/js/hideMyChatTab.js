// Remove story that belongs to  me 
let myChat = document.querySelectorAll('.chat_user_details');
let id = document.getElementById('userId').textContent
let str 
for(i = 0; i< myChat.length; i++){
    str = myChat[i].children[2].textContent
    if(str.includes(id)){
        myChat[i].parentElement.style.display = 'none'
    }

}

// Remove users that are not following
for(i = 0; i< myChat.length; i++){ 
    str = myChat[i].children[3].textContent
    if(!str.includes(id)){
        myChat[i].parentElement.style.display = 'none'
    }
}