// (function () {
// let myId = document.getElementById('myId').textContent
let downloadSrc = {}
let receiverIdx = location.href.substr(-24, location.href.length)



// Clicking the image to view large image ***************************
let viewimgImage = document.getElementById('viewimgImage')
function toggleViewImageContainer() {
    document.querySelector('.view_image_container').classList.add('toggle_open_image')
}

function toggleViewImageContainerRemove() {
    document.querySelector('.view_image_container').classList.remove('toggle_open_image')
}


// clocking the image modal
document.addEventListener('click', (e) => {
    if (e.target.classList == 'view_image_container toggle_open_image') {
        // toggleViewImageContainer()
        toggleViewImageContainerRemove()
    }
})

// Clicking the close button to close
document.getElementById('closeChatImg').addEventListener('click', e => {
    // toggleViewImageContainer()
    toggleViewImageContainerRemove()
})

// downloading the image
document.getElementById('downloadImage').addEventListener('click', () => {
    let id = document.getElementById('delInputImg').value
    let anchor = document.getElementById('autoDownloadClick')
    anchor.href = downloadSrc.url
    document.getElementById('imageForDownload').href = "/serveCHatImg/" + id
    // console.log()
    anchor.click()
})


document.getElementById('openImageToggle').addEventListener("click", e => {
    toggleImageUpload()
})

// toggle function
function toggleImageUpload() {
    document.querySelector('.upload_chat_image_container').classList.toggle('toggle_img_upload')
}

// choosing image
document.querySelector('#selectImg').addEventListener('click', e => {
    document.getElementById('chatImg').click()
})

// choosing an image from file
let imgUpload = document.getElementById('imgFileUpload')
document.querySelector('.imgUpload').addEventListener('change', function () {
    if (this.files) {
        imgUpload.src = URL.createObjectURL(this.files[0]);
        // toggleImageUpload()
        toggleUplaodFiles()
    }
})

// closing the image upload container by clicking (x)
document.querySelector('#closeImgUpload').addEventListener('click', e => {
    toggleImageUpload()
})

// canceling clicking the cancel buttin 
document.getElementById('cancelImgUpload').addEventListener('click', (e) => {
    e.preventDefault() //prevening it from loading 
    toggleImageUpload() //toggling  the imagee uploader
})

// closing the image uplloader by clsing the image container
let imgModal = document.querySelector('.upload_chat_image_container')
imgModal.addEventListener('click', (e) => {
    if (e.target.classList == 'upload_chat_image_container toggle_img_upload') {
        toggleImageUpload()
    }
})


// validate uploading image
let imageSendBtn = document.getElementById('sendImg')
let imagePick = document.querySelector('#imgUpload')
imageSendBtn.addEventListener('click', (e) => {
    if (imagePick.value == '') {
        e.preventDefault()
        return
    }
    else {
        socket.emit('imageSrc', {
            src: imgUpload.src,
            receiverId: receiverId,
            owner: myId,
            text: 'Image appended'
        })
    }
})


// Uploading an image
document.getElementById('uploadImageBtn').addEventListener('click', () => {
    let input = document.getElementById('chatImg')
    let message = document.getElementById('imageAttachedtxt')

    // appendingImageUpload(input.files[0], message.value)
    toggleImageUpload()

    var f = input.files[0];
    var fileName = f.name.split('.')[0];
    var img = new Image();
    img.src = URL.createObjectURL(f);
    img.onload = function () {
        var canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        var ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        canvas.toBlob(function (blob) {
            var newImage = new File([blob], fileName + ".jpeg");
            let data = new FormData()
            data.append('uploads', newImage)
            data.append('message', message.value)
            
            fetch('/chatImageUpload/' + location.href.substr(-24, location.href.length), {
                method: 'POST',
                body: data
            })
                .then(res => {
                    console.log(res)
                    setInterval(() => {
                        let ifSend = document.querySelectorAll('#sendingImagePara')
                        ifSend[ifSend.length - 1].textContent = 'Sent'
                    }, 1000);
                }).catch(err => {
                    console.log(err)
                })


        }, 'image/jpeg', 0.1);
    }
})

// Appendingimages to client's browser
socket.on('photoListen', data => {

    let receiverIdx = location.href.substr(-24, location.href.length)

    // append image
    if (data.receiverId === myId && data.owner === receiverIdx) {
        let html = `<div class="friend_chat_box pushImgLeft" id="chat_container_box">
    <div class="friends_image2"></div>
    <div class="friend_chat_details">            
        <div class="chat_text_box blueColor">                
            <img id="chatImage" src="/webStorage/chatImages/${data.image}" alt="">
            <p id="" style="display: none">${data.randomChatId2}</p>
            <p id="">${data.message}</p>
        </div>
    </div>`

        appendChatMessages.insertAdjacentHTML('beforeend', html)
        viewImageLarge()
        scrollUpUsers()
        scrollUpUsers()
        sound.play()
    }


    // Append the image to to first user using socket io

    if (data.owner == myId) {
        let html = `<div class="friend_chat_box pushImgRight" id="chat_container_box">
        <div class="friends_image2"></div>
        <div class="friend_chat_details">            
            <div class="chat_text_box blueColor">                
                <img id="chatImage" src="/webStorage/chatImages/${data.image}" alt="">
                <p id="" style="display: none">${data.randomChatId1}</p>
                <p id="">${data.message}</p>
                <p style="font-size: 10px;text-align: right; color: #bbb" id="sendingImagePara">Sending...</p>
            </div>
        </div>`

        appendChatMessages.insertAdjacentHTML('beforeend', html)
        viewImageLarge()
        scrollUpUsers()
        scrollUpUsers()
    }

})

// Viweing large image function
viewImageLarge()
function viewImageLarge() {
    let chatImages = document.querySelectorAll('#chatImage')
    for (i = 0; i < chatImages.length; i++) {
        chatImages[i].addEventListener('click', (e) => {
            toggleViewImageContainer()
            viewimgImage.src = e.target.src
            document.getElementById('delInputImg').value = e.target.parentElement.children[1].textContent
            // console.log(document.getElementById('delInputImg').value)
            downloadSrc.url = e.target.src

            let deleteImageForm = document.getElementById('deleteImageForm')
            let receiverIdx1 = location.href.substr(-24, location.href.length)
            deleteImageForm.setAttribute('action', '/deleteImg/' + receiverIdx1)


        })
    }
}