// Toggle Options
(function () {
    const socket = io()
    let optionBtn = document.querySelectorAll('.post_options');
    for (i = 0; i < optionBtn.length; i++) {
        optionBtn[i].addEventListener('click', (e) => {
            const showContainer = e.target.parentElement.parentElement.parentElement.children[4]
            showContainer.style.display = 'block'

            // Download image
            let saveImage = e.target.parentElement.parentElement.parentElement.children[4].children[0].children[0].children[0].children[2]
            saveImage.addEventListener('click', () => {
                let text = e.target.parentElement.parentElement.parentElement.children[4].children[0].children[0].children[0].children[2].children[0].children[1]
                text.textContent = 'Saved'
                setTimeout(() => {
                    text.textContent = 'Save Image'
                }, 2000)
            })

            // Delete post        
            let deleteBtn = e.target.parentElement.parentElement.parentElement.children[4].children[0].children[0].children[0].children[5]
            console.log(deleteBtn)
            deleteBtn.addEventListener('click', (e) => {
                let x = e.target.children[0]
                x.style.display = 'block'
            })


            let NoBtn = e.target.parentElement.parentElement.parentElement.children[4].children[0].children[0].children[0].children[5].children[0].children[1].children[1]
            NoBtn.addEventListener('click', (e) => {
                let x = e.target.parentElement.parentElement
                x.style.display = 'none'

            })

            // Close container
            function closeFun() {
                let closeBtn = e.target.parentElement.parentElement.parentElement.children[4].children[0].children[0].children[0].children[7]
                closeBtn.addEventListener('click', () => {
                    showContainer.style.display = 'none'
                })
            }
            closeFun()


            document.addEventListener('click', (e) => {
                if (e.target.className == 'option_list' || e.target.className == 'option_container') {
                    showContainer.style.display = 'none'
                }
            })


        })
    }


    // copy post url to clip-board
    let copyLink = document.querySelectorAll('#copyLink')
    for (i = 0; i < copyLink.length; i++) {
        copyLink[i].addEventListener('click', (e) => {
            let link, input
            input = e.target.parentElement.children[1]
            input.style.display = 'block'
            link = e.target.parentElement.children[3].children[0].href
            input.value = link
            input.select();
            document.execCommand('copy')
            input.style.display = 'none'
            e.target.textContent = 'Copied'
            setTimeout(() => {
                e.target.textContent = 'Copy'
            }, 2000)
        })

    }


    function toggleEdit() {
        document.querySelector('.update_post_container').classList.toggle('toggle_edit_class')
    }

    let closeEditBbtn = document.querySelectorAll('#editPostBtn')
    closeEditBbtn.forEach(val => {
        val.addEventListener('click', e => {
            toggleEdit()
        })
    })

    // @ close edit post modal
    let closeEditModal = document.querySelectorAll('.update_post_container')
    closeEditModal.forEach(val => {
        val.addEventListener('click', e => {
            if (e.target.className == 'update_post_container toggle_edit_class') toggleEdit()
        })
    })


    // hide number of shares length if item lesser that 0
    let numOfShare = document.querySelectorAll('#numOfShare')
    for (i = 0; i < numOfShare.length; i++) {
        let len = parseInt(numOfShare[i].textContent)
        if (len < 1) {
            numOfShare[i].style.display = 'none'
        }
    }


    let editPostTExt = document.querySelectorAll('#editPost')
    for (i = 0; i < editPostTExt.length; i++) {
        editPostTExt[i].addEventListener('click', (e) => {
            // document.querySelector('.update_post_container').style.display = 'block'
            toggleEdit() //toggle edit modal

            let id = e.target.children[1]
            let text = e.target.children[2]

            // Pust post id to input
            document.querySelector('#postIdForEdit').value = id.textContent
            // Pust description to textarea                
            document.querySelector('#editTextarea').value = text.textContent
        })
    }


    // optionBtn.forEach((cur) => {
    //     cur.addEventListener('click', (e) => {

    //     })
    // })

    // Hide delete button
    let delBtn = document.querySelectorAll('#deleteBtn');
    let globalId = document.getElementById('userId').textContent
    for (i = 0; i < delBtn.length; i++) {
        let text = delBtn[i].textContent;
        if (!text.includes(globalId)) {
            delBtn[i].style.display = 'none'
        }

    }


    // Hide edit post 
    let editPost = document.querySelectorAll('#editPost')
    for (i = 0; i < editPost.length; i++) {
        let text = editPost[i].textContent
        if (!text.includes(globalId)) {
            editPost[i].style.display = 'none'
        }
    }


    // video section
    let controller = document.querySelectorAll('#controller')
    for (i = 0; i < controller.length; i++) {
        controller[i].addEventListener('click', (e) => {

            let pausebtn = e.target.parentElement.children[1]
            let seeker = e.target.parentElement.nextElementSibling.children[0]
            e.target.parentElement.children[0].style.display = 'none'
            e.target.parentElement.children[1].style.display = 'block'

            let video = e.target.parentElement.parentElement.parentElement.parentElement.children[0]
            video.play()


            pausebtn.addEventListener('click', () => {
                video.pause()
                e.target.parentElement.children[0].style.display = 'block'
                e.target.parentElement.children[1].style.display = 'none'
            })

            setInterval(() => {
                // Show play pause button when video is finished loading
                if (video.currentTime === video.duration) {
                    e.target.parentElement.children[0].style.display = 'block'
                    e.target.parentElement.children[1].style.display = 'none'
                }

                // moveing seeker                
                seeker.max = video.duration
                seeker.value = video.currentTime

            }, 0);





        })
    }

    // Edit post
    let modal = document.querySelector('.update_post_container')
    document.addEventListener('click', (e) => {
        if (e.target.className == 'update_post_container') {
        }
    })


    // trim some part of strings 
    let last_comment_text = document.querySelectorAll('#last_comment_text')
    for (i = 0; i < last_comment_text.length; i++) {
        let string = last_comment_text[i].textContent
        string = string.substr(0, 40)
        last_comment_text[i].textContent = string
    }


    // Sliding image script
    let slideLeft = document.querySelectorAll('#slideLeft')
    let slideRight = document.querySelectorAll('#slideRight')
    let postImage = document.querySelectorAll('#postImage')
    for (i = 0; i < postImage.length; i++) {
        let image = postImage[i]
        let numOfImg = postImage[i].parentElement.children[1].children[0].children[2].textContent

        let imageId = postImage[i].parentElement.children[1].children[0].children[3].textContent
        let imageId2 = postImage[i].parentElement.children[1].children[0].children[4].textContent
        let imageId3 = postImage[i].parentElement.children[1].children[0].children[5].textContent

        numOfImg = parseInt(numOfImg)
        let left = postImage[i].parentElement.children[1].children[0].children[0]
        let right = postImage[i].parentElement.children[1].children[0].children[1]

        let counter = 0
        let arrImage = ['https://plogapp.s3.amazonaws.com/' + imageId, 'https://plogapp.s3.amazonaws.com/' + imageId2, 'https://plogapp.s3.amazonaws.com/' + imageId3]
        if (numOfImg == 2) {
            arrImage.pop()
        }
        if (numOfImg == 1) {
            right.style.display = 'none'
            left.style.display = 'none'
        }

        let lastItem = arrImage[arrImage.length - 1]
        let lastIndex = arrImage.lastIndexOf(lastItem)

        right.addEventListener('click', (e) => {
            counter++
        })

        left.addEventListener('click', (e) => {
            counter--
        })

        setInterval(() => {
            image.src = arrImage[counter]
            if (counter < 0) counter = numOfImg - 1
            if (counter > lastIndex) counter = 0
        }, 0);


    }

    // clicking fetch reaction modal
    let appendReactors = document.getElementById('appendReactors')
    document.querySelector('.load_likes_modal').addEventListener('click', e => {
        if (e.target.className == 'load_likes_modal') {
            e.target.style.display = 'none'
            appendReactors.innerHTML = ''
        }
    })

    // clsoing from the x 
    document.querySelector('#closeReactorsPage').addEventListener('click', e => {
        document.querySelector('.load_likes_modal').style.display = 'none'
        appendReactors.innerHTML = ''
    })



    // clicking to fetch reactors on dm
    let fetchReactors = document.querySelectorAll('.fetchReactors')
    for (i = 0; i < fetchReactors.length; i++) {
        fetchReactors[i].addEventListener('click', e => {
            let postId = e.target.parentElement.parentElement.children[1].textContent
            if (postId.includes('comments')) {
                return
            }
            document.querySelector('.load_likes_modal').style.display = 'block'
            socket.emit('sendPostIdForReaction', postId)
            document.querySelector('.likesReactionLoade').style.display = 'block' //show loader
        })
    }



    // fetch reactions for a post
    socket.on('reaction-users', (data) => {
        document.querySelector('.likesReactionLoade').style.display = 'none' //show loader        
        appendReactors.innerHTML = ''
        data.map(cur => {
            appendReactors.innerHTML += `<div class="div_flex">
            <a href="/profile/${cur._id}">
            <div class="reactor_wrapper">
                    <img id="userPostAvatar" src="/webStorage/avatar/${cur.avatar}" alt="">
                    <div>
                        <h3 style="text-transform: capitalize;">${cur.firstname} ${cur.lastname} <span><i class="${cur.verified}"></i></span></h3>
                    </div>
                </div>
                </a>
                
                <div class="icon_heart">
                    <i class="fa fa-heart"></i>
                </div>
            </div>`
        })

    })

    // follow button in post 
    let followButton = document.querySelectorAll('#shortFollowBtn')
    let primaryId = document.getElementById('primaryId').textContent
    for (i = 0; i < followButton.length; i++) {
        let owner = followButton[i].parentElement.children[1].textContent
        let button = followButton[i]
        let followingArr = followButton[i].parentElement.children[2].textContent

        // hide follow button if its my post
        if (owner == primaryId) {
            button.style.display = 'none'
        }

        if (followingArr.includes(owner)) {
            button.style.color = 'cornflowerblue'
            button.style.border = '3px solid cornflowerblue'
            button.textContent = 'Following'
        } else {
            button.style.backgroundColor = 'cornflowerblue'
            button.textContent = 'Follow'
            button.style.color = 'white'
        }

    }

    // follow or unfollow
    for (i = 0; i < followButton.length; i++) {
        followButton[i].addEventListener('click', (e) => {
            let btn = e.target
            let loader = e.target.parentElement.children[3]
            let followingId = e.target.parentElement.children[6].textContent
            btn.style.display = 'none'
            loader.style.display = 'block'
            setTimeout(() => {
                loader.style.display = 'none'
                btn.style.display = 'block'
                return
            }, 1000);

            let followingDetails = {
                followingId,
                userId: e.target.parentElement.children[4].textContent
            }
            socket.emit('followingDetails', followingDetails)

            if (btn.textContent === 'Follow') {
                btn.style.color = 'cornflowerblue'
                btn.style.border = '3px solid cornflowerblue'
                btn.style.backgroundColor = 'white'
                btn.textContent = 'Following'
            } else {
                btn.style.backgroundColor = 'cornflowerblue'
                btn.textContent = 'Follow'
                btn.style.color = 'white'
            }
        })
    }

    // open short profile container
    let hoverToShowProfile = document.querySelectorAll("#hoverToShow")
    hoverToShowProfile.forEach(cur => {
        cur.addEventListener('mouseover', e => {
            e.target.parentElement.parentElement.parentElement.parentElement.parentElement.children[1].style.display = 'block'
        })
    })

    let closeShortProfile = document.querySelectorAll('.closeshortdiv')
    for (i = 0; i < closeShortProfile.length; i++) {
        closeShortProfile[i].addEventListener('click', e => {
            e.target.parentElement.parentElement.parentElement.parentElement.style.display = 'none'
        })
    }

})()