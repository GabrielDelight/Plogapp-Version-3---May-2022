// Sort post randomly /Shuffle
let appendPost = document.getElementById('append-container')
let increase = 10
let sortCount = 10
if (window.matchMedia("(max-width: 700px)").matches) {
    sortCount = 10
}

// User details
let userData = {
    _id: document.getElementById('userId').textContent,
    following: document.getElementById('followingIds').textContent.toString()
}


let url = '/fetching-post'
if (location.href.includes('profile')) {
    url = '/profile_api/' + document.getElementById('paramsid').textContent
} else if (location.href.includes('hashtag'))
    url = '/hashtag-rout/' + document.getElementById('paramsid').textContent
else {
    url = '/fetching-post'
}



// window.onload = function (params) {
loadSortedPostFunction()
// }

function loadSortedPostFunction() {
    // axios.get(url)
    fetch(url)
        .then(result => result.json())
        .then(res => {
            function loadmore(val) {


                // console.log(res)
                // let newPost = res.data.splice(0, val)
                let newPost = res.splice(0, val)
                if (newPost.length < 1) {
                    loadSortedPostFunction()
                }


                if (newPost.length <= 0 || newPost.length == 0) {
                    document.querySelector('.empty_postAlert').style.display = 'block'
                }
                if (newPost.length >= 1) {
                    document.querySelector('.empty_postAlert').style.display = 'none'

                }


                newPost.map((cur, index) => {

                    function urlify2(text) {
                        var urlRegex = /(((https?:\/\/)|(www\.)|(#)|(@))[^\s]+)/g;
                        //var urlRegex = /(https?:\/\/[^\s]+)/g;
                        return text.replace(urlRegex, function (url, b, c) {
                            var url2 = (c == 'www.') ? 'http://' + url : url;
                            if (url2[0] == '#') {
                                url2 = url2.substr(1, url2.length)
                                url2 = '/hashtag/' + url2
                            }
                            return '<a href="' + url2 + '" target="">' + url + '</a>';
                        })
                    }

                    var text = cur.description;
                    cur.description = urlify2(text);



                    if (cur.reactionLength == null) cur.reactionLength = ''
                    if (cur.shareLength == null) cur.shareLength = ''
                    if (cur.commentlength == null) cur.commentlength = ''


                    if (cur.postType == 'text') {
                        let postFont = 20 + 'px'
                        if (cur.description.length > 500) {
                            postFont = 13 + 'px'
                        }

                        appendPost.innerHTML +=
                            `<div class="post-container" ${index} id="${index == 3 ? 'appendFirstsuggested' : 'not-three'}" >
                    <div class="post-head">
                
                        <div class="poster_details">
                
                            <div class="user_details--img--name">
                                <div class="user_image_box">
                                    <a href="/profile/${cur.owner}">
                                        <img id="userPostAvatar" src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                                    </a>
                                </div>
                
                                <a>
                                    <h4><span id="hoverToShow" class="hoverToShowClass">${cur.possterName}</span> <span><i
                                                class="${cur.verified}"></i></span> <span id="nickName">@${cur.posterNickName}</span></h4>
                                    <p style="display: none">${cur.owner}</p>
                                </a>
                            </div>
                
                            <i class="fa fa-ellipsis-h post_options"></i>
                        </div>
                        <div class="show_shot_profile">
                            <div class="shortprofile_head">
                                <div class="flex-short-profile">
                                    <a href="/profile/${cur.owner}">
                                        <img src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                                    </a>
                                    <div class="shortProfileLoader">
                                        <button id="shortFollowBtn">Follow</button>
                                        <p style="display: none">${cur.ownerPrimaryid}</p>
                                        <p style="display: none">${userData.following}</p>
                                        <div class="loader"></div>
                                        <p style="display: none">${userData._id}</p>
                                        <i style="font-size: 14px" class="fa fa-close closeshortdiv"></i>
                                        <p style="display: none">${cur.owner}</p>
                                    </div>
                                </div>
                
                                <div clas="sht_styler">
                                    <a href="/profile/${cur.owner}">
                                        <h3 style="font-size: 15px">${cur.possterName} <span><i class="${cur.verified}"></i></span></h3>
                                        <p><span id="nickName">@${cur.posterNickName}</span></p>
                                    </a>
                                    <p style="font-size: 15px"><span style="font-weight: bolder;">${cur.posterFollower}</span> <span
                                            style="color: #b0b0b0">followers <span
                                                style="font-weight: bolder;">${cur.posterFollowing}</span> following</p>
                                    <p style="margin-top: 20px;">${cur.posterBio}</p>
                
                                </div>
                            </div>
                        </div>
                
                    </div>
                
                    <div class="post-text-container">
                        <!-- POST  Text -->
                        <p id="postDescription" class="hashTag" style="font-size: ${postFont} !important;">${cur.description} </p>
                    </div>
                
                    <a href="/viewImagePostDetails/${cur._id}" style="display: none">
                        <div class="post-image" style="display: none">
                            <img src="/viewPostImage/${cur._id}">
                        </div>
                    </a>
                
                    <div class="reaction-container">
                
                        <div class="flexIcons" id="reactionElement">
                            <div class="jsHold">
                                <div class="heartReaction">
                                    <i id="changeHeartColor" class="fa fa-heart-o"><span id="staticColor">${cur.reactionLength}</span></i>
                                    <p style="display: none;">${userData._id}</p>
                                    <p style="display: none;">${cur._id}</p>
                                    <i class="fa fa-heart loaderHide"></i>
                                </div>
                            </div>
                
                
                
                            <div class="div_freactor" style="display: none;">
                                
                                <p id="allReactionId">${cur.reaction}</p>
                            </div>
                
                            <a href="/viewImagePostDetails/${cur._id}">
                                <div class="comment"><i id="commentBtn" class="fa fa-commenting-o"><span
                                            style="color: gray;">${cur.commentlength}</span></i></div>
                            </a>
                
                            <div>
                                <i id="shareBtn" class="fa fa-refresh"><span id="numOfShare">${cur.shareLength}</span></i>
                                <p style="display: none;">${cur._id}</p>
                                <a href="/viewImagePostDetails/${cur._id}"></a>
                                <p style="display: none;">${cur.postType}</p>
                            </div>
                
                        </div>
                
                        <div class="bottom_post_content">
                            <div class="fetch_reaction_div">
                                <p id="likeLength" class="fetchReactors">
                                    <span id="fetchReactors" style="display: ${(typeof (cur.reactionLength) == 'number' && cur.reactionLength > 0) ? 'inline-block' : 'none'}">${cur.reactionLength}</span>
                                    <span id="fetchReactors">${cur.reactionLength > 1 ? 'likes' : 'like'}</span>
                                </p>
                                <p style="display: none;">${cur._id}</p>
                            </div>
                
                            <a href="/viewImagePostDetails/${cur._id}">
                                <span id="view_all_comments">view all ${cur.commentlength} comments</span>
                
                                <div style="display: ${cur.hideLastComment}">
                                    <div class="last_commentor_avatar">
                                        <img id="" src="https://plogapp.s3.amazonaws.com/${cur.lastCommentAvatar}" alt="${cur.commentName}"
                                            width="${cur.commentWidth}" height="${cur.commentHeight}">
                                        <div class="last_comt_details">
                                            <h4>${cur.commentName}<span><i class="${cur.verifiedComment}"></i></span> <span
                                                    id="last_comment_text">${cur.Initcomment}</span></h4>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <p style="font-size: 10px; color: #555; padding-left: 8px">${cur.date}</p>
                        </div>
                    </div>
                
                
                    <div class="hide_option">
                        <div class="option_list" style="z-index: 5;">
                            <div class="option_container">
                                <ul>
                                    <li id="copyLink">Copy</li>
                                    <input class="hideInputForcopy" type="text">
                                    <label for="saveImage" style="display: none;">
                                        <a href="/viewPostImage/${cur._id}" download>
                                            <img src="viewPostImage/${cur._id}" class="hideSavedPic" width="30" height="30">
                                            <li id="saveImage">Save Image</li>
                                        </a>
                                    </label>
                                    <li><a href="/viewImagePostDetails/${cur._id}">View post</a></li>
                                    <li id="hidePic" type="post" victim="${cur._id}" onclick="reportPostFunction(this)">Report</li>
                                    <li id="deleteBtn">Delete post
                                        <div class="delete_confirmaion">
                                            <p>Are you sure you want to delete this post?</p>
                                            <div class="sub_buttons">
                                                <a href="/deletePost/${cur._id}"><button>Yes</button></a>
                                                <button>No</button>
                                            </div>
                                        </div>
                                        <span style="display: none;">${cur.owner}</span>
                                    </li>
                
                                    <li id="editPost">Edit post
                                        <p>${cur.owner}</p>
                                        <p>${cur._id}</p>
                                        <p>${cur.description}</p>
                                    </li>
                                    <li>Close</li>
                
                                </ul>
                            </div>
                        </div>
                    </div>
                    </div>`





                    }



                    else if (cur.postType == 'image') {

                        appendPost.innerHTML +=
                            `<div class="post-container">
                    <div class="post-head">
                
                        <div class="poster_details">
                            <div class="user_details--img--name">
                                <div class="user_image_box">
                                    <a href="/profile/${cur.owner}">
                                        <img id="userPostAvatar" src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                                    </a>
                                </div>
                
                                <a>
                                    <h4> <span id="hoverToShow" class="hoverToShowClass">${cur.possterName}</span> <span><i
                                                class="${cur.verified}"></i></span> <span id="nickName">@${cur.posterNickName}</span></h4>
                                                <p style="display: none">${cur.owner}</p>
                                </a>
                
                            </div>
                                            
                                <i class="fa fa-ellipsis-h post_options"></i>
                        </div>
                
                        <div class="show_shot_profile">
                            <div class="shortprofile_head">
                                <div class="flex-short-profile">
                                    <a href="/profile/${cur.owner}">
                                        <img src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                                    </a>
                                    <div class="shortProfileLoader">
                                        <button id="shortFollowBtn">Follow</button>
                                        <p style="display: none">${cur.ownerPrimaryid}</p>
                                        <p style="display: none">${userData.following}</p>
                                        <div class="loader"></div>
                                        <p style="display: none">${userData._id}</p>
                                        <i style="font-size: 14px" class="fa fa-close closeshortdiv"></i>
                                        <p style="display: none">${cur.owner}</p>
                                    </div>
                                </div>
                
                                <div clas="sht_styler">
                                    <a href="/profile/${cur.owner}">
                                        <h3 style="font-size: 15px">${cur.possterName} <span><i class="${cur.verified}"></i></span></h3>
                                        <p><span id="nickName">@${cur.posterNickName}</span></p>
                                    </a>
                                    <p style="font-size: 15px"><span style="font-weight: bolder;">${cur.posterFollower}</span> <span
                                            style="color: #b0b0b0">followers <span
                                                style="font-weight: bolder;">${cur.posterFollowing}</span> following</p>
                                    <p style="margin-top: 20px;">${cur.posterBio}</p>
                
                                </div>
                            </div>
                        </div>
                
                    </div>
                    <div style="display: none;" class="post-text-container">
                        
                        <p class="hashTag">${cur.description}</p>
                    </div>
                
                    <div class="post-image">
                        <img id="postImage" loading="eager" src="https://plogapp.s3.amazonaws.com/${cur.image}"> 
                        
                        <div class="slide_controls">
                            <div class="slide_handle">
                                <i id="slideLeft" class="fa fa-arrow-left"></i>
                                <i id="slideRight" class="fa fa-arrow-right"></i>
                                <p style="display: none;">${cur.imageLength}</p>
                                <p style="display: none;">${cur.image}</p>
                                <p style="display: none;">${cur.image1}</p>
                                <p style="display: none;">${cur.image2}</p>
                            </div>  
                        </div>
                    </div>
                
                    <div class="reaction-container">
                
                        <div class="flexIcons" id="reactionElement">
                            <div class="jsHold">
                                <div class="heartReaction">
                                    <i id="changeHeartColor" class="fa fa-heart-o"><span id="staticColor">${cur.reactionLength}</span></i>
                                    <p style="display: none;">${userData._id}</p>
                                    <p style="display: none;">${cur._id}</p>
                                    <i class="fa fa-heart loaderHide"></i>
                                </div>
                            </div>
                
                
                
                            <div class="div_freactor" style="display: none;">
                                
                                <p id="allReactionId">${cur.reaction}</p>
                            </div>
                
                            <a href="/viewImagePostDetails/${cur._id}">
                                <div class="comment"><i id="commentBtn" class="fa fa-commenting-o"><span
                                            style="color: gray;">${cur.commentlength}</span></i></div>
                            </a>
                
                            <div>
                                <i id="shareBtn" class="fa fa-refresh"><span id="numOfShare">${cur.shareLength}</span></i>
                                <p style="display: none;">${cur._id}</p>
                                <a href="/viewImagePostDetails/${cur._id}"></a>
                                <p style="display: none;">${cur.postType}</p>
                            </div>
                
                        </div>
                
                        <div class="bottom_post_content">
                            <div class="fetch_reaction_div">
                            <p id="likeLength" class="fetchReactors">
                                <span id="fetchReactors" style="display: ${(typeof (cur.reactionLength) == 'number' && cur.reactionLength > 0) ? 'inline-block' : 'none'}">${cur.reactionLength}</span>
                                <span id="fetchReactors">${cur.reactionLength > 1 ? 'likes' : 'like'}</span>
                            </p>
                                <p style="display: none;">${cur._id}</p>
                            </div>
                
                            <a href="/viewImagePostDetails/${cur._id}">
                                <span id="view_all_comments">view all ${cur.commentlength} comments</span>
                                <p style="margin-left: 1px;" class="hashTag">${cur.description}</p>
                
                                <div style="display: ${cur.hideLastComment}">
                                    <div class="last_commentor_avatar">
                                        <img id="" src="https://plogapp.s3.amazonaws.com/${cur.lastCommentAvatar}" alt="${cur.commentName}" width="${cur.commentWidth}"
                                            height="${cur.commentHeight}">
                                        <div class="last_comt_details">
                                            <h4>${cur.commentName}<span><i class="${cur.verifiedComment}"></i></span> <span
                                                    id="last_comment_text">${cur.Initcomment}</span></h4>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <p style="font-size: 10px; color: #555; padding-left: 8px">${cur.date}</p>
                        </div>
                    </div>
                
                
                
                    <div class="hide_option">
                        <div class="option_list">
                            <div class="option_container">
                                <ul>
                                    <li id="copyLink">Copy</li>
                                    <input class="hideInputForcopy" type="text">
                                    <label for="saveImage">
                                        <a href="https://plogapp.s3.amazonaws.com/${cur.image}" download>
                                            <img src="https://plogapp.s3.amazonaws.com/${cur.image}" class="hideSavedPic" width="30" height="30">
                                            <li id="saveImage">Save Image</li>
                                        </a>
                                    </label>
                                    <li><a href="/viewImagePostDetails/${cur._id}">View post</a></li>
                                    <li id="hidePic" type="post" victim="${cur._id}" onclick="reportPostFunction(this)">Report</li>
                
                                    <li id="deleteBtn">Delete post
                                        <div class="delete_confirmaion">
                                            <p>Are you sure you want to delete this post?</p>
                                            <div class="sub_buttons">
                                                <a href="/deletePost/${cur._id}"><button>Yes</button></a>
                                                <button>No</button>
                                            </div>
                                        </div>
                                        <span style="display: none;">${cur.owner}</span>
                                    </li>
                
                                    <li id="editPost">Edit post
                                        <p>${cur.owner}</p>
                                        <p>${cur._id}</p>
                                        <p>${cur.description}</p>
                                    </li>
                                    <li>Close</li>
                
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>`
                    }

                    else if (cur.postType == 'video') {
                        appendPost.innerHTML +=
                            `<div class="post-container">
                    <div class="post-head">
                
                        <div class="poster_details">
                            <div class="user_details--img--name">
                                <div class="user_image_box">
                                    <a href="/profile/${cur.owner}">
                                        <img id="userPostAvatar" src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                                    </a>
                                </div>
                
                                <a>
                                    <h4> <span id="hoverToShow" class="hoverToShowClass">${cur.possterName}</span> <span><i
                                                class="${cur.verified}"></i></span> <span id="nickName">@${cur.posterNickName}</span></h4>
                                                <p style="display: none">${cur.owner}</p>
                                </a>
                
                            </div>
                
                            
                                <i class="fa fa-ellipsis-h post_options"></i>
                        </div>
                
                        <div class="show_shot_profile">
                            <div class="shortprofile_head">
                                <div class="flex-short-profile">
                                    <a href="/profile/${cur.owner}">
                                        <img src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                                    </a>
                                    <div class="shortProfileLoader">
                                        <button id="shortFollowBtn">Follow</button>
                                        <p style="display: none">${cur.ownerPrimaryid}</p>
                                        <p style="display: none">${userData.following}</p>
                                        <div class="loader"></div>
                                        <p style="display: none">${userData._id}</p>
                                        <i style="font-size: 14px" class="fa fa-close closeshortdiv"></i>
                                        <p style="display: none">${cur.owner}</p>
                                    </div>
                                </div>
                
                                <div clas="sht_styler">
                                    <a href="/profile/${cur.owner}">
                                        <h3 style="font-size: 15px">${cur.possterName} <span><i class="${cur.verified}"></i></span></h3>
                                        <p><span id="nickName">@${cur.posterNickName}</span></p>
                                    </a>
                                    <p style="font-size: 15px"><span style="font-weight: bolder;">${cur.posterFollower}</span> <span
                                            style="color: #b0b0b0">followers <span
                                                style="font-weight: bolder;">${cur.posterFollowing}</span> following</p>
                                    <p style="margin-top: 20px;">${cur.posterBio}</p>
                
                                </div>
                            </div>
                        </div>
                
                    </div>
                    <div style="display: none;" class="post-text-container">
                        <!-- POST  Text -->
                        <p class="hashTag">${cur.description}</p>
                    </div>
                
                     <a> 
                        <div class="" id="relativeVideo">
                            <video id="myVideo" poster="https://plogapp.s3.amazonaws.com/${cur.image}"  src="https://plogapp.s3.amazonaws.com/${cur.video}" video-id="${cur._id}" ></video>
                            <div class="video_play_controls_wrapper" video-controls="video">
                                    <div class="centered_icons_vid_controls">
                                    <div class="play_btn_video">
                                        <i class="fa fa-play"></i>
                                    </div>
                                    </div>
                                </div>


                            <div class="video_loader" style="display: none;">
                                    <div class="loading">
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                    </div>
                                </div>
                
                            <div class="video_controllers" style="display: none;">
                                <div class="controllers_wrapper">
                                    <div class="pause_controller">
                                        <i id="controller" class="fa fa-play fa-3x"></i>
                                        <i id="pauseController" class="fa fa-pause fa-3x"></i>
                                    </div>
                
                                    <div class="video_seeker_box">
                                        <input type="range" name="" id="normalVideo" class="slider" value="0">
                                    </div>
                                </div>
                            </div>
                        </div>
                        </a>
                        
                
                    <div class="reaction-container">
                
                        <div class="flexIcons" id="reactionElement">
                            <div class="jsHold">
                                <div class="heartReaction">
                                    <i id="changeHeartColor" class="fa fa-heart-o"><span id="staticColor">${cur.reactionLength}</span></i>
                                    <p style="display: none;">${userData._id}</p>
                                    <p style="display: none;">${cur._id}</p>
                                    <i class="fa fa-heart loaderHide"></i>
                                </div>
                            </div>
                
                
                
                            <div class="div_freactor" style="display: none;">
                                
                                <p id="allReactionId">${cur.reaction}</p>
                            </div>
                
                            <a href="/viewVideoPostDetails/${cur._id}">
                                <div class="comment"><i id="commentBtn" class="fa fa-commenting-o"><span
                                            style="color: gray;">${cur.commentlength}</span></i></div>
                            </a>
                
                            <div>
                                <i id="shareBtn" class="fa fa-refresh"><span id="numOfShare">${cur.shareLength}</span></i>
                                <p style="display: none;">${cur._id}</p>
                                <a href="/viewVideoPostDetails/${cur._id}"></a>
                                <p style="display: none;">${cur.postType}</p>
                            </div>
                
                        </div>
                
                        <div class="bottom_post_content">
                            <div class="fetch_reaction_div">
                                <p id="likeLength" class="fetchReactors">
                                    <span id="fetchReactors" style="display: ${(typeof (cur.reactionLength) == 'number' && cur.reactionLength > 0) ? 'inline-block' : 'none'}">${cur.reactionLength}</span>
                                    <span id="fetchReactors">${cur.reactionLength > 1 ? 'likes' : 'like'}</span>
                                </p>
                                <p style="display: none;">${cur._id}</p>
                            </div>
                
                            <a href="/viewVideoPostDetails/${cur._id}">
                            <span id="view_all_comments">Has ${cur.views} views and ${cur.commentlength} comments</span>
                                <p style="margin-left: 1px;" class="hashTag">${cur.description}</p>
                
                                <div style="display: ${cur.hideLastComment}">
                                    <div class="last_commentor_avatar">
                                        <img id="" src="https://plogapp.s3.amazonaws.com/${cur.lastCommentAvatar}" alt="${cur.commentName}"
                                            width="${cur.commentWidth}" height="${cur.commentHeight}">
                                        <div class="last_comt_details">
                                            <h4>${cur.commentName}<span><i class="${cur.verifiedComment}"></i></span> <span
                                                    id="last_comment_text">${cur.Initcomment}</span></h4>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <p style="font-size: 10px; color: #555; padding-left: 8px">${cur.date}</p>
                        </div>
                    </div>
                
                
                    <div class="hide_option">
                        <div class="option_list">
                            <div class="option_container">
                                <ul>
                                    <li id="copyLink">Copy</li>
                                    <input class="hideInputForcopy" type="text">
                                    <label for="saveImage">
                                        <a href="https://plogapp.s3.amazonaws.com/${cur.video}" download>
                                            <video src="https://plogapp.s3.amazonaws.com/${cur.video}" class="hideSavedPic" width="30"
                                                height="30"></video>
                                            <li id="saveImage">Download</li>
                                        </a>
                                    </label>
                                    <li><a href="/viewVideoPostDetails/${cur._id}">View post</a></li>
                                    <li id="hidePic" type="post" victim="${cur._id}" onclick="reportPostFunction(this)">Report</li>
                                    <li id="deleteBtn">Delete post
                                        <div class="delete_confirmaion">
                                            <p>Are you sure you want to delete this post?</p>
                                            <div class="sub_buttons">
                                                <a href="/deletePost/${cur._id}"><button>Yes</button></a>
                                                <button>No</button>
                                            </div>
                                        </div>
                                        <span style="display: none;">${cur.owner}</span>
                                    </li>
                                    <li id="editPost">Edit post
                                        <p>${cur.owner}</p>
                                        <p>${cur._id}</p>
                                        <p>${cur.description}</p>
                                    </li>
                                    <li>Close</li>
                
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>`
                    }

                    else if (cur.postType == 'sharetext') {
                        appendPost.innerHTML +=
                            `<div class="post-container">
                        <div class="post-head">
                    
                            <div class="poster_details">
                                <div class="user_details--img--name">
                                    <div class="user_image_box">
                                        <a href="/profile/${cur.owner}">
                                            <img id="userPostAvatar" src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                                        </a>
                                    </div>
                    
                                    <a>
                                        <h4> <span id="hoverToShow" class="hoverToShowClass">${cur.possterName}</span> <span><i
                                                    class="${cur.verified}"></i></span> <span id="nickName">@${cur.posterNickName}</span></h4>
                                                    <p style="display: none">${cur.owner}</p>
                                    </a>
                    
                                </div>
                    
                                
                                    <i class="fa fa-ellipsis-h post_options"></i>
                            </div>
                    
                            <div class="show_shot_profile">
                                <div class="shortprofile_head">
                                    <div class="flex-short-profile">
                                        <a href="/profile/${cur.owner}">
                                            <img src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                                        </a>
                                        <div class="shortProfileLoader">
                                            <button id="shortFollowBtn">Follow</button>
                                            <p style="display: none">${cur.ownerPrimaryid}</p>
                                            <p style="display: none">${userData.following}</p>
                                            <div class="loader"></div>
                                            <p style="display: none">${userData._id}</p>
                                            <i style="font-size: 14px" class="fa fa-close closeshortdiv"></i>
                                            <p style="display: none">${cur.owner}</p>
                                        </div>
                                    </div>
                    
                                    <div clas="sht_styler">
                                        <a href="/profile/${cur.owner}">
                                            <h3 style="font-size: 15px">${cur.possterName} <span><i class="${cur.verified}"></i></span></h3>
                                            <p><span id="nickName">@${cur.posterNickName}</span></p>
                                        </a>
                                        <p style="font-size: 15px"><span style="font-weight: bolder;">${cur.posterFollower}</span> <span
                                                style="color: #b0b0b0">followers <span
                                                    style="font-weight: bolder;">${cur.posterFollowing}</span> following</p>
                                        <p style="margin-top: 20px;">${cur.posterBio}</p>
                    
                                    </div>
                                </div>
                            </div>
                    
                        </div>
                        <div class="post-text-container">
                            <!-- POST  Text -->
                            <p id="postDescription" class="hashTag">${cur.description}</p>
                        </div>
                    
                        <div class="post-image shared_div">
                            <div class="shared_profile">
                                <div class="user_image_box">
                                    <img class="sharedProfile_pic" src="https://plogapp.s3.amazonaws.com/${cur.shareAvatar}">
                                </div>
                                <a href="/profile/${cur.mainOwner}">
                                    <div class="share_profile_details">
                                        <h4>${cur.sharedPostOwnerName} <span><i class="${cur.verifiedSharedPost}"></i></span> <span
                                                id="nickName">@${cur.sharedPosterNickName}</span></h4>
                                        <p>${cur.sharedPostDate}</p>
                                    </div>
                                </a>
                            </div>
                        </div>
                    
                        <div class="shared_post_description">
                            <a href="/viewImagePostDetails/${cur.sharedPostLink}">
                                <p style="margin-left: 10%;" class="hashTag">${cur.sharedPostDescription}</p>
                            </a>
                        </div>
                    
                        <div class="hide_option">
                        <div class="option_list" style="z-index: 5;">
                            <div class="option_container">
                                <ul>
                                    <li id="copyLink">Copy</li>
                                    <input class="hideInputForcopy" type="text">
                                    <label for="saveImage" style="display: none;">
                                    </label>
                                    <li><a href="/shareLink/${cur._id}">View post</a></li>
                                    <li id="hidePic" type="post" victim="${cur._id}" onclick="reportPostFunction(this)">Report</li>                                    
                                    <li id="deleteBtn">Delete post
                                        <div class="delete_confirmaion">
                                            <p>Are you sure you want to delete this post?</p>
                                            <div class="sub_buttons">
                                                <a href="/deleteSharedPost/${cur._id}"><button>Yes</button></a>
                                                <button>No</button>
                                            </div>
                                        </div>
                                        <span style="display: none;">${cur.owner}</span>
                                    </li>
                                    <li id="editPost">Edit post
                                        <p>${cur.owner}</p>
                                        <p>${cur._id}</p>
                                        <p>${cur.description}</p>
                                    </li>
                                    <li>Close</li>
                
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                        <div class="reaction-container">
                    
                            <div class="flexIcons" id="reactionElement">
                                <div class="jsHold">
                                    <div class="heartReactionForShareedPost">
                                        <i id="changeHeartColorShared" class="fa fa-heart-o"><span
                                                id="staticColor">${cur.reactionLength}</span></i>
                                        <p style="display: none;">${userData._id}</p>
                                        <p style="display: none;">${cur._id}</p>
                                        <i class="fa fa-heart loaderHide"></i>
                                    </div>
                                </div>
                    
                                <div class="div_freactor" style="display: none;">                                  
                                    <p id="allReactionId">${cur.reaction}</p>
                                </div>
                    
                                <a href="/shareLink/${cur._id}">
                                    <div class="comment"><i id="commentBtn" class="fa fa-commenting-o"><span
                                                style="color: gray;">${cur.commentlength}</span></i></div>
                                </a>
                    
                                <div>
                                    <i id="shareBtn" class="fa fa-refresh"><span id="numOfShare">${cur.shareLength}</span></i>
                                    <p style="display: none;">${cur._id}</p>
                                    <a href="/shareLink/${cur._id}"></a>
                                    <p style="display: none;">${cur.postType}</p>
                                </div>
                    
                            </div>
                    
                    
                            <div class="bottom_post_content">
                                <div class="fetch_reaction_div">
                                    <p id="likeLength" class="fetchReactors">
                                        <span id="fetchReactors" style="display: ${(typeof (cur.reactionLength) == 'number' && cur.reactionLength > 0) ? 'inline-block' : 'none'}">${cur.reactionLength}</span>
                                        <span id="fetchReactors">${cur.reactionLength > 1 ? 'likes' : 'like'}</span>
                                    </p>
                                    <p style="display: none;">${cur._id}</p>
                                </div>
                                <a href="/shareLink/${cur._id}">
                                    <span id="view_all_comments">View all ${cur.commentlength} comments</span>
                    
                                    <div style="display: ${cur.hideLastComment}">
                                        <div class="last_commentor_avatar">
                                            <img id="" src="https://plogapp.s3.amazonaws.com/${cur.lastCommentAvatar}" alt="${cur.commentName}"
                                                width="${cur.commentWidth}" height="${cur.commentHeight}">
                                            <div class="last_comt_details">
                                                <h4>${cur.commentName}<span><i class="${cur.verifiedComment}"></i></span> <span
                                                        id="last_comment_text">${cur.Initcomment}</span></h4>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                                <p style="font-size: 10px; color: #555; padding-left: 8px">${cur.date}</p>
                            </div>
                        </div>
                    
                       
                    </div>
                    `

                    }

                    else if (cur.postType == 'shareimage') {
                        appendPost.innerHTML +=
                            `<div class="post-container">
                    <div class="post-head">
                
                        <div class="poster_details">
                            <div class="user_details--img--name">
                                <div class="user_image_box">
                                    <a href="/profile/${cur.owner}">
                                        <img id="userPostAvatar" src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                                    </a>
                                </div>
                
                                <a>
                                    <h4> <span id="hoverToShow" class="hoverToShowClass">${cur.possterName}</span> <span><i
                                                class="${cur.verified}"></i></span> <span id="nickName">@${cur.posterNickName}</span></h4>
                                                <p style="display: none">${cur.owner}</p>
                                </a>
                
                            </div>
                
                                <i class="fa fa-ellipsis-h post_options"></i>
                        </div>
                
                        <div class="show_shot_profile">
                            <div class="shortprofile_head">
                                <div class="flex-short-profile">
                                    <a href="/profile/${cur.owner}">
                                        <img src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                                    </a>
                                    <div class="shortProfileLoader">
                                        <button id="shortFollowBtn">Follow</button>
                                        <p style="display: none">${cur.ownerPrimaryid}</p>
                                        <p style="display: none">${userData.following}</p>
                                        <div class="loader"></div>
                                        <p style="display: none">${userData._id}</p>
                                        <i style="font-size: 14px" class="fa fa-close closeshortdiv"></i>
                                        <p style="display: none">${cur.owner}</p>
                                    </div>
                                </div>
                
                                <div clas="sht_styler">
                                    <a href="/profile/${cur.owner}">
                                        <h3 style="font-size: 15px">${cur.possterName} <span><i class="${cur.verified}"></i></span></h3>
                                        <p><span id="nickName">@${cur.posterNickName}</span></p>
                                    </a>
                                    <p style="font-size: 15px"><span style="font-weight: bolder;">${cur.posterFollower}</span> <span
                                            style="color: #b0b0b0">followers <span
                                                style="font-weight: bolder;">${cur.posterFollowing}</span> following</p>
                                    <p style="margin-top: 20px;">${cur.posterBio}</p>
                
                                </div>
                            </div>
                        </div>
                
                    </div>
                    <div class="post-text-container">
                        <!-- POST  Text -->
                        <p class="hashTag">${cur.description}</p>
                    </div>
                
                
                    <div class="post-image shared_div">
                        <div class="shared_profile">
                            <div class="user_image_box">
                                <img class="sharedProfile_pic" src="https://plogapp.s3.amazonaws.com/${cur.shareAvatar}">
                            </div>
                            <a href="/profile/${cur.mainOwner}">
                                <div class="share_profile_details">
                                    <h4>${cur.sharedPostOwnerName} <span><i class="${cur.verifiedSharedPost}"></i></span></h4>
                                    <p>${cur.sharedPostDate}</p>
                                </div>
                            </a>
                        </div>
                        <div class="shared_post_description">
                            <a href="/viewImagePostDetails/${cur.sharePostUrl}"></a>
                        </div>
                
                
                        <a href="/shareLink/${cur._id}">
                            <img class="sharedPhoto" src="https://plogapp.s3.amazonaws.com/${cur.sharedPostImage}">
                            <p style="margin-left: 10%;margin-top: 5px" class="hashTag">${cur.sharedPostDescription}</p>
                        </a>
                
                    </div>
                
                
                    <div class="reaction-container">
                
                        <div class="flexIcons" id="reactionElement">
                            <div class="jsHold">
                                <div class="heartReactionForShareedPost">
                                    <i id="changeHeartColorShared" class="fa fa-heart-o"><span
                                            id="staticColor">${cur.reactionLength}</span></i>
                                    <p style="display: none;">${userData._id}</p>
                                    <p style="display: none;">${cur._id}</p>
                                    <i class="fa fa-heart loaderHide"></i>
                                </div>
                            </div>
                
                            <div class="div_freactor" style="display: none;">
                                
                                <p id="allReactionId">${cur.reaction}</p>
                            </div>
                
                            <a href="/shareLink/${cur._id}">
                                <div class="comment"><i id="commentBtn" class="fa fa-commenting-o"><span
                                            style="color: gray;">${cur.commentlength}</span></i></div>
                            </a>
                
                            <div>
                                <i id="shareBtn" class="fa fa-refresh"><span id="numOfShare">${cur.shareLength}</span></i>
                                <p style="display: none;">${cur._id}</p>
                                <a href="/shareLink/${cur._id}"></a>
                                <p style="display: none;">${cur.postType}</p>
                            </div>
                
                        </div>
                
                        <div class="bottom_post_content">
                            <div class="fetch_reaction_div">
                                <p id="likeLength" class="fetchReactors">
                                    <span id="fetchReactors" style="display: ${(typeof (cur.reactionLength) == 'number' && cur.reactionLength > 0) ? 'inline-block' : 'none'}">${cur.reactionLength}</span>
                                    <span id="fetchReactors">${cur.reactionLength > 1 ? 'likes' : 'like'}</span>
                                </p>
                                <p style="display: none;">${cur._id}</p>
                            </div>
                
                            <a href="/shareLink/${cur._id}">
                                <span id="view_all_comments">View all ${cur.commentlength} comments</span>
                
                                <div style="display: ${cur.hideLastComment}">
                                    <div class="last_commentor_avatar" stye>
                                        <img id="" src="https://plogapp.s3.amazonaws.com/${cur.lastCommentAvatar}" alt="${cur.commentName}"
                                            width="${cur.commentWidth}" height="${cur.commentHeight}">
                                        <div class="last_comt_details">
                                            <h4>${cur.commentName}<span><i class="${cur.verifiedComment}"></i></span> <span
                                                    id="last_comment_text">${cur.Initcomment}</span></h4>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <p style="font-size: 10px; color: #555; padding-left: 8px">${cur.date}</p>
                        </div>
                    </div>
                
                
                
                    <div class="hide_option">
                        <div class="option_list">
                            <div class="option_container">
                                <ul>
                                    <li id="copyLink">Copy</li>
                                    <input class="hideInputForcopy" type="text">
                                    <label for="saveImage">
                                        <a href="https://plogapp.s3.amazonaws.com/${cur.sharedPostImage}" download>
                                            <img src="https://plogapp.s3.amazonaws.com/${cur.sharedPostImage}" class="hideSavedPic" width="30"
                                                height="30">
                                            <li id="saveImage">Save Image</li>
                                        </a>
                                    </label>
                                    <li><a href="/shareLink/${cur._id}">View post</a></li>
                                    <li id="hidePic" type="post" victim="${cur._id}" onclick="reportPostFunction(this)">Report</li>
                                    <li id="deleteBtn">Delete post
                                        <div class="delete_confirmaion">
                                            <p>Are you sure you want to delete this post?</p>
                                            <div class="sub_buttons">
                                                <a href="/deleteSharedPost/${cur._id}"><button>Yes</button></a>
                                                <button>No</button>
                                            </div>
                                        </div>
                                        <span style="display: none;">${cur.owner}</span>
                                    </li>
                                    <li id="editPost">Edit post
                                        <p>${cur.owner}</p>
                                        <p>${cur._id}</p>
                                        <p>${cur.description}</p>
                                    </li>
                                    <li>Close</li>
                
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>`
                    }

                    else if (cur.postType == 'sharevideo') {
                        appendPost.innerHTML +=
                            `<div class="post-container">
                    <div class="post-head">
                
                        <div class="poster_details">
                            <div class="user_details--img--name">
                                <div class="user_image_box">
                                    <a href="/profile/${cur.owner}">
                                        <img id="userPostAvatar" src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                                    </a>
                                </div>
                
                                <a>
                                    <h4> <span id="hoverToShow" class="hoverToShowClass">${cur.possterName}</span> <span><i
                                                class="${cur.verified}"></i></span> <span id="nickName">@${cur.posterNickName}</span></h4>
                                                <p style="display: none">${cur.owner}</p>
                                </a>
                
                            </div>
                
                
                            <i class="fa fa-ellipsis-h post_options"></i>
                        </div>
                
                        <div class="show_shot_profile">
                            <div class="shortprofile_head">
                                <div class="flex-short-profile">
                                    <a href="/profile/${cur.owner}">
                                        <img src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                                    </a>
                                    <div class="shortProfileLoader">
                                        <button id="shortFollowBtn">Follow</button>
                                        <p style="display: none">${cur.ownerPrimaryid}</p>
                                        <p style="display: none">${userData.following}</p>
                                        <div class="loader"></div>
                                        <p style="display: none">${userData._id}</p>
                                        <i style="font-size: 14px" class="fa fa-close closeshortdiv"></i>
                                        <p style="display: none">${cur.owner}</p>
                                    </div>
                                </div>
                
                                <div clas="sht_styler">
                                    <a href="/profile/${cur.owner}">
                                        <h3 style="font-size: 15px">${cur.possterName} <span><i class="${cur.verified}"></i></span></h3>
                                        <p><span id="nickName">@${cur.posterNickName}</span></p>
                                    </a>
                                    <p style="font-size: 15px"><span style="font-weight: bolder;">${cur.posterFollower}</span> <span
                                            style="color: #b0b0b0">followers <span
                                                style="font-weight: bolder;">${cur.posterFollowing}</span> following</p>
                                    <p style="margin-top: 20px;">${cur.posterBio}</p>
                
                                </div>
                            </div>
                        </div>
                
                    </div>
                    <div class="post-text-container">
                        <!-- POST  Text -->
                        <p class="hashTag">${cur.description}</p>
                    </div>
                
                    <div class="post-image shared_div">
                        <div class="shared_profile">
                            <div class="user_image_box">
                                <img class="sharedProfile_pic" src="https://plogapp.s3.amazonaws.com/${cur.shareAvatar}">
                            </div>
                            <a href="/profile/${cur.mainOwner}">
                                <div class="share_profile_details">
                                    <h4>${cur.sharedPostOwnerName} <span><i class="${cur.verifiedSharedPost}"></i></span></h4>
                                    <p>${cur.sharedPostDate}</p>
                                </div>
                            </a>
                        </div>
                
                        <p style="margin-left: 10% ;margin-top: 5px; display: none" class="hashTag">${cur.sharedPostDescription}</p>
                
                
                        <div class="" id="relativeVideo">
                            <video id="myVideo" class="sharedVideo"  poster="https://plogapp.s3.amazonaws.com/${cur.sharedPostImage}"  src="https://plogapp.s3.amazonaws.com/${cur.sharedPostLink}" video-id="${cur._id}"></video>

                            <div class="video_play_controls_wrapper" video-controls="video">
                                    <div class="centered_icons_vid_controls">
                                    <div class="play_btn_video">
                                        <i class="fa fa-play"></i>
                                    </div>
                                    </div>
                                </div>


                            <div class="video_loader" style="display: none;">
                                    <div class="loading">
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                    </div>
                                </div>
                
                            <div class="video_controllers" style="display: none;">
                                <div class="controllers_wrapper">
                                    <div class="pause_controller">
                                        <i id="controller" class="fa fa-play fa-3x"></i>
                                        <i id="pauseController" class="fa fa-pause fa-3x"></i>
                                    </div>
                
                                    <div class="video_seeker_box">
                                        <input type="range" name="" id="sharedVideo" class="slider" value="0">
                                    </div>
                                </div>
                            </div>
                
                        </div>
                    </div>
                
                
                
                
                    <div class="reaction-container">
                
                        <div class="flexIcons" id="reactionElement">
                            <div class="jsHold">
                                <div class="heartReactionForShareedPost">
                                    <i id="changeHeartColorShared" class="fa fa-heart-o"><span
                                            id="staticColor">${cur.reactionLength}</span></i>
                                    <p style="display: none;">${userData._id}</p>
                                    <p style="display: none;">${cur._id}</p>
                                    <i class="fa fa-heart loaderHide"></i>
                                </div>
                            </div>
                
                            <div class="div_freactor" style="display: none;">
                                <p id="allReactionId">${cur.reaction}</p>
                            </div>
                
                            <a href="/sharedLinkVideo/${cur._id}">
                                <div class="comment"><i id="commentBtn" class="fa fa-commenting-o"><span
                                            style="color: gray;">${cur.commentlength}</span></i></div>
                            </a>
                
                            <div>
                                <i id="shareBtn" class="fa fa-refresh"><span id="numOfShare">${cur.shareLength}</span></i>
                                <p style="display: none;">${cur._id}</p>
                                <a href="/sharedLinkVideo/${cur._id}"></a>
                                <p style="display: none;">${cur.postType}</p>
                            </div>
                
                        </div>
                
                
                        <div class="bottom_post_content">
                            <div class="fetch_reaction_div">
                                <p id="likeLength" class="fetchReactors">
                                    <span id="fetchReactors" style="display: ${(typeof (cur.reactionLength) == 'number' && cur.reactionLength > 0) ? 'inline-block' : 'none'}">${cur.reactionLength}</span>
                                    <span id="fetchReactors">${cur.reactionLength > 1 ? 'likes' : 'like'}</span>
                                </p>
                                <p style="display: none;">${cur._id}</p>
                            </div>
                            <a href="/sharedLinkVideo/${cur._id}">
                            <span id="view_all_comments">Has ${cur.views} views and ${cur.commentlength} comments</span>
                                <p style="margin-left: 0px" class="hashTag">${cur.sharedPostDescription}</p>
                                <div style="display: ${cur.hideLastComment}">
                                    <div class="last_commentor_avatar">
                                        <img id="" src="https://plogapp.s3.amazonaws.com/${cur.lastCommentAvatar}" alt="${cur.commentName}"
                                            width="${cur.commentWidth}" height="${cur.commentHeight}">
                                        <div class="last_comt_details">
                                            <h4>${cur.commentName}<span><i class="${cur.verifiedComment}"></i></span> <span
                                                    id="last_comment_text">${cur.Initcomment}</span></h4>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <p style="font-size: 10px; color: #555; padding-left: 8px">${cur.date}</p>
                        </div>
                    </div>
                
                    <div class="hide_option">
                        <div class="option_list">
                            <div class="option_container">
                                <ul>
                                    <li id="copyLink">Copy</li>
                                    <input class="hideInputForcopy" type="text">
                                    <label for="saveImage">
                                        <a href="https://plogapp.s3.amazonaws.com/${cur.sharedPostLink}" download>
                                            <img src="https://plogapp.s3.amazonaws.com/${cur.sharedPostLink}" class="hideSavedPic" width="30"
                                                height="30">
                                            <li id="saveImage">Download</li>
                                        </a>
                                    </label>
                                    <li><a href="/sharedLinkVideo/${cur._id}">View post</a></li>
                                    <li id="hidePic" type="post" victim="${cur._id}" onclick="reportPostFunction(this)">Report</li>
                                    <li id="deleteBtn">Delete post
                                        <div class="delete_confirmaion">
                                            <p>Are you sure you want to delete this post?</p>
                                            <div class="sub_buttons">
                                                <a href="/deleteSharedPost/${cur._id}"><button>Yes</button></a>
                                                <button>No</button>
                                            </div>
                                        </div>
                                        <span style="display: none;">${cur.owner}</span>
                                    </li>
                
                                    <li id="editPost">Edit post
                                        <p>${cur.owner}</p>
                                        <p>${cur._id}</p>
                                        <p>${cur.description}</p>
                                    </li>
                                    <li>Close</li>
                
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>`


                    }

                    darkModeFunction()



                    // All javascript code here
                    {


                        const socket = io()
                        // Change color globally
                        let colorGlobe = document.querySelectorAll('#changeHeartColor');
                        for (i = 0; i < colorGlobe.length; i++) {
                            colorGlobe[i].style.color = 'gray'
                        }

                        let mainId = document.getElementById('primaryId').textContent
                        // console.log(mainId)

                        let div = document.querySelectorAll('#reactionElement');
                        for (i = 0; i < div.length; i++) {
                            let icon = div[i].children[0].children[0].children[0];
                            let ids = div[i].children[1].children[0].textContent;
                            // console.log(ids.split(',').indexOf(mainId) > -1)
                            // console.log(ids, + `${mainId}`)
                            // console.log('==================================')
                            if (ids.split(',').indexOf(mainId) > -1) {
                                icon.style.color = '#ff00bc'
                                icon.classList = 'fa fa-heart'
                            }

                            // if (ids.includes(mainId)) {
                            //     icon.style.color = '#ff00bc'
                            //     icon.classList = 'fa fa-heart'
                            // }

                        }

                        let div2 = document.querySelectorAll('.heartReaction');
                        let likeBtn = document.querySelectorAll('#changeHeartColor')
                        for (i = 0; i < likeBtn.length; i++) {
                            likeBtn[i].addEventListener('click', (e) => {
                                let heart = e.target.parentElement.children[0]
                                let userId = e.target.parentElement.children[1].textContent
                                let postId = e.target.parentElement.children[2].textContent
                                let num = e.target.parentElement.parentElement.parentElement.parentElement.children[1].children[0].children[0].children[0]
                                let newStrNUm = parseInt(num.textContent) || 0;

                                let loader = e.target.parentElement.children[3]
                                let button = e.target

                                // button.style.display = 'none'
                                // loader.style.display = 'block'
                                let data = {
                                    userId,
                                    postId
                                }

                                // console.log(data)
                                socket.emit('reactionDetails', data)

                                // setTimeout(() => {
                                //     loader.style.display = 'none'
                                //     button.style.display = 'block'
                                //     return
                                // }, 500);





                                // Change heart color 
                                if (heart.style.color == 'gray') {
                                    heart.style.color = '#ff00bc'
                                    num.style.color = 'black'
                                    num.textContent = newStrNUm += 1
                                    num.style.color = 'gray'
                                    heart.classList = 'fa fa-heart'
                                    parseInt(num.textContent) < 2 ? num.parentElement.children[1].textContent = 'Like' : num.parentElement.children[1].textContent = 'Likes'

                                } else {
                                    heart.style.color = 'gray'
                                    num.style.color = 'black'
                                    num.textContent = newStrNUm -= 1
                                    num.style.color = 'gray'
                                    heart.classList = 'fa fa-heart-o'
                                    parseInt(num.textContent) < 2 ? num.parentElement.children[1].textContent = 'Like' : num.parentElement.children[1].textContent = 'Likes'
                                }

                            })

                        }

                        // If like is 1 show (like) instead of likes
                        let likeLength = document.querySelectorAll('#likeLength')
                        for (i = 0; i < likeLength.length; i++) {
                            let value = likeLength[i].children[0].textContent
                            value = parseInt(value)

                            let text = likeLength[i].children[1]
                            if (value < 2) {
                                likeLength[i].children[1].textContent = 'Like'
                            }

                        }

                    }


                    // Copy and pase post script here ****************************8
                    {
                        const socket = io()
                        let optionBtn = document.querySelectorAll('.post_options');
                        for (i = 0; i < optionBtn.length; i++) {
                            optionBtn[i].addEventListener('click', (e) => {
                                const showContainer = e.target.parentElement.parentElement.parentElement.children[4]
                                showContainer.style.display = 'block'

                                // Download image
                                let saveImage = e.target.parentElement.parentElement.parentElement.children[4].children[0].children[0].children[0].children[2]
                                saveImage.addEventListener('click', () => {
                                    let text = e.target.parentElement.parentElement.parentElement.children[4].children[0].children[0].children[0].children[2].children[0].children[1]
                                    text.textContent = 'Saved'
                                    setTimeout(() => {
                                        text.textContent = 'Save Image'
                                    }, 2000)
                                })

                                // Delete post        
                                let deleteBtn = e.target.parentElement.parentElement.parentElement.children[4].children[0].children[0].children[0].children[5]

                                deleteBtn.addEventListener('click', (e) => {
                                    let x = e.target.children[0]
                                    x.style.display = 'block'
                                })


                                let NoBtn = e.target.parentElement.parentElement.parentElement.children[4].children[0].children[0].children[0].children[5].children[0].children[1].children[1]
                                NoBtn.addEventListener('click', (e) => {
                                    let x = e.target.parentElement.parentElement
                                    x.style.display = 'none'

                                })

                                // Close container
                                function closeFun() {
                                    let closeBtn = e.target.parentElement.parentElement.parentElement.children[4].children[0].children[0].children[0].children[7]
                                    closeBtn.addEventListener('click', () => {
                                        showContainer.style.display = 'none'
                                    })
                                }
                                closeFun()


                                document.addEventListener('click', (e) => {
                                    if (e.target.className == 'option_list' || e.target.className == 'option_container') {
                                        showContainer.style.display = 'none'
                                    }
                                })


                            })
                        }


                        // copy post url to clip-board
                        let copyLink = document.querySelectorAll('#copyLink')
                        for (i = 0; i < copyLink.length; i++) {
                            copyLink[i].addEventListener('click', (e) => {
                                let link, input
                                input = e.target.parentElement.children[1]
                                input.style.display = 'block'
                                link = e.target.parentElement.children[3].children[0].href
                                input.value = link
                                input.select();
                                document.execCommand('copy')
                                input.style.display = 'none'
                                e.target.textContent = 'Copied'
                                setTimeout(() => {
                                    e.target.textContent = 'Copy'
                                }, 2000)
                            })

                        }


                        function toggleEdit() {
                            document.querySelector('.update_post_container').classList.toggle('toggle_edit_class')
                        }

                        let closeEditBbtn = document.querySelectorAll('#editPostBtn')
                        closeEditBbtn.forEach(val => {
                            val.addEventListener('click', e => {
                                toggleEdit()
                            })
                        })

                        // @ close edit post modal
                        let closeEditModal = document.querySelectorAll('.update_post_container')
                        closeEditModal.forEach(val => {
                            val.addEventListener('click', e => {
                                if (e.target.className == 'update_post_container toggle_edit_class') toggleEdit()
                            })
                        })


                        // hide number of shares length if item lesser that 0
                        let numOfShare = document.querySelectorAll('#numOfShare')
                        for (i = 0; i < numOfShare.length; i++) {
                            let len = parseInt(numOfShare[i].textContent)
                            if (len < 1) {
                                numOfShare[i].style.display = 'none'
                            }
                        }


                        let editPostTExt = document.querySelectorAll('#editPost')
                        for (i = 0; i < editPostTExt.length; i++) {
                            editPostTExt[i].addEventListener('click', (e) => {
                                // document.querySelector('.update_post_container').style.display = 'block'
                                toggleEdit() //toggle edit modal

                                let id = e.target.children[1]
                                let text = e.target.children[2]

                                // Pust post id to input
                                document.querySelector('#postIdForEdit').value = id.textContent
                                // Pust description to textarea                
                                document.querySelector('#editTextarea').value = text.textContent
                            })
                        }


                        // optionBtn.forEach((cur) => {
                        //     cur.addEventListener('click', (e) => {

                        //     })
                        // })

                        // Hide delete button
                        let delBtn = document.querySelectorAll('#deleteBtn');
                        let globalId = document.getElementById('userId').textContent
                        for (i = 0; i < delBtn.length; i++) {
                            let text = delBtn[i].textContent;
                            if (!text.includes(globalId)) {
                                delBtn[i].style.display = 'none'
                            }

                        }


                        // Hide edit post 
                        let editPost = document.querySelectorAll('#editPost')
                        for (i = 0; i < editPost.length; i++) {
                            let text = editPost[i].textContent
                            if (!text.includes(globalId)) {
                                editPost[i].style.display = 'none'
                            }
                        }


                        // video section
                        let controller = document.querySelectorAll('#controller')
                        for (i = 0; i < controller.length; i++) {
                            controller[i].addEventListener('click', (e) => {

                                let pausebtn = e.target.parentElement.children[1]
                                let seeker = e.target.parentElement.nextElementSibling.children[0]
                                e.target.parentElement.children[0].style.display = 'none'
                                e.target.parentElement.children[1].style.display = 'block'

                                let video = e.target.parentElement.parentElement.parentElement.parentElement.children[0]
                                video.play()


                                pausebtn.addEventListener('click', () => {
                                    video.pause()
                                    e.target.parentElement.children[0].style.display = 'block'
                                    e.target.parentElement.children[1].style.display = 'none'
                                })

                                setInterval(() => {
                                    // Show play pause button when video is finished loading
                                    if (video.currentTime === video.duration) {
                                        e.target.parentElement.children[0].style.display = 'block'
                                        e.target.parentElement.children[1].style.display = 'none'
                                    }

                                    // moveing seeker                
                                    seeker.max = video.duration
                                    seeker.value = video.currentTime

                                }, 0);





                            })
                        }

                        // Edit post
                        let modal = document.querySelector('.update_post_container')
                        document.addEventListener('click', (e) => {
                            if (e.target.className == 'update_post_container') {
                            }
                        })


                        // trim some part of strings 
                        let last_comment_text = document.querySelectorAll('#last_comment_text')
                        for (i = 0; i < last_comment_text.length; i++) {
                            let string = last_comment_text[i].textContent
                            string = string.substr(0, 40)
                            last_comment_text[i].textContent = string
                        }


                        // Sliding image script
                        // let slideLeft = document.querySelectorAll('#slideLeft')
                        // let slideRight = document.querySelectorAll('#slideRight')
                        let postImage = document.querySelectorAll('#postImage')
                        for (i = 0; i < postImage.length; i++) {
                            let image = postImage[i]

                            let numOfImg = postImage[i].parentElement.children[1].children[0].children[2].textContent

                            let imageId = postImage[i].parentElement.children[1].children[0].children[3].textContent
                            let imageId2 = postImage[i].parentElement.children[1].children[0].children[4].textContent
                            let imageId3 = postImage[i].parentElement.children[1].children[0].children[5].textContent

                            numOfImg = parseInt(numOfImg)
                            let left = postImage[i].parentElement.children[1].children[0].children[0]
                            let right = postImage[i].parentElement.children[1].children[0].children[1]

                            let counter = 0
                            let arrImage = ['https://plogapp.s3.amazonaws.com/' + imageId, 'https://plogapp.s3.amazonaws.com/' + imageId2, 'https://plogapp.s3.amazonaws.com/' + imageId3]
                            if (numOfImg == 2) {
                                arrImage.pop()
                            }
                            if (numOfImg == 1) {
                                right.style.display = 'none'
                                left.style.display = 'none'
                            }

                            let lastItem = arrImage[arrImage.length - 1]
                            let lastIndex = arrImage.lastIndexOf(lastItem)

                            right.addEventListener('click', (e) => {
                                counter++
                            })

                            left.addEventListener('click', (e) => {
                                counter--
                            })

                            setInterval(() => {
                                image.src = arrImage[counter]
                                if (counter < 0) counter = numOfImg - 1
                                if (counter > lastIndex) counter = 0
                            }, 0);


                        }

                        // clicking fetch reaction modal
                        let appendReactors = document.getElementById('appendReactors')
                        document.querySelector('.load_likes_modal').addEventListener('click', e => {
                            if (e.target.className == 'load_likes_modal') {
                                e.target.style.display = 'none'
                                appendReactors.innerHTML = ''
                            }
                        })

                        // clsoing from the x 
                        document.querySelector('#closeReactorsPage').addEventListener('click', e => {
                            document.querySelector('.load_likes_modal').style.display = 'none'
                            appendReactors.innerHTML = ''
                        })



                        // clicking to fetch reactors on dm
                        let fetchReactors = document.querySelectorAll('.fetchReactors')
                        for (i = 0; i < fetchReactors.length; i++) {
                            fetchReactors[i].addEventListener('click', e => {
                                let postId = e.target.parentElement.parentElement.children[1].textContent
                                if (postId.includes('comments')) {
                                    return
                                }
                                document.querySelector('.load_likes_modal').style.display = 'block'
                                socket.emit('sendPostIdForReaction', postId)
                                document.querySelector('.likesReactionLoade').style.display = 'block' //show loader
                            })
                        }



                        // fetch reactions for a post
                        socket.on('reaction-users', (data) => {
                            document.querySelector('.likesReactionLoade').style.display = 'none' //show loader        
                            appendReactors.innerHTML = ''
                            data.map(cur => {
                                appendReactors.innerHTML += `<div class="div_flex">
                            <a href="/profile/${cur._id}">
                            <div class="reactor_wrapper">
                                    <img id="userPostAvatar" src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                                    <div>
                                        <h3 style="text-transform: capitalize;">${cur.firstname} ${cur.lastname} <span><i class="${cur.verified}"></i></span></h3>
                                    </div>
                                </div>
                                </a>
                                
                                <div class="icon_heart">
                                    <i class="fa fa-heart"></i>
                                </div>
                            </div>`
                            })

                        })

                        // follow button in post 
                        let followButton = document.querySelectorAll('#shortFollowBtn')
                        let primaryId = document.getElementById('primaryId').textContent
                        for (i = 0; i < followButton.length; i++) {
                            let owner = followButton[i].parentElement.children[1].textContent
                            let button = followButton[i]
                            let followingArr = followButton[i].parentElement.children[2].textContent

                            // hide follow button if its my post
                            if (owner == primaryId) {
                                button.style.display = 'none'
                            }

                            if (followingArr.includes(owner)) {
                                button.style.color = 'cornflowerblue'
                                button.style.border = '3px solid cornflowerblue'
                                button.textContent = 'Following'
                            } else {
                                button.style.backgroundColor = 'cornflowerblue'
                                button.textContent = 'Follow'
                                button.style.color = 'white'
                            }

                        }

                        // follow or unfollow
                        for (i = 0; i < followButton.length; i++) {
                            followButton[i].addEventListener('click', (e) => {
                                let btn = e.target
                                let loader = e.target.parentElement.children[3]
                                let followingId = e.target.parentElement.children[6].textContent
                                btn.style.display = 'none'
                                loader.style.display = 'block'
                                setTimeout(() => {
                                    loader.style.display = 'none'
                                    btn.style.display = 'block'
                                    return
                                }, 1000);

                                fetch('/follow-unfollow', {
                                    method: 'POST',
                                    headers: {
                                        'Accept': 'application/json, text/plain, */*',
                                        'Content-Type': 'application/json'
                                    },
                                    body: JSON.stringify({
                                        followingId,
                                    })
                                })
                                    .then(res => {
                                        return res.json()
                                    })

                                    .then(data => {
                                        console.log(data)
                                    })
                                    .catch(error => {
                                        console.log(error)
                                    })

                                // let followingDetails = {
                                //     followingId,
                                //     userId: e.target.parentElement.children[4].textContent
                                // }
                                // socket.emit('followingDetails', followingDetails)

                                if (btn.textContent === 'Follow') {
                                    btn.style.color = 'cornflowerblue'
                                    btn.style.border = '3px solid cornflowerblue'
                                    btn.style.backgroundColor = 'white'
                                    btn.textContent = 'Following'
                                } else {
                                    btn.style.backgroundColor = 'cornflowerblue'
                                    btn.textContent = 'Follow'
                                    btn.style.color = 'white'
                                }
                            })
                        }

                        // open short profile container
                        let hoverToShowProfile = document.querySelectorAll("#hoverToShow")
                        hoverToShowProfile.forEach(cur => {
                            cur.addEventListener('mouseover', e => {
                                let id = e.target.parentElement.parentElement.children[1].textContent
                                // console.log(id)
                                fetch('/user_api/' + id)
                                    .then(result => result.json())
                                    .then(data => {
                                        let divElement = e.target.parentElement.parentElement.parentElement.parentElement.parentElement.children[1]

                                        if (data.user.bestSentence == '' || data.user.bestSentence == null) {
                                            data.user.bestSentence = 'Joined ' + data.user.month + " " + data.user.year
                                        }
                                        let html =
                                            ` <div clas="sht_styler">
                                        <a href="/profile/${data.user._id}">
                                            <h3 style="font-size: 15px">${data.user.firstname} ${data.user.lastname}<span><i class="${data.user.verified}"></i></span>
                                            </h3>
                                            <p><span id="nickName">@${data.user.fullName}</span></p>
                                        </a>
                                        <p style="font-size: 15px">
                                            <span style="font-weight: bolder;">${data.follower}</span> <span style="color: #b0b0b0">followers <span
                                                    style="font-weight: bolder;">${data.following}</span> following
                                        </p>
                                        <p style="margin-top: 20px;">${data.user.bestSentence}</p>
                                    </div>`
                                        divElement.children[0].children[1].innerHTML = html
                                        e.target.parentElement.parentElement.parentElement.parentElement.parentElement.children[1].style.display = 'block'
                                    }).catch(error => {
                                        console.log(error)
                                    })
                            })
                        })

                        let closeShortProfile = document.querySelectorAll('.closeshortdiv')
                        for (i = 0; i < closeShortProfile.length; i++) {
                            closeShortProfile[i].addEventListener('click', e => {
                                e.target.parentElement.parentElement.parentElement.parentElement.style.display = 'none'
                            })
                        }

                    }




                    {

                        // 

                    }
                    // Share post script
                    {
                        // share post section
                        // Shareing section
                        let shareBtn = document.querySelectorAll('#shareBtn')
                        function toogleShareDiv() {
                            document.querySelector('.share_model').classList.toggle('toggle_share')
                        }

                        // document.querySelector('.close_share_div').addEventListener('click', e => {
                        //     toogleShareDiv()
                        // })

                        // close model
                        // document.addEventListener('click', (e) => {
                        //     if (e.target.className == 'share_model') {
                        //         toogleShareDiv()
                        //     }
                        // })


                        for (i = 0; i < shareBtn.length; i++) {
                            shareBtn[i].addEventListener('click', (e) => {
                                if (e.target.className === 'fa fa-refresh') {
                                    // document.querySelector('.share_model').style.display = 'block'
                                    toogleShareDiv()
                                    //==================
                                    let id = e.target.parentElement.children[1].textContent
                                    document.getElementById('postIdLink').value = id


                                    let postLink = e.target.parentElement.children[2].href
                                    document.getElementById('copyPostLink').addEventListener('click', e => {
                                        // Get the link
                                        let input = document.getElementById('copylinkInput')
                                        input.style.display = 'block'
                                        input.value = postLink
                                        input.select()
                                        document.execCommand('copy')
                                        input.style.display = 'none'

                                        // toggle success message
                                        document.querySelector('.success_copied_link').style.display = 'block'
                                        setTimeout(() => {
                                            document.querySelector('.success_copied_link').style.display = 'none'
                                        }, 2000)
                                    })


                                    // share post to story
                                    let postType = e.target.parentElement.children[3].textContent
                                    if (postType != 'image') {
                                        document.getElementById('sharePostToStory').style.opacity = .1
                                        document.getElementById('sharePostToStory').style.cursor = 'not-allowed'
                                    } else {
                                        document.getElementById('sharePostToStory').style.opacity = 1
                                        document.getElementById('sharePostToStory').style.cursor = 'pointer'
                                    }
                                    document.getElementById('sharePostToStory').addEventListener('click', e => {
                                        if (postType == 'image') {
                                            console.log('post is an Image')
                                            document.getElementById('postToStoryInput').value = id;
                                            document.getElementById('manualShareClickPost').click();
                                            return
                                        }

                                        e.target.style.backgroundColor = 'gray'
                                    })
                                }
                            })

                        }

                    }

                    // shares post reaction script
                    {
                        const socket = io()
                        // Change color globally
                        let colorGlobe = document.querySelectorAll('#changeHeartColorShared');
                        for (i = 0; i < colorGlobe.length; i++) {
                            colorGlobe[i].style.color = 'gray'
                        }


                        // Styling icons
                        let mainId = document.getElementById('userId').textContent
                        let primaryId = document.getElementById('primaryId').textContent
                        let div = document.querySelectorAll('#reactionElement');
                        for (i = 0; i < div.length; i++) {
                            let icon = div[i].children[0].children[0].children[0];
                            let ids = div[i].children[1].textContent;

                            // if(ids.split(',').indexOf(mainId) > -1){
                            //     icon.style.color = '#ff00bc'
                            //     icon.classList = 'fa fa-heart'
                            // }

                            if (ids.includes(primaryId)) {
                                icon.style.color = '#ff00bc'
                                icon.classList = 'fa fa-heart'
                            }

                        }


                        // let div2 = document.querySelectorAll('.heartReactionForShareedPost');
                        let likeBtn = document.querySelectorAll('#changeHeartColorShared');
                        for (i = 0; i < likeBtn.length; i++) {
                            likeBtn[i].addEventListener('click', (e) => {
                                let heart = e.target.parentElement.children[0]
                                let userId = e.target.parentElement.children[1].textContent
                                let postId = e.target.parentElement.children[2].textContent
                                let num = e.target.parentElement.parentElement.parentElement.parentElement.children[1].children[0].children[0].children[0]

                                let newStrNUm = parseInt(num.textContent) || 0;

                                let loader = e.target.parentElement.children[3]
                                let button = e.target

                                // button.style.display = 'none'
                                // loader.style.display = 'block'
                                // setTimeout(() => {
                                //     loader.style.display = 'none'
                                //     button.style.display = 'block'
                                //     return
                                // }, 500);

                                let data = {
                                    userId,
                                    postId
                                }
                                socket.emit('reactionToSharedPost', data)

                                // Change heart color 
                                if (heart.style.color == 'gray') {
                                    heart.style.color = '#ff00bc'
                                    num.style.color = 'black'
                                    num.textContent = newStrNUm += 1
                                    num.style.color = 'gray'
                                    heart.classList = 'fa fa-heart'
                                    parseInt(num.textContent) < 2 ? num.parentElement.children[1].textContent = 'Like' : num.parentElement.children[1].textContent = 'Likes'

                                } else {
                                    heart.style.color = 'gray'
                                    num.style.color = 'black'
                                    num.textContent = newStrNUm -= 1
                                    num.style.color = 'gray'
                                    heart.classList = 'fa fa-heart-o'
                                    parseInt(num.textContent) < 2 ? num.parentElement.children[1].textContent = 'Like' : num.parentElement.children[1].textContent = 'Likes'
                                }

                            })
                        }
                    }

                    {
                        // Pause and play video
                        let video = document.querySelectorAll('#myVideo')
                        Array.from(video).forEach(cur => {
                            let video = cur
                            let playBtn = video.nextElementSibling
                            let icon = playBtn.children[0].children[0].children[0]
                            if (video.pause) {
                                playBtn.style.opacity = '1'
                            }
                            playBtn.onclick = function () {
                                if (video.paused) {
                                    // Close all other playing video
                                    let allVideos = document.querySelectorAll('#myVideo')
                                    Array.from(allVideos).forEach(cur => {
                                        cur.pause()
                                    })

                                    video.play()
                                    icon.className = 'fa fa-pause'
                                    playBtn.style.opacity = '0'
                                } else {
                                    video.pause()
                                    icon.className = 'fa fa-play'
                                    playBtn.style.opacity = '1'
                                }
                            }
                        })

                        // let allVideos = document.querySelectorAll('#myVideo')
                        // setInterval(() => {
                        //     allVideos.forEach(element => {
                        //         if (element.readyState === 4) {
                        //             element.parentElement.children[1].style.display = 'none'
                        //         }
                        //     });
                        // }, 1000);

                    }

                    


                    {
                        // add numbers of watch videos 
                        let videoTags = document.querySelectorAll('#myVideo')
                        Array.from(videoTags).forEach(video => {
                            video.onplaying = function () {
                                let videoId = video.getAttribute('video-id')
                                fetch('/create-video-views', {
                                    method: 'POST',
                                    headers: {
                                        'Accept': 'application/json, text/plain, */*',
                                        'Content-Type': 'application/json'
                                    },
                                    body: JSON.stringify({
                                        videoId
                                    })
                                })
                                    .then(res => {
                                        return res.json()
                                    })

                                    .then(data => {
                                        console.log(data)
                                    })
                                    .catch(error => {
                                        console.log(error)
                                    })
                            };
                        })
                    }


                    



                })

            }
            loadmore(sortCount)

            window.onscroll = function () {
                if ((window.innerHeight + window.pageYOffset) >= Math.round(document.body.offsetHeight / 1.5)) {
                    loadmore(increase++)
                }
            }
        }).catch(error => {
            console.log(error)
            loadSortedPostFunction()
        })
}








// reporting post
function reportPostFunction(e){
    console.log(e)
    let type = e.getAttribute('type')
    let victim = e.getAttribute('victim')
    location.href  = `/report?type=${type}&&victim=${victim}`    
}