(function () {
    var socket = io()
    var appendNotification = document.getElementById('appendNotification')
    let userId1 = document.querySelector('.user_id')
    let deletId = document.querySelector('#deleteNotificationId')
    // toggle notification
    function toggleNotification() {
        document.querySelector('.notification_container_slide').classList.toggle('toggle_notification')
    }

    let notiBell = document.querySelectorAll('#toggleNotification')
    for (i = 0; i < notiBell.length; i++) {
        notiBell[i].addEventListener('click', e => {
            // try {
            window.history.pushState("", "", '/notification');
            toggleNotification()
            initNotification()

            // removin the number in the bell
            console.log(userId1.textContent)
            socket.emit('removebnotNumber', userId1.textContent)
            document.querySelector('#hideNotificationMobile').style.display = 'none'
            document.querySelector('#hideNotification').style.display = 'none'

            // } catch (error) {
            //     console.log('Something went wrong', error.message)
            // }
        })
    }

    // clicking the body to clise the container
    document.querySelector('.notification_container_slide').addEventListener('click', (e) => {
        if (e.target.className == 'notification_container_slide toggle_notification') {
            toggleNotification()
            window.history.pushState("", "", '/home');
        }
    })

    document.getElementById('closeNotification').addEventListener('click', e => {
        toggleNotification()
        window.history.pushState("", "", '/home');

    })

    // *********************************************************************
    // opening and clossing the notification option
    function toggleNotificationOption() {
        document.querySelector('.new_notification_option').classList.toggle('toggle_notification_option')
    }
    document.getElementById('openNotificationOption').addEventListener('click', e => {
        toggleNotificationOption()

    })

    document.getElementById('closeNotificationOption').addEventListener('click', e => {
        toggleNotificationOption()
    })

    initNotification()
    function initNotification() {
        fetch('/notification-api')
            .then(result => result.json())
            .then(data => {
                notificationLoopFUnction(data)
            }).catch(error => {
                console.log(error)
            })

    }

    function notificationLoopFUnction(data) {
        appendNotification.innerHTML = ''

        data.map(cur => {
            cur.comment = cur.comment.substr(0, 100)
            let html = `
                <div class="notification_wrapper">
                <div class="noti_img">
                    <img src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                </div>
                <a id="notificationAbchor" href="/${cur.urlLink}">
                    <div class="notifi_details">
                        <h3 class="noti_des"> ${cur.ownerName}</h3>
                        <p>${cur.text} <i style="color: ${cur.readStatusColor};" class="${cur.readStatus}"></i></p>
                        <p style="word-break: break-all;">${cur.comment}</p>
                        <span class="notification_date">${cur.date}</span>
                    </div>
                </a>
                <a id="notificationAbchor" href="/${cur.urlLink}">
                    <div class="clickableNotification">
                        <p style="display: none;">${cur._id}</p>
                    </div>
                </a>
                <div class="noti_hanbuger">
                    <i id="notificationDelBtn" class="fa fa-ellipsis-h"></i>
                    <p style="display: none;">${cur._id}</p>
                </div>
            
                <div class="delete_notification_container">
                    <div class="flex_del_hd">
                        <a id="deleteMainBtn">
                            <i class="fa fa-trash"></i>
                            <p>Delete notification</p>
                        </a>
                        <i id="cancelDelNotification" class="fa fa-close"></i>
                    </div>
                    </a>
                </div>
            </div>`

            appendNotification.innerHTML += html
            notificationFUnctionController()
        })
    }
    notificationFUnctionController()
    function notificationFUnctionController() {
        // try {

        // when a clicks on a notification change the check icon to read
        let notificationAbchor = document.querySelectorAll('.clickableNotification')
        let userId = document.getElementById('userId').textContent

        for (i = 0; i < notificationAbchor.length; i++) {
            notificationAbchor[i].addEventListener('click', (e) => {
                let id = e.target.children[0].textContent
                socket.emit('notificationId', id)
            })
        }

        // Send user id
        let userNotificationId = document.getElementById('userNotificationId').textContent
        socket.emit('userNotificationId', userNotificationId)



        // delete snotification btn
        let notificationDelBtn = document.querySelectorAll('#notificationDelBtn')
        for (i = 0; i < notificationDelBtn.length; i++) {
            notificationDelBtn[i].addEventListener('click', e => {
                e.target.parentElement.parentElement.children[4].style.display = 'block'
                deletId.textContent = e.target.parentElement.children[1].textContent
            })
        }


        // delete snotification btn
        let deleteMainBtn = document.querySelectorAll('#deleteMainBtn')
        for (i = 0; i < deleteMainBtn.length; i++) {
            deleteMainBtn[i].addEventListener('click', e => {
                let id = deletId.textContent
                e.target.parentElement.parentElement.parentElement.parentElement.style.display = 'none'
                socket.emit('deleteSingleNotification', id)
            })
        }

        // cancel delete btn
        let cancelDelNotification = document.querySelectorAll('#cancelDelNotification')
        for (i = 0; i < cancelDelNotification.length; i++) {
            cancelDelNotification[i].addEventListener('click', e => {
                e.target.parentElement.parentElement.style.display = 'none'
            })
        }

        // } catch (error) {
        //     console.log(error.message)
        // }
    }

})()