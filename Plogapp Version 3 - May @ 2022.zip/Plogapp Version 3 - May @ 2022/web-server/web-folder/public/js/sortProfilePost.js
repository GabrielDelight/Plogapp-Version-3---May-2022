// Sort post randomly /Shuffle
let appendPost = document.getElementById('appendPost')
let toSort = document.querySelectorAll('.post-container');
let arr = []

// Loop to send toSrot(HTMl elem) to Arr Array
for(i = 0; i < toSort.length; i++){
    arr.push(toSort[i])                
}

// Shuffle aray randomly
let x = arr.sort((a,b) => {
    return b - a
})

// Append Post to brower
for(i = 0; i < x.length; i++){
    appendPost.appendChild(x[i])
}