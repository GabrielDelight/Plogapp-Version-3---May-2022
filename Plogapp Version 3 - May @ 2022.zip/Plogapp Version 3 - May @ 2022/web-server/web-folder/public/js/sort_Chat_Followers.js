let chatDiv = document.querySelectorAll('.floaf_img')
let _appender = document.querySelector('.floating_chat')
let chatArray = []
for(i = 0; i < chatDiv.length; i++){
    chatArray.push(chatDiv[i])
}
chatArray = chatArray.sort(() => Math.random() - 0.5)
for(i = 0; i < chatArray.length; i++){
    _appender.appendChild(chatArray[i])
    
}


// open group create
let modal = document.querySelector('.create_chat_group')
modal.addEventListener('click', (e) => {
    if(e.target.classList  == 'create_chat_group'){
        modal.style.display = 'none'
    }
})
document.getElementById('calcelBtn').addEventListener('click', (e) => {
    e.preventDefault()
    modal.style.display = 'none'
})