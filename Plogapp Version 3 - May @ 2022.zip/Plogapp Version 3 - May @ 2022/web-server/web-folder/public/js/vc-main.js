(function () {
    let otherCam = document.getElementById('largeVideo')
    var url = new URLSearchParams(location.search);
    var callerId = url.get("callerId");
    var receiverId = url.get("receiverId");
    let callStatus = url.get('status')
    let appendChatMessages = document.getElementById('appendChatMessages')
    let sendMessgebtn = document.querySelector('.send_btn_vc_msg')
    let messageinput = document.querySelector('#messageinput')
    let chat_option_div = document.querySelector('.chat_option_div')

    const socket = io()

    let deleteId = {}


    // Closing the chat at mobile view



    // Chat mechanism
    scrollChatFunction()
    function scrollChatFunction(params) {
        let element = document.querySelector('.message_body')
        element.scrollTop = element.scrollHeight + element.clientHeight
    }



    // @ Toggle dark mode and light mode
    {

        // Toggle dark mood
        function toggleDark(divColor, elemColor) {
            // Stable white
            let elem_white = document.querySelectorAll('i')
            Array.from(elem_white).forEach(cur => {
                cur.style.color = '#ddd'
            })


            // for divs with night_mood
            let div = document.querySelectorAll('.night_mood, textarea')
            Array.from(div).forEach(cur => {
                cur.style.backgroundColor = divColor
            })

            // Toggle param : i, a, h1, h2, h3, h4, h5, h6
            let elem = document.querySelectorAll(' a, h1, h2, h3, h4, h5, h6')
            Array.from(elem).forEach(cur => {
                cur.style.color = elemColor
            })
        }

        let storage = localStorage.getItem('dark-mode')
        if (storage == 'dark') {
            toggleDark('#181a1b', '#ddd')
        }

        document.querySelector('#toggle_dark_mode').addEventListener('click', e => {
            let storage = localStorage.getItem('dark-mode')
            // console.log(storage)
            if (storage == null) {
                localStorage.setItem('dark-mode', 'dark')
                toggleDark('#181a1b', 'white')
                return
            } else {
                toggleDark('white', '#181a1b')
                localStorage.removeItem('dark-mode')

            }
        })

    }
    // End of toggle


    // Muting audio
    document.getElementById('microphoneToggle').addEventListener('click', e => {
        let microPhoneIcon = document.getElementById('microPhoneIcon')
        if (!otherCam.muted) {
            otherCam.muted = true
            microPhoneIcon.className = 'fa fa-microphone'
        } else {
            otherCam.muted = false
            microPhoneIcon.className = 'fa fa-microphone-lines-slash'
        }
    })


    // Chat message function
    function loadChatFunction(data) {
        // Do something later\
        appendChatMessages.innerHTML = ''
        data.map(cur => {
            appendChatMessages.innerHTML +=
                `<div class="push_msg_left ${cur.pushChat}">
            <p id="chatClicking" chatId="${cur.randomId}">${cur.message == null ? '' : cur.message}</p >
            </div > `

            scrollChatFunction()
            let chatClicking = document.querySelectorAll('#chatClicking')
            Array.from(chatClicking).forEach(cur => {
                cur.addEventListener('click', e => {
                    // console.log(chat_option_div)
                    chat_option_div.classList.add('toggle_display')
                    deleteId.chatId = e.target.getAttribute('chatId')
                })
            })
        })
    }




    // clicing div
    document.querySelector('.chat_option_div button').addEventListener('click', e => {
        chat_option_div.classList.remove('toggle_display')

        fetch('/deleteMessage', {
            method: 'POST',
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                data: deleteId.chatId,
            })
        })
            .then(res => res.json())
            .then(res => {
                // console.log(res)
            }).catch(err => {
                console.log(err)
            })
    })


    document.querySelector('.close_div_chat_option').addEventListener('click', e => {
        chat_option_div.classList.remove('toggle_display')
    })


    // Load chat message both clients
    if (callStatus == 'host') {
        // Sending messages
        sendMessgebtn.addEventListener('click', e => {
            if (messageinput.value == '') {
                return
            }




            let myChat = {
                owner: callerId,
                message: messageinput.value,
                receiverId: receiverId,
                ownerName: 'From video call',
                replyOldMessage: '',
                receiverName: 'From video call'
            }

            socket.emit('myChat', myChat)
            socket.emit('saveChat', myChat)
            messageApiFunction()

            messageinput.value = ''
        })


        messageApiFunction()
        setInterval(messageApiFunction, 1000);
        function messageApiFunction() {
            fetch('/chat_messages_api/' + receiverId)
                .then(result => result.json())
                .then(data => {
                    loadChatFunction(data)
                }).catch(error => {
                    console.log(error)
                })
        }
    }


    if (callStatus == 'joined') {

        sendMessgebtn.addEventListener('click', e => {
            if (messageinput.value == '') {
                return
            }
            let myChat = {
                owner: receiverId,
                message: messageinput.value,
                receiverId: callerId,
                ownerName: '',
                replyOldMessage: '',
                receiverName: ''
            }

            socket.emit('myChat', myChat)
            socket.emit('saveChat', myChat)
            messageApiFunction()

            messageinput.value = ''
        })


        // Sending messages
        messageApiFunction()
        setInterval(messageApiFunction, 1000);
        function messageApiFunction() {
            fetch('/chat_messages_api/' + callerId)
                .then(result => result.json())
                .then(data => {
                    loadChatFunction(data)
                }).catch(error => {
                    console.log(error)
                })
        }
    }

    let video_calling_chat_area = document.querySelector('.video_calling_chat_area')
    
    if(window.matchMedia("(max-width: 600px)").matches){
        // console.log('Hey')
        video_calling_chat_area.classList.toggle('toggle_chat_dicplay')
    }

    // TOggleing Chat divs
    document.getElementById('toggleChatDiv').addEventListener('click', e => {
        // console.log(video_calling_chat_area.style.display)
        video_calling_chat_area.classList.toggle('toggle_chat_dicplay')
    })

    // .close chat div  
    document.getElementById('close_div').addEventListener('click', e => {
        video_calling_chat_area.classList.toggle('toggle_chat_dicplay')
        
    })

 


})()