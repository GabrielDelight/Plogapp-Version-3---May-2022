let storypostObject = {}
storypostObject.background = 'cornflowerblue'
let storyimageObject = {}
let storyVideoObject = {}
let videoCoverImage = {}
let alertBox = document.querySelector('.story_alert_box_info')
let currentOwnerImage = document.querySelector('.cure-user-avatar')
function toggleUpload() {
    document.querySelector('.update_upload_story_container').classList.toggle('toggle_story_upload_toggler')
    let video = document.querySelector('#videoElement')
    if (video.play()) {
        video.pause()
    }
}
document.getElementById('openStoryUpload').addEventListener('click', e => {
    toggleUpload()
})

document.getElementById('closeToggler').addEventListener('click', e => {
    toggleUpload()
})


// Hide video and photo divs and display only post text div if user makes post successfully
function hideVideoAndPhotoDiv() {
    story_text_preview.style.display = 'block'
    story_video_section.style.display = 'none'
    preview_story_img.style.display = 'none'
}

let openStoryVideoEdit = document.querySelector('#openStoryVideoEdit')
let openStoryTextEdit = document.querySelector('#openStoryTextEdit')
let openStoryPhotoEdit = document.querySelector('#openStoryPhotoEdit')



let story_video_section = document.querySelector('.story_video_section')
let preview_story_img = document.querySelector('.preview_story_img')
let story_text_preview = document.querySelector('.story_text_preview')

openStoryTextEdit.addEventListener('click', e => {
    story_text_preview.style.display = 'block'
    story_video_section.style.display = 'none'
    preview_story_img.style.display = 'none'

})

// Open picking story images 
openStoryPhotoEdit.addEventListener('click', e => {

    document.getElementById('uploadImgStoryForm').click()
    document.getElementById('uploadImgStoryForm').addEventListener('change', function () {

        if (this.files && this.files[0]) {
            document.getElementById('storyFullImage').src = URL.createObjectURL(this.files[0])
            storyimageObject.file = this.files[0]

            story_text_preview.style.display = 'none'
            story_video_section.style.display = 'none'
            preview_story_img.style.display = 'block'
        }
    })


})





let icons = document.querySelectorAll('#icons')
let storyText = document.getElementById('storyText')
for (i = 0; i < icons.length; i++) {
    icons[i].addEventListener('click', e => {
        storyText.value += e.target.textContent
    })
}


let textarea = document.getElementById('postTextarea')
document.getElementById('postTextarea').addEventListener('input', e => {


    if (textarea.value.length < 50) {
        textarea.style.fontSize = 40 + 'px'
        fontSize.textContent = 40
    }

    if (textarea.value.length > 50) {
        textarea.style.height = 300 + 'px'
    }


    if (textarea.value.length > 100) {
        textarea.style.height = 450 + 'px'
    }

    if (textarea.value.length > 150) {
        textarea.style.height = 500 + 'px'
    }
    if (textarea.value.length > 250) {
        textarea.style.height = 550 + 'px'
    }

    if (textarea.value.length > 250) {
        textarea.style.height = 650 + 'px'
        textarea.style.fontSize = 20 + 'px'
        fontSize.textContent = 20

    }

    if (textarea.value.length >= 500) {
        textarea.value = textarea.value.substr(0, 700)
        textarea.style.height = 100 + '%'
        textarea.style.fontSize = 14 + 'px'
        fontSize.textContent = 14


        alert('Your story update can not exceed 700 characters.')
    }


    if (textarea.value.trim() == '') {
        document.querySelector('#uploadStoryBtn').style.visibility = 'hidden'
    } else {
        document.querySelector('#uploadStoryBtn').style.visibility = 'visible'
    }
    storypostObject.description = textarea.value
})

// CHaching nackgrodund color
let counter = 0
document.getElementById('changebackground').addEventListener('click', e => {
    counter++
    let bgArray = [
        'gold',
        'green',
        'tan',
        'aqua',
        'black',
        'pink',
        'cornflowerblue',
    ]

    let random = Math.floor(Math.random() * bgArray.length)
    // console.log(bgArray[random])
    // console.log(bgArray[counter])

    if (bgArray[counter] !== undefined) {
        document.querySelector('.story_text_preview').style.backgroundColor = bgArray[counter]
        storypostObject.background = bgArray[counter]
    }

    if (counter >= bgArray.length) {
        counter = 0
    }
})


// change font size
let counterFont = 0
document.getElementById('fontSize').addEventListener('click', e => {
    counterFont++
    let fontArr = [
        '10px',
        '30px',
        '20px',
        '10px',
        '40px',
        '50px',
        '25px',
    ]

    let random = Math.floor(Math.random() * fontArr.length)
    // console.log(fontArr[random])
    // console.log(fontArr[counterFont])

    if (fontArr[counterFont] !== undefined) {
        document.querySelector('#postTextarea').style.fontSize = fontArr[counterFont]
        fontSize.textContent = fontArr[counterFont].substring(0, 2)
        storypostObject.fontSize = fontArr[counterFont]
    }

    if (counterFont >= fontArr.length) {
        counterFont = 0
    }
})


let bold = true
document.getElementById('boldText').addEventListener('click', e => {
    let btn = document.getElementById('boldText')
    if (bold) {
        textarea.style.fontWeight = '700'
        btn.style.fontWeight = '700'
        bold = false
        storypostObject.boldText = 'bolder'

    } else {
        textarea.style.fontWeight = '100'
        btn.style.fontWeight = '100'
        bold = true
        storypostObject.boldText = 'normal'
    }
})


// Font's families
//         font-family: Arial, Helvetica, sans-serif;
// font-family: cursive;
// font-family: Agency fb;
let fontFamily = 0
document.getElementById('changeFontFamily').addEventListener('click', e => {
    fontFamily++
    let bgArray = [
        'curs',
        'cursive',
        'Agency fb',
        'sans-serif',
    ]

    let random = Math.floor(Math.random() * bgArray.length)
    // console.log(bgArray[random])
    // console.log(bgArray[fontFamily])

    if (bgArray[fontFamily] !== undefined) {
        document.querySelector('#postTextarea').style.fontFamily = bgArray[fontFamily]
        storypostObject.fontFamily = bgArray[fontFamily]
    }

    if (fontFamily >= bgArray.length) {
        fontFamily = 0
    }
})

// Upload story text\
let uploadingIcon = document.getElementById('uploadingIcon')
document.getElementById('uploadStoryBtn').addEventListener('click', e => {
    if (textarea.value == "") return
    document.getElementById('uploadStoryBtn').style.display = 'none'
    uploadingIcon.style.display = 'block'

    document.querySelector('.uploading_progress_bar').style.display = 'block'
    toggleUpload() //Toggle out, after story has been uploaded               



    storypostObject.description = document.querySelector('#postTextarea').value


    let storyText = storypostObject.description
    let text1Sample = storyText.substr(0, 30)
    let text2Sample = storyText.substr(30, 50)
    let text3Sample = storyText.substr(50, 30)
    var canvas = document.createElement("canvas");
    var ctx = canvas.getContext("2d");
    // ctx.fillStyle = "green";



    ctx.fillStyle = storypostObject.background == undefined ? 'cornflowerblue' : storypostObject.background;
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    ctx.fillStyle = "white";
    ctx.font = '23px';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text1Sample, (canvas.width / 2), (canvas.height / 2) - (2 * 7));
    ctx.fillText(text2Sample, (canvas.width / 2), (canvas.height / 2) * 1);
    ctx.fillText(text3Sample, (canvas.width / 2), (canvas.height / 2) * 1.2);

    // storypostObject.file = canvas.toDataURL()

    canvas.toBlob(function (blob) {
        var newImage = new File([blob], 'story' + ".png");
        // newImage.type = 'image/png'
        storypostObject.file = newImage

        let data = new FormData()
        // console.log(storypostObject.file)
        // console.log(storypostObject)
        data.append('uploads', storypostObject.file)
        data.append('description', storypostObject.description)
        data.append('storyText', storypostObject.storyText)
        data.append('fontFamily', storypostObject.fontFamily)
        data.append('background', storypostObject.background)
        data.append('fontSize', storypostObject.fontSize)
        data.append('boldText', storypostObject.boldText)

        fetch('/upload-story-text', {
            method: 'POST',
            body: data
        })
            .then(res => {
                return res.json()
            })
            .then(data => {
                // console.log(data)

                currentOwnerImage.src = URL.createObjectURL(storypostObject.file)


                 
                document.querySelector('.uploading_progress_bar').style.display = 'none'

                document.getElementById('uploadStoryBtn').style.display = 'block'
                document.getElementById('uploadStoryBtn').style.display = 'flex'
                uploadingIcon.style.display = 'none'
                textarea.value = ""



            }).catch(error => {
                console.log(error)
            })
    }, 'image/jpeg', 0.4);

})



// Upload story for photo
let imageFIle = document.getElementById('uploadImgStoryForm')
document.getElementById('uploadStoryForPhoto').addEventListener('click', e => {
    if (imageFIle.value == '') {
        return alertBox.style.display = 'block'
    }

    document.getElementById('uploadStoryForPhoto').style.display = 'none'
    document.getElementById('uploadRefreshcon').style.display = 'block'

    document.querySelector('.uploading_progress_bar').style.display = 'block'
    toggleUpload() //Toggle out, after story has been uploaded               



    let imageDescription = document.getElementById('storyImageTextarea').value
    storyimageObject.description = imageDescription

    // console.log(storyimageObject)

    let f = storyimageObject.file;
    // console.log(f)
    let fileName = f.name.split('.')[0];
    let img = new Image();
    img.src = URL.createObjectURL(f);
    img.onload = function () {
        let canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        let ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        canvas.toBlob(function (blob) {
            let newImage = new File([blob], fileName + ".jpeg");
            // console.log(newImage)
            let data = new FormData()
            data.append('uploads', newImage)
            data.append('storyText', storyimageObject.description)

            fetch('/uploadStatusPhoto', {
                method: 'POST',
                body: data
            })
                .then(res => res.json())
                .then(result => {

                    currentOwnerImage.src = URL.createObjectURL(storyimageObject.file)
                    
                    document.getElementById('uploadRefreshcon').style.display = 'none'
                    document.getElementById('uploadStoryForPhoto').style.display = 'block'
                    document.getElementById('uploadStoryForPhoto').style.display = 'flex'

                    document.querySelector('.uploading_progress_bar').style.display = 'none'

                    hideVideoAndPhotoDiv()

                }).catch(err => {
                    console.log(err)
                })

        }, 'image/jpeg', 0.4);
    }



    // if successful    

})



openStoryVideoEdit.addEventListener('click', e => {
    document.getElementById('videoFile').click()
    document.getElementById('videoFile').addEventListener('change', function () {
        if (this.files && this.files[0]) {



            let video = document.getElementById('videoElement')
            video.src = URL.createObjectURL(this.files[0])
            storyVideoObject.file = this.files[0]
            video.play()
            story_text_preview.style.display = 'none'
            story_video_section.style.display = 'block'
            preview_story_img.style.display = 'none'




            var canvas = document.createElement('canvas');
            var ctx = canvas.getContext('2d');

            // set canvas size = video size when known
            video.addEventListener('loadedmetadata', function () {
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
            });

            video.addEventListener('play', function () {
                var $this = this; //cache
                (function loop() {
                    if (!$this.paused && !$this.ended) {
                        ctx.drawImage($this, 0, 0);

                        canvas.toBlob(function (blob) {
                            var newImage = new File([blob], 'story' + ".png");
                            // newImage.type = 'image/png'
                            videoCoverImage.file = newImage

                        }, 'image/jpeg', 0.4);


                        // image.src = canvas.toDataURL();
                        // videoCoverImage.file = canvas.toDataURL();

                        setTimeout(loop, 1000 / 30); // drawing at 30fps

                    }
                })();
            }, 0);


        }
    })

})



let videoFile = document.getElementById('videoFile')
document.getElementById('uploadVideoBtn').addEventListener('click', e => {

    if (storyVideoObject.file.size > 44816215) {
        // console.log('video too large, size ', storyVideoObject.file.size)
        document.querySelector('.story_alert_box_info').style.display = 'block'
        document.getElementById('alertPara').textContent = 'Sorry, the video is too large please trim the video and try again later.'
        setTimeout(() => {
            // document.querySelector('.story_alert_box_info').style.display = 'none'
            document.getElementById('alertPara').textContent = `Sorry, you can not upload an empty story or a large video at the moment.  Seems the file are been removed Try adding a text, photo or short video. Click any of the top right icons to restart Or try again later thank you.`
        }, 5000);

        return
    }


    storyVideoObject.description = document.getElementById('storyVideoDescription').value
    // console.log(storyVideoObject)
    // if successful    
    if (videoFile.value == '') {
        return alertBox.style.display = 'block'
    }

    // if success

    document.getElementById('uploadVideoBtn').style.display = 'none'
    document.getElementById('uploadRefreshconForVideo').style.display = 'block'


    document.querySelector('.uploading_progress_bar').style.display = 'block'
    toggleUpload() //Toggle out, after story has been uploaded   

    const data = new FormData()
    data.append('uploads', storyVideoObject.file)
    // data.append('uploads', storyVideoObject.file)
    data.append('storyText', storyVideoObject.description)

    fetch('/upload-story-video', {
        method: 'POST',
        body: data
    })
        .then(res => res.json())
        .then(result => {
            // If uploaded upload image backgrund here
            // console.log(result)
            // console.log(videoCoverImage.file)
            uploadStoryVideoWrapper(videoCoverImage.file, result._id)

        }).catch(err => {
            console.log(err)
        })


})


function uploadStoryVideoWrapper(file, storyId) {
    
    const data = new FormData()
    data.append('uploads', file)
    data.append('storyId', storyId)
    fetch('/upload-story-video-cover/', {
        method: 'POST',
        body: data
    })
        .then(res => res.json())
        .then(result => {
            // If uploaded upload image backgrund here
            currentOwnerImage.src = URL.createObjectURL(file)
            // console.log(result)
            // console.log(videoCoverImage.file)

            document.getElementById('uploadVideoBtn').style.display = 'block'
            document.getElementById('uploadVideoBtn').style.display = 'flex'
            document.getElementById('uploadRefreshconForVideo').style.display = 'none'

            // toggleUpload()
            hideVideoAndPhotoDiv()

            document.querySelector('.uploading_progress_bar').style.display = 'none'

                        

        }).catch(err => {
            console.log(err)
        })
}


