const socket = io()
// Make the form active
let input = document.getElementById('myInput');
let appender = document.getElementById('apendder')
let groupId = document.getElementById('groupId')
let myName = document.getElementById('myName').textContent
let recepientName = document.getElementById('myName').textContent
let myId = document.getElementById('myId').textContent
let memebers = document.getElementById('groupMembers').textContent

document.getElementById('myInput').focus()

document.querySelector('.main_chat_body_content').scrollTop += 994000

// Date
let monthsArray;
let month;
let newMonth;
let day = new Date().getDate();
let year = new Date().getFullYear();
let time = new Date().toLocaleTimeString();
monthsArray = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
month = new Date().getMonth();
newMonth = monthsArray[month];
let fullDateStr = `${year} ${newMonth} ${day} AT ${time}`


input.focus()
let sendBtn = document.querySelector('.send_icon');
sendBtn.style.display = 'none'
document.addEventListener('input', () => {
    if (input.value == '') {
        sendBtn.style.display = 'none'
    } else {
        sendBtn.style.display = 'block'
    }
})


// Function for scrolling bottom
function scrollUpUsers() {
    let x = document.querySelector('.main_chat_body_content')
    x.scrollTop += 994000
}



document.getElementById('btn').addEventListener('click', () => {

    if (input.value == '') {
        return
    }

    let saveData = {
        owner: myId,
        message: input.value,
        date: fullDateStr,
        receiverId: groupId.textContent,
        ownerName: myName,
        pushChat: 'pushLeft',
    }

    socket.emit('saveGrupMessage', saveData)


    let myChat = {
        owner: myId,
        message: input.value,
        date: fullDateStr,
        receiverId: groupId.textContent,
        ownerName: myName,
        pushChat: 'pushRight',
    }


    socket.emit('myMessage', myChat)

    // Append my chat

    let newhtml = `<div class="friend_chat_box pushLeft" id="chat_container_box">
        <div class="friends_image2">
            <img src="/userPostAvatar/%id%" alt="">
        </div>
        <div class="friend_chat_details">
            <div class="date--name2">
                <h4 style="text-transform: capitalize;">$name$ <span></span></h4>
            </div>
            <div class="chat_text_box blueColor">
                <p id="stylerColor">$message$</p>                                            
            </div>
        </div>
    </div>`


    let validate = input.value
    validate = validate.replace(/</g, '')
    validate = validate.replace(/>/g, '')
    newhtml = newhtml.replace('$message$', validate)
    newhtml = newhtml.replace('$name$', myName)
    newhtml = newhtml.replace('%id%', myId)
    appender.insertAdjacentHTML('beforeend', newhtml)
    scrollUpUsers()
    input.value = ''

})


socket.on('instantMessage', (data) => {


    if (memebers.includes(myId)) {
        let newhtml = `<div class="friend_chat_box pushLeft" id="chat_container_box"><div class="friends_image2"><img src="/userPostAvatar/%id%" alt=""></div><div class="friend_chat_details"><div class="date--name2"><h4 style="text-transform: capitalize;">$name$ <span></span></h4></div><div class="chat_text_box blueColor"><p id="stylerColor">$message$</p></div></div></div>`

        let validate = data.message
        validate = validate.replace(/</g, '')
        validate = validate.replace(/>/g, '')
        newhtml = newhtml.replace('$message$', validate)
        newhtml = newhtml.replace('$name$', data.ownerName)
        newhtml = newhtml.replace('%id%', data.owner)
        appender.insertAdjacentHTML('beforeend', newhtml)
        scrollUpUsers()
    }


})


// Remove users that are not following 
let followers = document.querySelectorAll('.add_btn')
let myFollowers = document.getElementById('myFollowers').textContent
// Remover users that are not following me
for (i = 0; i < followers.length; i++) {
    let id = followers[i].children[1].textContent
    if (!myFollowers.includes(id)) {
        followers[i].parentElement.style.display = 'none'
    }

    // remove my data from list
    if (id.includes(myId)) {
        followers[i].parentElement.style.display = 'none'
    }

    // Remover friends from add list that are already in group
    if (memebers.includes(id)) {
        followers[i].children[0].style.display = 'none'
        followers[i].children[2].style.display = 'block'
    }




}

let addBtn = document.querySelectorAll('#addBtn')

for (i = 0; i < addBtn.length; i++) {
    addBtn[i].addEventListener('click', (e) => {
        let id = e.target.parentElement.children[1].textContent
        let invitee = myName
        socket.emit('addDetails', {
            id,
            invitee,
            groupId: groupId.textContent,
            myId
        })

        e.target.parentElement.children[0].style.display = 'none'
        e.target.parentElement.children[2].style.display = 'block'

    })
}



// CLose group option list
document.addEventListener('click', (e) => {
    if (e.target.classList == 'main_chat_body_content') {
        document.querySelector('.gp_option_list').style.display = 'none'
    }
})


// Chat emogi
let emogi = document.querySelectorAll('#emogi')
for (i = 0; i < emogi.length; i++) {
    emogi[i].addEventListener('click', (e) => {
        input.value += e.target.textContent
        sendBtn.style.display = 'block'
    })

}
// Show chat model
let model = document.querySelector('.chatemogi_container')
document.addEventListener('click', (e) => {
    if (e.target.classList == 'chatemogi_container') {
        model.style.display = 'none'
    }
})

// Sort for followes
let text = document.getElementById('search')
let div = document.querySelectorAll('#names')
let arr = []

document.addEventListener('input', (e) => {
    for (i = 0; i < div.length; i++) {
        let str = div[i].textContent
        let search = text.value.toLowerCase()

        if(str.includes(search)){
            div[i].parentElement.parentElement.parentElement.parentElement.style.display = 'block'
        }else {
            div[i].parentElement.parentElement.parentElement.parentElement.style.display = 'none'
        }


    }
})