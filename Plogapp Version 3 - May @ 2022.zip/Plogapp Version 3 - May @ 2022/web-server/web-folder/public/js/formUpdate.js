const socket = io()
let jwt = document.cookie
// deleting of account section ************************************
let userid = document.getElementById('userId').textContent

let deletePassword = document.getElementById('deletePassword')
let deleteOwner = document.getElementById('deleteOwner')
document.getElementById('delBtn').addEventListener('click', e => {
    if (deletePassword.value.trim() === '') {
        return
    }
    socket.emit('deleteInfo', {
        jwt,
        deletePassword: deletePassword.value,
        deleteOwner: deleteOwner.value
    })
})

// if the password is wrong
socket.on('wrongPassword', data => {
    document.getElementById('wrongPasssword').textContent = data
    document.getElementById('wrongPasssword').style.display = 'block'
})

// if the password is correct
socket.on('showCnfirmBtn', data => {
    document.querySelector('.hide_del_div').style.display = 'none' //hide the confirm password container
    document.querySelector('.div_hide_form').style.display = 'block'
    document.getElementById('wrongPasssword').style.display = 'none'
})

// _----------------------------------------------------------------------


// chanhing of password section
let oldPassword = document.getElementById('oldPassword')
let newPassword = document.getElementById('newPassword')
let confirmNewPassword = document.getElementById('confirmNewPassword')
document.getElementById('confirmOldPassBtn').addEventListener('click', e => {
    if (oldPassword.value.trim() == '' ||
        newPassword.value.trim() === '' ||
        confirmNewPassword.value.trim() === ''
    ) {
        document.getElementById('wrongChangePass').textContent = 'All fields are required'
        return
    }
    else if (newPassword.value !== confirmNewPassword.value) {
        document.getElementById('wrongChangePass').textContent = 'New password and confirm password does not match.'
        return
    } else if (newPassword.value.length < 6) {
        document.getElementById('wrongChangePass').textContent = 'Your new password must be greater than 6 characters.'
        return
    }

    socket.emit('coinfirmPassword', {
        userid,
        jwt,
        currentPassword: oldPassword.value,
        newPassword: newPassword.value
    })
})

// show error in confirm pass
socket.on('wrongChangePass', data => {
    document.getElementById('wrongChangePass').textContent = 'Your old password is a wrong password'
})

// @Success in changing the password
socket.on('passwordSuccess', data => {
    document.getElementById('wrongChangePass').textContent = 'Success, thanks for changing your password.'
    document.getElementById('wrongChangePass').stylec.color = 'green'
})


//@ changing email address here --------------------------------
let newEmail = document.getElementById('newEmail')
document.getElementById('verifyEmailBtn').addEventListener('click', e => {
    if (newEmail.value.trim() === '') {
        document.getElementById('emailErrorMessage').textContent = 'Please type a new email'
        return
    }

    socket.emit('emailInfo', {
        userid,
        email: newEmail
    })
})

// @ listen to confirm emial
socket.on('oldverifyEmail', data => {
    document.getElementById('oldverifyEmail').style.display = 'none'
    document.querySelector('.hide_email_verify').style.display = 'block'
})


// final email verification button 
let emailVerificationCode = document.getElementById('emailVerificationCode')
document.getElementById('finalEmailVerifybtn').addEventListener('click', e => {
    if (emailVerificationCode.value.trim() === '') {
        document.getElementById('emailErrorMessage').textContent = 'Type in your verification code'
        return
    }

    socket.emit('emailVerificationCode', {
        userid,
        email: newEmail.value,
        code: emailVerificationCode.value,

    })

})

// @ throw an error for rejecting the code
socket.on('rejectCode', data => {
    document.getElementById('emailErrorMessage').textContent = data
})

// @ success in emial changing
socket.on('changeEmailSuccess', data => {
    document.getElementById('emailErrorMessage').textContent = 'You\'ve successfully changed your email address'
    document.getElementById('emailErrorMessage').style.color = 'green'
})


// @ change number section ***********************************************
let newNumber = document.getElementById('newNumber')
let countryCode = document.getElementById('countryCode')
document.getElementById('newNumberBtn').addEventListener('click', e => {
    if (newNumber.value.trim() === '') {
        document.getElementById('numberErrorMessage').textContent = 'Please type in your new number'
        return
    }

    socket.emit('numberInfo', {
        userid,
        number: newNumber.value,
        countryCode: countryCode.value
    })

})

// @ verify number process
socket.on('verifyNumber', data => {
    console.log('heyyy')
    document.getElementById('inputting_number_div').style.display = 'none'
    document.querySelector('.verify_number_div').style.display = 'block'

})


// confirm phone verification
let phoneverifyCode = document.getElementById('phoneverifyCode')
document.getElementById('phoneverifyCodeBtn').addEventListener('click', e => {
    if (phoneverifyCode.value.trim() === '') {
        document.getElementById('numberErrorMessage').textContent = 'Please type in the correct code sent to this phone number'
        return
    }
    socket.emit('confirmMobileCode', {
        userid,
        newNumber: newNumber.value,
        code: phoneverifyCode.value,
    })
    console.log('Hello world')

})

// invalid code
socket.on('rejectPhoneCode', data => {
    document.getElementById('numberErrorMessage').textContent = data
})


// @ phone number changed succssfully
socket.on('changePhoneSuccess', data => {
    console.log('Success')
    document.getElementById('numberErrorMessage').textContent = 'You\'ve successfully changed your email address'
    document.getElementById('numberErrorMessage').style.color = 'green'
})



//@ nickname section
let newNickname = document.getElementById('newNickname')
// '!@#$%^&*(){|\""}/><,'
newNickname.addEventListener('input', e => {
    let s = newNickname.value;
    let punctuationless = s.replace(/[.,\/#!$%@<>,?:';'`""\^&\*;:{}=\-`~()]/g, "");
    let finalString = punctuationless.replace(/\s{2,}/g, " ");
    finalString = finalString.replace(/ /g, '')
    finalString = finalString.replace(/]/g, '')
    finalString = finalString.replace(/\[/, '')
    newNickname.value  = finalString

    document.getElementById('prevNickname').textContent = '@'+ newNickname.value
})

document.getElementById('nicknameBtn').addEventListener('click', () => {
    if (newNickname.value.trim() === '') {
        document.getElementById('nicknameError').textContent = 'Please type a nickname'
        document.getElementById('nicknameError').style.color = 'red'
        return
    }

    let s = newNickname.value;
    let punctuationless = s.replace(/[.,\/#!$%@<>,?:';'`""\^&\*;:{}=\-_`~()]/g, "");
    let finalString = punctuationless.replace(/\s{2,}/g, " ");
    finalString = finalString.replace(/ /g, '')
    finalString = finalString.replace(/]/g, '')
    finalString = finalString.replace(/\[/, '')
    newNickname.value  = finalString




    socket.emit('nicknameInfo', {
        userid,
        jwt,
        newNickname: newNickname.value
    })

})


// @ nickname exist
socket.on('nicknameExist', data => {
    document.getElementById('nicknameError').textContent = data
    document.getElementById('nicknameError').style.color = 'red'
})

socket.on('nicknameSuccess', data => {
    document.getElementById('nicknameError').textContent = data
    document.getElementById('nicknameError').style.color = 'green'
})


// update fullname 
let firstname = document.getElementById('firstname')
let lastname = document.getElementById('lastname')
document.getElementById('fullNameBtn').addEventListener('click', e => {
    if (firstname.value.trim() == '' ||
        lastname.value.trim() == ''
    ) {
        document.getElementById('fullNamError').textContent = 'Please all fields are required'
        document.getElementById('fullNamError').style.color = 'red'
        return
    }

    socket.emit('fullNameInfo', {
        userid,
        jwt,
        firstname: firstname.value,
        lastname: lastname.value

    })
})

socket.on('fullNameSuccess', data => {
    document.getElementById('fullNamError').textContent = data
    document.getElementById('fullNamError').style.color = 'green'
})


// gender section
let genderBtn = document.querySelectorAll('.genderradio')
genderBtn.forEach(cur => {
    cur.addEventListener('click', e => {
        let gender = e.target.value
        document.getElementById('genderbtn').addEventListener('click', e => {
            socket.emit('genderInfo', {
                userid,
                jwt,
                gender
            })
        })
    })
})

socket.on('successInGender', data => {
    document.getElementById('genderError').textContent = data
    document.getElementById('genderError').style.color = 'green'
})



// update bio
let bioText = document.getElementById('bioText')



document.getElementById('bioBtn').addEventListener('click', e => {
    socket.emit('bioInfo', {
        userid,
        jwt,
        bio: bioText.value,
    })
})

socket.on('bioSuccess', (data) => {
    document.getElementById('bioError').textContent = data
    document.getElementById('bioError').style.color = 'green'
})