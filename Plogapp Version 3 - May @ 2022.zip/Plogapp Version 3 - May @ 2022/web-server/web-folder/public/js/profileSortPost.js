// Sort post randomly /Shuffle

let appendPost = document.getElementById('append-container')
let toSort = document.querySelectorAll('.post-container');
let arr = []

// Loop to send toSrot(HTMl elem) to Arr Array
for(i = 0; i < toSort.length; i++){
    arr.push(toSort[i]) 
}

// Shuffle aray randomly
let x = arr.sort(() => {
    return Math.random() - 0.5
})

// Append Post to brower
for(i = 0; i < x.length; i++){
    appendPost.appendChild(x[i])
}



// Paginate
let post = document.querySelectorAll('.post-container');

let increase = 4

let postArray = []
for (i = 0; i < post.length; i++) {    
    post[i].style.display ='none'
    postArray.push(post[i])
}



function loadmore(val) {
    let newPost = postArray.splice(0, val)    
    for (i = 0; i < newPost.length; i++) {        
        newPost[i].style.display = 'block'
        appendPost.insertAdjacentHTML('beforeend', newPost[i])
    }
}

loadmore(4)

window.onscroll = function(){
    if((window.innerHeight + window.pageYOffset) >= document.body.offsetHeight){
        loadmore(increase++)
    }
}


