(function () {
    const socket = io()
    // Change color globally
    let colorGlobe = document.querySelectorAll('#changeHeartColor');
    for (i = 0; i < colorGlobe.length; i++) {
        colorGlobe[i].style.color = 'gray'
    }

    let mainId = document.getElementById('primaryId').textContent
    
    let div = document.querySelectorAll('#reactionElement');
    for (i = 0; i < div.length; i++) {
        let icon = div[i].children[0].children[0].children[0];
        let ids = div[i].children[1].children[0].textContent;
        
        
        if(ids.split(',').indexOf(mainId) > -1){
            icon.style.color = '#ff00bc'
            icon.classList = 'fa fa-heart'
        }
    }

    let div2 = document.querySelectorAll('.heartReaction');
    let likeBtn = document.querySelectorAll('#changeHeartColor')
    for (i = 0; i < likeBtn.length; i++) {
        likeBtn[i].addEventListener('click', (e) => {
            let heart = e.target.parentElement.children[0]
            let userId = e.target.parentElement.children[1].textContent
            let postId = e.target.parentElement.children[2].textContent
            let num = e.target.parentElement.parentElement.parentElement.parentElement.children[1].children[0].children[0].children[0]
            let newStrNUm = parseInt(num.textContent) || 0;
            
            // let loader = e.target.parentElement.children[3]
            // let button = e.target

            // button.style.display = 'none'
            // loader.style.display = 'block'
            // setTimeout(() => {
            //     loader.style.display = 'none'
            //     button.style.display = 'block'
            //     return
            // },500);


            
            let data = {
                userId,
                postId
            }
            
            socket.emit('reactionDetails', data)                

            // Change heart color 
            if (heart.style.color == 'gray') {
                heart.style.color = '#ff00bc'
                num.style.color = 'black'
                num.textContent = newStrNUm += 1
                num.style.color = 'gray'
                heart.classList = 'fa fa-heart'
                parseInt(num.textContent) < 2 ? num.parentElement.children[1].textContent = 'Like' : num.parentElement.children[1].textContent = 'Likes'

            } else {
                heart.style.color = 'gray'
                num.style.color = 'black'
                num.textContent = newStrNUm -= 1
                num.style.color = 'gray'
                heart.classList = 'fa fa-heart-o'
                parseInt(num.textContent) < 2 ? num.parentElement.children[1].textContent = 'Like' : num.parentElement.children[1].textContent = 'Likes'
            }

        })

    }

    // If like is 1 show (like) instead of likes
    let likeLength = document.querySelectorAll('#likeLength')
    for (i = 0; i < likeLength.length; i++) {
        let value = likeLength[i].children[0].textContent
        value = parseInt(value)

        let text = likeLength[i].children[1]
        if (value < 2) {
            likeLength[i].children[1].textContent = 'Like'
        }

    }
})()