
// let receiverId = location.href.substr(-24, location.href.length)

// let vc_sec = document.getElementById('vc_sec')
// let vc_min = document.getElementById('vc_min')
// let = downloadObj = {}
// function firstGlobalFunction() {
//     let sec = 0;
//     let min = 0
//     let intervalId = setInterval(() => {
//         sec += 1

//         if (sec >= 59) {
//             sec = 0;
//             min += 1
//         }
//         vc_sec.textContent = sec
//         vc_min.textContent = min
//         downloadObj.audioTime = min + ":" + sec
//         if (min >= 2) {
//             clearIntervalFunction()
//             stopRecording()
//         }
//     }, 1000);


//     function clearIntervalFunction() {
//         clearInterval(intervalId)
//         let vcLoader = document.querySelectorAll('.animateLoader')
//         for (i = 0; i < vcLoader.length; i++) {
//             vcLoader[i].classList.toggle('pauseAnimation')
//         }

//     }

//     document.getElementById('stopRecord').addEventListener('click', e => {
//         clearIntervalFunction()
//     })


//     // document.getElementById('stopRecording').addEventListener('click', e => {
//     //     document.querySelector('.vc_record_container').style.display = 'none'
//     //     stopRecording()
//     //     clearIntervalFunction()
//     //     vc_sec.textContent = 0
//     //     vc_min.textContent = 0
    
    
//     //     getUserMedia({ audio: true }).then(stream => {
//     //         stream.getTracks().forEach(function (track) {
//     //             track.stop();
//     //         });
//     //     })
//     // })

//     // Cancel recording and delete
//     // document.getElementById('stopRecording').addEventListener('click', e => {
//         // console.log('Hello clicked')
//         // document.querySelector('.vc_record_container').style.display = 'none'
//         // clearIntervalFunction()
//         // stopRecording()
//         // vc_sec.textContent = 0
//         // vc_min.textContent = 0
//     // })
// }


// // document.getElementById('stopRecording').addEventListener('click', e => {
// //     console.log('Hello clicked')

//     // document.querySelector('.vc_record_container').style.display = 'none'
//     // // Stop recording function
//     // stopRecording()

//     // vc_sec.textContent = 0
//     // vc_min.textContent = 0
// // })



// async function getUserMedia(constraints) {
//     if (navigator.mediaDevices) {
//         return navigator.mediaDevices.getUserMedia(constraints)
//     }

//     let legacyApi = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia;

//     if (legacyApi) {
//         return new Promise(function (resolve, reject) {
//             legacyApi.bind(navigator)(constraints, resolve, reject)
//         })
//     } else {
//         alert('user api not supported')
//     }
// }



// getUserMedia({ audio: true }).then(stream => {
//     handlerFunction(stream)
// })

// function handlerFunction(stream) {
//     rec = new MediaRecorder(stream);
//     rec.ondataavailable = e => {
//         audioChunks.push(e.data);
//         if (rec.state == "inactive") {
//             let blob = new Blob(audioChunks, { type: 'audio/mp3' });
//             downloadObj.file = blob
//             console.log('blob')
//         }
//     }
// }

// console.log('File is on')
// // Start recording
// document.getElementById('startRecording').addEventListener('click', () => {
//     console.log('hello wolrd')
//     document.querySelector('.vc_record_container').style.display = 'block'
//     firstGlobalFunction()
//     audioChunks = [];
//     rec.start();

//     socket.emit('sendTyping', {
//         activity: 'recording audio...',
//         receiverId: receiverId,
//         owner: myId,
//     })
//     let vcLoader = document.querySelectorAll('.animateLoader')
//     for (i = 0; i < vcLoader.length; i++) {
//         vcLoader[i].classList.remove('pauseAnimation')
//     }
// })

// // Stop recording video function

// function stopRecording(params) {
//     rec.stop();
//     socket.emit('sendTyping', {
//         activity: '',
//         receiverId: receiverId,
//         owner: myId,
//     })
// }





// // Stop recording and save 
// document.getElementById('stopRecord').addEventListener('click', () => {

//     document.querySelector('.vc_record_container').style.display = 'none'
//     // Stop recording function
//     stopRecording()

//     vc_sec.textContent = 0
//     vc_min.textContent = 0

//     setTimeout(() => {
//         let data = new FormData()
//         data.append('uploads', downloadObj.file)
//         data.append('voiceNoteTime', downloadObj.audioTime)

//         fetch('/voiceNoteUpload/' + receiverId, {
//             method: 'POST',
//             body: data
//         })
//             .then(res => res.json())
//             .then(data => {
//                 let html = `
//                     <div class="friend_chat_box pushAudioRight" id="chat_container_box">
//                     <div class="ch_record_chat_list">
//                         <div class="vc_chat_hd">
//                             <p>${data.date}</p>

//                             <div class="cv_option_relative">
//                                 <i class="fa fa-ellipsis-v"
//                                     onclick="this.parentElement.children[1].style.display = 'block'"></i>

//                                 <div class="main_vc_chat_option" style="display: none;">
//                                     <div class="vc_option_absolute_list">
//                                         <p>Delete</p>
//                                         <div class="close_vc_option">
//                                             <i onclick="this.parentElement.parentElement.parentElement.style.display = 'none'"
//                                                 class="fa fa-close"></i>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>

//                         </div>
//                         <div class="cv_sender_recievers_img">
//                             <div class="cv_snd_img">
//                                 <img src="/webStorage/avatar/${data.chatSenderImage}" alt="">
//                             </div>
//                             <div class="cv_snd_img">
//                                 <img src="/webStorage/avatar/${data.chatReceiverImage}" alt="">
//                             </div>


//                             <div class="audio_vc_loader">
//                                 <div class="box">
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                     <div class="animateLoader"></div>
//                                 </div>
//                             </div>
//                         </div>

//                         <div class="vc_sec_section">
//                             <p> ${data.voiceNoteTime} </p>
//                             <div class="vc_seeker">
//                                 <input class="vcAudioSlider" type="range" max="0" name="" id="">
//                             </div>


//                             <div class="vc_play_btn">
//                                 <i id="playVoiceNoteInit" class="fa fa-play"></i>
//                                 <audio src="/webStorage/voiceNote/${data.voiceNote}" id="vn_audio"></audio>
//                             </div>
//                         </div>
//                     </div>
//                     </div>

//                     `

//                 appendChatMessages.insertAdjacentHTML('beforeend', html)
//                 playVoiceNoteFunction()
//                 scrollUpUsers()

//             }).catch(err => {
//                 console.log(err)
//             })

//     }, 1000);
// })