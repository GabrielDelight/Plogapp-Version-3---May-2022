function sayhello() {
    const socket = io()
    // Getting replies from database
    // Initiallized at [post router]
    let viewMore = document.querySelectorAll('#getReplies')
    let counter = 3;
    for (i = 0; i < viewMore.length; i++) {
        viewMore[i].addEventListener('click', (e) => {
            let _id = e.target.parentElement.children[1].textContent
            console.log(_id)
            let event = e.target
            event.parentElement.parentElement.children[0].children[2].style.display = 'none'
            let appender = event.parentElement.parentElement.children[0].children[1]

            fetch('/fetch_replies_for_comment/' + _id)
                .then(res => res.json())
                .then(data => {

                    appender.innerHTML = ''
                    // loadMoreReplies(4)
                    function loadMoreReplies(val) {
                        // console.log(val)
                        data = data.splice(0, val)

                        event.textContent = 'View replies (' + event.getAttribute('replyLengthAttr') + "/" + data.length +")"


                        data.map(cur => {

                            function urlify2(text) {
                                var urlRegex = /(((https?:\/\/)|(www\.)|(#)|(@))[^\s]+)/g;
                                //var urlRegex = /(https?:\/\/[^\s]+)/g;
                                return text.replace(urlRegex, function (url, b, c) {
                                    var url2 = (c == 'www.') ? 'http://' + url : url;
                                    if (url2[0] == '#') {
                                        url2 = url2.substr(1, url2.length)
                                        url2 = '/hashtag/' + url2
                                    }
                                    return '<a href="' + url2 + '" target="">' + url + '</a>';
                                })
                            }
        
                            var text = cur.comment;
                            cur.comment = urlify2(text);


                            appender.innerHTML +=
                                `<div class="last_reply_img">
                                                <a href="/profile/${cur.owner}">
                                                    <img src="https://plogapp.s3.amazonaws.com/${cur.avatar}">                                
                                                </a>
                                            <div class="last_reply_name_">
                                                <a href="/profile/${cur.owner}">
                                                    <p>${cur.fullName} <span><i class="${cur.verified}"></i></span></p>
                                                </a>
                                                    <p class="commentText hashTag">${cur.comment} <span>${cur.date}</span></p>
                                                <div class="replies_like_box">
                                                    <i id="replyheart" onclick="sayHii(this)" style="font-size: 11px !important;" class="fa fa-heart-o" > <span>${cur.reactionLength}</span> </i>
                                                    <p style="display: none">${cur._id}</p>
                                                    <p style="display: none">${cur.reaction}</p>
                                                </div>
                                            </div>
                                    </div> `

                            // Add likeing script 
                            let userId = document.getElementById('userId').textContent
                            let primaryId = document.getElementById('primaryId').textContent

                            let replyheart = document.querySelectorAll('#replyheart')
                            for (i = 0; i < replyheart.length; i++) {
                                replyheart[i].style.color = 'gray'

                                // Check is my id is in reaction array
                                if (replyheart[i].parentElement.children[2].textContent.includes(primaryId)) {
                                    replyheart[i].classList = 'fa fa-heart'
                                    replyheart[i].style.color = '#ff00bc'
                                }

                                // addding and removving likes
                                replyheart[i].addEventListener('click', (e) => {
                                    console.log('Reacted')
                                    let heart = e.target
                                    let commentId = e.target.parentElement.children[1].textContent
                                    let reactionIds = e.target.parentElement.children[2]
                                    let numOfLikes = e.target.children[0]
                                    let nreNumberOfLikes = parseInt(numOfLikes.textContent) || 0

                                    let reactionForReplyDetails = {
                                        userId,
                                        commentId
                                    }

                                    // Send data  to database
                                    socket.emit('reactionForReplyDetails', reactionForReplyDetails)

                                    if (heart.style.color == 'gray') {
                                        heart.classList = 'fa fa-heart'
                                        heart.style.color = '#ff00bc'
                                        numOfLikes.textContent = nreNumberOfLikes += 1
                                    } else {
                                        heart.classList = 'fa fa-heart-o'
                                        heart.style.color = 'gray'
                                        numOfLikes.textContent = nreNumberOfLikes -= 1
                                    }
                                })
                            }
                        })
                    }

                    loadMoreReplies(counter++)



                }).catch(error => {
                    console.log(error)
                })
        })
    }

}


// function sayHii(e){
//     console.log(e)
//     console.log('hello wolrd')
// }