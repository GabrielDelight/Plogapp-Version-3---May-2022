const socket = io();

let userId = document.getElementById('userId').textContent
let suggFollowBtn = document.querySelectorAll('#suggBtn')
for(i = 0; i < suggFollowBtn.length; i++){
    suggFollowBtn[i].addEventListener('click', (e) => {        
        let followingId = e.target.parentElement.children[1].textContent
        
        let followingDetails = {
            followingId,
            userId
        }
        socket.emit('followingDetails', followingDetails)
        
        // console.log(e.target.style.color)
        if(e.target.textContent == 'Follow'){
            e.target.style.backgroundColor = '#cccbd2'
            e.target.style.color = 'black'
            e.target.textContent = 'Unfollow'
            
        }else{
            e.target.style.backgroundColor = '#4196ff'
            e.target.style.color = 'white'
            e.target.textContent = 'Follow'
            
        }
  

    })
}

//Delete my cuurent div
let followingId = document.querySelectorAll('#followingId')
for(i = 0; i < followingId.length; i++){
    if(followingId[i].parentElement.children[1].textContent.includes(userId)){
        followingId[i].parentElement.parentElement.parentElement.style.display = 'none'
    }
}

// Delete user that am already following
for(i = 0; i < followingId.length; i++){
    if(followingId[i].parentElement.children[2].textContent.includes(userId)){
        followingId[i].parentElement.parentElement.parentElement.style.display = 'none'
    }
}

// Randomply shuffle 

let xappender = document.getElementById('xappender')
let div = document.querySelectorAll('.suggested_container');
let suggArray = []
for(i = 0; i < div.length; i++){
    suggArray.push(div[i])
}

let shuffle = suggArray.sort(() => Math.random() - 0.5)

if(shuffle.length > 0){
    let newShuffled =  shuffle.splice(0, 4)
    for( i = 0; i < newShuffled.length; i++){        
        xappender.appendChild(newShuffled[i])        
    }    
    
}




