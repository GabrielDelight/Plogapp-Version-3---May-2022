// (function () {
const socket = io()
var url = new URLSearchParams(location.search);
let chatGlobalObject = {}
let userId = document.getElementById('userId').textContent
let messageUption = document.querySelectorAll('#messageUption')
let appendMessages = document.getElementById('appendMessage')
let appendSentChatNotificationMessages = document.getElementById('appendSentChatNotificationMessages')


// Function for scrolling bottom
function scrollUpUsers() {
    let x = document.querySelector('.main_chat_body_content')
    x.scrollTop = x.scrollHeight
}


function tgleChatOption() {
    document.querySelector('.message_option_list_container').classList.toggle('toggle_mesg_opt')
}

//  opening message option modal
for (i = 0; i < messageUption.length; i++) {
    messageUption[i].addEventListener('click', e => {
        tgleChatOption()
        document.getElementById('storeChatId').value = e.target.parentElement.children[1].textContent
        document.getElementById('storeChatOwnerId').value = e.target.parentElement.children[2].textContent
    })
}

// closing the modal 
document.querySelector('.message_option_list_container').addEventListener('click', e => {
    if (e.target.className === 'message_option_list_container toggle_mesg_opt') {
        tgleChatOption()
    }
})


// deleting a mesage 
function toggleDeleteMessage() {
    document.querySelector('.global_container_del').classList.toggle('toggle_delete_message_modal')
}

document.querySelector('#deleteMesage').addEventListener('click', e => {
    toggleDeleteMessage()
    tgleChatOption()
})

// closing delete modal
document.querySelector('.global_container_del').addEventListener('click', e => {
    if (e.target.className == 'global_container_del toggle_delete_message_modal') {
        toggleDeleteMessage()
        tgleChatOption()
    }
})

document.querySelector('#cancelDelBtn').addEventListener('click', e => {
    toggleDeleteMessage()
    tgleChatOption()
})


// videocall from message
// document.querySelector('#startVideoCall').addEventListener('click', e => {
//     let a = document.createElement('a')
//     let id = document.getElementById('storeChatOwnerId').value
//     a.setAttribute('href', '/start-calling/' + id)
//     a.click()
// })

document.querySelector('#viewChatProfile').addEventListener('click', e => {
    let a = document.createElement('a')
    let id = document.getElementById('storeChatOwnerId').value
    a.setAttribute('href', '/profile/' + id)
    a.click()
})

document.querySelector('#deleteMessage').addEventListener('click', e => {
    let a = document.createElement('a')
    let id = document.getElementById('storeChatId').value
    let owner = document.getElementById('storeChatOwnerId').value
    console.log(owner)
    a.setAttribute('href', '/deletemessage/' + id + "/" + owner)
    a.click()
})


// toggle chatr animation 
function toggleMySentModal() {
    document.querySelector('.my_sent_messages_container').classList.toggle('toggle_mySent_message')
}


document.getElementById('mySentMessages').addEventListener('click', e => {
    toggleMySentModal()
})


document.getElementById('closeMySent').addEventListener('click', e => {
    toggleMySentModal()
})

document.querySelector('.my_sent_messages_container').addEventListener('click', e => {
    if (e.target.className == 'my_sent_messages_container toggle_mySent_message') {
        toggleMySentModal()
    }
})

// toggle home messaqge container
function toggleMessageModal() {
    document.querySelector('.new_chat_modal').classList.toggle('toggle_newMsg_maodal')
}

let toggleChatMessages = document.querySelectorAll('#toggleChatMessages')
for (i = 0; i < toggleChatMessages.length; i++) {
    toggleChatMessages[i].addEventListener('click', e => {
        toggleMessageModal()
        document.querySelector('#hideNotificationMessahe').style.display = 'none'
        document.querySelector('#hideNotificationMessageMobile').style.display = 'none'
        socket.emit('removeChatNotification', {
            userId
        })
    })
}

document.querySelector('.new_chat_modal').addEventListener('click', e => {
    if (e.target.className == 'new_chat_modal toggle_newMsg_maodal') {
        toggleMessageModal()
    }
})

document.querySelector('#closChatNew').addEventListener('click', e => {
    toggleMessageModal()
})




// Message api script

fetchMessagesApi()
// }, 2000);
function fetchMessagesApi() {
    // fetch('/messages-api')
    // .then(result => result.json())
    function animateFunction() {
        axios.get('/messages-api')
            .then(data => {
                // console.log(data)
                chatNotificationMessageFunction(data.data)
            }).catch(error => {
                console.log(error)
            })
    }


    animateFunction();
    setInterval(animateFunction, 2000);


    function chatNotificationMessageFunction(data) {
        appendMessages.innerHTML = ''
        
        if (data.length === 0) {
            appendMessages.innerHTML = '<p style="text-align: center; margin-top: 10%" >No messages found <i class="fa fa-envelope"></i> </p>'

        }

        data.map(cur => {
            if (cur.lastChat.length >= 50) {
                cur.lastChat = cur.lastChat.substr(0, 30) + "..."
            }
            let html = `
                <div id="updateChatDiv" style="position: relative;">
                <p style="display: none;">${cur.owner}</p>
                <!--<a class="messageAnchor" href="/chat/${cur.owner}">-->
                    <p style="display: none;" id="messaheId">${cur.owner}</p>
                    <p style="display: none;" id="searchQuery">${cur.receiverName}</p>

                    <div class="chat_message_content">
                        <div class="image_avatar_holder">
                            <img src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                        </div>
                        <div class="chat_messages_details__">
                            <h5 style="text-transform: capitalize;">${cur.ownerName}</h5>
                            <div class="flex_chat_mess_list"> 
                                <div class="read_icon_messages_list" style="display:${cur.showCheckIcon}">
                                    <i style="color: ${cur.chatReadColor}" class="fa fa-check"></i>
                                </div>
                                <div style="display: flex; align-items: center">
                                    <i class="${cur.message_icon}" style="margin-right: 5px; font-size: 11px"> </i> <p> ${cur.lastChat}</p>
                                </div>
                            </div>
                        </div>

                        <div class="_message_list_date">
                            <p>${cur.date}</p>
                            <div style="display:${cur.displayMessageCounter}">
                                <div class="chatMessagesCounter">
                                    <p>${cur.unreadLength}</p>
                                </div>
                            </div>
                        </div>

            
                        <div id="messageCLickingDiv" class="clicking_div">
                            <p style="display: none;">${cur._id}</p>
                            <p style="display: none;">${cur.owner}</p>
                        </div>
                    </div>
                <!--</a>-->
                <div class="message_option">
                    <i id="messageUption" class="fa fa-ellipsis-h"></i>
                    <p style="display: none;">${cur._id}</p>
                    <p style="display: none;">${cur.owner}</p>
                </div>
            </div>`

            appendMessages.innerHTML += html
            messageController()
            darkModeFunction()
        })
    }

}



// Reply, delete, copy section
function chatActivity() {
    let allChat = document.querySelectorAll('.chatMessage')
    let arrIdForChat = []
    let arrOTargetDiv = []
    for (i = 0; i < allChat.length; i++) {
        let chatHoldBtn = allChat[i]
        let count = 0
        let interval
        let onHold = false

        chatHoldBtn.addEventListener('click', (e) => {
            arrIdForChat.unshift(e.target.parentElement.children[1].textContent)
            arrOTargetDiv.unshift(e.target)
            count += 1
            console.log(count)
            if (true) {
                count = 0
                document.querySelector('.chat_option_container').style.display = 'block'
                // toggleChatOption()
                // document.querySelector('.chat_option_container').style.display ='block'
                let val = e.target.parentElement.children[0].textContent

                // Replying 
                document.getElementById('replyDiv').addEventListener('click', (e) => {
                    replyInput.value = val
                    document.querySelector('.reply_chat_sample').style.display = 'block'
                    document.querySelector('#replyingMessage').textContent = `${val.substr(0, val.length > 50 ? 50 : val.length)}  ${+ val.length > 50 ? '...' : ''} `
                    
                    // toggleChatOption()
                    document.querySelector('.chat_option_container').style.display = 'none'

                    document.getElementById('myInput').focus()

                    // close the replying div
                    document.querySelector('.close_repling').addEventListener('click', (e) => {
                        document.querySelector('.reply_chat_sample').style.display = 'none'
                        document.querySelector('#replyingMessage').textContent = ''
                        replyInput.value = ''
                    })
                })



                // Copying
                document.getElementById('copyChat').addEventListener('click', (e) => {
                    replyInput.value = val
                    replyInput.select()
                    document.execCommand('copy')
                    setTimeout(() => {
                        document.querySelector('.chat_option_container').style.display = 'none'

                    }, 100)

                })



                // Delete 
                // let delIput = document.getElementById('delInput')
                // let elId = e.target.parentElement.children[1].textContent
                let targetDeletedText = e.target
                document.getElementById('deleteMsh').addEventListener('click', (e) => {
                    // delIput.value = elId
                    document.querySelector('.chat_option_container').style.display = 'none'
                    fetch('/deleteMessage', {
                        method: 'POST',
                        headers: {
                            'Accept': 'application/json, text/plain, */*',
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            data: arrIdForChat[0],
                        })
                    })
                        .then(res => {
                            arrOTargetDiv[0].textContent = 'Message Deleted'
                        }).catch(err => {
                            console.log(err)
                        })
                })


                onHold = true
                clearInterval(interval)
                return
            } else {
                onHold = false
            }
        })



    }
    // close chat message option
    document.addEventListener('click', (e) => {
        if (e.target.classList == 'chat_option_container') {
            // toggleChatOption()
            document.querySelector('.chat_option_container').style.display = 'none'
            // document.querySelector('.chat_option_container').style.display = 'none'
        }
    })




}



// Chat video controller
function videoOptions() {
    // Video option scripts
    // @ Delete video
    let deleVideobtn = document.querySelectorAll('#deleVideo')
    for (i = 0; i < deleVideobtn.length; i++) {
        deleVideobtn[i].addEventListener('click', e => {
            let id = e.target.parentElement.children[1].textContent
            let src = e.target.parentElement.children[2].textContent
            document.querySelector('.chat_video_option_container').style.display = 'block'

            // Delete the video container
            document.getElementById('deleteVideoBtn').addEventListener('click', e => {
                document.getElementById('autoDeleteVideo').href = "/deletevideo/" + id + "/" + receiverIdx1
                console.log(document.getElementById('autoDeleteVideo'))
                document.getElementById('autoDeleteVideo').click()
            })


            // @ downloading the video
            document.getElementById('downloadVideo').addEventListener('click', e => {
                let user2id = location.href.substr(-24, (location.href.length))
                let a = document.createElement('a')
                a.href = src
                a.setAttribute('download', '')
                let video = document.createElement('video')
                video.src = src
                a.appendChild(video)
                a.click()
                setTimeout(() => {
                    window.history.pushState("", "", '/chat/' + user2id);
                }, 1000);

            })
        })
    }
}


function messageController() {
    let messageUptionJs = document.querySelectorAll('#messageUption')
    //  opening message option modal
    for (i = 0; i < messageUptionJs.length; i++) {
        messageUptionJs[i].addEventListener('click', e => {
            toggleContainer()
            document.getElementById('storeChatId').value = e.target.parentElement.children[1].textContent
            document.getElementById('storeChatOwnerId').value = e.target.parentElement.children[2].textContent
        })
    }

    function toggleContainer() {
        tgleChatOption()
    }

    // Press hosling to show option
    let clicking_div = document.querySelectorAll('#messageCLickingDiv')
    for (i = 0; i < clicking_div.length; i++) {
        let count = 0
        let interval
        let btn = clicking_div[i]
        let onHold = false
        clicking_div[i].addEventListener("mousedown", e => {
            interval = setInterval(() => {
                count += 1
                if (count > 5) {
                    // toggleContainer()
                    document.getElementById('storeChatId').value = e.target.children[0].textContent
                    document.getElementById('storeChatOwnerId').value = e.target.children[1].textContent
                    onHold = true
                    clearInterval(interval)
                    return
                } else {
                    onHold = false
                }

            }, 100);

            btn.addEventListener("click", e => {
                count = 0
                clearInterval(interval)
                if (!onHold) {
                    // Do something
                    window.history.pushState("", "", '/chat/' + e.target.children[1].textContent);
                    let receiverId = location.href.substr(-24, location.href.length)

                    // find reciver details 
                    fetch('/user_api/' + receiverId)
                        .then(res => res.json())
                        .then(data => {
                            document.getElementById('recieverName').textContent = data.user.firstname + " " + data.user.lastname
                            document.getElementById('profileImageAvatar').src = "https://plogapp.s3.amazonaws.com/" + data.user.avatar

                            let userProfile = document.querySelectorAll('#receiverProfile')
                            userProfile.forEach(cur => cur.href = '/profile/' + data.user._id)


                            // console.log(data.user.firstname)
                            chatGlobalObject.recipientId = data.user._id
                            chatGlobalObject.receiverName = data.user.firstname + " " + data.user.lastname
                            chatGlobalFunction(chatGlobalObject)

                            globalVideoFunction(chatGlobalObject)

                            // Add useful links in video chat btns
                            // let startVideoCall
                            // let videoCALLLIN
                            // `/video-calling?callerId=${data}&receiverId=${data._id}&status=host`
                            let startVideoCallbtn = document.querySelectorAll('#startVideoCall')
                            Array.from(startVideoCallbtn).forEach(elem => {

                                elem.href = `/video-calling?callerId=${userId}&receiverId=${data.user._id}&status=host`
                            })




                        }).catch(error => {
                            console.log(error)
                        })

                    // fetch('/chat_messages_api/' + receiverId)
                    axios.get('/chat_messages_api/' + receiverId)
                        // .then(res => res.json())
                        .then(data => {
                            let firstChatLoad = data.data.splice(-20, data.data.length)
                            let appendChatElement = document.getElementById('appendChatMessages')

                            loadChatMessages(appendChatElement, firstChatLoad)
                            document.querySelector('article').style.display = 'block'

                            setTimeout(() => {
                                let lastfetchedChat = data.data.splice(20, data.data.length)
                                let lastAppendMessages = document.getElementById('appendChatMessagesInit')
                                loadChatMessages(lastAppendMessages, lastfetchedChat)
                            }, 1000);


                        })
                        .catch(error => {
                            console.log(error)
                        })
                }
            })
        })
    }

}

// Playing audio function
function playAudioFunction() {
    // playing audio
    let audioDiv = document.querySelectorAll('#musicIcon')
    for (i = 0; i < audioDiv.length; i++) {
        audioDiv[i].addEventListener('click', (e) => {

            // Show controls of audio
            let mainControlDiv = e.target.parentElement.children[1]
            mainControlDiv.style.display = 'block'
            let icon = e.target.parentElement.children[1].children[0].children[0]
            let src = e.target.parentElement.children[1].children[0].children[1].textContent
            let range = e.target.parentElement.children[1].children[0].children[3]
            let closeBtn = e.target.parentElement.children[1].children[0].children[4]
            // scrollUpUsers()
            // let audio = e.target.parentElement.children[1].children[0].children[1]
            let audio = document.createElement('audio')

            console.log(range)

            audio.src = src
            console.log(audio)
            audio.play()
            icon.classList = 'fa fa-pause'

            icon.addEventListener('click', (e) => {
                if (audio.paused) {
                    audio.play()
                    icon.classList = 'fa fa-pause'
                } else {
                    audio.pause()
                    icon.classList = 'fa fa-play'
                }

            })


            range.addEventListener('input', () => {
                console.log(audio.duration)
                audio.currentTime = range.value
            })


            setInterval(() => {
                range.max = audio.duration
                range.value = audio.currentTime
            }, 100);


            let audeoOption = document.querySelectorAll('#audeoOption')
            audeoOption.forEach(cur => {
                cur.addEventListener('click', e => {
                    e.target.parentElement.children[1].style.display = 'block'
                })
            })

            // @ Download audio
            let saveAudio = document.querySelectorAll('#saveAudio')
            saveAudio.forEach(cur => {
                cur.addEventListener('click', e => {
                    let audioSrc = e.target.parentElement.children[0].textContent
                    document.getElementById('saveAudioAnchor').href = 'https://plogapp.s3.amazonaws.com/' + audioSrc
                    document.getElementById('mainAudioDOwnloadTag').src = 'https://plogapp.s3.amazonaws.com/' + audioSrc
                    document.getElementById('saveAudioAnchor').click()
                })
            })


            // Deleteing audio

            let deleteAudio = document.querySelectorAll('#deleteAudio')
            deleteAudio.forEach(cur => {
                cur.addEventListener('click', e => {
                    let audioId = e.target.parentElement.children[1].textContent
                    // Deleteing the main parent audio container
                    function removeAudioChat() {
                        e.target.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.style.display = 'none'
                        audio.pause()
                    }
                    document.querySelector('.delete_chat_confirmation_container').style.display = 'block'

                    let audioDeleteLinkType = ''
                    document.getElementById('deleteAudioFOrMe').addEventListener('click', e => {
                        audioDeleteLinkType = 'single'
                        deleteFunction()
                    })

                    document.getElementById('deleteAudioForEveryOne').addEventListener('click', e => {
                        audioDeleteLinkType = 'multiple'
                        deleteFunction()
                    })
                    function deleteFunction() {
                        fetch('/deleteAudio', {
                            method: 'POST',
                            headers: {
                                'Accept': 'application/json, text/plain, */*',
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                data: audioId,
                                deleteType: audioDeleteLinkType,
                            })
                        })
                            .then(res => {
                                removeAudioChat()
                                document.querySelector('.delete_chat_confirmation_container').style.display = 'none'
                            }).catch(err => {
                                console.log(err)
                            })
                    }

                })
            })



            let closeAudeioIOption = document.querySelectorAll('#closeAudeioIOption')
            closeAudeioIOption.forEach(cur => {
                cur.addEventListener('click', e => {
                    e.target.parentElement.parentElement.parentElement.style.display = 'none'
                })
            })



        })
    }

}

// If the page load fetch user data
let urlId = location.href.substr(-24, location.href.length)

fetch('/user_api/' + urlId)
    .then(res => res.json())
    .then(data => {
        document.getElementById('recieverName').textContent = data.user.firstname + " " + data.user.lastname
        document.getElementById('profileImageAvatar').src = "https://plogapp.s3.amazonaws.com/" + data.user.avatar

        let userProfile = document.querySelectorAll('#receiverProfile')
        userProfile.forEach(cur => cur.href = '/profile/' + data.user._id)

        // console.log(data.user.firstname)
        chatGlobalObject.recipientId = data.user._id
        chatGlobalObject.receiverName = data.user.firstname + " " + data.user.lastname
        chatGlobalFunction(chatGlobalObject)
        // chatAuioGLobalFunction(chatGlobalObject)
        // globalImageFunction(chatGlobalObject)
        // chatVoiceNoteFunction(chatGlobalObject)
        globalVideoFunction(chatGlobalObject)

        let startVideoCallbtn = document.querySelectorAll('#startVideoCall')
        Array.from(startVideoCallbtn).forEach(elem => {

            elem.href = `/video-calling?callerId=${userId}&receiverId=${data.user._id}&status=host`
        })

    }).catch(error => {
        console.log(error)
    })

// WHen te page loads fetch messages

// fetch('/chat_messages_api/' + urlId)
axios.get('/chat_messages_api/' + urlId)
    // .then(res => res.json())
    .then(data => {
        let firstChatLoad = data.data.splice(-20, data.data.length)
        let appendChatElement = document.getElementById('appendChatMessages')

        loadChatMessages(appendChatElement, firstChatLoad)
        document.querySelector('article').style.display = 'block'

        setTimeout(() => {
            let lastfetchedChat = data.data.splice(20, data.data.length)
            let lastAppendMessages = document.getElementById('appendChatMessagesInit')
            loadChatMessages(lastAppendMessages, lastfetchedChat)
        }, 1000);
    })
    .catch(error => {
        console.log(error)
    })


// console.log(data)
function loadChatMessages(appendChatElement, data) {
    document.querySelector('.mobile_nav_container').style.display = 'none'
    appendChatElement.innerHTML = ''
    data.map(cur => {
        if (cur.replyOldMessage == null) cur.replyOldMessage = ''
        if (cur.message == null) cur.message = ''
        // mathing hashtags andf urls 
        function urlify2(text) {
            var urlRegex = /(((https?:\/\/)|(www\.)|(#)|(@))[^\s]+)/g;
            //var urlRegex = /(https?:\/\/[^\s]+)/g;
            return text.replace(urlRegex, function (url, b, c) {
                var url2 = (c == 'www.') ? 'http://' + url : url;
                if (url2[0] == '#') {
                    url2 = url2.substr(1, url2.length)
                    url2 = '/hashtag/' + url2
                }
                return '<a href="' + url2 + '" class="linkChat">' + url + '</a>';
            })
        }

        var text = cur.message;
        cur.message = urlify2(text);

        appendChatElement.innerHTML +=
            `<div class="friend_chat_box ${cur.pushChat}" id="chat_container_box">
                                    <div class="friends_image2"></div>
                                    <div class="friend_chat_details">
    
                                        <div style="display: ${cur.hideOldReply};" class="reply_old_text">
                                            <span>${cur.replyOldMessage}</span>
                                        </div>
    
                                        <div class="chat_text_box blueColor">
                                            <div class="message_text" style="display: ${cur.hideChatText}">
                                                <p id="stylerColor" class="hashTag chatMessage">${cur.message}</p>
                                                <p style="display: none;">${cur.randomId}</p>
                                            </div>
    
                                            <div class="chat_imag" style="display: ${cur.hide};">
                                                <img id="chatImage" src="https://plogapp.s3.amazonaws.com/${cur.image}" alt="">
                                                <p style="display: none;">${cur.randomId}</p>
                                                <p class="attchedText">${cur.message}</p>
                                                <p style="display: none;">${cur.image}</p>
                                            </div>
    
                                            <div class="video_sned_div" style="display: ${cur.hideVideo};">
                                                <div id="appendVideo" image-poster="https://plogapp.s3.amazonaws.com/${cur.image}" video-src="https://plogapp.s3.amazonaws.com/${cur.video}" ><span style="display: none;"></span></div>
                                                <div class="chat_video_control" style="display: none">
                                                    <i id="playVideo" class="fa fa-play"></i>
                                                    <i style="display: none;" class="fa fa-pause"></i>
                                                </div>
                                                <div class="chat_video_option">
                                                    <i id="deleVideo" class="fa fa-ellipsis-h"></i>
                                                    <p style="display: none;">${cur.randomId}</p>
                                                    <p style="display: none;">https://plogapp.s3.amazonaws.com/${cur.video}</p>
                                                </div>
                                            </div>
    
                                            

                                            <div class="ch_record_chat_list '${cur.randomId}'" style="display: ${cur.hideAudio};">
                                            <div class="vc_chat_hd">
                                                <p style="font-size: 12px;"> <i class="fa fa-clock-o" ></i> <small> ${cur.date}</small>-|-<small> ${cur.voiceNoteTime}</small> </p>
                                
                                                <div class="cv_option_relative">
                                                    <i class="fa fa-ellipsis-v" onclick="this.parentElement.children[1].style.display = 'block'"></i>
                                
                                                    <div class="main_vc_chat_option" style="display: none;">
                                                        <div class="vc_option_absolute_list">
                                                            <div>
                                                                <p id="deleteVoiceNoteBtn" onclick="deleteVoiceNoteFun('${cur.randomId}')">Delete</p>
                                                            </div>
                                                            <div class="close_vc_option">
                                                                <i onclick="this.parentElement.parentElement.parentElement.style.display = 'none'"
                                                                    class="fa fa-close"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                
                                            </div>
                                            
                                            <div class="cv_sender_recievers_img">
                                                <div class="audio_vc_loader">
                                                    <div class="box init">
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                       
                                                    </div>
                                                </div>
                                                <div class="vc_play_btn">
                                                    <i id="playVoiceNote" onclick="playVnBtn('https://plogapp.s3.amazonaws.com/${cur.audio}')" class="fa fa-circle"></i>
                                                </div>
                                            </div>
                                            
                                        </div>





    
                                            <div class="story_message" style="display: ${cur.hideStory}">
                                                <img src="https://plogapp.s3.amazonaws.com/${cur.storyImageUrl}" alt="">
                                                <p>${cur.message}</p>
                                            </div>



                                            <div class="ch_record_chat_list '${cur.randomId}'" style="display: ${cur.hideVoiceNote};">
                                            <div class="vc_chat_hd">
                                            <p style="font-size: 12px;"> <i class="fa fa-microphone" ></i> <small> ${cur.date}</small>-|-<small> ${cur.voiceNoteTime}</small> </p>
                                
                                                <div class="cv_option_relative">
                                                    <i class="fa fa-ellipsis-v" onclick="this.parentElement.children[1].style.display = 'block'"></i>
                                
                                                    <div class="main_vc_chat_option" style="display: none;">
                                                        <div class="vc_option_absolute_list">
                                                            <div>
                                                                <p id="deleteVoiceNoteBtn" onclick="deleteVoiceNoteFun('${cur.randomId}')">Delete</p>
                                                            </div>
                                                            <div class="close_vc_option">
                                                                <i onclick="this.parentElement.parentElement.parentElement.style.display = 'none'"
                                                                    class="fa fa-close"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                
                                            </div>
                                            
                                            <div class="cv_sender_recievers_img">
                                                <div class="audio_vc_loader">
                                                    <div class="box init">
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                        <div class="animateLoader"></div>
                                                       
                                                    </div>
                                                </div>
                                                <div class="vc_play_btn">
                                                    <i id="playVoiceNote" onclick="playVnBtn('https://plogapp.s3.amazonaws.com/${cur.voiceNote}')" class="fa fa-circle"></i>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="deleted_message_div">
                                            <p>Message Deleted</p>
                                        </div>
                                    </div>
                                </div> `
        scrollUpUsers()
        chatActivity()
        viewImageLarge()
        // playVoiceNote()
        videoOptions()
        playAudioFunction()
        changeIconbtn()

    })
}


