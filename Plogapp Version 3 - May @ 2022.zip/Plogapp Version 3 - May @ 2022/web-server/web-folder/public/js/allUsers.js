const socket = io()
let appender = document.getElementById('appender')
let myid = document.getElementById('mainId').textContent;
let primaryId = document.getElementById('primaryId').textContent;
let followingIds = document.getElementById('followingIds').textContent;
let appendFollowing = document.getElementById('appendFollowing')
var url = new URLSearchParams(location.search);
var paramsid = url.get("action");

let increateFollowing = 20



// Remove my div from following container

// SHow active to db
socket.emit('sendUserDetails', myid)
socket.emit('idForDisconnection', myid)


let apiUrl = '/allusers-api'
if (paramsid == 'my-friends') {
    apiUrl = '/friends_api'
    document.title  = 'Friends'
    document.getElementById('titleTxt').textContent = 'Friends List'
}
fetch(apiUrl)
    .then(result => result.json())

    // axios.get('/allusers-api')

    .then(res => {
        function showMoreFollowingFunction(val) {
            let data = res.splice(0, val)
            data.forEach(cur => {
                appendFollowing.innerHTML += `
                        <div class="wrapper_for_all">
                        <div class="wrap_user_div">
                            <div class="user_img">
                                <a href="/profile/${cur._id}"><img src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="${cur.firstname}"></a>
                            </div>
                            <div class="user_des_details">
                                <a href="/profile/${cur._id}">
                                    <p><span style="font-weight: bold">${cur.firstname} ${cur.lastname}</span> <span><i class="${cur.verified}"></i></span></p>
                                </a>
                                <p style="display: none;">Follow</p>
                                <p style="display: none;">${cur.id}</p>
                                <p style="display: none" id="userBio">${cur.bestSentence}</p>
                                <p style="display: none;">${cur._id}</p>
                                <div>
                                <p id="singularPara"><span id="nickName">@${cur.fullName}</span></p>
                                <p style="display: none;">${cur.followerLength}</p>
                                <p style="display: t" id="userBio">${cur.bestSentence}</p>
                                </div>
                            </div>
                        </div>
                        <div class="follow_div">
                            <button id="followbtn">Follow</button>
                            <p style="display: none;">${cur._id}</p>
                            <p style="display: none;">${myid}</p>
                            <div class="loader"></div>
                        </div>
                    </div>
                    `

                let allBtn = document.querySelectorAll('#followbtn');
                for (i = 0; i < allBtn.length; i++) {
                    allBtn[i].style.color = 'white'
                    allBtn[i].style.backgroundColor = 'cornflowerblue'
                }

                // Hide current user
                let div = document.querySelectorAll('.wrapper_for_all');
                for (i = 0; i < div.length; i++) {
                    let str = div[i].children[0].children[1].children[4].textContent;
                    if (str.includes(myid)) {
                        // div[i].style.display = 'none'
                        div[i].children[1].style.display = 'none'
                    }
                }

                // check if followers is one or more than one
                // let singularPara = document.querySelectorAll('#singularPara')
                // for (i = 0; i < singularPara.length; i++) {
                //     let checkNum = singularPara[i].parentElement.children[1].textContent
                //     checkNum = parseInt(checkNum)
                //     if (checkNum <= 1) {
                //         singularPara[i].textContent = checkNum + ' follower'
                //     }

                // }

                // Check for following and unfollowing
                for (i = 0; i < div.length; i++) {
                    let id = div[i].children[0].children[1].children[2].textContent
                    let text = div[i].children[0].children[1].children[1]
                    let button = div[i].children[1].children[0] //For changing the value
                    followingIds = followingIds.split(',').toString()
                    if (followingIds.includes(id)) {
                        text.textContent = 'Following'
                        button.textContent = 'Following';
                        button.style.backgroundColor = 'white'
                        button.style.border = '3px solid cornflowerblue'
                        button.style.color = 'cornflowerblue'

                    } else {
                        button.style.padding = '7px 18px'
                    }
                }


                // send following details to database
                let followBtn = document.querySelectorAll('#followbtn');
                for (i = 0; i < followBtn.length; i++) {
                    followBtn[i].addEventListener('click', (e) => {
                        let button = e.target.parentElement.children[0]
                        let followingId = e.target.parentElement.children[1].textContent
                        let userId = e.target.parentElement.children[2].textContent
                        let followingText = e.target.parentElement.parentElement.children[0].children[1].children[1]

                        let loader = e.target.parentElement.children[3]
                        // show loading button
                        button.style.display = 'none'
                        loader.style.display = 'block'
                        setTimeout(() => {
                            loader.style.display = 'none'
                            button.style.display = 'block'
                            return
                        }, 1000);


                        fetch('/follow-unfollow', {
                            method: 'POST',
                            headers: {
                                'Accept': 'application/json, text/plain, */*',
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                followingId,
                                userId
                            })
                        })
                            .then(res => {
                                return res.json()
                            })

                            .then(data => {
                                console.log(data)
                            })
                            .catch(error => {
                                console.log(error)
                            })



                        // socket.emit('followingDetails', followingDetails)

                        // Start changing items
                        if (button.textContent === 'Follow') {
                            button.style.color = 'cornflowerblue'
                            button.textContent = 'Following'
                            button.style.backgroundColor = 'white'
                            button.style.border = '3px solid cornflowerblue'
                            followingText.textContent = 'Following'
                            // button.style.padding = '7px'
                        } else {
                            button.style.color = 'white'
                            button.style.padding = '7px 18px'
                            button.style.backgroundColor = 'cornflowerblue'
                            button.textContent = 'Follow'
                            followingText.textContent = 'Follow'
                        }
                    })
                }

                // let trimBio = document.querySelectorAll('#userBio')
                // let nickName = document.querySelectorAll('#nickName')
                // trimMultiple(trimBio, 30)
                // trimMultiple(nickName, 6)
                // function trimMultiple(trim, num) {
                //     for (i = 0; i < trim.length; i++) {
                //         let str = trim[i].textContent
                //         if (str.length > num) {
                //             str = str.substr(0, num)
                //             trim[i].textContent = str + '...'
                //         }
                //     }

                // }

                // triming the over flowting   text
                if (window.matchMedia("(max-width: 600px)").matches) {
                    let trimBio = document.querySelectorAll('#userBio')
                    let nickName = document.querySelectorAll('#nickName')
                    trimMultiple(trimBio, 17)
                    trimMultiple(nickName, 6)
                    function trimMultiple(trim, num) {
                        for (i = 0; i < trim.length; i++) {
                            let str = trim[i].textContent
                            if (str.length > num) {
                                str = str.substr(0, num)
                                trim[i].textContent = str
                            }
                        }

                    }
                }

            })

            // End the loader
            if (data.length === 0 || data.length < 12) {
                document.querySelector('.loading_data').style.display = 'none'
            }

        }

        showMoreFollowingFunction(20)

        window.onscroll = function () {
            if ((window.innerHeight + window.pageYOffset) >= document.body.offsetHeight) {
                showMoreFollowingFunction(increateFollowing++)
            }
        }

    })

    .catch(err => {
        console.log()
    })
