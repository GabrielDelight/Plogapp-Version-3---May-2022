let url = new URLSearchParams(location.search);
let postId = url.get("postId");
// let curUserId = url.get("curUserId");
let curUserId = document.getElementById('userId').textContent
let appendComments = document.getElementById('appendComments')
let loader = document.querySelector('.comment_loader')



commentLoaderFunction()
function commentLoaderFunction(url) {
    fetch('/fetch-post-comments/' + postId)
        .then(res => res.json())
        .then(data => {
            if (data.length < 1) {
                loader.style.display = 'none'
                loader.textContent = 'No comment'
                return
            }

            loader.style.display = 'none' //

            appendComments.innerHTML = ''
            data.map(cur => {

                function urlify2(text) {
                    var urlRegex = /(((https?:\/\/)|(www\.)|(#)|(@))[^\s]+)/g;
                    //var urlRegex = /(https?:\/\/[^\s]+)/g;
                    return text.replace(urlRegex, function (url, b, c) {
                        var url2 = (c == 'www.') ? 'http://' + url : url;
                        if (url2[0] == '#') {
                            url2 = url2.substr(1, url2.length)
                            url2 = '/hashtag/' + url2
                        }
                        return '<a href="' + url2 + '" class=".hashlink" target="">' + url + '</a>';
                    })
                }

                var text = cur.comment;
                cur.comment = urlify2(text);


                appendComments.innerHTML += `
                <div class="comment_box" comment-attribute-id-div="${cur._id}">
                <div class="comment_option_">
                    <i id="commentOptionIcon" class="fa fa-ellipsis-h"></i>
            
                    <div class="comment_sub_wrap">
            
                        <div class="opt_box">
                            <p id="copyComment"><i class="fa fa-copy"></i> Copy</p>
                            <input type="text" value="${cur.comment}" style="display: none;visibility: hiddem">
                        </div>
            
                        <div class="opt_box" style="display: ${cur.owner == curUserId ? 'block' : 'none'}">
                            <p id="deleteMessage"  comment-id="${cur._id}"><i class="fa fa-trash"></i> Delete</p>
                            <p style="display: none;" id="hideDeleteButton">${cur.owner}</p>
                        </div>

                        <div class="opt_box" style="display: ${cur.owner == curUserId ? 'none' : 'block'}">
                            <p id="reportCommentBtn" type="comment" victim="${cur._id}" onclick="reportPostFunction(this)"  comment-id="${cur._id}"><i class="fa fa-flag"></i> Report</p>
                        </div>
            
            
                        <div class="opt_box" id="closeOption">
                            <p><i class="fa fa-close"></i> Close</p>
                        </div>
            
                    </div>
            
                </div>
            
                <div class="image">
                    <a href="/profile/${cur.owner}">
                        <img src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                    </a>
                </div>
            
            
                <div class="comment_des_name">
                    <div class="commentors_name">
                        <h4 style="text-transform: capitalize;"> <a href="/profile/${cur.owner}">${cur.fullName}</a>
                            <span><i class="${cur.verified}"></i></span>
                        </h4>
                        <span id="nickName"><a href="/profile/${cur.owner}">@${cur.commentorNickName}</a></span>
            
            
                        <div class="comment_text">
                            <p class="hashTag">${cur.comment}</p>
                        </div>
            
                        <div class="img_container_comment">
                            <img src="https://plogapp.s3.amazonaws.com/${cur.image}" alt="" style="display: ${cur.hideImage};">
                        </div>
                    </div>
            
                    <div class="comment_icons">
                        <div class="reactionGlobally">
                            <i id="changeHeartCOlor" class="fa fa-heart-o">
                                <span>
                                    <a>${cur.reactionLength}</a>
                                </span>
                            </i>
                            <p style="display: none;">${curUserId}</p >
                            <p style="display: none;">${cur._id}</p>
                            <p style="display: none;">${cur.reaction}</p>
                        </div >

            <div class="reply_text">
                <a href="/replyComment/${cur._id}">
                    <p style="display: none">${cur._id}</p>
                    <i class="fa fa-commenting-o"></i> <span> ${cur.replylength}</span>
                </a>
            </div>
            
            
            
                    </div >
                    <div class="view_date">
                        <p>${cur.date}</p>
                    </div>
            
                    <div>
            
                        <div class="last_two_reply_contrainer" style="display: ${cur.hideReply};">
                            <p style="display: none;">${cur._id}</p>
                            <div id="commentAppender"></div>
                            <a href="/replyComment/${cur._id}">
                                <div class="last_reply_img">
                                    <img src="https://plogapp.s3.amazonaws.com/${cur.lastReplyAvatar}">
                                    <div class="last_reply_name_">
                                        <p>${cur.lastReplyName} <span><i class="${cur.lastReplyVerified}"></i></span>
                                        </p>
                                        <p class="commentText hashTag">${cur.lastReplyText} <span>${cur.date}</span>
                                        </p>
                                        <div class="replies_like_box">
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div >

            <div class="view_replies" style="display: ${cur.replylength == 0 ? 'none' : 'block'}">
                <p id="getReplies" replyLengthAttr="${cur.replylength}" >View replies (${cur.replylength})</p>
                <p style="display: none">${cur._id}</p>
                <p style="display: none" class="hideReply">Hide</p>
                <p style="display: none" id="checkRepliesLength">${cur.replylength}</p>
            </div>
            
                    </div >
                </div >
            </div >
            `

                LikingCommentsFunction()
                sayhello()
                commentOptionFunction()

                // Script for deleting comments*********************
                let deleteMessage = document.querySelectorAll('#deleteMessage')
                Array.from(deleteMessage).map(cur => {
                    cur.addEventListener('click', e => {
                        let id = e.target.getAttribute('comment-id')
                        fetch('/delete-comment', {
                            method: 'POST',
                            headers: {
                                'Accept': 'application/json, text/plain, */*',
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                id
                            })
                        })

                            .then(res => res.json())
                            .then(data => {
                                // let delAttr =  document.getAttribute('comment-attribute-id-div')
                                let comment_box = document.querySelectorAll('.comment_box')
                                Array.from(comment_box).forEach(element => {
                                    let attr = element.getAttribute('comment-attribute-id-div')
                                    if (attr == id) {
                                        element.classList.add('animate_delete_out')
                                        setTimeout(() => {
                                            element.style.display = 'none'
                                        }, 400);
                                    }

                                });


                            })
                            .catch(error => {
                                console.log(error)
                            })
                    })
                })

                darkModeFunction()

            })
        })
        .catch(error => {
            console.log(error)
        })
}



function commentOptionFunction(params) {
    let commentOptionIcon = document.querySelectorAll('#commentOptionIcon')
    for (i = 0; i < commentOptionIcon.length; i++) {
        commentOptionIcon[i].addEventListener('click', (e) => {
            // Open comment option        

            let div = document.querySelectorAll('.comment_sub_wrap')
            for (j = 0; j < div.length; j++) {
                div[j].style.display = 'none'
            }

            e.target.parentElement.children[1].style.display = 'block'

        })
    }

    // Hide delete button 
    // let delBtn = document.querySelectorAll('#hideDeleteButton')
    // for (i = 0; i < delBtn.length; i++) {
    //     if (!delBtn[i].textContent.includes(myId)) {
    //         delBtn[i].parentElement.style.display = 'none'
    //     }
    // }


    let coyComment = document.querySelectorAll('#copyComment')
    for (i = 0; i < coyComment.length; i++) {
        coyComment[i].addEventListener('click', (e) => {
            // Open comment option
            let input = e.target.parentElement.children[1]
            input.style.display = 'block'
            input.select()
            document.execCommand('copy')
            input.style.display = 'none'
        })
    }

    let closeOption = document.querySelectorAll('#closeOption')
    for (i = 0; i < closeOption.length; i++) {
        closeOption[i].addEventListener('click', (e) => {
            e.target.parentElement.parentElement.style.display = 'none'
        })
    }

    let checkRepliesLength = document.querySelectorAll('#checkRepliesLength')
    for (i = 0; i < checkRepliesLength.length; i++) {
        let num = parseInt(checkRepliesLength[i].textContent)
        if (checkRepliesLength[i].textContent === '' || num < 1) {
            checkRepliesLength[i].parentElement.style.display = 'none'
        }
    }
}

// reporting post
function reportPostFunction(e) {
    let type = e.getAttribute('type')
    let victim = e.getAttribute('victim')
    location.href = `/report?type=${type}&&victim=${victim}`
}