
    // Selecting location phone number and interests
    let country_container = document.querySelector('.country_container')
    let mobile_container = document.querySelector('.mobile_container')
    let interests_container = document.querySelector('.interests_container')
    let bio_container = document.querySelector('.bio_container')


    let titlePlc = document.getElementById('titlePlc')
    let descriptionPlc = document.getElementById('descriptionPlc')

    let update_content_para = document.querySelectorAll('.update_content_para p')

    // 
    function updateProfileFunction(country, mobile, bio, interest, topic, description, indexPara) {
        document.querySelector('.profile_logo_sample_ease').style.display = 'none'
        country_container.style.display = country
        mobile_container.style.display = mobile
        bio_container.style.display = bio
        interests_container.style.display = interest

        titlePlc.textContent = topic
        descriptionPlc.textContent = description
        // ''
        update_content_para.forEach(cur => {
            cur.classList.remove('toggle_para_des')
            update_content_para[indexPara].classList.add('toggle_para_des')
        })

    }


    // *************************//

    update_content_para[0].addEventListener('click', e => {
        updateProfileFunction('block', 'none', 'none', 'none', 'Update Country', 'By using your current country we show you events happening near you', 0)
    })
    document.getElementById('locationId').addEventListener('click', e => {
        updateProfileFunction('block', 'none', 'none', 'none', 'Update Country', 'By using your current country we show you events happening near you', 0)
    })

    // *************************//

    update_content_para[1].addEventListener('click', e => {
        updateProfileFunction('none', 'block', 'none', 'none', 'Recovery Phone number', 'Add a recovery phone number as a backup to your plogapp account.', 1)
    })
    document.getElementById('phoneId').addEventListener('click', e => {
        updateProfileFunction('none', 'block', 'none', 'none', 'Recovery Phone number', 'Add a recovery phone number as a backup to your plogapp account.', 1)
    })


    // *************************//

    update_content_para[2].addEventListener('click', e => {
        updateProfileFunction('none', 'none', 'block', 'none', 'Add a Bio', 'Add a descriptive bio about yourself', 2)
    })
    document.getElementById('bioId').addEventListener('click', e => {
        updateProfileFunction('none', 'none', 'block', 'none', 'Add a Bio', 'Add a descriptive bio about yourself', 2)
    })

    // *************************//
    update_content_para[3].addEventListener('click', e => {
        updateProfileFunction('none', 'none', 'none', 'block', 'Favorites&Hobbies', 'You can add Interests to show/describe your daily activities on Plogapp', 3)
    })
    document.getElementById('interestId').addEventListener('click', e => {
        updateProfileFunction('none', 'none', 'none', 'block', 'Favorites&Hobbies', 'You can add Interests to show/describe your daily activities on Plogapp', 3)
    })

    // ************************//

    // setInterval(() => {
    let hobiesArr = []

    let hobbiesBtn = document.querySelectorAll('.hobbies_coontainer button')
    for (i = 0; i < hobbiesBtn.length; i++) {
        let colorArr = ['orange', 'red', 'pink', 'cornflowerblue', 'lemon', 'green', 'purple']
        let random = Math.floor(Math.random() * colorArr.length)
        hobbiesBtn[i].style.backgroundColor = colorArr[random]


        // selecting
        hobbiesBtn[i].addEventListener('click', e => {
            if (e.target.classList == 'selected_btn') {
                e.target.classList.remove('selected_btn')
                e.target.style.backgroundColor = '#bbb'
            } else {
                e.target.classList.add('selected_btn')
                e.target.style.backgroundColor = colorArr[random]

            }

            hobiesArr.push(e.target.textContent)
            // console.log(newArr)
        })
    }


    //fetch api profile_ease_edit
    setTimeout(() => {
        checkIfprofileFunction()
    }, 5000);
    function checkIfprofileFunction() {
        fetch('/profile_ease_edit')
            .then(res => res.json())
            .then(data => {
                if (data.noUpdate) {
                    document.querySelector('.global_ease').style.display = 'none'
                }

                if (data.updateProfile == 'all') {
                    document.querySelector('.global_ease').style.display = 'block'
                }

                if (data.updateProfile == 'interests') {
                    document.querySelector('.global_ease').style.display = 'block'
                    updateProfileFunction('none', 'none', 'none', 'block', 'Favorites&Hobbies', 'You can add Interests to show/describe your daily activities on Plogapp', 3)
                }

                if (data.updateProfile == 'country') {
                    document.querySelector('.global_ease').style.display = 'block'
                    updateProfileFunction('block', 'none', 'none', 'none', 'Update Country', 'Using your country, plogapp shows events happening around you', 0)
                }

                if (data.updateProfile == 'city') {
                    document.querySelector('.global_ease').style.display = 'block'
                }

                if (data.updateProfile == 'phone') {
                    document.querySelector('.global_ease').style.display = 'block'
                    updateProfileFunction('none', 'block', 'none', 'none', 'Recovery Phone number', 'Add a recovery phone number as a backup to your plogapp account.', 1)
                }

                if (data.updateProfile == 'bio') {
                    document.querySelector('.global_ease').style.display = 'block'
                    updateProfileFunction('none', 'none', 'block', 'none', 'Add a Bio', 'Add a descriptive bio about yourself', 2)
                }
            }).catch(error => {
                console.log(error)
            })
    }


    // Saving country api
    document.getElementById('saveCountryBtn').addEventListener('click', e => {
        let eventBtn = e.target

        let country = document.getElementById('countriesList')
        let city = document.getElementById('citiesId')
        let town = document.getElementById('town')
        
      

        fetch('/update_country', {
            method: 'POST',
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                country: country.value,
                city: city.value,
                town: town.value,
            })
        })
            .then(res => res.json())
            .then(data => {
                console.log(data)

                if (data.success) {
                    eventBtn.textContent = data.success
                    eventBtn.style.backgroundColor = 'Green'
                    checkIfprofileFunction()
                }
            })
            .catch(err => {
                console.log(err)
            })
    })

    // Adding phone number
    document.getElementById('savePhoneBtn').addEventListener('click', e => {
        let eventBtn = e.target

        let phone = document.getElementById('phone')
        if (phone.value == '') return

        fetch('/update_phone_number', {
            method: 'POST',
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                phone: phone.value
            })
        })
            .then(res => res.json())
            .then(data => {
                console.log(data)

                if (data.success) {
                    eventBtn.textContent = data.success
                    eventBtn.style.backgroundColor = 'Green'
                    checkIfprofileFunction()
                }
            })
            .catch(err => {
                console.log(err)
            })
    })

    // Updat profile bio
    document.getElementById('updateBio').addEventListener('click', e => {
        let eventBtn = e.target
        let bio = document.getElementById('bio')
        if (bio.value == '') return

        fetch('/update_bio_api', {
            method: 'POST',
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                bio: bio.value
            })
        })
            .then(res => res.json())
            .then(data => {
                console.log(data)

                if (data.success) {
                    eventBtn.textContent = data.success
                    eventBtn.style.backgroundColor = 'Green'
                    checkIfprofileFunction()
                }
            })
            .catch(err => {
                console.log(err)
            })
    })

    //Saving interests
    document.getElementById('saveinterest').addEventListener('click', e => {
        // let newArr = [new Set(hobiesArr)]
        let arrOftexts = []
        hobbiesBtn.forEach(cur => {
            if (cur.classList == '') {
                arrOftexts.push(cur.textContent)
            }
        })

        // This is the array of selected items
        console.log(arrOftexts)

        let eventBtn = e.target
        if (arrOftexts.length < 1) return

        fetch('/update_user_interests', {
            method: 'POST',
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                interests: arrOftexts.toString()
            })
        })
            .then(res => res.json())
            .then(data => {
                console.log(data)

                if (data.success) {
                    eventBtn.textContent = data.success
                    eventBtn.style.backgroundColor = 'Green'
                    checkIfprofileFunction()
                }
            })
            .catch(err => {
                console.log(err)
            })


    })