const socket = io()
const Peer = require('simple-peer')
const wrtc = require('wrtc')
let peerType = document.getElementById('peerType').textContent

navigator.mediaDevices.getUserMedia({
    video: {
        facingMode: 'user'
    },
    audio: true
})

    .then(stream => {
        let myFaceCam = document.getElementById('myFaceCam')
        myFaceCam.srcObject = stream
        myFaceCam.play()
        myFaceCam.style.height = '300px'

        var peer = new Peer({
            initiator: true,
            trickle: false,
            stream: stream,
            wrtc: wrtc
        })




        // Start video chat calling
        peer.on('signal', async (data) => {
            console.log('Welcome signal')
            console.log(data)
            document.getElementById('myPeerId').value = JSON.stringify(data) //pusting my peer id in a text area
            
            if (peerType === 'init') {
                let videoCaller = document.getElementById('videoCaller').textContent
                let videoReceiverId = document.getElementById('videoReceiver').textContent

                // send id to get receiver for video call
                socket.emit('fetchVideoCallReceiver', {
                    videoReceiverId,
                    videoCaller,

                })

                socket.on('readyToPeer', id => {
                    // sending my peer id to receiver
                    if (id === videoCaller) {
                        console.log('Receiver is ready')
                        socket.emit('sendMyPeerIdToReceiver', {
                            peerId: data,
                            videoCaller,
                            videoReceiverId
                        })
                    }
                })

            }
        })


        socket.on('sendPeeridToReceiverTextArea', data => {
            if (peerType === 'not init') {
                let receiverId = document.getElementById('myId').textContent
                console.log('waiting for not init')
                console.log(data)
                if (data.videoReceiverId === receiverId) {
                    document.getElementById('otherPeerId').value = JSON.stringify(data.peerId)
                }

            }
        })

        // adding caller peer id to my textarea
        socket.on('gettingPerrIdFromInit', data => {
            console.log(data)
            if (peerType === 'not init') {
                let receiverId = document.getElementById('myId').textContent
                if (receiverId === data.videoReceiverId) {
                    // adding offer id to receiver other id
                    document.getElementById('otherPeerId').value = JSON.stringify(data.peerId)
                    console.log('Adding caler peer to receiver other id')
                    
                    //receiver picking the call
                    document.querySelector('#pick_btn').addEventListener('click', e => {

                        // offer accepted 
                        var otherId = JSON.parse(document.getElementById('otherPeerId').value)
                        peer.signal(otherId)

                        // opening the video
                        document.querySelector('.video_call_progress_container').style.display = 'block'


                        setTimeout(() => {
                            // sending signal to claller and open his caller id
                            let myAnswerId = JSON.parse(document.getElementById('myPeerId').value)
                            console.log(myAnswerId)
                            socket.emit('signalThatUserAnswered', {
                                videoCaller: data.videoCaller,
                                receiverId: data.receiverId,
                                myAnswerId
                            })

                        }, 1000);

                        socket.emit('receiverAccepted', callerId) //send signal for caller to peer too
                    })


                }
            }
        })


        socket.on('openCallerVideo', data => {
            if (peerType === 'init') {
                let videoCaller = document.getElementById('videoCaller').textContent
                if (videoCaller === data.videoCaller) {
                    console.log(data)

                    document.getElementById('otherPeerId').value = JSON.stringify(data.myAnswerId)
                    var otherId = JSON.parse(document.getElementById('otherPeerId').value)
                    peer.signal(otherId)
                }

            }

            if (peerType === 'not init') {
                let receiverId = document.getElementById('myId').textContent
                if (data.videoReceiverId == receiverId) {
                    // open video call 
                    document.querySelector('.video_call_progress_container').style.display = 'block'
                }
            }
            if (peerType === 'init') {
                let videoCaller = document.getElementById('videoCaller').textContent
                if (videoCaller === data.videoCaller) {
                    // open video call 
                    document.querySelector('.video_call_progress_container').style.display = 'block'
                }
            }

        })

        peer.on('stream', function (stream) {
            console.log("stream", stream)
            var video = document.getElementById('streamWebCam')
            video.srcObject = stream
            video.play()
            video.style.width = '100%'
            video.style.height = '100%'
        })





    })

    .catch(error => {
        console.log('Error:', error)
    })
