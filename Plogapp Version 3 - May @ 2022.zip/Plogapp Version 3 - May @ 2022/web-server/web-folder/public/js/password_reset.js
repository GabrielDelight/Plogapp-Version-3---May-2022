(function () {
    emailjs.init("user_u6oEvmbiDQ8MGU688vgZV");
})();


let code1 = Math.floor(Math.random() * 10) 
let code2 = Math.floor(Math.random() * 10) 
let code3 = Math.floor(Math.random() * 10) 
let code4 = Math.floor(Math.random() * 10) 
let code5 = Math.floor(Math.random() * 10) 
let code6 = Math.floor(Math.random() * 10) 

let code = [code1, code2, code3, code4, code5, code6]
code = code.map(el => el.toString())
code = code.toString().replace(/,/g, '')

let userId = document.getElementById('userId')
fetch('/user_with_auth/' + userId.textContent)
    .then(res => res.json())
    .then(data => {
        document.getElementById('btn').style.display = 'block'
        document.getElementById('btn').addEventListener('click', e => {

            var templateParams = {
                from_name: "plogapp",
                to_name: data.firstname,
                message: "This is your confirmation code: " + code,
                receiver_email: data.email,
                reset_code: code,
                reply_to: "",
                subject: code + ' is your Plogapp account recovery code',
                message_body: 'We received a request to reset your Plogapp password. Enter the following password reset code:',
                message_footer: `This message was sent to ${data.email} for a requst of a new password.`
            };

            emailjs.send("service_rr6s8ac", "template_v483zkd", templateParams)
                .then(function (response) {
                    console.log('SUCCESS!', response.status, response.text);

                    fetch('/update_reset_code', {
                        method: 'POST',
                        headers: {
                            'Accept': 'application/json, text/plain, */*',
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            code: code,
                            owner: data._id,
                        })
                    })
                        .then(res => res.json())
                        .then(result => {
                            console.log(result)
                            location.href = '/forgotPassword/' + data._id
                        })

                        .catch(error => {
                            console.log(error, 'Error')
                        })
                }, function (error) {
                    console.log('FAILED...', error);
                });

        })
    })
    .catch(error => {
        console.log(error)
    })
