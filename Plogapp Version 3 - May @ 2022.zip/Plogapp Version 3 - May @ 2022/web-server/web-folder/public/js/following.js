// Remove main User
const socket = io()
let mainId = document.getElementById('mainId').textContent
let followingOwner = document.getElementById('followingOwner').textContent

let users = document.querySelectorAll('.user_details_des');
let appendFollowing = document.getElementById('appendFollowing')
let increateFollowing = 10

let hideMe = document.querySelectorAll('.user_details_des');
for (i = 0; i < hideMe.length; i++) {
    if (hideMe[i].children[2].textContent.includes(mainId)) {
        hideMe[i].children[2].parentElement.parentElement.parentElement.style.display = 'none'
    }
}

// Check  weither user is following me ot vice versa
let checkFollowing = document.querySelectorAll('.follow_div_Btn');
for (i = 0; i < checkFollowing.length; i++) {
    if (checkFollowing[i].textContent.includes(mainId)) {
        checkFollowing[i].parentElement.children[0].children[1].children[2].textContent = 'Followed you'
    }else {
        checkFollowing[i].parentElement.children[0].children[1].children[2].textContent = 'Following'
    }
}

// Show follow or Umfollow ing button
let myFollowrs = document.getElementById('myFollowers').textContent
let followOrUnfollow = document.querySelectorAll('.follow_div_Btn');
for (i = 0; i < followOrUnfollow.length; i++) {
    let id = followOrUnfollow[i].children[2].textContent
    if (myFollowrs.includes(id)) {
        followOrUnfollow[i].children[0].textContent = 'Following'
        followOrUnfollow[i].children[0].style.backgroundColor = 'white'
        followOrUnfollow[i].children[0].style.border = '3px solid cornflowerblue'
        followOrUnfollow[i].children[0].style.color = 'cornflowerblue'
        followOrUnfollow[i].children[0].style.borderColor = 'cornflowerblue'
        // followOrUnfollow[i].children[0].style.padding = '7px 18px'
        // followOrUnfollow[i].parentElement.children[0].children[1].children[1].textContent = 'Following'
        followOrUnfollow[i].children[0].textContent = 'Following'
    } else {
        followOrUnfollow[i].children[0].textContent = 'Follow'
        followOrUnfollow[i].children[0].style.backgroundColor = 'cornflowerblue'
        // followOrUnfollow[i].children[0].style.border = '1px solid gray'
        followOrUnfollow[i].children[0].style.padding = '7px 18px'
        followOrUnfollow[i].children[0].style.color = 'white'
    }
}

// Saving following and followers in database
let btnClick = document.querySelectorAll('#followingBtn');

for (i = 0; i < btnClick.length; i++) {
    btnClick[i].addEventListener('click', (e) => {
        // let followingId = e.target.parentElement.children[2].textContent
        let followingId = e.target.parentElement.children[4].textContent

        // show loading button
        let loader = e.target.parentElement.children[3]
        let button = e.target
        button.style.display = 'none'
        loader.style.display = 'block'
        setTimeout(() => {
            loader.style.display = 'none'
            button.style.display = 'block'
            return
        }, 1000);

        

        fetch('/follow-unfollow', {
            method: 'POST',
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                followingId,
            })
        })
            .then(res => {
                return res.json()
            })

            .then(data => {
                console.log(data)
            })
            .catch(error => {
                console.log(error)
            })

        // console.log(followingDetails)
        // socket.emit('followingDetails', followingDetails)

        // Change buttonm performance or modify button
        if (e.target.textContent == 'Follow') {
            e.target.style.backgroundColor = 'white'
            e.target.style.color = 'cornflowerblue'
            e.target.style.border = '3px solid cornflowerblue'
            e.target.textContent = 'Following'
            e.target.style.padding = '7px'
        } else {
            e.target.style.backgroundColor = 'cornflowerblue'
            e.target.style.padding = '7px 18px'
            e.target.style.color = 'white'
            e.target.textContent = 'Follow'
        }

    })
}

// triming the over flowting   text
if (window.matchMedia("(max-width: 600px)").matches) {
    let trimBio = document.querySelectorAll('#userBio')
    let nickName = document.querySelectorAll('#nickName')
    trimMultiple(trimBio, 10)
    trimMultiple(nickName, 6)
    function trimMultiple(trim, num){
        for (i = 0; i < trim.length; i++) {
            let str = trim[i].textContent
            if(str.length > num){
                str = str.substr(0, num)
                trim[i].textContent = str + '...'
            }
        }

    }
}


socket.emit('sendUserIdToGetFollowing', followingOwner)


// fetch('/following-api')
//.then(result => result.json())
// // axios.get('/allusers-api')
//.then(res => {

    // socket.on('following-socket', (res) => {
    //     function showMoreFollowingFunction(val) {
            // let data = res
            // let data = res.data.splice(0, val)
            // let data = res.splice(0, val)
            // data.forEach(cur => {
            //     appendFollowing.innerHTML += `
                    //   <div class="wrapper_for_all">
                    //     <div class="wrap_user_div">
                    //         <div class="user_img">
                    //             <a href="/profile/${cur._id}">
                    //                 <img src="/userPostAvatar/${cur._id}" alt="">
                    //             </a>
                    //         </div>
                    //         <div class="user_details_des">
                    //             <a href="/profile/${cur._id}">
                    //                 <p>${cur.firstname} ${cur.lastname} <span><i class="${cur.verified}"></i></span> </p>
                    //             </a>
                    //             <p id="followTxt">Follow</p>
                    //             <p style="display: none;">${cur._id}</p>                                
                    //         </div>
                    //     </div>
                    //     <div class="follow_div_Btn">                            
                    //         <button id="followingBtn">Follow</button>                                                       
                    //         <p style="display: none;">${cur.following}</p>
                    //         <p style="display: none;">${cur._id}</p>
                    //         <div class="loader"></div>
                    //     </div>
                    // </div>`

    //         })

    //         if(data.length === 0 || data.length < 12 ){
    //             document.querySelector('.loading_data').style.display = 'none'
    //         }

    //     }

    //     showMoreFollowingFunction(12)

    //     window.onscroll = function () {
    //         if ((window.innerHeight + window.pageYOffset) >= document.body.offsetHeight) {
    //             showMoreFollowingFunction(increateFollowing++)
    //         }
    //     }

    // })

    // .catch(err => {
    //     console.log(err, 'Error')
    // })


    // Remove main User
// const socket = io()
// let mainId = document.getElementById('mainId').textContent
// let followingOwner = document.getElementById('followingOwner').textContent

// let users = document.querySelectorAll('.user_details_des');
// let appendFollowing = document.getElementById('appendFollowing')
// let increateFollowing = 10

// socket.emit('sendUserIdToGetFollowing', followingOwner)


// // fetch('/following-api')
// //.then(result => result.json())
// // // axios.get('/allusers-api')
// //.then(res => {

//     socket.on('following-socket', (res) => {
//         function showMoreFollowingFunction(val) {
//             // let data = res
//             // let data = res.data.splice(0, val)
//             let data = res.splice(0, val)
//             data.forEach(cur => {
//                 appendFollowing.innerHTML += `
//                       <div class="wrapper_for_all">
//                         <div class="wrap_user_div">
//                             <div class="user_img">
//                                 <a href="/profile/${cur._id}">
//                                     <img src="/userPostAvatar/${cur._id}" alt="">
//                                 </a>
//                             </div>
//                             <div class="user_details_des">
//                                 <a href="/profile/${cur._id}">
//                                     <p>${cur.firstname} ${cur.lastname} <span><i class="${cur.verified}"></i></span> </p>
//                                 </a>
//                                 <p id="followTxt">Follow</p>
//                                 <p style="display: none;">${cur._id}</p>                                
//                             </div>
//                         </div>
//                         <div class="follow_div_Btn">                            
//                             <button id="followingBtn">Follow</button>                                                       
//                             <p style="display: none;">${cur.following}</p>
//                             <p style="display: none;">${cur._id}</p>
//                             <div class="loader"></div>
//                         </div>
//                     </div>`

//                 let hideMe = document.querySelectorAll('.user_details_des');
//                 for (i = 0; i < hideMe.length; i++) {
//                     if (hideMe[i].children[2].textContent.includes(mainId)) {
//                         hideMe[i].children[2].parentElement.parentElement.parentElement.style.display = 'none'
//                     }
//                 }

//                 // Check  weither user is following me ot vice versa
//                 let checkFollowing = document.querySelectorAll('.follow_div_Btn');
//                 for (i = 0; i < checkFollowing.length; i++) {
//                     if (checkFollowing[i].textContent.includes(mainId)) {
//                         checkFollowing[i].parentElement.children[0].children[1].children[1].textContent = 'Following you'
//                     }
//                 }

//                 // Show follow or Umfollow ing button
//                 let myFollowrs = document.getElementById('myFollowers').textContent
//                 let followOrUnfollow = document.querySelectorAll('.follow_div_Btn');
//                 for (i = 0; i < followOrUnfollow.length; i++) {
//                     let id = followOrUnfollow[i].children[2].textContent

//                     if (myFollowrs.includes(id)) {
//                         followOrUnfollow[i].children[0].textContent = 'Following'
//                         followOrUnfollow[i].children[0].style.backgroundColor = 'white'
//                         followOrUnfollow[i].children[0].style.border = '1px solid cornflowerblue'
//                         followOrUnfollow[i].children[0].style.color = 'cornflowerblue'
//                         followOrUnfollow[i].children[0].style.borderColor = 'cornflowerblue'
//                         // followOrUnfollow[i].children[0].style.padding = '7px 18px'
//                         followOrUnfollow[i].parentElement.children[0].children[1].children[1].textContent = 'Following'
//                         followOrUnfollow[i].children[0].textContent = 'Following'
//                     } else {
//                         followOrUnfollow[i].children[0].textContent = 'Follow'
//                         followOrUnfollow[i].children[0].style.backgroundColor = 'cornflowerblue'
//                         // followOrUnfollow[i].children[0].style.border = '1px solid gray'
//                         followOrUnfollow[i].children[0].style.padding = '7px 18px'
//                         followOrUnfollow[i].children[0].style.color = 'white'
//                     }
//                 }

//                 // Saving following and followers in database
//                 let btnClick = document.querySelectorAll('#followingBtn');

//                 for (i = 0; i < btnClick.length; i++) {
//                     btnClick[i].addEventListener('click', (e) => {
//                         let followingId = e.target.parentElement.children[2].textContent

//                         // show loading button
//                         let loader = e.target.parentElement.children[3]
//                         let button = e.target
//                         button.style.display = 'none'
//                         loader.style.display = 'block'
//                         setTimeout(() => {
//                             loader.style.display = 'none'
//                             button.style.display = 'block'
//                             return
//                         }, 1000);

//                         let followingDetails = {
//                             followingId,
//                             userId: mainId
//                         }
//                         socket.emit('followingDetails', followingDetails)

//                         // Change buttonm performance or modify button
//                         if (e.target.textContent == 'Follow') {
//                             e.target.style.backgroundColor = 'white'
//                             e.target.style.color = 'black'
//                             e.target.style.border = '1px solid gray'
//                             e.target.textContent = 'Following'
//                             e.target.style.padding = '7px'
//                             e.target.parentElement.parentElement.children[0].children[1].children[1].textContent = 'Following'
//                         } else {
//                             e.target.style.backgroundColor = 'cornflowerblue'
//                             e.target.style.padding = '7px 18px'
//                             e.target.style.color = 'white'
//                             e.target.textContent = 'Follow'
//                             e.target.parentElement.parentElement.children[0].children[1].children[1].textContent = 'Follow'
//                         }

//                     })
//                 }

//             })

//             if(data.length === 0 || data.length < 12 ){
//                 document.querySelector('.loading_data').style.display = 'none'
//             }

//         }

//         showMoreFollowingFunction(12)

//         window.onscroll = function () {
//             if ((window.innerHeight + window.pageYOffset) >= document.body.offsetHeight) {
//                 showMoreFollowingFunction(increateFollowing++)
//             }
//         }

//     })

    // .catch(err => {
    //     console.log(err, 'Error')
    // })
