{
    // Validation for fields
    let input = document.getElementById('input');
    let description = document.getElementById('description');
    let amount = document.getElementById('amount');;
    let errorMessage = document.getElementById('errorMessage');;


    document.querySelector('button').addEventListener('click', (e) => {
        if (title.value.trim() === '') {
            e.preventDefault()
            errorMessage.textContent = 'Title must be provided'
        }
        else if (description.value.trim() === '') {
            e.preventDefault()
            errorMessage.textContent = 'Description must be provided'
        }
        else if (amount.value.trim() === '') {
            e.preventDefault()
            errorMessage.textContent = 'Amount must be provided'
        }

    })


    // close and open model
    let model = document.querySelector('.hide_and_show');
    let x = document.querySelector('#close');
    x.addEventListener('click', (e) => {
        model.style.display = 'none'
    })

    document.querySelector('.add_income').addEventListener('click', () => {
        model.style.display = 'block'
    })

}




{
    // Calculating the budget
    let income = document.querySelectorAll('#income');
    let expenses = document.querySelectorAll('#expenses');
    const incomeArray = [0];
    const expensesArray = [0];

    function calcBudget(num, arr) {
        try {
            num.forEach(cur => {
                arr.push(parseInt(cur.textContent))
            })
            return arr.reduce((cur, value) => {
                return cur += value
            })
        } catch (error) {
            console.log('Error')
        }

    }
    let percent = 0
    let totalIncome = calcBudget(income, incomeArray)
    let totalExpenses = calcBudget(expenses, expensesArray)
    let totalBudget = totalIncome - totalExpenses; //Total budget
    percent = Math.round((totalExpenses / totalIncome) * 100)

    


    document.getElementById('totalBudget').textContent = totalBudget.toLocaleString()
    document.getElementById('totalIncome').textContent = totalIncome.toLocaleString()
    document.getElementById('totalExpenses').textContent = totalExpenses.toLocaleString()
    document.getElementById('percentage').textContent = percent + '%'
    // console.log(percent)

}





// Chart creatring ***************************
let income = document.querySelectorAll('#income');
let expenses = document.querySelectorAll('#expenses');
let incomeArray = [];
income.forEach((cur) => {
    incomeArray.push(parseInt(cur.textContent))
})

let index = []
for(i = 0; i < incomeArray.length;i++){
    index.push(i)
}


{
    let x = document.getElementById('canvas')
    x.style.width = '100%'
    x.style.height = '100%'
    let chart = document.getElementById('canvas').getContext('2d');
    Chart.defaults.global.defaultFontColor = 'black';
    Chart.defaults.defaultFontSize = 20
    Chart.defaults.defaultFontWeight = 'bold'
    let chartOne = new Chart(chart, {
        type: 'bar',
        data: {
            labels: index,
            datasets: [{
                label: 'Your incomes',
                data: incomeArray,
                backgroundColor: '#58b2e8',
                borderWidth: 1,
                hoverBackgroundColor: 'gray'
            }]
        },
        options: {
            title: {
                display: false,
                text: 'Population by users',
                fontSize: 49
            }
    
        }
    })
        
}


// Second chart
{
    let x = document.getElementById('secondCanvas')
    x.style.width = '100%'
    x.style.height = '100%'
    let canvas2 = document.getElementById('secondCanvas').getContext('2d')
    Chart.defaults.defaultFontColor = 'black'
    let startCanvas = new Chart(canvas2, {
        type: 'pie',
        data: {
            labels: index,
            datasets: [{
                label: 'Budget',
                data: incomeArray,
                backgroundColor: 'pink',
                borderWidth: 3,
                hoverBorderColor: 'gold'
            }]
        },
        options: {
            title:{
                display: true,
                text: 'Budget',
                labels:{
                    fontColor: 'Gold'
                }
            },
            labels: {
                display: false
            }

        }
        
    })

}




