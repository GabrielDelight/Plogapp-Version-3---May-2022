const socket = io()
const userId = document.getElementById('myId').textContent
const recipientID = document.getElementById('recipientID').textContent

console.log('welcome incoming')


socket.on('openClientReceiverIncomingCall', data => {
    console.log(data)
    if (data.recipientID === userId) {
        // document.getElementById('firstIncomingAvatar').src = '/userPostAvatar/' + data.userId
        // document.getElementById('videoCallerName').textContent = data.callerName
        // document.querySelector('.main_incoming_modal').style.display = 'block'
    }
})