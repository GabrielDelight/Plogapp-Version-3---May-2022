(function () {
    emailjs.init("user_u6oEvmbiDQ8MGU688vgZV");
})();


let input1 = document.getElementById('input1')
let input2 = document.getElementById('input2')
let input3 = document.getElementById('input3')
let input4 = document.getElementById('input4')


input1.addEventListener('input', e => {
    input2.focus()
})

input2.addEventListener('input', e => {
    input3.focus()
})

input3.addEventListener('input', e => {
    input4.focus()
})

input4.addEventListener('input', e => {
    e.target.style.borderBottomColor = 'cornflowerblue'
})


let code1 = Math.floor(Math.random() * 10)
let code2 = Math.floor(Math.random() * 10)
let code3 = Math.floor(Math.random() * 10)
let code4 = Math.floor(Math.random() * 10)
let code = [code1, code2, code3, code4]
code = code.map(el => el.toString())
code = code.toString().replace(/,/g, '')

countdownFucntion()
function countdownFucntion() {
    let countdown = 59
    document.getElementById('countDown').style.display = 'block'
    document.getElementById('resendCode').style.display = 'none'
    let intervalId = setInterval(() => {
        countdown -= 1
        document.getElementById('counter').textContent = 0 + ":" + countdown
        if (countdown <= 0) {
            clearInterval(intervalId)
            document.getElementById('countDown').style.display = 'none'
            document.getElementById('resendCode').style.display = 'block'
            countdown = 59

        }
    }, 1000);
}


function sendEmailFunction(data) {
    var templateParams = {
        from_name: "plogapp",
        to_name: data.firstname,
        message: "This is your confirmation code: " + code,
        receiver_email: data.email,
        reset_code: code,
        reply_to: "",
        subject: code + ' is your Plogapp account recovery code',
        message_body: 'We received a request to reset your Plogapp password. Enter the following password reset code:',
        message_footer: `This message was sent to ${data.email} for a requst of a new password.`
    };

    emailjs.send("service_rr6s8ac", "template_v483zkd", templateParams)
        .then(function (response) {
            console.log('SUCCESS!', response.status, response.text);

            fetch('/update_reset_code', {
                method: 'POST',
                headers: {
                    'Accept': 'application/json, text/plain, */*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    code: code,
                    owner: data._id,
                })
            })
                .then(res => res.json())
                .then(result => {
                    // console.log(result)

                })

                .catch(error => {
                    console.log(error, 'Error')
                })
        }, function (error) {
            console.log('FAILED...', error);
        });

}




//send email
let userId = document.getElementById('userId')
fetch('/user_with_auth/' + userId.textContent)
    .then(res => res.json())
    .then(data => {
        // console.log(data)
        document.getElementById('requestCode').addEventListener('click', e => {

            e.target.style.display = 'none'
            document.querySelector('#hidex').style.display = 'block'
            document.querySelector('#showTxt').style.display = 'block'
            document.querySelector('#hideTxt').style.display = 'none'

            sendEmailFunction(data)

            document.getElementById('resendCode').addEventListener('click', e => {
                sendEmailFunction(data)
                countdownFucntion()
            })



            document.getElementById('cornfirmBtn').addEventListener('click', e => {
                e.preventDefault()
                fetch('/confirmemail/' + data._id, {
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json, text/plain, */*',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        code: parseInt(`${input1.value}${input2.value}${input3.value}${input4.value}`),
                        owner: data._id,
                    })
                })
                    .then(res => res.json())
                    .then(result => {
                        console.log(result)
                        if (result.notMatch && result.notMatch == 'Failed') {
                            document.querySelector('._not_result').style.display = 'block'
                            return
                        }

                        if (result.success) {
                            location.href = '/nickname'
                        }
                    })

                    .catch(error => {
                        console.log(error, 'Error')
                    })
            })

        })
    })
    .catch(error => {
        console.log(error)
    })



