// share post section
// Shareing section
var shareBtn = document.querySelectorAll('#shareBtn')
function toogleShareDiv() {
    document.querySelector('.share_model').classList.toggle('toggle_share')
}

document.querySelector('.close_share_div').addEventListener('click', e => {
    // toogleShareDiv()
    document.querySelector('.share_model').classList.remove('toggle_share')
})

// close model
// document.addEventListener('click', (e) => {
//     if (e.target.className == 'share_model toggle_share') {
//         // document.querySelector('.share_model').style.display = 'none'
//         toogleShareDiv()
//     }
// })


for (i = 0; i < shareBtn.length; i++) {
    shareBtn[i].addEventListener('click', (e) => {
        if (e.target.className === 'fa fa-refresh') {
            // document.querySelector('.share_model').style.display = 'block'
            toogleShareDiv()
            //==================
            var id = e.target.parentElement.children[1].textContent
            document.getElementById('postIdLink').value = id


            var postLink = e.target.parentElement.children[2].href
            document.getElementById('copyPostLink').addEventListener('click', e => {
                // Get the link
                var input = document.getElementById('copylinkInput')
                input.style.display = 'block'
                input.value = postLink
                input.select()
                document.execCommand('copy')
                input.style.display = 'none'

                // toggle success message
                document.querySelector('.success_copied_link').style.display = 'block'
                setTimeout(() => {
                    document.querySelector('.success_copied_link').style.display = 'none'
                }, 2000)
            })


            // share post to story
            var postType = e.target.parentElement.children[3].textContent
            if(postType !=  'image'){
                document.getElementById('sharePostToStory').style.opacity = .1    
                document.getElementById('sharePostToStory').style.cursor =  'not-allowed'
            }else{
                document.getElementById('sharePostToStory').style.opacity = 1    
                document.getElementById('sharePostToStory').style.cursor =  'pointer'
            }
            document.getElementById('sharePostToStory').addEventListener('click', e => {
                if(postType == 'image'){
                    console.log('post is an Image')
                    document.getElementById('postToStoryInput').value = id;
                    document.getElementById('manualShareClickPost').click();
                    return                    
                }

                e.target.style.backgroundColor = 'gray'
            })
        }
    })

}
