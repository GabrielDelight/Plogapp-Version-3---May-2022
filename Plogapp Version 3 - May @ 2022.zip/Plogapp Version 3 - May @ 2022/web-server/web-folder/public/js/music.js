const socket = io();

// Show user is active or not
let userId = document.getElementById('userId').textContent;
socket.emit('sendUserDetails', userId)    
socket.emit('idForDisconnection', userId)    

let btn = document.querySelectorAll('#likebtn')

// auto change color to gray
for (i = 0; i < btn.length; i++) {
    btn[i].style.color = 'gray'
}


// Auto Reaction  color
for (i = 0; i < btn.length; i++) {
    let userId = btn[i].parentElement.children[2].textContent
    let ids = btn[i].parentElement.children[4].textContent
    let icon = btn[i].parentElement.children[0]

    if (ids.includes(userId)) {
        icon.style.color = '#4666ff'

    }
}

// Send reaction

btn.forEach(cur => {
    cur.addEventListener('click', (e) => {
        let icon = e.target.parentElement.children[0]
        let num = e.target.parentElement.children[1]
        let userId = e.target.parentElement.children[2].textContent
        let musicId = e.target.parentElement.children[3].textContent
        let newNum = parseInt(num.textContent);
        let likeDetails = {
            userId,
            musicId
        }

        socket.emit('likeDetails', likeDetails);

        // Change color;
        if (icon.style.color == 'gray') {
            icon.style.color = '#4666ff'
            num.textContent = newNum += 1
        } else {
            icon.style.color = 'gray'
            num.textContent = newNum -= 1
        }

    })
})



// Download btn sending to db for count
let downloadBtn = document.querySelectorAll('#downloadBtn');
for (i = 0; i < downloadBtn.length; i++) {
    downloadBtn[i].addEventListener('click', (e) => {
        let userId = e.target.parentElement.children[0].textContent;
        let musicId = e.target.parentElement.children[1].textContent;;
        socket.emit('downloadCount', {
            userId,
            musicId
        })
        let num = e.target.parentElement.nextElementSibling
        let newNum = parseInt(num.textContent);
        numNum = newNum += 1;
        num.textContent = newNum
        console.log(num.textContent)
    })
}


// Play all songs
let globalPlayBtn = document.querySelectorAll('.play_icn');
let myMusic = document.getElementById('myMusic')
let musicTitle = document.querySelector('.musicTitle')
let musicDescription = document.querySelector('.musicDescription')
let musicSeeker = document.querySelector('.slider')
let musicControl = document.getElementById('playBtn');
let image = document.getElementById('musicImg')
globalPlayBtn.forEach(cur => {
    cur.addEventListener('click', (e) => {
        let audio = e.target.children[0].textContent

        let img = e.target.children[1].src
        
        let title = e.target.children[2].textContent
        let description = e.target.children[3].textContent

        musicTitle.textContent = title;
        musicDescription.textContent = description;
        image.src = img
        image.style.width = '35px'
        image.style.height = '35px'
        myMusic.src = audio;

        myMusic.load()
        myMusic.play()

        // ****
        // let count = 0
        // let idInt = setInterval(() => {
        //     count += 1
        //     musicSeeker.value = count;
        //     if (musicSeeker.value >= Math.round(myMusic.duration - 1)) {
        //         clearInterval(idInt);
        //         musicSeeker.value = 0;
        //         myMusic.play()
        //     }
        // },10)

        controlAudio()
        function controlAudio() {
            // Contrl seeker
            document.addEventListener('input', () => {
                myMusic.currentTime = musicSeeker.value
            })

            setInterval(() => {
                musicSeeker.max = myMusic.duration;
                musicSeeker.value = myMusic.currentTime
            }, 100)


            musicControl.addEventListener('click', (e) => {
                if (myMusic.paused) {
                    e.target.className = 'fa fa-pause';
                    myMusic.play()
                } else {
                    myMusic.pause()
                    e.target.className = 'fa fa-play-circle';
                }
            })
        }

    })
})


// next btn 
document.getElementById('next').addEventListener('click', ()=> {
    myMusic.currentTime = 10  
})