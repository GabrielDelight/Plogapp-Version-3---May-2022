(function () {
    const socket = io();
    let userId2 = document.getElementById('userId').textContent
    // Scrolling left and right
    let  scrollLeftIcon = document.querySelector('#scrollLeftIcon')
    let scrollRightIcon = document.querySelector('#scrollRightIcon')
    
    scrollLeftIcon.addEventListener("click",e => {
        document.querySelector('.people_you_may_know_container').scrollLeft -= 150
    })
    scrollRightIcon.addEventListener("click",e => {
        document.querySelector('.people_you_may_know_container').scrollLeft += 150
    })


    //Loop through people yopu maty follow
    let appendPeopleYouMayKnow = document.querySelector('.people_you_may_know_container')
    fetch('/suggested-to-follow-api')
        .then(res => res.json())
        .then(result => {
            if (result.length < 1) {
                appendPeopleYouMayKnow.parentElement.style.display = 'none'
            }
            let data = [...new Set(result)]



            data.map(cur => {
                appendPeopleYouMayKnow.innerHTML +=
                    `
                        <div class="people_you_may_know_wrappper dark_div">
                            <div class="close_div">
                                <i onclick="this.parentElement.parentElement.style.display  ='none'" class="fa fa-close"></i>
                            </div>

                            <a href="/profile/${cur._id}">
                                <div class="img_sugg_ppl">
                                    <img src="https://plogapp.s3.amazonaws.com/${cur.avatar}" alt="">
                                </div>
                            </a>

                            <a href="/profile/${cur._id}">
                                <div class="follow_sugg_txt">
                                    <h3>${cur.firstname} ${cur.lastname} <span><i class="${cur.verified}"></i></span> </h3>
                                    <p>@${cur.fullName}</p>
                                </div>
                            </a>

                            <div class="follow_btn">
                                <div class="follow_button">
                                    <button id="subFollowBtnClick">Follow</button>
                                    <p style="display: none;">${cur._id}</p>
                                    <div class="loader"></div>
                                </div>
                            </div>
                        </div>`


                let btn = document.querySelectorAll('#subFollowBtnClick')
                for (i = 0; i < btn.length; i++) {
                    btn[i].addEventListener('click', (e) => {
                        let followingId = e.target.parentElement.children[1].textContent

                        // show loading button
                        let loader = e.target.parentElement.children[2]
                        let button = e.target
                        button.style.display = 'none'
                        loader.style.display = 'block'
                        setTimeout(() => {
                            loader.style.display = 'none'
                            button.style.display = 'block'
                            return
                        }, 1000);


                        fetch('/follow-unfollow', {
                            method: 'POST',
                            headers: {
                                'Accept': 'application/json, text/plain, */*',
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                followingId,
                            })
                        })
                            .then(res => {
                                return res.json()
                            })
                
                            .then(data => {
                                console.log(data)
                            })
                            .catch(error => {
                                console.log(error)
                            })
                

                        // socket.emit('followingDetails', followingDetails1)


                        // console.log(e.target.style.color)
                        if (e.target.textContent == 'Follow') {
                            e.target.style.backgroundColor = 'white'
                            e.target.style.color = 'cornflowerblue'
                            e.target.style.border = '3px solid cornflowerblue'
                            e.target.style.padding = '7px'
                            e.target.textContent = 'Following'

                        } else {
                            e.target.style.backgroundColor = 'cornflowerblue'
                            e.target.style.color = 'white'
                            e.target.style.padding = '7px 18px'
                            e.target.textContent = 'Follow'

                        }

                    })

                }

            })
        })
        .catch(error => {
            console.log(error)
        })
})()

