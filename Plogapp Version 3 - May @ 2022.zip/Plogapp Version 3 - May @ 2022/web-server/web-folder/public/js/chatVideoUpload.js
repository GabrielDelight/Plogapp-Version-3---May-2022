// (function () {
let postVideoCoverImage = {}
function globalVideoFunction(chatGlobalObject) {
    // function displayingVideo

    // @ Create video with javascript

    let appendVideo = document.querySelectorAll('#appendVideo')
    Array.from(appendVideo).forEach(videoAppender => {
        let video = document.createElement('video')
        let poster = videoAppender.getAttribute('image-poster')
        let src = videoAppender.getAttribute('video-src')
        video.setAttribute('controls', '')
        video.setAttribute('poster', poster)
        video.setAttribute('src', src)
        videoAppender.appendChild(video)
    })

}


// opening and c losing video section container
// toggle upload video
function toggleUploadvideo() {
    document.querySelector('.video_upload_container').classList.toggle('toggle_video_upload')
}

document.getElementById('upload_video_button').addEventListener('click', e => {
    e.preventDefault()
    document.getElementById('upload_video').click()
})

// Function close all opened divs in the video controller
function closeAllUpladsSubDivsFunction() {
    document.querySelector('.video_upload_container').style.display = 'none'
    document.querySelector('.picking_upload').style.display = 'block'
    document.querySelector('.hidePreview').style.display = 'none'
    document.querySelector('.upload_video_loader').style.display = 'none'
    document.getElementById('upload_video').value = ''
    document.querySelector('.final_upload_loader').style.display = 'none'
    document.querySelector('#finalUploadVideoButton').style.display = 'block'
}


// closing and opening video upload

document.querySelector('.close_video_upload_icn').addEventListener('click', e => {
    closeAllUpladsSubDivsFunction()
})


document.getElementById('upload_video').addEventListener('change', function () {
    if (this.files) {
        if (this.files[0].size > 44816215) {
            document.querySelector('.largeFileerror').style.display = 'block'
            return
        }
        // success in uploading
        let video = document.getElementById('videoUploadSrc')
        document.querySelector('.largeFileerror').style.display = 'none'
        document.querySelector('.picking_upload').style.display = 'none'
        document.querySelector('.upload_video_loader').style.display = 'block'




        // after 10s show the upload details
        setTimeout(() => {
            // hide the loader
            document.querySelector('.upload_video_loader').style.display = 'none'
            document.querySelector('.hidePreview').style.display = 'block'

            // preview the video
            video.src = URL.createObjectURL(this.files[0])
            document.getElementById('filename').textContent = this.files[0].name
            video.play()



            // Create a coever photo for the video

            var canvas = document.createElement('canvas');
            var ctx = canvas.getContext('2d');

            // set canvas size = video size when known
            video.addEventListener('loadedmetadata', function () {
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
            });

            video.addEventListener('play', function () {
                var $this = this; //cache
                (function loop() {
                    if (!$this.paused && !$this.ended) {
                        ctx.drawImage($this, 0, 0);

                        canvas.toBlob(function (blob) {
                            var newImage = new File([blob], 'story' + ".png");

                            postVideoCoverImage.file = newImage

                        }, 'image/jpeg', 0.4);

                        setTimeout(loop, 1000 / 30); // drawing at 30fps

                    }
                })();
            }, 0);


        }, 1200);

    }
})






let receiverIdx1 = location.href.substr(-24, location.href.length)


// Upload video container
document.querySelector('#selectVideo').addEventListener('click', (e) => {
    document.querySelector('.video_upload_container').style.display = 'block';
    // document.querySelector('.video_upload_wrapper').style.display = 'block';
    toggleUplaodFiles()
})

function toggleUplaodFiles() {
    document.querySelector('.global_files_container').classList.toggle('toggle_upload_modal')
}


document.addEventListener('click', (e) => {
    if (e.target.classList == 'video_upload_container') {
        document.querySelector('.video_upload_container').style.display = 'none'
    }
})






function toggleUploadvideo() {
    document.querySelector('.video_upload_container').classList.toggle('toggle_video_upload')
}




// append image
socket.on('showVideo', (data) => {
    if (data.receiverId === myId && data.owner === receiverIdx1) {

        let html = `<div class="friend_chat_box pushImgLeft" id="chat_container_box">
    <div class="friends_image2"></div>
    <div class="friend_chat_details">            
        <div class="chat_text_box blueColor">                
        <a href="">    
        <img id="downloadImg" src="/images/download.png" alt="">
        <p id="downloadPara">Download video</p>
            </a>
        </div>
    </div>
    </div>`

        appendChatMessages.insertAdjacentHTML('beforeend', html)
        scrollUpUsers()



    }
})




// Uploading a video
document.getElementById('finalUploadVideoButton').addEventListener('click', () => {
    let input = document.getElementById('upload_video')
    let message = document.getElementById('chatUploadVideoMessage')
    let data = new FormData()
    data.append('uploads', input.files[0])
    data.append('message', message.value)
    appendingImageUpload(input.files[0], message.value)
    document.querySelector('.video_upload_container').style.display = 'none'
    document.querySelector('.sending_status').style.display = 'block';

    fetch('/videoChatUpload/' + location.href.substr(-24, location.href.length), {
        method: 'POST',
        body: data
    })
        .then(res => res.json())
        .then(result => {


            document.querySelector('.sending_status').style.display = 'none';

            uploadvideoCoverPhoto(postVideoCoverImage.file, result)


            setInterval(() => {
                let ifSend = document.querySelectorAll('#sendingImagePara')
                ifSend[ifSend.length - 1].textContent = 'Sent'
            }, 1000);
        }).catch(err => {
            console.log(err)
        })
})


function uploadvideoCoverPhoto(file, chatObjids) {
    console.log(file)
    console.log(chatObjids)
    const data = new FormData()
    data.append('uploads', file)
    data.append('chatsenderId', chatObjids.randomChatId1)
    data.append('chatReceiverId', chatObjids.randomChatId2)





    fetch('/upload-chat-video-cover-photo', {
        method: 'POST',
        body: data
    })
        .then(res => res.json())
        .then(data => {
            console.log(data)
            closeAllUpladsSubDivsFunction()
        })
        .catch(error => {
            console.log(error)
        })
}



// Append chatimage
function appendingImageUpload(file, message, data) {
    let html = `
    <div class="pushImgRight" id="chat_container_box">
        <div class="friend_chat_details_new">
            <div class="chat_text_box blueColor_new">
                <div class="video_sned_div" id="appendingVideo">
                    <video controls id="vidPlayer" src="/webStorage/chatVideos/{{video}}"></video>
                    <div class="chat_video_control" style="display: none">
                        <i id="playVideo" class="fa fa-play"></i>
                        <i style="display: none;" class="fa fa-pause"></i>
                    </div>
                    <div class="chat_video_option">
                        <i style="visibility: hidden" id="deleVideo" class="fa fa-ellipsis-h"></i>
                        <p style="display: none;">{{_id}}</p>
                    </div>
                </div>

                <p id="">${message}</p>
                <p style="font-size: 10px;text-align: right; color: #bbb" id="sendingImagePara">Sending...</p>
                <p style="display: none"></p>
            </div>
        </div>
    </div>

`

    appendChatMessages.insertAdjacentHTML('beforeend', html)
    let vidPlayer = document.querySelectorAll('#vidPlayer')
    vidPlayer[vidPlayer.length - 1].src = URL.createObjectURL(file);
    scrollUpUsers()

    // playVideoFunction()

}






// Append video to the second user
// let recepientId = document.getElementById('recipientID')

let myIdx = document.getElementById('myId').textContent
socket.on('videoListen', data => {
    let receiverIdx = location.href.substr(-24, location.href.length)
    // append image
    if (data.receiverId === myIdx && data.owner === receiverIdx) {
        console.log('Hello')
        let html = `<div class="friend_chat_box pushImgLeft" id="chat_container_box">
        <div class="friends_image2"></div>
        <div class="friend_chat_details">            
            <div class="chat_text_box blueColor">                
                
            <div class="video_sned_div" id="appendingVideo">
            <video controls id="vidPlayer" src="/webStorage/chatVideos/${data.video}"></video>
            <div class="chat_video_control" style="display: none">
                <i id="playVideo" class="fa fa-play"></i>
                <i style="display: none;" class="fa fa-pause"></i>
            </div>
            <div class="chat_video_option">
                <i style="visibility: hidden" id="deleVideo" class="fa fa-ellipsis-h"></i>
                <p style="display: none;">{{_id}}</p>
            </div>
        </div>
        <p id="">${data.message}</p>
        <p style="font-size: 10px;text-align: left; color: #bbb">Now</p>
        </div>
        </div>`

        appendChatMessages.insertAdjacentHTML('beforeend', html)
        scrollUpUsers()
        // playVideoFunction()
    }

})