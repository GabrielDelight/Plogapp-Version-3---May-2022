let getCookie = document.getElementById('cookie')
localStorage.setItem('safewatchpro', getCookie.textContent)